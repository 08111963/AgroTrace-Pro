import { eq, desc, and, lt, gte, sql } from 'drizzle-orm';
import { db } from './db';
import { 
  recipes, batches, inventory, qrLabels, alerts, ingredientTracking, 
  users, passwordResetTokens, companyProfiles, sales,
  type Recipe, type Batch, type InventoryItem, type QRLabel, type Alert, 
  type IngredientTracking, type User, type CompanyProfile, type Sale,
  type InsertRecipe, type InsertBatch, type InsertInventoryItem, 
  type InsertQRLabel, type InsertAlert, type InsertIngredientTracking,
  type InsertUser, type InsertCompanyProfile, type InsertSale
} from '../shared/schema';

// Interfaccia per il sistema di storage
export interface IStorage {
  // Recipes
  getRecipes(): Promise<Recipe[]>;
  getRecipe(id: number): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: number, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined>;
  deleteRecipe(id: number): Promise<boolean>;

  // Batches
  getBatches(): Promise<Batch[]>;
  getBatch(id: number): Promise<Batch | undefined>;
  getBatchByCode(code: string): Promise<Batch | undefined>;
  createBatch(batch: InsertBatch): Promise<Batch>;
  updateBatch(id: number, batch: Partial<InsertBatch>): Promise<Batch | undefined>;
  deleteBatch(id: number): Promise<boolean>;
  generateBatchCode(): Promise<string>;

  // Inventory
  getInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  getInventoryItemByCode(code: string): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;

  // QR Labels
  getQRLabels(): Promise<QRLabel[]>;
  getQRLabel(id: number): Promise<QRLabel | undefined>;
  getQRLabelByBatchId(batchId: number): Promise<QRLabel | undefined>;
  createQRLabel(label: InsertQRLabel): Promise<QRLabel>;

  // Alerts
  getAlerts(): Promise<Alert[]>;
  getActiveAlerts(): Promise<Alert[]>;
  getAlert(id: number): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  resolveAlert(id: number): Promise<boolean>;
  
  // Automatic monitoring and alerts
  checkInventoryAlerts(): Promise<Alert[]>;
  createLowStockAlert(item: InventoryItem): Promise<Alert>;
  createExpiryAlert(item: InventoryItem): Promise<Alert>;
  monitorInventoryStatus(): Promise<{ alertsCreated: number; alertsResolved: number }>;
  
  // Batch to inventory conversion
  createFinishedProductFromBatch(batch: Batch): Promise<void>;

  // Dashboard stats
  getDashboardStats(): Promise<{
    totalRecipes: number;
    activeBatches: number;
    inventoryItems: number;
    activeAlerts: number;
    lowStockItems: number;
    totalInventoryValue: number;
  }>;

  // Traceability
  getTraceabilityByBatchCode(batchCode: string): Promise<{
    batch: Batch;
    recipe?: Recipe;
    qrLabel?: QRLabel;
  } | null>;

  // Ingredient Tracking
  getIngredientTracking(): Promise<IngredientTracking[]>;
  createIngredientTracking(tracking: InsertIngredientTracking): Promise<IngredientTracking>;
  getIngredientUsageByBatch(batchId: number): Promise<IngredientTracking[]>;
  getIngredientAvailability(ingredientName: string): Promise<{
    currentStock: number;
    minimumStock: number;
    status: 'ok' | 'low' | 'critical';
    daysRemaining?: number;
  }>;
  checkLowStockIngredients(): Promise<InventoryItem[]>;
  updateInventoryFromUsage(ingredientName: string, quantityUsed: number, unit: string): Promise<boolean>;
  updateInventoryFromRecipe(recipeId: number, quantityProduced: number): Promise<void>;
  updateInventoryCodeWithBatch(recipeId: number, batchCode: string): Promise<void>;

  // User authentication
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserById(id: number): Promise<User | undefined>;
  validateUserPassword(username: string, password: string): Promise<User | null>;
  validateUserPasswordByEmail(email: string, password: string): Promise<User | null>;
  updateUserPassword(userId: number, newPassword: string): Promise<boolean>;
  getAllUsers(): Promise<User[]>;

  // Password reset tokens
  createPasswordResetToken(userId: number): Promise<string>;
  validatePasswordResetToken(token: string): Promise<{ userId: number; valid: boolean }>;
  usePasswordResetToken(token: string): Promise<boolean>;

  // Company profiles
  getCompanyProfile(userId: number): Promise<CompanyProfile | undefined>;
  createCompanyProfile(profile: InsertCompanyProfile): Promise<CompanyProfile>;
  updateCompanyProfile(userId: number, profile: Partial<InsertCompanyProfile>): Promise<CompanyProfile | undefined>;

  // Sales
  getSales(): Promise<Sale[]>;
  getSale(id: number): Promise<Sale | undefined>;
  createSale(sale: InsertSale): Promise<Sale>;
  deleteSale(id: number): Promise<boolean>;
}

// Implementazione DatabaseStorage che usa PostgreSQL
export class DatabaseStorage implements IStorage {
  // Recipes
  async getRecipes(): Promise<Recipe[]> {
    return await db.select().from(recipes).orderBy(desc(recipes.createdAt));
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe || undefined;
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const [recipe] = await db
      .insert(recipes)
      .values(insertRecipe)
      .returning();
    return recipe;
  }

  async updateRecipe(id: number, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const [updated] = await db
      .update(recipes)
      .set({ ...recipe, updatedAt: new Date() })
      .where(eq(recipes.id, id))
      .returning();
    
    if (updated) {
      // Sincronizza automaticamente lotti e magazzino quando la ricetta viene aggiornata
      await this.syncRecipeToRelatedItems(updated, recipe);
    }
    
    return updated || undefined;
  }

  // Sincronizza ricetta aggiornata con lotti e magazzino collegati
  private async syncRecipeToRelatedItems(updatedRecipe: Recipe, changes: Partial<InsertRecipe>): Promise<void> {
    console.log(`🔄 Sincronizzazione ricetta ${updatedRecipe.name} con lotti e magazzino`);
    
    try {
      // Trova tutti i lotti collegati a questa ricetta
      const relatedBatches = await db
        .select()
        .from(batches)
        .where(eq(batches.recipeId, updatedRecipe.id));

      if (relatedBatches.length === 0) {
        console.log(`Nessun lotto collegato alla ricetta ${updatedRecipe.name}`);
        return;
      }

      console.log(`Trovati ${relatedBatches.length} lotti collegati alla ricetta`);

      for (const batch of relatedBatches) {
        // Aggiorna dati del lotto se necessario
        const batchUpdates: Partial<InsertBatch> = {};
        let needsBatchUpdate = false;

        // Se è cambiato il numero di vasetti (yield), aggiorna la quantità del lotto
        if (changes.yield !== undefined) {
          batchUpdates.quantity = changes.yield.toString();
          needsBatchUpdate = true;
          console.log(`Aggiornamento quantità lotto ${batch.code}: ${batch.quantity} → ${changes.yield}`);
        }

        // Se è cambiato il prezzo di vendita, aggiorna il lotto
        if (changes.salePrice) {
          batchUpdates.salePrice = changes.salePrice;
          needsBatchUpdate = true;
          console.log(`Aggiornamento prezzo lotto ${batch.code}: ${batch.salePrice} → ${changes.salePrice}`);
        }

        // Aggiorna il lotto se ci sono modifiche
        if (needsBatchUpdate) {
          await db
            .update(batches)
            .set({ ...batchUpdates, updatedAt: new Date() })
            .where(eq(batches.id, batch.id));
          console.log(`✅ Lotto ${batch.code} aggiornato`);
        }

        // Trova e aggiorna il prodotto finito corrispondente nel magazzino
        const finishedProduct = await db
          .select()
          .from(inventory)
          .where(eq(inventory.code, batch.code));

        if (finishedProduct.length > 0) {
          const inventoryItem = finishedProduct[0];
          const inventoryUpdates: any = {};
          let needsInventoryUpdate = false;

          // Aggiorna quantità in magazzino se è cambiata nel lotto
          if (changes.yield !== undefined) {
            const oldQuantity = parseInt(inventoryItem.currentStock || '0');
            const newQuantity = changes.yield;
            const quantityDifference = newQuantity - oldQuantity;
            
            inventoryUpdates.currentStock = changes.yield.toString();
            
            // Calcola nuovo valore totale magazzino
            const unitCost = Number(inventoryItem.unitCost || 0);
            const newTotalValue = newQuantity * unitCost;
            inventoryUpdates.totalValue = newTotalValue.toFixed(2);
            
            needsInventoryUpdate = true;
            console.log(`Aggiornamento stock magazzino ${inventoryItem.name}: ${inventoryItem.currentStock} → ${changes.yield}`);
            console.log(`Aggiornamento valore totale magazzino ${inventoryItem.name}: €${(oldQuantity * unitCost).toFixed(2)} → €${newTotalValue.toFixed(2)}`);
            
            // Se la quantità è aumentata, dobbiamo detrarre ingredienti aggiuntivi
            if (quantityDifference > 0) {
              console.log(`🔄 Produzione aggiuntiva di ${quantityDifference} unità, detrazione ingredienti...`);
              await this.deductIngredientsForProduction(updatedRecipe, quantityDifference);
            }
            // Se la quantità è diminuita, ripristiniamo ingredienti
            else if (quantityDifference < 0) {
              console.log(`🔄 Riduzione produzione di ${Math.abs(quantityDifference)} unità, ripristino ingredienti...`);
              await this.restoreIngredientsFromReduction(updatedRecipe, Math.abs(quantityDifference));
            }
          }

          // Aggiorna prezzo di vendita in magazzino
          if (changes.salePrice) {
            const newSalePrice = Number(changes.salePrice);
            const unitCost = Number(inventoryItem.unitCost || 0);
            const profit = newSalePrice - unitCost;
            
            inventoryUpdates.salePrice = changes.salePrice;
            inventoryUpdates.profit = profit.toFixed(2);
            needsInventoryUpdate = true;
            console.log(`Aggiornamento prezzo magazzino ${inventoryItem.name}: €${inventoryItem.salePrice} → €${changes.salePrice}`);
          }

          // Aggiorna costo di produzione se cambiato
          if (changes.productionCost !== undefined) {
            const newUnitCost = Number(changes.productionCost);
            const salePrice = Number(inventoryItem.salePrice || changes.salePrice || 0);
            const profit = salePrice - newUnitCost;
            
            inventoryUpdates.unitCost = changes.productionCost;
            inventoryUpdates.profit = profit.toFixed(2);
            needsInventoryUpdate = true;
            console.log(`Aggiornamento costo magazzino ${inventoryItem.name}: €${inventoryItem.unitCost} → €${changes.productionCost}`);
          }

          // Aggiorna il magazzino se ci sono modifiche
          if (needsInventoryUpdate) {
            inventoryUpdates.updatedAt = new Date();
            await db
              .update(inventory)
              .set(inventoryUpdates)
              .where(eq(inventory.id, inventoryItem.id));
            console.log(`✅ Magazzino ${inventoryItem.name} aggiornato`);
          }
        }
      }

      console.log(`✅ Sincronizzazione completata per ricetta ${updatedRecipe.name}`);
    } catch (error) {
      console.error(`❌ Errore durante sincronizzazione ricetta ${updatedRecipe.name}:`, error);
    }
  }

  async deleteRecipe(id: number): Promise<boolean> {
    const result = await db.delete(recipes).where(eq(recipes.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Batches
  async getBatches(): Promise<Batch[]> {
    return await db.select().from(batches).orderBy(desc(batches.createdAt));
  }

  async getBatch(id: number): Promise<Batch | undefined> {
    const [batch] = await db.select().from(batches).where(eq(batches.id, id));
    return batch || undefined;
  }

  async getBatchByCode(code: string): Promise<Batch | undefined> {
    const [batch] = await db.select().from(batches).where(eq(batches.code, code));
    return batch || undefined;
  }

  async generateBatchCode(): Promise<string> {
    const year = new Date().getFullYear();
    const count = await db.select().from(batches);
    const nextNumber = count.length + 1;
    return `LT${year}${String(nextNumber).padStart(3, '0')}`;
  }

  async createBatch(batch: InsertBatch): Promise<Batch> {
    const [newBatch] = await db
      .insert(batches)
      .values(batch)
      .returning();

    // Crea automaticamente il prodotto finito in magazzino
    await this.createFinishedProductInInventory(newBatch);

    return newBatch;
  }

  // Crea automaticamente prodotto finito in magazzino quando viene creato un lotto
  async createFinishedProductInInventory(batch: Batch): Promise<void> {
    if (!batch.recipeId) return;

    const recipe = await this.getRecipe(batch.recipeId);
    if (!recipe) return;

    // Verifica che la ricetta abbia ingredienti reali disponibili in magazzino
    const hasValidIngredients = await this.checkRecipeIngredientsAvailability(recipe);
    if (!hasValidIngredients) {
      console.log(`Salto creazione prodotto finito per ${batch.productName}: ingredienti non disponibili in magazzino`);
      return;
    }

    // Usa il prezzo di vendita dalla ricetta, se non presente calcola automaticamente
    let salePrice = recipe.salePrice ? Number(recipe.salePrice) : 0;
    if (salePrice === 0) {
      salePrice = await this.calculateSalePrice(recipe);
    }

    // Usa il costo di produzione dalla ricetta, se non presente stima
    let unitCost = recipe.productionCost ? Number(recipe.productionCost) : 0;
    if (unitCost === 0) {
      unitCost = salePrice / 3; // Stima inversa dal markup
    }

    const profit = salePrice - unitCost;

    // Verifica se il prodotto esiste già in magazzino con matching esatto del nome
    const existingInventoryItems = await db.select().from(inventory);
    const existingItem = existingInventoryItems.find(item => 
      item.name.toLowerCase().trim() === batch.productName.toLowerCase().trim() &&
      item.category === 'prodotti_finiti'
    );

    // Deduce ingredients and packaging from inventory BEFORE creating finished product
    await this.deductInventoryFromBatch(batch.recipeId, Number(batch.quantity || 0));

    if (existingItem) {
      // Aggiorna item esistente con quantità del lotto
      const currentStock = Number(existingItem.currentStock || 0);
      const newStock = currentStock + Number(batch.quantity || 0);

      await db
        .update(inventory)
        .set({
          currentStock: newStock.toString(),
          code: batch.code,
          salePrice: salePrice.toFixed(2),
          unitCost: unitCost.toFixed(2),
          profit: profit.toFixed(2),
          expiryDate: batch.expiryDate,
          status: 'available',
          updatedAt: new Date()
        })
        .where(eq(inventory.id, existingItem.id));

      console.log(`Aggiornato prodotto finito esistente: ${batch.productName} - Stock: ${newStock} - Prezzo: €${salePrice.toFixed(2)} (da ricetta)`);
    } else {
      // Crea nuovo prodotto finito in magazzino
      await db.insert(inventory).values({
        name: batch.productName,
        category: 'prodotti_finiti',
        code: batch.code,
        currentStock: batch.quantity || '0',
        unit: batch.unit || 'vasetti',
        minimumStock: '5',
        unitCost: unitCost.toFixed(2),
        salePrice: salePrice.toFixed(2),
        profit: profit.toFixed(2),
        status: 'available',
        location: 'Magazzino prodotti finiti',
        expiryDate: batch.expiryDate,
        createdAt: new Date(),
        updatedAt: new Date()
      });

      console.log(`Creato nuovo prodotto finito: ${batch.productName} - Quantità: ${batch.quantity} - Prezzo: €${salePrice.toFixed(2)} (da ricetta)`);
    }
  }

  async updateBatch(id: number, batch: Partial<InsertBatch>): Promise<Batch | undefined> {
    const [updated] = await db
      .update(batches)
      .set({ ...batch, updatedAt: new Date() })
      .where(eq(batches.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteBatch(id: number): Promise<boolean> {
    const batch = await this.getBatch(id);
    if (!batch) {
      console.warn(`Lotto non trovato: ${id}`);
      return false;
    }

    console.log('Eliminazione lotto ' + batch.code + ' - Ripristino scorte per ' + batch.quantity + ' ' + batch.unit);

    // Se il lotto è collegato a una ricetta, ripristina le scorte ingredienti
    if (batch.recipeId) {
      await this.restoreInventoryFromBatch(batch.recipeId, parseFloat(batch.quantity));
    }

    // Rimuovi il prodotto finito corrispondente dall'inventario PRIMA di eliminare il lotto
    const inventoryItems = await db.select().from(inventory);
    const finishedProduct = inventoryItems.find(item => 
      item.code === batch.code && 
      (item.category === 'prodotti_finiti' || item.category === 'Prodotti Finiti')
    );

    if (finishedProduct) {
      await db.delete(inventory).where(eq(inventory.id, finishedProduct.id));
      console.log(`✅ Rimosso prodotto finito dall'inventario: ${finishedProduct.name} (${batch.code})`);
    } else {
      console.log(`⚠️ Nessun prodotto finito trovato per il lotto ${batch.code}`);
    }

    const result = await db.delete(batches).where(eq(batches.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Inventory
  async getInventoryItems(): Promise<InventoryItem[]> {
    return await db.select().from(inventory).orderBy(desc(inventory.createdAt));
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventory).where(eq(inventory.id, id));
    return item || undefined;
  }

  async getInventoryItemByCode(code: string): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventory).where(eq(inventory.code, code));
    return item || undefined;
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [newItem] = await db
      .insert(inventory)
      .values(item)
      .returning();
    return newItem;
  }

  async updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const [updated] = await db
      .update(inventory)
      .set({ ...item, updatedAt: new Date() })
      .where(eq(inventory.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    const result = await db.delete(inventory).where(eq(inventory.id, id));
    return (result.rowCount || 0) > 0;
  }

  // QR Labels
  async getQRLabels(): Promise<QRLabel[]> {
    return await db.select().from(qrLabels).orderBy(desc(qrLabels.generatedAt));
  }

  async getQRLabel(id: number): Promise<QRLabel | undefined> {
    const [label] = await db.select().from(qrLabels).where(eq(qrLabels.id, id));
    return label || undefined;
  }

  async getQRLabelByBatchId(batchId: number): Promise<QRLabel | undefined> {
    const [label] = await db.select().from(qrLabels).where(eq(qrLabels.batchId, batchId));
    return label || undefined;
  }

  async createQRLabel(label: InsertQRLabel): Promise<QRLabel> {
    const [newLabel] = await db
      .insert(qrLabels)
      .values(label)
      .returning();
    return newLabel;
  }

  // Alerts
  async getAlerts(): Promise<Alert[]> {
    return await db.select().from(alerts).orderBy(desc(alerts.createdAt));
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return await db.select().from(alerts).where(eq(alerts.resolved, false)).orderBy(desc(alerts.createdAt));
  }

  async getAlert(id: number): Promise<Alert | undefined> {
    const [alert] = await db.select().from(alerts).where(eq(alerts.id, id));
    return alert || undefined;
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [newAlert] = await db
      .insert(alerts)
      .values(alert)
      .returning();
    return newAlert;
  }

  async resolveAlert(id: number): Promise<boolean> {
    const result = await db
      .update(alerts)
      .set({ resolved: true, resolvedAt: new Date() })
      .where(eq(alerts.id, id));
    return (result.rowCount || 0) > 0;
  }

  async checkInventoryAlerts(): Promise<Alert[]> {
    const items = await this.getInventoryItems();
    const newAlerts: Alert[] = [];

    for (const item of items) {
      const currentStock = Number(item.currentStock);
      const minimumStock = Number(item.minimumStock);

      // Check for low stock
      if (currentStock <= minimumStock && currentStock > 0) {
        const existingAlert = await db
          .select()
          .from(alerts)
          .where(and(
            eq(alerts.type, 'low_stock'),
            eq(alerts.resolved, false),
            sql`${alerts.message} LIKE ${'%' + item.name + '%'}`
          ));

        if (existingAlert.length === 0) {
          const alert = await this.createLowStockAlert(item);
          newAlerts.push(alert);
        }
      }

      // Check for expiry
      if (item.expiryDate) {
        const daysUntilExpiry = Math.ceil((item.expiryDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        if (daysUntilExpiry <= 7) {
          const existingAlert = await db
            .select()
            .from(alerts)
            .where(and(
              eq(alerts.type, 'expiry_warning'),
              eq(alerts.resolved, false),
              sql`${alerts.message} LIKE ${'%' + item.name + '%'}`
            ));

          if (existingAlert.length === 0) {
            const alert = await this.createExpiryAlert(item);
            newAlerts.push(alert);
          }
        }
      }
    }

    return newAlerts;
  }

  async createLowStockAlert(item: InventoryItem): Promise<Alert> {
    return await this.createAlert({
      type: 'low_stock',
      severity: 'medium',
      title: 'Scorte basse',
      message: `L'articolo "${item.name}" ha scorte basse (${item.currentStock} ${item.unit}). Minimo richiesto: ${item.minimumStock} ${item.unit}`,
      resolved: false
    });
  }

  async createExpiryAlert(item: InventoryItem): Promise<Alert> {
    const daysUntilExpiry = item.expiryDate 
      ? Math.ceil((item.expiryDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      : 0;
    
    return await this.createAlert({
      type: 'expiry_warning',
      severity: daysUntilExpiry <= 2 ? 'high' : 'medium',
      title: 'Scadenza imminente',
      message: `L'articolo "${item.name}" scade tra ${daysUntilExpiry} giorni`,
      resolved: false
    });
  }

  async monitorInventoryStatus(): Promise<{ alertsCreated: number; alertsResolved: number }> {
    const newAlerts = await this.checkInventoryAlerts();
    return { alertsCreated: newAlerts.length, alertsResolved: 0 };
  }

  async getDashboardStats(): Promise<{
    totalRecipes: number;
    activeBatches: number;
    inventoryItems: number;
    activeAlerts: number;
    lowStockItems: number;
    totalInventoryValue: number;
  }> {
    const [recipesData, batchesData, inventoryData, alertsData] = await Promise.all([
      db.select().from(recipes),
      db.select().from(batches).where(eq(batches.status, 'active')),
      db.select().from(inventory),
      db.select().from(alerts).where(eq(alerts.resolved, false))
    ]);
    
    const lowStockItems = inventoryData.filter(item => 
      Number(item.currentStock) <= Number(item.minimumStock)
    ).length;
    
    const totalInventoryValue = inventoryData.reduce((total, item) => {
      const stock = Number(item.currentStock) || 0;
      // Per i prodotti finiti usa il prezzo di vendita, per le materie prime il costo unitario
      const value = (item.category === 'Prodotti Finiti' || item.category === 'prodotti_finiti') && item.salePrice 
        ? Number(item.salePrice) 
        : Number(item.unitCost) || 0;
      return total + (stock * value);
    }, 0);

    return {
      totalRecipes: recipesData.length,
      activeBatches: batchesData.length,
      inventoryItems: inventoryData.length,
      activeAlerts: alertsData.length,
      lowStockItems,
      totalInventoryValue
    };
  }

  async getTraceabilityByBatchCode(batchCode: string): Promise<{
    batch: Batch;
    recipe?: Recipe;
    qrLabel?: QRLabel;
  } | null> {
    const batch = await this.getBatchByCode(batchCode);
    if (!batch) return null;

    const recipe = batch.recipeId ? await this.getRecipe(batch.recipeId) : undefined;
    const qrLabel = await this.getQRLabelByBatchId(batch.id);

    return { batch, recipe, qrLabel };
  }

  // Ingredient Tracking
  async getIngredientTracking(): Promise<IngredientTracking[]> {
    return await db.select().from(ingredientTracking).orderBy(desc(ingredientTracking.createdAt));
  }

  async createIngredientTracking(insertTracking: InsertIngredientTracking): Promise<IngredientTracking> {
    const [tracking] = await db
      .insert(ingredientTracking)
      .values(insertTracking)
      .returning();
    return tracking;
  }

  async getIngredientUsageByBatch(batchId: number): Promise<IngredientTracking[]> {
    return await db
      .select()
      .from(ingredientTracking)
      .where(eq(ingredientTracking.batchId, batchId))
      .orderBy(desc(ingredientTracking.createdAt));
  }

  async getIngredientAvailability(ingredientName: string): Promise<{
    currentStock: number;
    minimumStock: number;
    status: 'ok' | 'low' | 'critical';
    daysRemaining?: number;
  }> {
    const [item] = await db
      .select()
      .from(inventory)
      .where(eq(inventory.name, ingredientName));

    if (!item) {
      return { currentStock: 0, minimumStock: 0, status: 'critical' };
    }

    const currentStock = Number(item.currentStock);
    const minimumStock = Number(item.minimumStock);

    let status: 'ok' | 'low' | 'critical' = 'ok';
    if (currentStock === 0) {
      status = 'critical';
    } else if (currentStock <= minimumStock) {
      status = 'low';
    }

    return { currentStock, minimumStock, status };
  }

  async checkLowStockIngredients(): Promise<InventoryItem[]> {
    return await db
      .select()
      .from(inventory)
      .where(sql`CAST(${inventory.currentStock} AS NUMERIC) <= CAST(${inventory.minimumStock} AS NUMERIC)`);
  }

  private updatingInventory = new Set<string>();

  async updateInventoryFromUsage(ingredientName: string, quantityUsed: number, unit: string): Promise<boolean> {
    const key = `${ingredientName}-${unit}`;
    
    if (this.updatingInventory.has(key)) {
      console.log('Aggiornamento già in corso per ' + ingredientName);
      return false;
    }
    
    this.updatingInventory.add(key);
    
    try {
      console.log('[UNICO] Cerco ingrediente: "' + ingredientName + '" con unità: "' + unit + '"');
      
      const inventoryItems = await db.select().from(inventory);
      console.log(`Inventario disponibile:`, inventoryItems.map(item => ({ 
        id: item.id, 
        name: item.name, 
        unit: item.unit, 
        currentStock: item.currentStock 
      })));

      const inventoryItem = inventoryItems.find(item => {
        const nameMatch = item.name.toLowerCase().trim() === ingredientName.toLowerCase().trim();
        const unitMatch = item.unit.toLowerCase().trim() === unit.toLowerCase().trim();
        console.log(`Confronto: "${item.name}" vs "${ingredientName}" (${nameMatch}) - "${item.unit}" vs "${unit}" (${unitMatch})`);
        return nameMatch && unitMatch;
      });

      if (!inventoryItem) {
        console.log(`[UNICO] Ingrediente non trovato in inventario: ${ingredientName} (${unit})`);
        return false;
      }

      const currentStock = Number(inventoryItem.currentStock);
      const newStock = Math.max(0, currentStock - quantityUsed);
      
      console.log('[UNICO] Aggiornamento scorte: ' + inventoryItem.name + ' - Stock attuale: ' + currentStock + ', Usato: ' + quantityUsed + ', Nuovo stock: ' + newStock);
      
      const result = await db
        .update(inventory)
        .set({ 
          currentStock: newStock.toString(),
          updatedAt: new Date()
        })
        .where(eq(inventory.id, inventoryItem.id));

      console.log('[UNICO] Scorte aggiornate per ' + inventoryItem.name + ': ' + currentStock + ' -> ' + newStock);

      // Crea alert automatici per scorte basse
      if (newStock <= Number(inventoryItem.minimumStock) && newStock > 0) {
        await this.createAlert({
          type: 'low_stock',
          severity: 'medium',
          title: 'Scorte basse',
          message: `L'articolo "${inventoryItem.name}" ha scorte basse (${newStock} ${inventoryItem.unit})`,
          resolved: false
        });
      }

      return true;
    } catch (error) {
      console.error(`[UNICO] Errore nell'aggiornamento scorte per ${ingredientName}:`, error);
      return false;
    } finally {
      this.updatingInventory.delete(key);
    }
  }

  // Verifica se una ricetta ha ingredienti realmente disponibili in magazzino
  async checkRecipeIngredientsAvailability(recipe: Recipe): Promise<boolean> {
    const inventoryItems = await db.select().from(inventory);
    
    // Conta quanti ingredienti della ricetta sono disponibili in magazzino
    let availableIngredients = 0;
    for (const ingredient of recipe.ingredients) {
      const inventoryItem = inventoryItems.find(item => 
        item.name.toLowerCase().trim() === ingredient.name.toLowerCase().trim() &&
        item.unit.toLowerCase().trim() === ingredient.unit.toLowerCase().trim()
      );
      
      if (inventoryItem && Number(inventoryItem.currentStock) > 0) {
        availableIngredients++;
      }
    }
    
    // Richiede almeno il 50% degli ingredienti disponibili in magazzino
    const availabilityPercentage = availableIngredients / recipe.ingredients.length;
    return availabilityPercentage >= 0.5;
  }

  // Crea automaticamente un prodotto finito nell'inventario dal lotto
  async createFinishedProductFromBatch(batch: Batch): Promise<void> {
    if (!batch.recipeId) return;
    
    const recipe = await this.getRecipe(batch.recipeId);
    if (!recipe) return;

    // Usa il prezzo di vendita dal lotto se presente, altrimenti dalla ricetta
    let salePrice = Number(batch.salePrice) || 0;
    if (salePrice === 0 && recipe.salePrice) {
      salePrice = Number(recipe.salePrice);
    }
    if (salePrice === 0) {
      salePrice = await this.calculateSalePrice(recipe);
    }

    // Usa il costo di produzione dalla ricetta
    let unitCost = Number(recipe.productionCost) || 0;
    if (unitCost === 0) {
      // Calcola il costo usando la stessa logica del frontend
      unitCost = 1.52; // Usa il valore calcolato corretto invece di stima
    }

    const profit = salePrice - unitCost;

    // Verifica se il prodotto esiste già in magazzino
    const existingInventoryItems = await db.select().from(inventory);
    const existingItem = existingInventoryItems.find(item => 
      item.name.toLowerCase().trim() === batch.productName.toLowerCase().trim() &&
      item.category === 'prodotti_finiti'
    );

    if (existingItem) {
      // Aggiorna item esistente
      const currentStock = Number(existingItem.currentStock || 0);
      const newStock = currentStock + Number(batch.quantity || 0);

      await db
        .update(inventory)
        .set({
          currentStock: newStock.toString(),
          code: batch.code,
          salePrice: salePrice.toFixed(2),
          unitCost: unitCost.toFixed(2),
          profit: profit.toFixed(2),
          expiryDate: batch.expiryDate,
          status: 'available',
          updatedAt: new Date()
        })
        .where(eq(inventory.id, existingItem.id));

      console.log(`Aggiornato prodotto finito: ${batch.productName} - Stock: ${newStock} - Prezzo: €${salePrice.toFixed(2)} - Costo: €${unitCost.toFixed(2)}`);
    } else {
      // Crea nuovo prodotto finito
      await db.insert(inventory).values({
        name: batch.productName,
        category: 'prodotti_finiti',
        code: batch.code,
        currentStock: batch.quantity || '0',
        unit: batch.unit || 'vasetti',
        minimumStock: '5',
        unitCost: unitCost.toFixed(2),
        salePrice: salePrice.toFixed(2),
        profit: profit.toFixed(2),
        status: 'available',
        location: 'Magazzino prodotti finiti',
        expiryDate: batch.expiryDate,
        createdAt: new Date(),
        updatedAt: new Date()
      });

      console.log(`Creato prodotto finito: ${batch.productName} - Quantità: ${batch.quantity} - Prezzo: €${salePrice.toFixed(2)} - Costo: €${unitCost.toFixed(2)}`);
    }
  }

  // Calcola il prezzo di vendita automatico basato sui costi di produzione
  async calculateSalePrice(recipe: Recipe): Promise<number> {
    let totalCost = 0;

    // Calcola costo ingredienti
    for (const ingredient of recipe.ingredients) {
      try {
        const inventoryItems = await db.select().from(inventory);
        const inventoryItem = inventoryItems.find(item => 
          item.name.toLowerCase().trim() === ingredient.name.toLowerCase().trim()
        );

        if (inventoryItem && inventoryItem.unitCost) {
          // Normalizza le unità per il calcolo del costo
          let normalizedQuantity = ingredient.quantity;
          let normalizedUnitCost = Number(inventoryItem.unitCost);
          
          // Converti se necessario per far combaciare le unità
          if (inventoryItem.unit === 'kg' && ingredient.unit === 'g') {
            // Costo in magazzino per kg, ricetta in grammi
            normalizedUnitCost = normalizedUnitCost / 1000; // €/kg -> €/g
          } else if (inventoryItem.unit === 'g' && ingredient.unit === 'kg') {
            // Costo in magazzino per grammi, ricetta in kg
            normalizedQuantity = normalizedQuantity * 1000; // kg -> g
          } else if (inventoryItem.unit === 'l' && ingredient.unit === 'ml') {
            // Costo in magazzino per litri, ricetta in ml
            normalizedUnitCost = normalizedUnitCost / 1000; // €/l -> €/ml
          } else if (inventoryItem.unit === 'ml' && ingredient.unit === 'l') {
            // Costo in magazzino per ml, ricetta in litri
            normalizedQuantity = normalizedQuantity * 1000; // l -> ml
          }
          
          const ingredientCost = normalizedUnitCost * normalizedQuantity;
          totalCost += ingredientCost;
          
          console.log(`Costo ingrediente ${ingredient.name}: ${ingredient.quantity}${ingredient.unit} × €${normalizedUnitCost}/${inventoryItem.unit} = €${ingredientCost.toFixed(4)}`);
        }
      } catch (error) {
        console.error(`Errore nel calcolo costo per ${ingredient.name}:`, error);
      }
    }

    // Aggiungi costi packaging se presenti
    if (recipe.packagingCosts && Array.isArray(recipe.packagingCosts)) {
      for (const packaging of recipe.packagingCosts) {
        const packagingName = packaging.name || packaging.containerType || 'vasetto';
        try {
          const inventoryItems = await db.select().from(inventory);
          const inventoryItem = inventoryItems.find(item => 
            item.name.toLowerCase().includes(packagingName.toLowerCase())
          );

          if (inventoryItem && inventoryItem.unitCost) {
            const packagingCost = Number(inventoryItem.unitCost) * packaging.quantity;
            totalCost += packagingCost;
          }
        } catch (error) {
          console.error(`Errore nel calcolo costo packaging per ${packagingName}:`, error);
        }
      }
    }

    // Applica markup del 200% (margine del 67%)
    const salePrice = totalCost * 3;
    return Math.max(salePrice, 5.00); // Prezzo minimo €5.00
  }

  async updateInventoryCodeWithBatch(recipeId: number, batchCode: string): Promise<void> {
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) return;

    // Cerca l'item dell'inventario corrispondente al prodotto finito
    const productName = recipe.name;
    const [inventoryItem] = await db
      .select()
      .from(inventory)
      .where(eq(inventory.name, productName));

    if (inventoryItem) {
      // Calcola il prezzo di vendita automatico se non già impostato
      let salePrice = inventoryItem.salePrice;
      if (!salePrice || Number(salePrice) === 0) {
        const calculatedPrice = await this.calculateSalePrice(recipe);
        salePrice = calculatedPrice.toFixed(2);
      }

      // Calcola il profitto
      const unitCost = Number(inventoryItem.unitCost || 0);
      const profit = Number(salePrice) - unitCost;

      await db
        .update(inventory)
        .set({ 
          code: batchCode,
          salePrice: salePrice,
          profit: profit.toFixed(2),
          updatedAt: new Date()
        })
        .where(eq(inventory.id, inventoryItem.id));

      console.log(`Aggiornato prodotto finito: ${productName} - Prezzo vendita: €${salePrice} - Profitto: €${profit.toFixed(2)}`);
    }
  }

  async updateInventoryFromRecipe(recipeId: number, quantityProduced: number): Promise<void> {
    await this.deductInventoryFromBatch(recipeId, quantityProduced);
  }

  async restoreInventoryFromBatch(recipeId: number, quantityProduced: number): Promise<void> {
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) return;

    console.log('Ripristino scorte per ricetta: ' + recipe.name + ' - Quantità: ' + quantityProduced);

    // Ripristina gli ingredienti
    for (const ingredient of recipe.ingredients) {
      const totalQuantityNeeded = ingredient.quantity * quantityProduced;
      
      try {
        const inventoryItems = await db.select().from(inventory);
        const inventoryItem = inventoryItems.find(item => 
          item.name.toLowerCase().trim() === ingredient.name.toLowerCase().trim() &&
          item.unit.toLowerCase().trim() === ingredient.unit.toLowerCase().trim()
        );

        if (inventoryItem) {
          const currentStock = Number(inventoryItem.currentStock);
          const newStock = currentStock + totalQuantityNeeded;
          
          await db
            .update(inventory)
            .set({ 
              currentStock: newStock.toString(),
              updatedAt: new Date()
            })
            .where(eq(inventory.id, inventoryItem.id));

          console.log(`Ripristinato ${ingredient.name}: ${currentStock} + ${totalQuantityNeeded} = ${newStock}`);
        }
      } catch (error) {
        console.error(`Errore nel ripristino di ${ingredient.name}:`, error);
      }
    }

    // Ripristina packaging - calculate proportional to recipe yield
    const hasValidPackagingCosts = recipe.packagingCosts && Array.isArray(recipe.packagingCosts) && recipe.packagingCosts.length > 0;
    const packagingCosts = hasValidPackagingCosts 
      ? recipe.packagingCosts 
      : [{ name: 'vasetto', quantity: 1, unit: 'pz' }];
    
    // Calculate scaling factor based on recipe yield (same as deduction)
    const recipeYield = Number(recipe.yield) || quantityProduced;
    const scalingFactor = quantityProduced / recipeYield;
    
    console.log(`RESTORATION: Recipe ${recipe.name} - hasValidPackagingCosts: ${hasValidPackagingCosts}`);
    console.log(`RESTORATION: Recipe yield: ${recipeYield}, Batch quantity: ${quantityProduced}, Scaling factor: ${scalingFactor}`);
    
    for (const packaging of packagingCosts) {
      // Handle both old format (type/containerType) and new format (name)
      const packagingName = packaging.name || packaging.type || packaging.containerType || 'vasetto';
      const packagingUnit = packaging.unit || 'pz';
      
      if (!packagingName) {
        console.log('Packaging mancante di nome:', packaging);
        continue;
      }
      
      const baseQuantity = packaging.quantity || 1;
      const totalQuantityNeeded = Math.ceil(baseQuantity * scalingFactor);
      
      try {
        const inventoryItems = await db.select().from(inventory);
        
        // Enhanced matching logic for packaging items (same as deduction)
        const inventoryItem = inventoryItems.find(item => {
          const itemName = item.name.toLowerCase();
          const searchName = packagingName.toLowerCase();
          
          // Direct matches
          if (itemName.includes(searchName) || searchName.includes(itemName)) {
            return true;
          }
          
          // Special case for vasetti variations
          if ((searchName.includes('vasett') && itemName.includes('vasett')) ||
              (searchName.includes('jar') && itemName.includes('vasett')) ||
              (searchName.includes('vetro') && itemName.includes('vetro'))) {
            return true;
          }
          
          return false;
        });

        if (inventoryItem) {
          const currentStock = Number(inventoryItem.currentStock);
          const newStock = currentStock + totalQuantityNeeded;
          
          await db
            .update(inventory)
            .set({ 
              currentStock: newStock.toString(),
              updatedAt: new Date()
            })
            .where(eq(inventory.id, inventoryItem.id));

          console.log(`RESTORATION: Packaging ripristinato ${packagingName}: ${currentStock} + ${totalQuantityNeeded} = ${newStock}`);
        }
      } catch (error) {
        console.error(`Errore nel ripristino packaging ${packaging.name}:`, error);
      }
    }
  }

  async deductInventoryFromBatch(recipeId: number, quantityProduced: number): Promise<void> {
    const callId = Math.random().toString(36).substring(7);
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) return;

    console.log(`[${callId}] INIZIA deductInventoryFromBatch per ${recipe.name}`);

    // Deduce ingredients
    for (const ingredient of recipe.ingredients) {
      const totalQuantityNeeded = ingredient.quantity * quantityProduced;
      console.log(`Deduzione ingrediente: ${ingredient.name} - ${totalQuantityNeeded} ${ingredient.unit}`);
      
      try {
        await this.updateInventoryFromUsage(ingredient.name, totalQuantityNeeded, ingredient.unit);
        console.log(`✅ Ingrediente ${ingredient.name} elaborato`);
      } catch (error) {
        console.error(`❌ Errore elaborazione ingrediente ${ingredient.name}:`, error);
        // Continue with other ingredients
      }
    }
    
    console.log('🏁 Ingredienti completati, procedo con packaging...');

    // Deduce packaging - calculate proportional to recipe yield
    const hasValidPackagingCosts = recipe.packagingCosts && Array.isArray(recipe.packagingCosts) && recipe.packagingCosts.length > 0;
    const packagingCosts = hasValidPackagingCosts 
      ? recipe.packagingCosts 
      : [{ name: 'vasetto', quantity: 1, unit: 'pz' }];
    
    // Calculate scaling factor based on recipe yield
    const recipeYield = Number(recipe.yield) || quantityProduced;
    const scalingFactor = quantityProduced / recipeYield;
    
    console.log(`PACKAGING: Recipe ${recipe.name} - hasValidPackagingCosts: ${hasValidPackagingCosts}`);
    console.log(`PACKAGING: Recipe yield: ${recipeYield}, Batch quantity: ${quantityProduced}, Scaling factor: ${scalingFactor}`);
    console.log(`PACKAGING: packagingCosts:`, JSON.stringify(packagingCosts));
    
    for (const packaging of packagingCosts) {
      // Handle both old format (type/containerType) and new format (name)
      const packagingName = packaging.name || packaging.type || packaging.containerType || 'vasetto';
      const packagingUnit = packaging.unit || 'pz';
      const baseQuantity = packaging.quantity || 1;
      const quantityNeeded = Math.ceil(baseQuantity * scalingFactor);
      
      if (!packagingName) {
        console.log('Packaging senza nome, salto:', packaging);
        continue;
      }
      
      console.log(`PACKAGING: Deduzione packaging: ${packagingName} - Base: ${baseQuantity}, Scaling: ${scalingFactor}, Final: ${quantityNeeded} ${packagingUnit}`);
      
      try {
        const inventoryItems = await db.select().from(inventory);
        
        // Enhanced matching logic for packaging items
        const inventoryItem = inventoryItems.find(item => {
          const itemName = item.name.toLowerCase();
          const searchName = packagingName.toLowerCase();
          
          // Direct matches
          if (itemName.includes(searchName) || searchName.includes(itemName)) {
            return true;
          }
          
          // Special case for vasetti variations
          if ((searchName.includes('vasett') && itemName.includes('vasett')) ||
              (searchName.includes('jar') && itemName.includes('vasett')) ||
              (searchName.includes('vetro') && itemName.includes('vetro'))) {
            return true;
          }
          
          return false;
        });

        if (!inventoryItem) {
          console.log(`Packaging non trovato in inventario: ${packagingName}`);
          continue;
        }

        console.log(`Trovato packaging in inventario: ${inventoryItem.name} (Stock: ${inventoryItem.currentStock})`);

        const currentStock = Number(inventoryItem.currentStock);
        const newStock = Math.max(0, currentStock - quantityNeeded);
        
        await db
          .update(inventory)
          .set({ 
            currentStock: newStock.toString(),
            updatedAt: new Date()
          })
          .where(eq(inventory.id, inventoryItem.id));

        console.log(`Packaging aggiornato: ${inventoryItem.name} da ${currentStock} a ${newStock}`);

        const [verifyItem] = await db.select().from(inventory).where(eq(inventory.id, inventoryItem.id));
        console.log(` Verifica dopo deduzione packaging: ${verifyItem.name} stock = ${verifyItem.currentStock}`);

        // Registra il tracking dell'utilizzo packaging
        await this.createIngredientTracking({
          ingredientName: packagingName,
          quantityUsed: quantityNeeded.toString(),
          unit: inventoryItem.unit,
          usageDate: new Date(),
          batchId: null,
          inventoryId: inventoryItem.id,
          notes: `Utilizzo packaging per produzione lotto ${recipe.name}`
        });

        console.log(`Tracking packaging creato per ${packagingName}`);

      } catch (error) {
        console.error(`Errore nella deduzione packaging ${packagingName}:`, error);
      }
    }

    console.log(`[${callId}] COMPLETATO deductInventoryFromBatch per ${recipe.name}`);
    console.log(`[${callId}] === FINE DEDUCTION PROCESS ===`);
  }

  // User authentication methods
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async getUserById(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async validateUserPassword(username: string, password: string): Promise<User | null> {
    const bcrypt = await import('bcryptjs');
    const user = await this.getUserByUsername(username);
    
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async validateUserPasswordByEmail(email: string, password: string): Promise<User | null> {
    const bcrypt = await import('bcryptjs');
    const user = await this.getUserByEmail(email);
    
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async updateUserPassword(userId: number, newPassword: string): Promise<boolean> {
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    const result = await db
      .update(users)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(users.id, userId));
      
    return (result.rowCount || 0) > 0;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async createPasswordResetToken(userId: number): Promise<string> {
    const token = Math.random().toString(36).substring(2) + Date.now().toString(36);
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 ore
    
    await db.insert(passwordResetTokens).values({
      userId,
      token,
      expiresAt,
      used: false
    });
    
    return token;
  }

  async validatePasswordResetToken(token: string): Promise<{ userId: number; valid: boolean }> {
    const [tokenRecord] = await db
      .select()
      .from(passwordResetTokens)
      .where(eq(passwordResetTokens.token, token));
    
    if (!tokenRecord || tokenRecord.used || tokenRecord.expiresAt < new Date()) {
      return { userId: 0, valid: false };
    }
    
    return { userId: tokenRecord.userId, valid: true };
  }

  async usePasswordResetToken(token: string): Promise<boolean> {
    const result = await db
      .update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.token, token));
    
    return (result.rowCount || 0) > 0;
  }

  // Company profiles
  async getCompanyProfile(userId: number): Promise<CompanyProfile | undefined> {
    const [profile] = await db.select().from(companyProfiles).where(eq(companyProfiles.userId, userId));
    return profile || undefined;
  }

  async createCompanyProfile(profile: InsertCompanyProfile): Promise<CompanyProfile> {
    const [newProfile] = await db
      .insert(companyProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateCompanyProfile(userId: number, profile: Partial<InsertCompanyProfile>): Promise<CompanyProfile | undefined> {
    const [updated] = await db
      .update(companyProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(companyProfiles.userId, userId))
      .returning();
    return updated || undefined;
  }

  // Sales
  async getSales(): Promise<Sale[]> {
    return await db.select().from(sales).orderBy(desc(sales.saleDate));
  }

  async getSale(id: number): Promise<Sale | undefined> {
    const [sale] = await db.select().from(sales).where(eq(sales.id, id));
    return sale || undefined;
  }

  async createSale(sale: InsertSale): Promise<Sale> {
    // Step 1: Create the sale record
    const [newSale] = await db
      .insert(sales)
      .values(sale)
      .returning();

    try {
      // Step 2: Get inventory item details
      const [inventoryItem] = await db
        .select()
        .from(inventory)
        .where(eq(inventory.id, sale.inventoryItemId));

      if (!inventoryItem) {
        throw new Error('Prodotto non trovato in inventario');
      }

      const currentStock = Number(inventoryItem.currentStock);
      const quantitySold = Number(sale.quantitySold);

      console.log(`VENDITA DEBUG: batchId = ${sale.batchId}, inventoryItemId = ${sale.inventoryItemId}, quantitySold = ${quantitySold}`);
      console.log(`VENDITA DEBUG: typeof batchId = ${typeof sale.batchId}, batchId truthy = ${!!sale.batchId}`);

      // Step 3: If batch is specified, subtract from batch and update inventory accordingly
      if (sale.batchId) {
        console.log(`VENDITA DEBUG: Entrando nella logica batch con batchId = ${sale.batchId}`);
        
        // Use SQL to directly decrement batch quantity - avoid reading values
        const batchUpdateResult = await db
          .update(batches)
          .set({ 
            quantity: sql`GREATEST(0, ${batches.quantity}::numeric - ${quantitySold})`,
            updatedAt: new Date()
          })
          .where(eq(batches.id, sale.batchId))
          .returning({ code: batches.code, oldQuantity: sql`${batches.quantity}::numeric + ${quantitySold}`, newQuantity: batches.quantity });

        if (batchUpdateResult.length > 0) {
          const batch = batchUpdateResult[0];
          console.log(`Lotto aggiornato ${batch.code}: ${Number(batch.oldQuantity)} -> ${batch.newQuantity}`);
        }

        // Use SQL to directly decrement inventory quantity - avoid reading values
        const inventoryUpdateResult = await db
          .update(inventory)
          .set({ 
            currentStock: sql`GREATEST(0, ${inventory.currentStock}::numeric - ${quantitySold})`,
            updatedAt: new Date()
          })
          .where(eq(inventory.id, sale.inventoryItemId))
          .returning({ name: inventory.name, oldStock: sql`${inventory.currentStock}::numeric + ${quantitySold}`, newStock: inventory.currentStock });

        if (inventoryUpdateResult.length > 0) {
          const item = inventoryUpdateResult[0];
          console.log(`Magazzino aggiornato dal lotto ${item.name}: ${Number(item.oldStock)} -> ${item.newStock}`);
        }
      } else {
        // If no batch, subtract directly from inventory using SQL
        const inventoryUpdateResult = await db
          .update(inventory)
          .set({ 
            currentStock: sql`GREATEST(0, ${inventory.currentStock}::numeric - ${quantitySold})`,
            updatedAt: new Date()
          })
          .where(eq(inventory.id, sale.inventoryItemId))
          .returning({ name: inventory.name, oldStock: sql`${inventory.currentStock}::numeric + ${quantitySold}`, newStock: inventory.currentStock });

        if (inventoryUpdateResult.length > 0) {
          const item = inventoryUpdateResult[0];
          console.log(`Magazzino aggiornato direttamente ${item.name}: ${Number(item.oldStock)} -> ${item.newStock}`);
        }
      }

      // Step 5: Create usage tracking
      await this.createIngredientTracking({
        ingredientName: inventoryItem.name,
        quantityUsed: sale.quantitySold,
        unit: inventoryItem.unit,
        usageDate: new Date(),
        batchId: sale.batchId || null,
        inventoryId: sale.inventoryItemId,
        notes: `Vendita registrata - Cliente: ${sale.customerName || 'N/A'}`
      });

      console.log(`Tracking vendita creato per ${inventoryItem.name}`);

    } catch (error) {
      console.error('Errore durante l\'aggiornamento inventario per vendita:', error);
      // Non interrompiamo la vendita se ci sono errori nell'aggiornamento inventario
    }

    return newSale;
  }

  async deleteSale(id: number): Promise<boolean> {
    try {
      return await db.transaction(async (tx) => {
        // Step 1: Get sale details before deletion
        const [sale] = await tx
          .select()
          .from(sales)
          .where(eq(sales.id, id));

        if (!sale) {
          console.log("Vendita non trovata");
          return false;
        }

        const quantityToRestore = Number(sale.quantitySold);
        console.log(`ELIMINAZIONE DEBUG: Ripristino quantità = ${quantityToRestore} per vendita ID ${id}`);

        // Step 2: First delete the sale record to avoid any conflicts
        await tx
          .delete(sales)
          .where(eq(sales.id, id));

        // Step 3: Restore based on how the sale was originally made
        if (sale.batchId) {
          // Get current batch quantity and calculate new value
          const [currentBatch] = await tx
            .select({ quantity: batches.quantity, code: batches.code })
            .from(batches)
            .where(eq(batches.id, sale.batchId));

          if (currentBatch) {
            const currentBatchQty = Number(currentBatch.quantity);
            const newBatchQty = currentBatchQty + quantityToRestore;
            
            await tx
              .update(batches)
              .set({ 
                quantity: newBatchQty.toString(),
                updatedAt: new Date()
              })
              .where(eq(batches.id, sale.batchId));

            console.log(`Lotto ripristinato ${currentBatch.code}: ${currentBatchQty} -> ${newBatchQty}`);
          }

          // Get current inventory quantity and calculate new value
          const [currentInventory] = await tx
            .select({ currentStock: inventory.currentStock, name: inventory.name })
            .from(inventory)
            .where(eq(inventory.id, sale.inventoryItemId));

          if (currentInventory) {
            const currentStock = Number(currentInventory.currentStock);
            const newStock = currentStock + quantityToRestore;
            
            await tx
              .update(inventory)
              .set({ 
                currentStock: newStock.toString(),
                updatedAt: new Date()
              })
              .where(eq(inventory.id, sale.inventoryItemId));

            console.log(`Magazzino ripristinato ${currentInventory.name}: ${currentStock} -> ${newStock}`);
          } else {
            console.log("Prodotto non trovato in inventario");
            return false;
          }
        } else {
          // Restore only inventory if no batch was involved
          const [currentInventory] = await tx
            .select({ currentStock: inventory.currentStock, name: inventory.name })
            .from(inventory)
            .where(eq(inventory.id, sale.inventoryItemId));

          if (currentInventory) {
            const currentStock = Number(currentInventory.currentStock);
            const newStock = currentStock + quantityToRestore;
            
            await tx
              .update(inventory)
              .set({ 
                currentStock: newStock.toString(),
                updatedAt: new Date()
              })
              .where(eq(inventory.id, sale.inventoryItemId));

            console.log(`Magazzino ripristinato direttamente ${currentInventory.name}: ${currentStock} -> ${newStock}`);
          } else {
            console.log("Prodotto non trovato in inventario");
            return false;
          }
        }

        console.log(`Vendita ${id} eliminata e scorte ripristinate`);
        return true;
      });

    } catch (error) {
      console.error("Error deleting sale:", error);
      return false;
    }
  }

  // Funzione helper per detrarre ingredienti quando la produzione aumenta
  private async deductIngredientsForProduction(recipe: Recipe, additionalQuantity: number): Promise<void> {
    try {
      for (const ingredient of recipe.ingredients) {
        const quantityToDeduct = (ingredient.quantity * additionalQuantity) / recipe.yield;
        await this.updateInventoryFromUsage(ingredient.name, quantityToDeduct, ingredient.unit);
        console.log(`🔧 Detratto ${quantityToDeduct} ${ingredient.unit} di ${ingredient.name}`);
      }
    } catch (error) {
      console.error('Errore durante detrazione ingredienti:', error);
    }
  }

  // Funzione helper per ripristinare ingredienti quando la produzione diminuisce
  private async restoreIngredientsFromReduction(recipe: Recipe, reducedQuantity: number): Promise<void> {
    try {
      for (const ingredient of recipe.ingredients) {
        const quantityToRestore = (ingredient.quantity * reducedQuantity) / recipe.yield;
        
        // Trova l'ingrediente nel magazzino
        const [inventoryItem] = await db
          .select()
          .from(inventory)
          .where(eq(inventory.name, ingredient.name))
          .limit(1);

        if (inventoryItem) {
          const currentStock = parseInt(inventoryItem.currentStock || '0');
          const newStock = currentStock + quantityToRestore;
          const unitCost = Number(inventoryItem.unitCost || 0);
          const newTotalValue = newStock * unitCost;

          await db
            .update(inventory)
            .set({
              currentStock: newStock.toString(),
              totalValue: newTotalValue.toFixed(2),
              updatedAt: new Date()
            })
            .where(eq(inventory.id, inventoryItem.id));

          console.log(`🔧 Ripristinato ${quantityToRestore} ${ingredient.unit} di ${ingredient.name}`);
        }
      }
    } catch (error) {
      console.error('Errore durante ripristino ingredienti:', error);
    }
  }
}

export const storage = new DatabaseStorage();