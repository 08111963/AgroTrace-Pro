import { db } from "./db";
import { users, subscriptionPlans, subscriptionHistory } from "@shared/schema";
import { eq, and } from "drizzle-orm";

export interface LicenseStatus {
  isValid: boolean;
  status: 'trial' | 'active' | 'expired' | 'cancelled';
  plan: string;
  daysRemaining?: number;
  trialDaysRemaining?: number;
  features: {
    maxRecipes: number;
    maxBatches: number;
    maxInventoryItems: number;
    hasAdvancedReports: boolean;
    hasQRLabels: boolean;
    hasTraceability: boolean;
    hasBackup: boolean;
    hasAPIAccess: boolean;
  };
  message?: string;
  upgradeRequired?: boolean;
}

export class LicenseService {
  
  async initializeSubscriptionPlans() {
    // Controlla se i piani esistono già
    const existingPlans = await db.select().from(subscriptionPlans);
    
    if (existingPlans.length === 0) {
      // Inserisci i piani predefiniti
      await db.insert(subscriptionPlans).values([
        {
          name: "free",
          displayName: "Prova Gratuita",
          description: "7 giorni gratis per testare tutte le funzionalità",
          price: "0.00",
          billingPeriod: "trial",
          trialDays: 7,
          maxRecipes: 5,
          maxBatches: 10,
          maxInventoryItems: 25,
          maxUsers: 1,
          maxStorageGB: 1,
          hasAdvancedReports: false,
          hasQRLabels: true,
          hasTraceability: true,
          hasBackup: false,
          hasAPIAccess: false,
          hasPrioritySupport: false,
        },
        {
          name: "basic",
          displayName: "Piano Base",
          description: "Perfetto per piccole aziende agricole",
          price: "29.99",
          billingPeriod: "monthly",
          trialDays: 7,
          maxRecipes: 50,
          maxBatches: 100,
          maxInventoryItems: 200,
          maxUsers: 2,
          maxStorageGB: 5,
          hasAdvancedReports: true,
          hasQRLabels: true,
          hasTraceability: true,
          hasBackup: true,
          hasAPIAccess: false,
          hasPrioritySupport: false,
        },
        {
          name: "premium",
          displayName: "Piano Premium",
          description: "Per aziende in crescita con funzionalità avanzate",
          price: "59.99",
          billingPeriod: "monthly",
          trialDays: 7,
          maxRecipes: -1, // illimitato
          maxBatches: -1,
          maxInventoryItems: -1,
          maxUsers: 5,
          maxStorageGB: 20,
          hasAdvancedReports: true,
          hasQRLabels: true,
          hasTraceability: true,
          hasBackup: true,
          hasAPIAccess: true,
          hasPrioritySupport: true,
        },
        {
          name: "enterprise",
          displayName: "Piano Enterprise",
          description: "Soluzione completa per grandi aziende",
          price: "149.99",
          billingPeriod: "monthly",
          trialDays: 30,
          maxRecipes: -1,
          maxBatches: -1,
          maxInventoryItems: -1,
          maxUsers: -1,
          maxStorageGB: 100,
          hasAdvancedReports: true,
          hasQRLabels: true,
          hasTraceability: true,
          hasBackup: true,
          hasAPIAccess: true,
          hasPrioritySupport: true,
        }
      ]);
      
      console.log("Piani di abbonamento inizializzati con successo");
    }
  }

  async checkUserLicense(userId: number): Promise<LicenseStatus> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    
    if (!user) {
      throw new Error("Utente non trovato");
    }

    const now = new Date();
    
    // Se l'utente è in prova
    if (user.subscriptionStatus === 'trial') {
      const trialEnd = user.trialEndDate;
      
      if (!trialEnd) {
        // Calcola e imposta la data di fine prova (7 giorni dalla registrazione)
        const calculatedTrialEnd = new Date(user.trialStartDate || user.createdAt);
        calculatedTrialEnd.setDate(calculatedTrialEnd.getDate() + 7);
        
        await db.update(users)
          .set({ trialEndDate: calculatedTrialEnd })
          .where(eq(users.id, userId));
          
        return this.checkUserLicense(userId); // Ricontrolla dopo l'aggiornamento
      }
      
      const daysRemaining = Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysRemaining <= 0) {
        // Prova scaduta
        await db.update(users)
          .set({ subscriptionStatus: 'expired' })
          .where(eq(users.id, userId));
          
        return {
          isValid: false,
          status: 'expired',
          plan: 'free',
          features: this.getBasicFeatures(),
          message: "La tua prova gratuita di 7 giorni è scaduta. Sottoscrivi un piano per continuare ad utilizzare AgroTrace Pro.",
          upgradeRequired: true
        };
      }
      
      return {
        isValid: true,
        status: 'trial',
        plan: 'free',
        trialDaysRemaining: daysRemaining,
        features: this.getTrialFeatures(),
        message: `Prova gratuita: ${daysRemaining} giorni rimanenti`
      };
    }
    
    // Se l'utente ha un abbonamento attivo
    if (user.subscriptionStatus === 'active') {
      const subscriptionEnd = user.subscriptionEndDate;
      
      if (!subscriptionEnd) {
        return {
          isValid: false,
          status: 'expired',
          plan: user.subscriptionPlan,
          features: this.getBasicFeatures(),
          message: "Errore nella configurazione dell'abbonamento. Contatta il supporto.",
          upgradeRequired: true
        };
      }
      
      const daysRemaining = Math.ceil((subscriptionEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysRemaining <= 0) {
        // Abbonamento scaduto
        await db.update(users)
          .set({ subscriptionStatus: 'expired' })
          .where(eq(users.id, userId));
          
        return {
          isValid: false,
          status: 'expired',
          plan: user.subscriptionPlan,
          features: this.getBasicFeatures(),
          message: "Il tuo abbonamento è scaduto. Rinnova per continuare ad utilizzare tutte le funzionalità.",
          upgradeRequired: true
        };
      }
      
      const planFeatures = await this.getPlanFeatures(user.subscriptionPlan);
      
      return {
        isValid: true,
        status: 'active',
        plan: user.subscriptionPlan,
        daysRemaining,
        features: planFeatures,
        message: daysRemaining <= 7 ? `Il tuo abbonamento scade tra ${daysRemaining} giorni` : undefined
      };
    }
    
    // Abbonamento scaduto o cancellato
    return {
      isValid: false,
      status: user.subscriptionStatus as any,
      plan: user.subscriptionPlan,
      features: this.getBasicFeatures(),
      message: "Il tuo abbonamento non è attivo. Sottoscrivi un piano per accedere a tutte le funzionalità.",
      upgradeRequired: true
    };
  }

  private async getPlanFeatures(planName: string) {
    const [plan] = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.name, planName));
    
    if (!plan) {
      return this.getBasicFeatures();
    }
    
    return {
      maxRecipes: plan.maxRecipes || -1,
      maxBatches: plan.maxBatches || -1,
      maxInventoryItems: plan.maxInventoryItems || -1,
      hasAdvancedReports: plan.hasAdvancedReports || false,
      hasQRLabels: plan.hasQRLabels || false,
      hasTraceability: plan.hasTraceability || false,
      hasBackup: plan.hasBackup || false,
      hasAPIAccess: plan.hasAPIAccess || false,
    };
  }

  private getTrialFeatures() {
    return {
      maxRecipes: 5,
      maxBatches: 10,
      maxInventoryItems: 25,
      hasAdvancedReports: false,
      hasQRLabels: true,
      hasTraceability: true,
      hasBackup: false,
      hasAPIAccess: false,
    };
  }

  private getBasicFeatures() {
    return {
      maxRecipes: 2,
      maxBatches: 3,
      maxInventoryItems: 10,
      hasAdvancedReports: false,
      hasQRLabels: false,
      hasTraceability: false,
      hasBackup: false,
      hasAPIAccess: false,
    };
  }

  async validateFeatureAccess(userId: number, feature: string): Promise<boolean> {
    const license = await this.checkUserLicense(userId);
    
    if (!license.isValid) {
      return false;
    }
    
    switch (feature) {
      case 'advanced_reports':
        return license.features.hasAdvancedReports;
      case 'qr_labels':
        return license.features.hasQRLabels;
      case 'traceability':
        return license.features.hasTraceability;
      case 'backup':
        return license.features.hasBackup;
      case 'api_access':
        return license.features.hasAPIAccess;
      default:
        return true;
    }
  }

  async checkResourceLimit(userId: number, resource: 'recipes' | 'batches' | 'inventory', currentCount: number): Promise<boolean> {
    const license = await this.checkUserLicense(userId);
    
    if (!license.isValid) {
      return false;
    }
    
    switch (resource) {
      case 'recipes':
        return license.features.maxRecipes === -1 || currentCount < license.features.maxRecipes;
      case 'batches':
        return license.features.maxBatches === -1 || currentCount < license.features.maxBatches;
      case 'inventory':
        return license.features.maxInventoryItems === -1 || currentCount < license.features.maxInventoryItems;
      default:
        return true;
    }
  }

  async getAllPlans() {
    return await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.isActive, true));
  }

  async startTrial(userId: number) {
    const now = new Date();
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + 7);
    
    await db.update(users)
      .set({
        subscriptionStatus: 'trial',
        subscriptionPlan: 'free',
        trialStartDate: now,
        trialEndDate: trialEnd
      })
      .where(eq(users.id, userId));
  }

  async upgradePlan(userId: number, planName: string, paymentMethod?: string) {
    const [plan] = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.name, planName));
    
    if (!plan) {
      throw new Error("Piano non trovato");
    }
    
    const now = new Date();
    const subscriptionEnd = new Date();
    
    // Calcola la data di scadenza in base al periodo di fatturazione
    if (plan.billingPeriod === 'monthly') {
      subscriptionEnd.setMonth(subscriptionEnd.getMonth() + 1);
    } else if (plan.billingPeriod === 'yearly') {
      subscriptionEnd.setFullYear(subscriptionEnd.getFullYear() + 1);
    }
    
    await db.update(users)
      .set({
        subscriptionStatus: 'active',
        subscriptionPlan: planName,
        subscriptionStartDate: now,
        subscriptionEndDate: subscriptionEnd,
        lastPaymentDate: now,
        nextBillingDate: subscriptionEnd,
        paymentMethod: paymentMethod || null
      })
      .where(eq(users.id, userId));
      
    // Registra nella cronologia
    await db.insert(subscriptionHistory).values({
      userId,
      planId: plan.id,
      status: 'started',
      startDate: now,
      endDate: subscriptionEnd,
      amount: plan.price,
      paymentMethod: paymentMethod || null,
      notes: `Upgrade a piano ${plan.displayName}`
    });
  }
}

export const licenseService = new LicenseService();