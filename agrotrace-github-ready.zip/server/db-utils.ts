import { db } from "./db";

/**
 * Wrapper per operazioni database con retry automatico e gestione errori
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      console.warn(`Database operation failed (attempt ${attempt}/${maxRetries}):`, error);
      
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, delay * attempt));
      }
    }
  }
  
  throw lastError!;
}

/**
 * Esegue query con gestione errori sicura
 */
export async function safeQuery<T>(
  queryFn: () => Promise<T>,
  fallback?: T
): Promise<T | undefined> {
  try {
    return await withRetry(queryFn);
  } catch (error) {
    console.error('Database query failed:', error);
    return fallback;
  }
}

/**
 * Transazione sicura con rollback automatico
 */
export async function safeTransaction<T>(
  transactionFn: (tx: any) => Promise<T>
): Promise<T | null> {
  try {
    return await db.transaction(async (tx) => {
      return await transactionFn(tx);
    });
  } catch (error) {
    console.error('Transaction failed and rolled back:', error);
    return null;
  }
}