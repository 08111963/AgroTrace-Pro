import { 
  recipes, batches, inventory, qrLabels, alerts, users, ingredientTracking, passwordResetTokens, companyProfiles,
  Recipe, InsertRecipe, 
  Batch, InsertBatch,
  InventoryItem, InsertInventoryItem,
  QRLabel, InsertQRLabel,
  Alert, InsertAlert,
  User, InsertUser,
  IngredientTracking, InsertIngredientTracking,
  CompanyProfile, InsertCompanyProfile
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Recipes
  getRecipes(): Promise<Recipe[]>;
  getRecipe(id: number): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: number, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined>;
  deleteRecipe(id: number): Promise<boolean>;

  // Batches
  getBatches(): Promise<Batch[]>;
  getBatch(id: number): Promise<Batch | undefined>;
  getBatchByCode(code: string): Promise<Batch | undefined>;
  createBatch(batch: InsertBatch): Promise<Batch>;
  updateBatch(id: number, batch: Partial<InsertBatch>): Promise<Batch | undefined>;
  deleteBatch(id: number): Promise<boolean>;
  generateBatchCode(): Promise<string>;

  // Inventory
  getInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  getInventoryItemByCode(code: string): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;

  // QR Labels
  getQRLabels(): Promise<QRLabel[]>;
  getQRLabel(id: number): Promise<QRLabel | undefined>;
  getQRLabelByBatchId(batchId: number): Promise<QRLabel | undefined>;
  createQRLabel(label: InsertQRLabel): Promise<QRLabel>;

  // Alerts
  getAlerts(): Promise<Alert[]>;
  getActiveAlerts(): Promise<Alert[]>;
  getAlert(id: number): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  resolveAlert(id: number): Promise<boolean>;
  
  // Automatic monitoring and alerts
  checkInventoryAlerts(): Promise<Alert[]>;
  createLowStockAlert(item: InventoryItem): Promise<Alert>;
  createExpiryAlert(item: InventoryItem): Promise<Alert>;
  monitorInventoryStatus(): Promise<{ alertsCreated: number; alertsResolved: number }>;

  // Dashboard stats
  getDashboardStats(): Promise<{
    totalRecipes: number;
    activeBatches: number;
    inventoryItems: number;
    activeAlerts: number;
    lowStockItems: number;
    totalInventoryValue: number;
  }>;

  // Traceability
  getTraceabilityByBatchCode(batchCode: string): Promise<{
    batch: Batch;
    recipe?: Recipe;
    qrLabel?: QRLabel;
  } | null>;

  // Ingredient Tracking
  getIngredientTracking(): Promise<IngredientTracking[]>;
  createIngredientTracking(tracking: InsertIngredientTracking): Promise<IngredientTracking>;
  getIngredientUsageByBatch(batchId: number): Promise<IngredientTracking[]>;
  getIngredientAvailability(ingredientName: string): Promise<{
    currentStock: number;
    minimumStock: number;
    status: 'ok' | 'low' | 'critical';
    daysRemaining?: number;
  }>;
  checkLowStockIngredients(): Promise<InventoryItem[]>;
  updateInventoryFromUsage(ingredientName: string, quantityUsed: number, unit: string): Promise<boolean>;
  updateInventoryFromRecipe(recipeId: number, quantityProduced: number): Promise<void>;
  updateInventoryCodeWithBatch(recipeId: number, batchCode: string): Promise<void>;

  // User authentication
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserById(id: number): Promise<User | undefined>;
  validateUserPassword(username: string, password: string): Promise<User | null>;
  validateUserPasswordByEmail(email: string, password: string): Promise<User | null>;
  updateUserPassword(userId: number, newPassword: string): Promise<boolean>;
  getAllUsers(): Promise<User[]>;

  // Password reset tokens
  createPasswordResetToken(userId: number): Promise<string>;
  validatePasswordResetToken(token: string): Promise<{ userId: number; valid: boolean }>;
  usePasswordResetToken(token: string): Promise<boolean>;

  // Company profiles
  getCompanyProfile(userId: number): Promise<CompanyProfile | undefined>;
  createCompanyProfile(profile: InsertCompanyProfile): Promise<CompanyProfile>;
  updateCompanyProfile(userId: number, profile: Partial<InsertCompanyProfile>): Promise<CompanyProfile | undefined>;
}

export class MemStorage implements IStorage {
  private recipes: Map<number, Recipe> = new Map();
  private batches: Map<number, Batch> = new Map();
  private inventory: Map<number, InventoryItem> = new Map();
  private qrLabels: Map<number, QRLabel> = new Map();
  private alerts: Map<number, Alert> = new Map();
  private ingredientTracking: Map<number, IngredientTracking> = new Map();
  
  private currentIds = {
    recipes: 1,
    batches: 1,
    inventory: 1,
    qrLabels: 1,
    alerts: 1,
    ingredientTracking: 1,
  };

  private batchCounter = 1;

  constructor() {
    this.seedInitialData();
  }

  private seedInitialData() {
    // Ricette iniziali
    const initialRecipes: InsertRecipe[] = [
      {
        name: "Salsa di Pomodoro Bio",
        category: "Salse",
        description: "Salsa tradizionale con pomodori San Marzano DOP",
        ingredients: [
          { name: "Pomodori San Marzano DOP", quantity: 5, unit: "kg", cost: 3.50, allergens: [] },
          { name: "Basilico fresco", quantity: 100, unit: "g", cost: 2.00, allergens: [] },
          { name: "Aglio", quantity: 50, unit: "g", cost: 0.50, allergens: [] },
          { name: "Olio extravergine", quantity: 200, unit: "ml", cost: 4.00, allergens: [] },
          { name: "Sale marino", quantity: 20, unit: "g", cost: 0.10, allergens: [] }
        ],
        allergens: [],
        instructions: "1. Sbollentare i pomodori e pelare. 2. Tritare aglio e basilico. 3. Soffriggere. 4. Aggiungere pomodori e cuocere 30 min. 5. Aggiungere basilico e sale.",
        preparationTime: 90,
        yield: "20 vasetti da 300g",
        productionCost: "10.10",
        status: "active"
      },
      {
        name: "Pesto Genovese DOP",
        category: "Salse", 
        description: "Pesto tradizionale ligure con certificazione DOP",
        ingredients: [
          { name: "Basilico genovese DOP", quantity: 500, unit: "g", cost: 8.00, allergens: [] },
          { name: "Parmigiano Reggiano", quantity: 200, unit: "g", cost: 12.00, allergens: ["latte"] },
          { name: "Pecorino romano", quantity: 100, unit: "g", cost: 6.00, allergens: ["latte"] },
          { name: "Pinoli", quantity: 150, unit: "g", cost: 15.00, allergens: ["frutta a guscio"] },
          { name: "Aglio", quantity: 30, unit: "g", cost: 0.30, allergens: [] },
          { name: "Olio EVO ligure", quantity: 300, unit: "ml", cost: 8.00, allergens: [] }
        ],
        allergens: ["latte", "frutta a guscio"],
        instructions: "1. Pestare basilico con aglio e sale. 2. Aggiungere pinoli. 3. Incorporare formaggi. 4. Emulsionare con olio.",
        preparationTime: 45,
        yield: "15 vasetti da 180g",
        productionCost: "49.30",
        status: "active"
      }
    ];

    initialRecipes.forEach(recipe => this.createRecipe(recipe));

    // Inventario iniziale
    const initialInventory: InsertInventoryItem[] = [
      {
        code: "SM001",
        name: "Pomodori San Marzano DOP",
        category: "materie_prime",
        currentStock: "150",
        unit: "kg",
        minimumStock: "50",
        unitCost: "3.50",
        supplier: "Azienda Agricola Vesuvio",
        location: "Magazzino A - Scaffale 1",
        status: "available"
      },
      {
        code: "BF001", 
        name: "Basilico fresco Bio",
        category: "materie_prime",
        currentStock: "15",
        unit: "kg",
        minimumStock: "20",
        unitCost: "12.00",
        supplier: "Cooperativa Verde",
        location: "Cella frigorifera",
        status: "low_stock"
      },
      {
        code: "OEO001",
        name: "Olio Extravergine di Oliva",
        category: "materie_prime", 
        currentStock: "200",
        unit: "L",
        minimumStock: "100",
        unitCost: "8.50",
        supplier: "Frantoio del Sole",
        location: "Magazzino B - Zona liquidi",
        status: "available"
      },
      {
        code: "VAS001",
        name: "Vasetti in vetro 300g",
        category: "imballaggi",
        currentStock: "500",
        unit: "pz",
        minimumStock: "200",
        unitCost: "0.45",
        supplier: "Vetreria Italiana",
        location: "Magazzino C - Scaffale 3",
        status: "available"
      }
    ];

    initialInventory.forEach(item => this.createInventoryItem(item));

    // Lotti iniziali
    const initialBatches: InsertBatch[] = [
      {
        code: "LT2024001",
        recipeId: 1,
        productName: "Salsa di Pomodoro Bio",
        quantity: "500",
        unit: "vasetti",
        status: "active",
        productionDate: new Date("2024-01-15"),
        expiryDate: new Date("2025-01-15"),
        notes: "Lotto per ordine GDO Roma"
      },
      {
        code: "LT2024002", 
        recipeId: 2,
        productName: "Pesto Genovese DOP",
        quantity: "300",
        unit: "vasetti",
        status: "active",
        productionDate: new Date("2024-01-14"),
        expiryDate: new Date("2024-07-14"),
        notes: "Lotto per mercato locale"
      }
    ];

    initialBatches.forEach(batch => this.createBatch(batch));

    // Alert iniziali
    const initialAlerts: InsertAlert[] = [
      {
        type: "low_stock",
        message: "Basilico fresco Bio sotto soglia minima (15kg rimanenti, minimo 20kg)",
        severity: "high",
        referenceTable: "inventory",
        referenceId: 2,
        resolved: false
      }
    ];

    initialAlerts.forEach(alert => this.createAlert(alert));
  }

  // Recipes
  async getRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const id = this.currentIds.recipes++;
    const now = new Date();
    const recipe: Recipe = { 
      ...insertRecipe, 
      id,
      description: insertRecipe.description || null,
      allergens: insertRecipe.allergens || [],
      ingredients: insertRecipe.ingredients || [],
      productionCost: insertRecipe.productionCost || null,
      status: insertRecipe.status || "active",
      createdAt: now, 
      updatedAt: now 
    };
    this.recipes.set(id, recipe);
    return recipe;
  }

  async updateRecipe(id: number, updateData: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const existing = this.recipes.get(id);
    if (!existing) return undefined;
    
    const updated: Recipe = { 
      ...existing, 
      ...updateData,
      allergens: updateData.allergens || existing.allergens || [],
      ingredients: updateData.ingredients || existing.ingredients || [],
      updatedAt: new Date() 
    };
    this.recipes.set(id, updated);
    return updated;
  }

  async deleteRecipe(id: number): Promise<boolean> {
    return this.recipes.delete(id);
  }

  // Batches
  async getBatches(): Promise<Batch[]> {
    return Array.from(this.batches.values());
  }

  async getBatch(id: number): Promise<Batch | undefined> {
    return this.batches.get(id);
  }

  async getBatchByCode(code: string): Promise<Batch | undefined> {
    return Array.from(this.batches.values()).find(batch => batch.code === code);
  }

  async generateBatchCode(): Promise<string> {
    const year = new Date().getFullYear();
    const code = `LT${year}${String(this.batchCounter++).padStart(3, '0')}`;
    return code;
  }

  async createBatch(insertBatch: InsertBatch): Promise<Batch> {
    const id = this.currentIds.batches++;
    const now = new Date();
    const batch: Batch = { 
      ...insertBatch, 
      id,
      status: insertBatch.status || "active",
      recipeId: insertBatch.recipeId || null,
      expiryDate: insertBatch.expiryDate || null,
      notes: insertBatch.notes || null,
      qrCode: insertBatch.qrCode || null,
      createdAt: now, 
      updatedAt: now 
    };
    this.batches.set(id, batch);

    return batch;
  }

  async updateBatch(id: number, updateData: Partial<InsertBatch>): Promise<Batch | undefined> {
    const existing = this.batches.get(id);
    if (!existing) return undefined;
    
    const updated: Batch = { 
      ...existing, 
      ...updateData, 
      updatedAt: new Date() 
    };
    this.batches.set(id, updated);
    return updated;
  }

  async deleteBatch(id: number): Promise<boolean> {
    return this.batches.delete(id);
  }

  // Inventory
  async getInventoryItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventory.values());
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    return this.inventory.get(id);
  }

  async getInventoryItemByCode(code: string): Promise<InventoryItem | undefined> {
    return Array.from(this.inventory.values()).find(item => item.code === code);
  }

  async createInventoryItem(insertItem: InsertInventoryItem): Promise<InventoryItem> {
    const id = this.currentIds.inventory++;
    const now = new Date();
    
    // Auto-update status based on stock levels
    let status = "available";
    if (Number(insertItem.currentStock) <= 0) {
      status = "out_of_stock";
    } else if (Number(insertItem.currentStock) <= Number(insertItem.minimumStock)) {
      status = "low_stock";
    }

    const item: InventoryItem = { 
      ...insertItem, 
      id,
      currentStock: insertItem.currentStock || "0",
      minimumStock: insertItem.minimumStock || "0",
      unitCost: insertItem.unitCost || null,
      supplier: insertItem.supplier || null,
      location: insertItem.location || null,
      expiryDate: insertItem.expiryDate || null,
      status,
      createdAt: now, 
      updatedAt: now 
    };
    this.inventory.set(id, item);
    return item;
  }

  async updateInventoryItem(id: number, updateData: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const existing = this.inventory.get(id);
    if (!existing) return undefined;
    
    const updated: InventoryItem = { 
      ...existing, 
      ...updateData, 
      updatedAt: new Date() 
    };

    // Auto-update status based on stock levels
    if (updateData.currentStock !== undefined || updateData.minimumStock !== undefined) {
      const currentStock = Number(updateData.currentStock ?? existing.currentStock);
      const minimumStock = Number(updateData.minimumStock ?? existing.minimumStock);
      
      if (currentStock <= 0) {
        updated.status = "out_of_stock";
      } else if (currentStock <= minimumStock) {
        updated.status = "low_stock";
      } else {
        updated.status = "available";
      }
    }

    this.inventory.set(id, updated);
    return updated;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    return this.inventory.delete(id);
  }

  // QR Labels
  async getQRLabels(): Promise<QRLabel[]> {
    return Array.from(this.qrLabels.values());
  }

  async getQRLabel(id: number): Promise<QRLabel | undefined> {
    return this.qrLabels.get(id);
  }

  async getQRLabelByBatchId(batchId: number): Promise<QRLabel | undefined> {
    return Array.from(this.qrLabels.values()).find(label => label.batchId === batchId);
  }

  async createQRLabel(insertLabel: InsertQRLabel): Promise<QRLabel> {
    const id = this.currentIds.qrLabels++;
    const now = new Date();
    const label: QRLabel = { 
      ...insertLabel, 
      id,
      batchId: insertLabel.batchId || null,
      generatedAt: now 
    };
    this.qrLabels.set(id, label);
    return label;
  }

  // Alerts
  async getAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values());
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter(alert => !alert.resolved);
  }

  async getAlert(id: number): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentIds.alerts++;
    const now = new Date();
    const alert: Alert = { 
      ...insertAlert, 
      id,
      severity: insertAlert.severity || "medium",
      resolved: insertAlert.resolved || false,
      referenceTable: insertAlert.referenceTable || null,
      referenceId: insertAlert.referenceId || null,
      createdAt: now,
      resolvedAt: null
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async resolveAlert(id: number): Promise<boolean> {
    const alert = this.alerts.get(id);
    if (!alert) return false;
    
    const updated: Alert = { 
      ...alert, 
      resolved: true,
      resolvedAt: new Date()
    };
    this.alerts.set(id, updated);
    return true;
  }

  // Dashboard stats
  async getDashboardStats() {
    const recipes = Array.from(this.recipes.values());
    const batches = Array.from(this.batches.values());
    const inventory = Array.from(this.inventory.values());
    const activeAlerts = Array.from(this.alerts.values()).filter(alert => !alert.resolved);

    const activeBatches = batches.filter(batch => batch.status === "active").length;
    const lowStockItems = inventory.filter(item => item.status === "low_stock" || item.status === "out_of_stock").length;
    const totalInventoryValue = inventory.reduce((sum, item) => {
      const value = Number(item.currentStock) * Number(item.unitCost || 0);
      return sum + value;
    }, 0);

    return {
      totalRecipes: recipes.length,
      activeBatches,
      inventoryItems: inventory.length,
      activeAlerts: activeAlerts.length,
      lowStockItems,
      totalInventoryValue,
    };
  }

  // Traceability
  async getTraceabilityByBatchCode(batchCode: string): Promise<{
    batch: Batch;
    recipe?: Recipe;
    qrLabel?: QRLabel;
  } | null> {
    const batch = await this.getBatchByCode(batchCode);
    if (!batch) return null;

    const recipe = batch.recipeId ? await this.getRecipe(batch.recipeId) : undefined;
    const qrLabel = await this.getQRLabelByBatchId(batch.id);

    return {
      batch,
      recipe,
      qrLabel,
    };
  }

  // Ingredient Tracking
  async getIngredientTracking(): Promise<IngredientTracking[]> {
    return Array.from(this.ingredientTracking.values());
  }

  async createIngredientTracking(insertTracking: InsertIngredientTracking): Promise<IngredientTracking> {
    const id = this.currentIds.ingredientTracking++;
    const now = new Date();
    
    const tracking: IngredientTracking = {
      ...insertTracking,
      id,
      usageDate: insertTracking.usageDate || now,
      createdAt: now
    };
    
    this.ingredientTracking.set(id, tracking);
    
    // Aggiorna automaticamente l'inventario se disponibile
    await this.updateInventoryFromUsage(
      insertTracking.ingredientName,
      Number(insertTracking.quantityUsed),
      insertTracking.unit
    );
    
    return tracking;
  }

  async getIngredientUsageByBatch(batchId: number): Promise<IngredientTracking[]> {
    return Array.from(this.ingredientTracking.values())
      .filter(tracking => tracking.batchId === batchId);
  }

  async getIngredientAvailability(ingredientName: string): Promise<{
    currentStock: number;
    minimumStock: number;
    status: 'ok' | 'low' | 'critical';
    daysRemaining?: number;
  }> {
    const inventoryItem = Array.from(this.inventory.values())
      .find(item => item.name.toLowerCase() === ingredientName.toLowerCase());
    
    if (!inventoryItem) {
      return {
        currentStock: 0,
        minimumStock: 0,
        status: 'critical'
      };
    }

    const currentStock = Number(inventoryItem.currentStock);
    const minimumStock = Number(inventoryItem.minimumStock);
    
    let status: 'ok' | 'low' | 'critical' = 'ok';
    if (currentStock <= 0) {
      status = 'critical';
    } else if (currentStock <= minimumStock) {
      status = 'low';
    }

    // Calcola giorni rimanenti basati su consumo medio giornaliero
    const usageHistory = Array.from(this.ingredientTracking.values())
      .filter(tracking => tracking.ingredientName.toLowerCase() === ingredientName.toLowerCase())
      .sort((a, b) => new Date(b.usageDate).getTime() - new Date(a.usageDate).getTime())
      .slice(0, 30); // Ultimi 30 utilizzi

    let daysRemaining: number | undefined;
    if (usageHistory.length > 0) {
      const totalUsage = usageHistory.reduce((sum, tracking) => sum + Number(tracking.quantityUsed), 0);
      const averageDailyUsage = totalUsage / Math.max(usageHistory.length, 1);
      if (averageDailyUsage > 0) {
        daysRemaining = Math.floor(currentStock / averageDailyUsage);
      }
    }

    return {
      currentStock,
      minimumStock,
      status,
      daysRemaining
    };
  }

  async checkLowStockIngredients(): Promise<InventoryItem[]> {
    const inventory = Array.from(this.inventory.values());
    return inventory.filter(item => {
      const current = Number(item.currentStock);
      const minimum = Number(item.minimumStock);
      return current <= minimum;
    });
  }

  async updateInventoryFromUsage(ingredientName: string, quantityUsed: number, unit: string): Promise<boolean> {
    // Non implementata in MemStorage - solo placeholder per compatibilità interfaccia
    console.warn("updateInventoryFromUsage non implementata in MemStorage");
    return false;
  }



  // Placeholder per compatibilità interfaccia (non implementata in MemStorage)
  async updateInventoryFromRecipe(recipeId: number, quantityProduced: number): Promise<void> {
    // Non implementata in MemStorage - solo per compatibilità interfaccia
    console.warn("updateInventoryFromRecipe non implementata in MemStorage");
  }

  async updateInventoryCodeWithBatch(recipeId: number, batchCode: string): Promise<void> {
    // Non implementata in MemStorage - solo per compatibilità interfaccia
    console.warn("updateInventoryCodeWithBatch non implementata in MemStorage");
  }

  // User authentication methods (placeholder for MemStorage)
  async getUserByUsername(username: string): Promise<User | undefined> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async createUser(user: InsertUser): Promise<User> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async getUserById(id: number): Promise<User | undefined> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async validateUserPassword(username: string, password: string): Promise<User | null> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async validateUserPasswordByEmail(email: string, password: string): Promise<User | null> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async updateUserPassword(userId: number, newPassword: string): Promise<boolean> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async getAllUsers(): Promise<User[]> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async createPasswordResetToken(userId: number): Promise<string> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async validatePasswordResetToken(token: string): Promise<{ userId: number; valid: boolean }> {
    throw new Error("Authentication not supported in MemStorage");
  }

  async usePasswordResetToken(token: string): Promise<boolean> {
    throw new Error("Authentication not supported in MemStorage");
  }

  // Company profiles
  async getCompanyProfile(userId: number): Promise<CompanyProfile | undefined> {
    throw new Error("Company profiles not supported in MemStorage");
  }

  async createCompanyProfile(profile: InsertCompanyProfile): Promise<CompanyProfile> {
    throw new Error("Company profiles not supported in MemStorage");
  }

  async updateCompanyProfile(userId: number, profile: Partial<InsertCompanyProfile>): Promise<CompanyProfile | undefined> {
    throw new Error("Company profiles not supported in MemStorage");
  }

  // Automatic monitoring and alerts
  async checkInventoryAlerts(): Promise<Alert[]> {
    throw new Error("Inventory alerts not supported in MemStorage");
  }

  async createLowStockAlert(item: InventoryItem): Promise<Alert> {
    throw new Error("Inventory alerts not supported in MemStorage");
  }

  async createExpiryAlert(item: InventoryItem): Promise<Alert> {
    throw new Error("Inventory alerts not supported in MemStorage");
  }

  async monitorInventoryStatus(): Promise<{ alertsCreated: number; alertsResolved: number }> {
    throw new Error("Inventory monitoring not supported in MemStorage");
  }
}

// Implementazione DatabaseStorage che usa PostgreSQL
export class DatabaseStorage implements IStorage {
  // Recipes
  async getRecipes(): Promise<Recipe[]> {
    return await db.select().from(recipes).orderBy(desc(recipes.createdAt));
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe || undefined;
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const [recipe] = await db
      .insert(recipes)
      .values({
        ...insertRecipe,
        allergens: insertRecipe.allergens || [],
        ingredients: insertRecipe.ingredients || [],
        status: insertRecipe.status || "active"
      })
      .returning();
    
    // Sincronizza automaticamente con il magazzino se presente prezzo di vendita
    if (recipe.salePrice) {
      await this.syncRecipeToInventory(recipe);
    }
    
    return recipe;
  }

  async updateRecipe(id: number, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const [updated] = await db
      .update(recipes)
      .set({ ...recipe, updatedAt: new Date() })
      .where(eq(recipes.id, id))
      .returning();
    
    // Sincronizza automaticamente i dati con il magazzino se presenti prezzo di vendita e costi
    if (updated && recipe.salePrice) {
      console.log('Sincronizzazione ricetta con magazzino:', updated.name, 'prezzo:', recipe.salePrice);
      try {
        await this.syncRecipeToInventory(updated);
        console.log('Sincronizzazione completata con successo');
      } catch (error) {
        console.error('Errore durante sincronizzazione:', error);
      }
    }
    
    return updated || undefined;
  }

  async deleteRecipe(id: number): Promise<boolean> {
    const result = await db.delete(recipes).where(eq(recipes.id, id));
    return result.rowCount > 0;
  }

  // Sincronizza automaticamente ricetta con magazzino
  async syncRecipeToInventory(recipe: Recipe): Promise<void> {
    if (!recipe.salePrice) return;

    // Calcola il costo di produzione completo
    const productionCost = await this.calculateRecipeProductionCost(recipe);
    const salePrice = parseFloat(recipe.salePrice);
    const profit = salePrice - productionCost;

    // Cerca se esiste già un item nel magazzino per questo prodotto finito
    const existingInventoryItem = await db
      .select()
      .from(inventory)
      .where(eq(inventory.name, recipe.name))
      .limit(1);

    const inventoryData = {
      name: recipe.name,
      category: "Prodotti Finiti",
      code: `PF-${recipe.id}`,
      unit: "pz",
      unitCost: productionCost.toFixed(2),
      salePrice: salePrice.toFixed(2),
      profit: profit.toFixed(2),
      status: "available",
      updatedAt: new Date()
    };

    if (existingInventoryItem.length > 0) {
      // Aggiorna item esistente
      await db
        .update(inventory)
        .set(inventoryData)
        .where(eq(inventory.id, existingInventoryItem[0].id));
    } else {
      // Crea nuovo item nel magazzino
      await db.insert(inventory).values({
        ...inventoryData,
        currentStock: "0",
        minimumStock: "5"
      });
    }
  }

  // Calcola il costo di produzione completo di una ricetta
  async calculateRecipeProductionCost(recipe: Recipe): Promise<number> {
    let ingredientsCost = 0;

    // Calcola costo ingredienti
    for (const ingredient of recipe.ingredients) {
      const cost = ingredient.cost || 0;
      let quantity = ingredient.quantity;
      
      // Converti in kg/l se necessario
      if (ingredient.unit === 'g') quantity = quantity / 1000;
      if (ingredient.unit === 'ml') quantity = quantity / 1000;
      
      ingredientsCost += cost * quantity;
    }

    // Calcola costi di confezionamento
    const packagingCostPerUnit = 0.48; // Costo vasetto in vetro
    const yieldCount = recipe.yield || 1;
    const totalPackagingCost = packagingCostPerUnit * yieldCount;

    // Calcola costi generali (overhead)
    const preparationTimeHours = (recipe.preparationTime || 60) / 60;
    const overheadCosts = {
      electricity: 0.25 * preparationTimeHours,
      machinery: 2.5 * preparationTimeHours,
      labor: 15 * preparationTimeHours,
      facility: 1.2 * preparationTimeHours,
      other: 0.8 * preparationTimeHours
    };

    const totalOverheadCosts = Object.values(overheadCosts).reduce((sum, cost) => sum + cost, 0);
    const totalBatchCost = ingredientsCost + totalPackagingCost + totalOverheadCosts;
    
    return totalBatchCost / yieldCount;
  }

  // Batches
  async getBatches(): Promise<Batch[]> {
    return await db.select().from(batches).orderBy(desc(batches.createdAt));
  }

  async getBatch(id: number): Promise<Batch | undefined> {
    const [batch] = await db.select().from(batches).where(eq(batches.id, id));
    return batch || undefined;
  }

  async getBatchByCode(code: string): Promise<Batch | undefined> {
    const [batch] = await db.select().from(batches).where(eq(batches.code, code));
    return batch || undefined;
  }

  async createBatch(batch: InsertBatch): Promise<Batch> {
    const [created] = await db
      .insert(batches)
      .values({
        ...batch,
        status: batch.status || "active"
      })
      .returning();

    // Se il lotto è collegato a una ricetta, aggiorna automaticamente le scorte ingredienti
    if (batch.recipeId) {
      await this.updateInventoryFromRecipe(batch.recipeId, parseFloat(batch.quantity));
      
      // Aggiorna il codice prodotto nel magazzino con il numero di lotto
      await this.updateInventoryCodeWithBatch(batch.recipeId, created.code);
    }

    return created;
  }

  async updateBatch(id: number, batch: Partial<InsertBatch>): Promise<Batch | undefined> {
    const [updated] = await db
      .update(batches)
      .set({ ...batch, updatedAt: new Date() })
      .where(eq(batches.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteBatch(id: number): Promise<boolean> {
    // Prima di eliminare, ottieni i dati del lotto per ripristinare le scorte
    const batch = await this.getBatch(id);
    if (!batch) {
      console.warn(`Lotto non trovato: ${id}`);
      return false;
    }

    console.log('Eliminazione lotto ' + batch.code + ' - Ripristino scorte per ' + batch.quantity + ' ' + batch.unit);

    // Se il lotto è collegato a una ricetta, ripristina le scorte ingredienti
    if (batch.recipeId) {
      await this.restoreInventoryFromBatch(batch.recipeId, parseFloat(batch.quantity));
    }

    const result = await db.delete(batches).where(eq(batches.id, id));
    return result.rowCount > 0;
  }

  async generateBatchCode(): Promise<string> {
    const year = new Date().getFullYear();
    const count = await db.select().from(batches);
    const nextNumber = count.length + 1;
    return `LT${year}${String(nextNumber).padStart(3, '0')}`;
  }

  // Inventory
  async getInventoryItems(): Promise<InventoryItem[]> {
    return await db.select().from(inventory).orderBy(desc(inventory.createdAt));
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventory).where(eq(inventory.id, id));
    return item || undefined;
  }

  async getInventoryItemByCode(code: string): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventory).where(eq(inventory.code, code));
    return item || undefined;
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    // Auto-update status based on stock levels
    let status = "available";
    if (Number(item.currentStock) <= 0) {
      status = "out_of_stock";
    } else if (Number(item.currentStock) <= Number(item.minimumStock)) {
      status = "low_stock";
    }

    const [created] = await db
      .insert(inventory)
      .values({
        ...item,
        status,
        currentStock: item.currentStock || "0",
        minimumStock: item.minimumStock || "0"
      })
      .returning();
    return created;
  }

  async updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const [updated] = await db
      .update(inventory)
      .set({ ...item, updatedAt: new Date() })
      .where(eq(inventory.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    const result = await db.delete(inventory).where(eq(inventory.id, id));
    return result.rowCount > 0;
  }

  // QR Labels
  async getQRLabels(): Promise<QRLabel[]> {
    return await db.select().from(qrLabels).orderBy(desc(qrLabels.generatedAt));
  }

  async getQRLabel(id: number): Promise<QRLabel | undefined> {
    const [label] = await db.select().from(qrLabels).where(eq(qrLabels.id, id));
    return label || undefined;
  }

  async getQRLabelByBatchId(batchId: number): Promise<QRLabel | undefined> {
    const [label] = await db.select().from(qrLabels).where(eq(qrLabels.batchId, batchId));
    return label || undefined;
  }

  async createQRLabel(label: InsertQRLabel): Promise<QRLabel> {
    const [created] = await db
      .insert(qrLabels)
      .values(label)
      .returning();
    return created;
  }

  // Alerts
  async getAlerts(): Promise<Alert[]> {
    return await db.select().from(alerts).orderBy(desc(alerts.createdAt));
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return await db.select().from(alerts).where(eq(alerts.resolved, false));
  }

  async getAlert(id: number): Promise<Alert | undefined> {
    const [alert] = await db.select().from(alerts).where(eq(alerts.id, id));
    return alert || undefined;
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [created] = await db
      .insert(alerts)
      .values(alert)
      .returning();
    return created;
  }

  async resolveAlert(id: number): Promise<boolean> {
    const result = await db
      .update(alerts)
      .set({ resolved: true, updatedAt: new Date() })
      .where(eq(alerts.id, id));
    return result.rowCount > 0;
  }

  // Automatic monitoring and alerts
  async checkInventoryAlerts(): Promise<Alert[]> {
    const inventoryItems = await this.getInventoryItems();
    const existingAlerts = await this.getActiveAlerts();
    const newAlerts: Alert[] = [];

    for (const item of inventoryItems) {
      const currentStock = Number(item.currentStock);
      const minimumStock = Number(item.minimumStock);

      // Check for low stock alerts
      if (currentStock <= minimumStock && currentStock > 0) {
        const existingAlert = existingAlerts.find(alert => 
          alert.type === 'low_stock' && 
          alert.relatedEntity === 'inventory' &&
          alert.relatedEntityId === item.id
        );

        if (!existingAlert) {
          const alert = await this.createLowStockAlert(item);
          newAlerts.push(alert);
        }
      }

      // Check for out of stock alerts
      if (currentStock <= 0) {
        const existingAlert = existingAlerts.find(alert => 
          alert.type === 'out_of_stock' && 
          alert.relatedEntity === 'inventory' &&
          alert.relatedEntityId === item.id
        );

        if (!existingAlert) {
          const alert = await this.createAlert({
            type: 'out_of_stock',
            message: `Prodotto "${item.name}" terminato - scorte a zero`,
            severity: 'high',
            relatedEntity: 'inventory',
            relatedEntityId: item.id
          });
          newAlerts.push(alert);
        }
      }

      // Check for expiry alerts (within 7 days)
      if (item.expiryDate) {
        const today = new Date();
        const expiryDate = new Date(item.expiryDate);
        const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

        if (daysUntilExpiry <= 7 && daysUntilExpiry >= 0) {
          const existingAlert = existingAlerts.find(alert => 
            alert.type === 'expiry_warning' && 
            alert.relatedEntity === 'inventory' &&
            alert.relatedEntityId === item.id
          );

          if (!existingAlert) {
            const alert = await this.createExpiryAlert(item);
            newAlerts.push(alert);
          }
        }
      }

      // Update inventory status based on stock levels
      let newStatus = item.status;
      if (currentStock <= 0) {
        newStatus = 'out_of_stock';
      } else if (currentStock <= minimumStock) {
        newStatus = 'low_stock';
      } else {
        newStatus = 'available';
      }

      if (newStatus !== item.status) {
        await this.updateInventoryItem(item.id, { status: newStatus });
      }
    }

    return newAlerts;
  }

  async createLowStockAlert(item: InventoryItem): Promise<Alert> {
    const currentStock = Number(item.currentStock);
    const minimumStock = Number(item.minimumStock);
    
    return await this.createAlert({
      type: 'low_stock',
      message: `Scorte basse per "${item.name}" - Rimanenti: ${currentStock} ${item.unit} (minimo: ${minimumStock})`,
      severity: 'medium',
      relatedEntity: 'inventory',
      relatedEntityId: item.id
    });
  }

  async createExpiryAlert(item: InventoryItem): Promise<Alert> {
    const today = new Date();
    const expiryDate = new Date(item.expiryDate!);
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    let severity: 'low' | 'medium' | 'high' = 'medium';
    if (daysUntilExpiry <= 2) severity = 'high';
    else if (daysUntilExpiry <= 5) severity = 'medium';
    else severity = 'low';

    return await this.createAlert({
      type: 'expiry_warning',
      message: `"${item.name}" in scadenza tra ${daysUntilExpiry} giorni (${expiryDate.toLocaleDateString()})`,
      severity,
      relatedEntity: 'inventory',
      relatedEntityId: item.id
    });
  }

  async monitorInventoryStatus(): Promise<{ alertsCreated: number; alertsResolved: number }> {
    // Create new alerts for current inventory issues
    const newAlerts = await this.checkInventoryAlerts();
    
    // Resolve alerts for items that no longer have issues
    const activeAlerts = await this.getActiveAlerts();
    const inventoryItems = await this.getInventoryItems();
    let alertsResolved = 0;

    for (const alert of activeAlerts) {
      if (alert.relatedEntity === 'inventory' && alert.relatedEntityId) {
        const item = inventoryItems.find(i => i.id === alert.relatedEntityId);
        
        if (item) {
          const currentStock = Number(item.currentStock);
          const minimumStock = Number(item.minimumStock);
          let shouldResolve = false;

          switch (alert.type) {
            case 'low_stock':
              // Resolve if stock is now above minimum
              shouldResolve = currentStock > minimumStock;
              break;
            case 'out_of_stock':
              // Resolve if stock is now available
              shouldResolve = currentStock > 0;
              break;
            case 'expiry_warning':
              // Resolve if expiry date is more than 7 days away or item expired
              if (item.expiryDate) {
                const today = new Date();
                const expiryDate = new Date(item.expiryDate);
                const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                shouldResolve = daysUntilExpiry > 7 || daysUntilExpiry < 0;
              }
              break;
          }

          if (shouldResolve) {
            await this.resolveAlert(alert.id);
            alertsResolved++;
          }
        }
      }
    }

    return {
      alertsCreated: newAlerts.length,
      alertsResolved
    };
  }

  // Dashboard stats
  async getDashboardStats(): Promise<{
    totalRecipes: number;
    activeBatches: number;
    inventoryItems: number;
    activeAlerts: number;
    lowStockItems: number;
    totalInventoryValue: number;
  }> {
    const [recipesCount, batchesData, inventoryData, alertsData] = await Promise.all([
      db.select().from(recipes),
      db.select().from(batches),
      db.select().from(inventory),
      db.select().from(alerts).where(eq(alerts.resolved, false))
    ]);

    const activeBatches = batchesData.filter(b => b.status === 'active').length;
    const lowStockItems = inventoryData.filter(i => i.status === 'low_stock').length;
    const totalInventoryValue = inventoryData.reduce((sum, item) => {
      const stock = Number(item.currentStock);
      // Per i prodotti finiti usa il prezzo di vendita se impostato, altrimenti il costo unitario
      const price = item.category === 'Prodotti Finiti' && item.salePrice 
        ? Number(item.salePrice) 
        : Number(item.unitCost || 0);
      return sum + (stock * price);
    }, 0);

    return {
      totalRecipes: recipesCount.length,
      activeBatches,
      inventoryItems: inventoryData.length,
      activeAlerts: alertsData.length,
      lowStockItems,
      totalInventoryValue
    };
  }

  // Traceability
  async getTraceabilityByBatchCode(batchCode: string): Promise<{
    batch: Batch;
    recipe?: Recipe;
    qrLabel?: QRLabel;
  } | null> {
    // Query ottimizzata con JOIN per ridurre chiamate database
    const result = await db
      .select({
        batch: batches,
        recipe: recipes,
        qrLabel: qrLabels
      })
      .from(batches)
      .leftJoin(recipes, eq(batches.recipeId, recipes.id))
      .leftJoin(qrLabels, eq(qrLabels.batchId, batches.id))
      .where(eq(batches.code, batchCode))
      .limit(1);

    if (!result.length) return null;

    const { batch, recipe, qrLabel } = result[0];
    
    return {
      batch,
      recipe: recipe || undefined,
      qrLabel: qrLabel || undefined
    };
  }

  // Ingredient Tracking
  async getIngredientTracking(): Promise<IngredientTracking[]> {
    return await db.select().from(ingredientTracking).orderBy(desc(ingredientTracking.createdAt));
  }

  async createIngredientTracking(insertTracking: InsertIngredientTracking): Promise<IngredientTracking> {
    const [tracking] = await db
      .insert(ingredientTracking)
      .values(insertTracking)
      .returning();
    
    // Solo tracking, senza aggiornamento automatico inventario
    // (l'inventario viene aggiornato direttamente da updateInventoryFromRecipe)
    
    return tracking;
  }

  async getIngredientUsageByBatch(batchId: number): Promise<IngredientTracking[]> {
    return await db.select().from(ingredientTracking).where(eq(ingredientTracking.batchId, batchId));
  }

  async getIngredientAvailability(ingredientName: string): Promise<{
    currentStock: number;
    minimumStock: number;
    status: 'ok' | 'low' | 'critical';
    daysRemaining?: number;
  }> {
    const inventoryItems = await db.select().from(inventory);
    const inventoryItem = inventoryItems.find(item => 
      item.name.toLowerCase() === ingredientName.toLowerCase()
    );
    
    if (!inventoryItem) {
      return {
        currentStock: 0,
        minimumStock: 0,
        status: 'critical'
      };
    }

    const currentStock = Number(inventoryItem.currentStock);
    const minimumStock = Number(inventoryItem.minimumStock);
    
    let status: 'ok' | 'low' | 'critical' = 'ok';
    if (currentStock <= 0) {
      status = 'critical';
    } else if (currentStock <= minimumStock) {
      status = 'low';
    }

    // Calcola giorni rimanenti basati su consumo medio giornaliero
    const usageHistory = await db.select()
      .from(ingredientTracking)
      .where(eq(ingredientTracking.ingredientName, ingredientName))
      .orderBy(desc(ingredientTracking.usageDate))
      .limit(30);

    let daysRemaining: number | undefined;
    let averageDailyUsage: number | undefined;
    
    if (usageHistory.length >= 2) {
      // Calcola i giorni effettivi tra primo e ultimo utilizzo
      const firstUsage = usageHistory[usageHistory.length - 1]; // Il più vecchio
      const lastUsage = usageHistory[0]; // Il più recente
      
      const daysBetween = Math.max(1, Math.ceil(
        (lastUsage.usageDate.getTime() - firstUsage.usageDate.getTime()) / (1000 * 60 * 60 * 24)
      ));
      
      const totalUsage = usageHistory.reduce((sum, tracking) => sum + Number(tracking.quantityUsed), 0);
      averageDailyUsage = Math.round((totalUsage / daysBetween) * 100) / 100;
      
      if (averageDailyUsage > 0) {
        daysRemaining = Math.floor(currentStock / averageDailyUsage);
      }
    }

    return {
      currentStock,
      minimumStock,
      status,
      daysRemaining,
      averageDailyUsage
    };
  }

  async checkLowStockIngredients(): Promise<InventoryItem[]> {
    const inventoryItems = await db.select().from(inventory);
    return inventoryItems.filter(item => {
      const current = Number(item.currentStock);
      const minimum = Number(item.minimumStock);
      return current <= minimum;
    });
  }

  // Aggiunto flag per prevenire chiamate multiple della stessa funzione
  private updatingInventory = new Set<string>();

  async updateInventoryFromUsage(ingredientName: string, quantityUsed: number, unit: string): Promise<boolean> {
    const key = `${ingredientName}-${unit}-${quantityUsed}`;
    
    if (this.updatingInventory.has(key)) {
      console.warn(`⚠️ Aggiornamento già in corso per ${ingredientName}, ignoro duplicato`);
      return false;
    }
    
    this.updatingInventory.add(key);
    
    try {
      console.log('[UNICO] Cerco ingrediente: "' + ingredientName + '" con unità: "' + unit + '"');
      
      const inventoryItems = await db.select().from(inventory);
      console.log(`Inventario disponibile:`, inventoryItems.map(item => ({ 
        id: item.id, 
        name: item.name, 
        unit: item.unit, 
        stock: item.currentStock 
      })));
      
      const inventoryItem = inventoryItems.find(item => 
        item.name.toLowerCase() === ingredientName.toLowerCase() && item.unit === unit
      );
      
      if (!inventoryItem) {
        console.warn(`Ingrediente non trovato: "${ingredientName}" con unità "${unit}"`);
        return false;
      }

      const currentStock = Number(inventoryItem.currentStock);
      const newStock = Math.max(0, currentStock - quantityUsed);
      
      console.log('[UNICO] Aggiornamento scorte: ' + inventoryItem.name + ' - Stock attuale: ' + currentStock + ', Usato: ' + quantityUsed + ', Nuovo stock: ' + newStock);
      
      const result = await db
        .update(inventory)
        .set({ 
          currentStock: newStock.toString(),
          updatedAt: new Date()
        })
        .where(eq(inventory.id, inventoryItem.id));

      console.log('[UNICO] Scorte aggiornate per ' + inventoryItem.name + ': ' + currentStock + ' -> ' + newStock);

      // Crea alert automatici per scorte basse
      if (newStock <= Number(inventoryItem.minimumStock) && newStock > 0) {
        await this.createAlert({
          type: "low_stock",
          message: `Scorte basse per ${ingredientName}: ${newStock} ${unit} rimanenti`,
          severity: "medium",
          referenceTable: "inventory",
          referenceId: inventoryItem.id
        });
      } else if (newStock <= 0) {
        await this.createAlert({
          type: "out_of_stock",
          message: `Scorte esaurite per ${ingredientName}`,
          severity: "high",
          referenceTable: "inventory",
          referenceId: inventoryItem.id
        });
      }

      return true;
    } finally {
      this.updatingInventory.delete(key);
    }
  }

  // Aggiorna il codice prodotto nel magazzino con il numero di lotto
  async updateInventoryCodeWithBatch(recipeId: number, batchCode: string): Promise<void> {
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) return;

    const existingItem = await db
      .select()
      .from(inventory)
      .where(eq(inventory.name, recipe.name));

    if (existingItem.length > 0) {
      await db
        .update(inventory)
        .set({ 
          code: batchCode,
          updatedAt: new Date()
        })
        .where(eq(inventory.id, existingItem[0].id));
    }
  }

  // Implementazione DatabaseStorage per aggiornamento automatico scorte da ricetta
  async updateInventoryFromRecipe(recipeId: number, quantityProduced: number): Promise<void> {
    console.log(`🔄 INIZIO updateInventoryFromRecipe - recipeId: ${recipeId}, quantità: ${quantityProduced}`);
    
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) {
      console.warn(` Ricetta non trovata: ${recipeId}`);
      return;
    }

    console.log(`📋 Ricetta trovata: ${recipe.name} con ${recipe.ingredients.length} ingredienti`);
    console.log(`📋 Ingredienti ricetta:`, JSON.stringify(recipe.ingredients, null, 2));

    // Per ogni ingrediente nella ricetta, calcola la quantità necessaria
    for (let i = 0; i < recipe.ingredients.length; i++) {
      const ingredient = recipe.ingredients[i];
      const quantityNeeded = ingredient.quantity * quantityProduced;
      
      console.log(` Elaborando ingrediente ${i + 1}: ${ingredient.name}`);
      console.log(`📊 Quantità necessaria: ${quantityNeeded} ${ingredient.unit} (${ingredient.quantity} × ${quantityProduced})`);
      
      try {
        // Trova l'item nell'inventario
        console.log(` Cercando nell'inventario: "${ingredient.name}" con unità "${ingredient.unit}"`);
        const inventoryItems = await db.select().from(inventory);
        console.log(`Inventario totale:`, inventoryItems.map(item => ({ name: item.name, unit: item.unit, stock: item.currentStock })));
        
        const inventoryItem = inventoryItems.find(item => 
          item.name.toLowerCase().trim() === ingredient.name.toLowerCase().trim() && 
          item.unit === ingredient.unit
        );
        
        if (!inventoryItem) {
          console.warn(` Ingrediente non trovato nell'inventario: "${ingredient.name}" con unità "${ingredient.unit}"`);
          console.warn(` Inventario disponibile:`, inventoryItems.map(item => `${item.name} (${item.unit})`));
          continue;
        }

        console.log(` Ingrediente trovato nell'inventario: ID ${inventoryItem.id}, Stock attuale: ${inventoryItem.currentStock}`);

        const currentStock = Number(inventoryItem.currentStock);
        const newStock = Math.max(0, currentStock - quantityNeeded);
        
        console.log(`📊 Calcolo aggiornamento: ${currentStock} - ${quantityNeeded} = ${newStock}`);
        
        // Aggiorna il database
        console.log(`🔄 Aggiornando database per ID ${inventoryItem.id}...`);
        const updateResult = await db
          .update(inventory)
          .set({ 
            currentStock: newStock.toString(),
            updatedAt: new Date()
          })
          .where(eq(inventory.id, inventoryItem.id))
          .returning();

        console.log(` Database aggiornato:`, updateResult);

        // Verifica l'aggiornamento
        const [verifyItem] = await db.select().from(inventory).where(eq(inventory.id, inventoryItem.id));
        console.log(` Verifica dopo aggiornamento: ${verifyItem.name} stock = ${verifyItem.currentStock}`);

        // Registra il tracking dell'utilizzo ingrediente
        await this.createIngredientTracking({
          ingredientName: ingredient.name,
          quantityUsed: quantityNeeded.toString(),
          unit: ingredient.unit,
          usageDate: new Date(),
          batchId: null,
          inventoryId: inventoryItem.id,
          notes: `Utilizzo automatico per produzione ${recipe.name}`
        });

        console.log(` Tracking creato per ${ingredient.name}`);

      } catch (error) {
        console.error(` Errore nell'aggiornamento di ${ingredient.name}:`, error);
      }
    }

    // Gestione dei materiali di confezionamento (packaging costs)
    if (recipe.packagingCosts && recipe.packagingCosts.length > 0) {
      console.log(` Elaborando ${recipe.packagingCosts.length} materiali di confezionamento`);
      
      for (let i = 0; i < recipe.packagingCosts.length; i++) {
        const packaging = recipe.packagingCosts[i];
        const quantityNeeded = packaging.quantity * quantityProduced;
        
        const packagingName = packaging.name || packaging.type;
        console.log(` Elaborando packaging ${i + 1}: ${packagingName}`);
        console.log(`📊 Quantità necessaria: ${quantityNeeded} (${packaging.quantity} × ${quantityProduced})`);
        console.log(` Struttura packaging:`, JSON.stringify(packaging, null, 2));
        
        try {
          // Trova l'item nell'inventario
          console.log(` Cercando packaging nell'inventario: "${packagingName}"`);
          const inventoryItems = await db.select().from(inventory);
          console.log(` Inventario completo:`, inventoryItems.map(item => ({ id: item.id, name: item.name, unit: item.unit, stock: item.currentStock })));
          
          const inventoryItem = inventoryItems.find(item => 
            item.name.toLowerCase().trim() === packagingName.toLowerCase().trim()
          );
          
          if (!inventoryItem) {
            console.warn(` Packaging non trovato nell'inventario: "${packagingName}"`);
            console.warn(` Nomi disponibili:`, inventoryItems.map(item => item.name));
            continue;
          }

          console.log(` Packaging trovato nell'inventario: ID ${inventoryItem.id}, Stock attuale: ${inventoryItem.currentStock}`);

          const currentStock = Number(inventoryItem.currentStock);
          const newStock = Math.max(0, currentStock - quantityNeeded);
          
          console.log(`📊 Calcolo aggiornamento packaging: ${currentStock} - ${quantityNeeded} = ${newStock}`);
          
          // Aggiorna il database
          console.log(`🔄 Aggiornando database per packaging ID ${inventoryItem.id}...`);
          const updateResult = await db
            .update(inventory)
            .set({ 
              currentStock: newStock.toString(),
              updatedAt: new Date()
            })
            .where(eq(inventory.id, inventoryItem.id))
            .returning();

          console.log(` Database packaging aggiornato:`, updateResult);

          // Verifica l'aggiornamento
          const [verifyItem] = await db.select().from(inventory).where(eq(inventory.id, inventoryItem.id));
          console.log(` Verifica dopo aggiornamento packaging: ${verifyItem.name} stock = ${verifyItem.currentStock}`);

          // Registra il tracking dell'utilizzo packaging
          await this.createIngredientTracking({
            ingredientName: packagingName,
            quantityUsed: quantityNeeded.toString(),
            unit: inventoryItem.unit,
            usageDate: new Date(),
            batchId: null,
            inventoryId: inventoryItem.id,
            notes: `Utilizzo packaging per produzione ${recipe.name}`
          });

          console.log(` Tracking packaging creato per ${packaging.name}`);

        } catch (error) {
          console.error(` Errore nell'aggiornamento packaging ${packaging.name}:`, error);
        }
      }
    }

    console.log(` COMPLETATO updateInventoryFromRecipe per ${recipe.name}`);
  }

  // Implementazione DatabaseStorage per ripristino scorte da eliminazione lotto
  async restoreInventoryFromBatch(recipeId: number, quantityProduced: number): Promise<void> {
    console.log(`🔄 INIZIO restoreInventoryFromBatch - recipeId: ${recipeId}, quantità: ${quantityProduced}`);
    
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) {
      console.warn(` Ricetta non trovata: ${recipeId}`);
      return;
    }

    console.log(`📋 Ricetta trovata: ${recipe.name} con ${recipe.ingredients.length} ingredienti`);

    // Per ogni ingrediente nella ricetta, ripristina la quantità necessaria
    for (let i = 0; i < recipe.ingredients.length; i++) {
      const ingredient = recipe.ingredients[i];
      const quantityToRestore = ingredient.quantity * quantityProduced;
      
      console.log(` Ripristinando ingrediente ${i + 1}: ${ingredient.name}`);
      console.log(`📊 Quantità da ripristinare: ${quantityToRestore} ${ingredient.unit} (${ingredient.quantity} × ${quantityProduced})`);
      
      try {
        // Trova l'item nell'inventario
        console.log(` Cercando nell'inventario: "${ingredient.name}" con unità "${ingredient.unit}"`);
        const inventoryItems = await db.select().from(inventory);
        
        const inventoryItem = inventoryItems.find(item => 
          item.name.toLowerCase().trim() === ingredient.name.toLowerCase().trim() && 
          item.unit === ingredient.unit
        );
        
        if (!inventoryItem) {
          console.warn(` Ingrediente non trovato nell'inventario: "${ingredient.name}" con unità "${ingredient.unit}"`);
          continue;
        }

        console.log(` Ingrediente trovato nell'inventario: ID ${inventoryItem.id}, Stock attuale: ${inventoryItem.currentStock}`);

        const currentStock = Number(inventoryItem.currentStock);
        const newStock = currentStock + quantityToRestore; // Ripristina aggiungendo
        
        console.log(`📊 Calcolo ripristino: ${currentStock} + ${quantityToRestore} = ${newStock}`);
        
        // Aggiorna il database
        console.log(`🔄 Aggiornando database per ID ${inventoryItem.id}...`);
        const updateResult = await db
          .update(inventory)
          .set({ 
            currentStock: newStock.toString(),
            updatedAt: new Date()
          })
          .where(eq(inventory.id, inventoryItem.id))
          .returning();

        console.log(` Database aggiornato:`, updateResult);

        // Verifica l'aggiornamento
        const [verifyItem] = await db.select().from(inventory).where(eq(inventory.id, inventoryItem.id));
        console.log(` Verifica dopo ripristino: ${verifyItem.name} stock = ${verifyItem.currentStock}`);

        // Registra il tracking del ripristino ingrediente
        await this.createIngredientTracking({
          ingredientName: ingredient.name,
          quantityUsed: (-quantityToRestore).toString(), // Negativo per indicare ripristino
          unit: ingredient.unit,
          usageDate: new Date(),
          batchId: null,
          inventoryId: inventoryItem.id,
          notes: `Ripristino scorte da eliminazione lotto ${recipe.name}`
        });

        console.log(` Tracking ripristino creato per ${ingredient.name}`);

      } catch (error) {
        console.error(` Errore nel ripristino di ${ingredient.name}:`, error);
      }
    }

    // Gestione ripristino materiali di confezionamento (packaging costs)
    if (recipe.packagingCosts && recipe.packagingCosts.length > 0) {
      console.log(` Ripristinando ${recipe.packagingCosts.length} materiali di confezionamento`);
      
      for (let i = 0; i < recipe.packagingCosts.length; i++) {
        const packaging = recipe.packagingCosts[i];
        const quantityToRestore = packaging.quantity * quantityProduced;
        
        const packagingName = packaging.name || packaging.type;
        console.log(` Ripristinando packaging ${i + 1}: ${packagingName}`);
        console.log(`📊 Quantità da ripristinare: ${quantityToRestore} (${packaging.quantity} × ${quantityProduced})`);
        
        try {
          // Trova l'item nell'inventario
          console.log(` Cercando packaging nell'inventario: "${packagingName}"`);
          const inventoryItems = await db.select().from(inventory);
          
          const inventoryItem = inventoryItems.find(item => 
            item.name.toLowerCase().trim() === packagingName.toLowerCase().trim()
          );
          
          if (!inventoryItem) {
            console.warn(` Packaging non trovato nell'inventario: "${packagingName}"`);
            continue;
          }

          console.log(` Packaging trovato nell'inventario: ID ${inventoryItem.id}, Stock attuale: ${inventoryItem.currentStock}`);

          const currentStock = Number(inventoryItem.currentStock);
          const newStock = currentStock + quantityToRestore; // Ripristina aggiungendo
          
          console.log(`📊 Calcolo ripristino packaging: ${currentStock} + ${quantityToRestore} = ${newStock}`);
          
          // Aggiorna il database
          console.log(`🔄 Aggiornando database per packaging ID ${inventoryItem.id}...`);
          const updateResult = await db
            .update(inventory)
            .set({ 
              currentStock: newStock.toString(),
              updatedAt: new Date()
            })
            .where(eq(inventory.id, inventoryItem.id))
            .returning();

          console.log(` Database packaging aggiornato:`, updateResult);

          // Verifica l'aggiornamento
          const [verifyItem] = await db.select().from(inventory).where(eq(inventory.id, inventoryItem.id));
          console.log(` Verifica dopo ripristino packaging: ${verifyItem.name} stock = ${verifyItem.currentStock}`);

          // Registra il tracking del ripristino packaging
          await this.createIngredientTracking({
            ingredientName: packagingName,
            quantityUsed: (-quantityToRestore).toString(), // Negativo per indicare ripristino
            unit: inventoryItem.unit,
            usageDate: new Date(),
            batchId: null,
            inventoryId: inventoryItem.id,
            notes: `Ripristino packaging da eliminazione lotto ${recipe.name}`
          });

          console.log(` Tracking ripristino packaging creato per ${packagingName}`);

        } catch (error) {
          console.error(` Errore nel ripristino packaging ${packagingName}:`, error);
        }
      }
    }

    console.log(` COMPLETATO restoreInventoryFromBatch per ${recipe.name}`);
  }

  // Deduct ingredients from inventory when creating a batch
  async deductInventoryFromBatch(recipeId: number, quantityProduced: number): Promise<void> {
    console.log(`📉 INIZIO deductInventoryFromBatch - recipeId: ${recipeId}, quantità: ${quantityProduced}`);
    
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) {
      console.warn(` Ricetta non trovata: ${recipeId}`);
      return;
    }

    console.log(`📋 Ricetta trovata: ${recipe.name} con ${recipe.ingredients.length} ingredienti`);

    // Per ogni ingrediente nella ricetta, deduci la quantità necessaria
    for (let i = 0; i < recipe.ingredients.length; i++) {
      const ingredient = recipe.ingredients[i];
      const quantityToDeduct = ingredient.quantity * quantityProduced;
      
      console.log(` Deducendo ingrediente ${i + 1}: ${ingredient.name}`);
      console.log(`📊 Quantità da detrarre: ${quantityToDeduct} ${ingredient.unit} (${ingredient.quantity} × ${quantityProduced})`);
      
      try {
        // Trova l'item nell'inventario
        console.log(` Cercando nell'inventario: "${ingredient.name}" con unità "${ingredient.unit}"`);
        const inventoryItems = await db.select().from(inventory);
        
        const inventoryItem = inventoryItems.find(item => 
          item.name.toLowerCase().trim() === ingredient.name.toLowerCase().trim() && 
          item.unit === ingredient.unit
        );
        
        if (!inventoryItem) {
          console.warn(` Ingrediente non trovato nell'inventario: "${ingredient.name}" con unità "${ingredient.unit}"`);
          continue;
        }

        const currentStock = parseFloat(inventoryItem.currentStock || "0");
        const newStock = Math.max(0, currentStock - quantityToDeduct); // Non permettere stock negativi
        
        console.log(`📊 ${inventoryItem.name}: ${currentStock} -> ${newStock} ${inventoryItem.unit}`);
        
        // Aggiorna lo stock nell'inventario
        await db.update(inventory)
          .set({ 
            currentStock: newStock.toString(),
            updatedAt: new Date()
          })
          .where(eq(inventory.id, inventoryItem.id));

        // Verifica l'aggiornamento
        const [verifyItem] = await db.select().from(inventory).where(eq(inventory.id, inventoryItem.id));
        console.log(` Verifica dopo deduzione: ${verifyItem.name} stock = ${verifyItem.currentStock}`);

        // Registra il tracking dell'utilizzo ingrediente
        await this.createIngredientTracking({
          ingredientName: ingredient.name,
          quantityUsed: quantityToDeduct.toString(),
          unit: ingredient.unit,
          usageDate: new Date(),
          batchId: null,
          inventoryId: inventoryItem.id,
          notes: `Utilizzo per produzione lotto ${recipe.name}`
        });

        console.log(` Tracking utilizzo creato per ${ingredient.name}`);

      } catch (error) {
        console.error(` Errore nella deduzione ingrediente ${ingredient.name}:`, error);
      }
    }

    // Gestisci i materiali di confezionamento
    // Se packagingCosts non è definito, usa il yield per calcolare i vasetti necessari
    const packagingToProcess = recipe.packagingCosts && recipe.packagingCosts.length > 0 
      ? recipe.packagingCosts 
      : [{
          containerType: 'Vasetti in vetro',
          quantity: 1, // 1 vasetto per unità prodotta
          supplier: 'Standard',
          unitCost: 0.35,
          containerCost: 0.35
        }];

    console.log(` Gestione packaging per ${recipe.name}`);
    
    for (const packaging of packagingToProcess) {
        try {
          const packagingName = packaging.containerType || packaging.type || 'Vasetti in vetro';
          const quantityNeeded = packaging.quantity * quantityProduced;
          
          console.log(` Cercando packaging: "${packagingName}"`);
          
          const inventoryItems = await db.select().from(inventory);
          const inventoryItem = inventoryItems.find(item => 
            item.name.toLowerCase().includes(packagingName.toLowerCase()) ||
            packagingName.toLowerCase().includes(item.name.toLowerCase())
          );
          
          if (!inventoryItem) {
            console.warn(` Materiale packaging non trovato: "${packagingName}"`);
            continue;
          }

          const currentStock = parseFloat(inventoryItem.currentStock || "0");
          const newStock = Math.max(0, currentStock - quantityNeeded);
          
          console.log(` ${inventoryItem.name}: ${currentStock} -> ${newStock} ${inventoryItem.unit}`);
          
          await db.update(inventory)
            .set({ 
              currentStock: newStock.toString(),
              updatedAt: new Date()
            })
            .where(eq(inventory.id, inventoryItem.id));

          const [verifyItem] = await db.select().from(inventory).where(eq(inventory.id, inventoryItem.id));
          console.log(` Verifica dopo deduzione packaging: ${verifyItem.name} stock = ${verifyItem.currentStock}`);

          // Registra il tracking dell'utilizzo packaging
          await this.createIngredientTracking({
            ingredientName: packagingName,
            quantityUsed: quantityNeeded.toString(),
            unit: inventoryItem.unit,
            usageDate: new Date(),
            batchId: null,
            inventoryId: inventoryItem.id,
            notes: `Utilizzo packaging per produzione lotto ${recipe.name}`
          });

          console.log(`Tracking packaging creato per ${packagingName}`);

        } catch (error) {
          console.error(`Errore nella deduzione packaging ${packagingName}:`, error);
        }
      }
    }

    console.log('COMPLETATO deductInventoryFromBatch per ' + recipe.name);
  }

  // User authentication methods
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async getUserById(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async validateUserPassword(username: string, password: string): Promise<User | null> {
    const bcrypt = await import('bcryptjs');
    const user = await this.getUserByUsername(username);
    
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async validateUserPasswordByEmail(email: string, password: string): Promise<User | null> {
    const bcrypt = await import('bcryptjs');
    const user = await this.getUserByEmail(email);
    
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async updateUserPassword(userId: number, newPassword: string): Promise<boolean> {
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    const result = await db
      .update(users)
      .set({ password: hashedPassword })
      .where(eq(users.id, userId));
    
    return result.rowCount !== null && result.rowCount > 0;
  }

  async createPasswordResetToken(userId: number): Promise<string> {
    const token = Math.random().toString(36).substring(2) + Date.now().toString(36);
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 ore
    
    await db.insert(passwordResetTokens).values({
      userId,
      token,
      expiresAt,
      used: false
    });
    
    return token;
  }

  async validatePasswordResetToken(token: string): Promise<{ userId: number; valid: boolean }> {
    const [tokenRecord] = await db
      .select()
      .from(passwordResetTokens)
      .where(eq(passwordResetTokens.token, token));
    
    if (!tokenRecord || tokenRecord.used || tokenRecord.expiresAt < new Date()) {
      return { userId: 0, valid: false };
    }
    
    return { userId: tokenRecord.userId, valid: true };
  }

  async usePasswordResetToken(token: string): Promise<boolean> {
    const result = await db
      .update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.token, token));
    
    return result.rowCount > 0;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Company profiles
  async getCompanyProfile(userId: number): Promise<CompanyProfile | undefined> {
    const [profile] = await db.select().from(companyProfiles).where(eq(companyProfiles.userId, userId));
    return profile || undefined;
  }

  async createCompanyProfile(profile: InsertCompanyProfile): Promise<CompanyProfile> {
    const [newProfile] = await db
      .insert(companyProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateCompanyProfile(userId: number, profile: Partial<InsertCompanyProfile>): Promise<CompanyProfile | undefined> {
    const [updated] = await db
      .update(companyProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(companyProfiles.userId, userId))
      .returning();
    return updated || undefined;
  }
}

export const storage = new DatabaseStorage();