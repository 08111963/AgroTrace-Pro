import OpenAI from "openai";
import { calculateNutritionalValues, getAvailableIngredients, getIngredientsByCategory } from "./nutritional-data";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Calcola il fattore di scarto specifico per ogni ingrediente
function getIngredientWasteFactor(ingredientName: string): number {
  const name = ingredientName.toLowerCase();
  
  // Fattori di scarto specifici per tipo di ingrediente
  if (name.includes('albicocche') || name.includes('pesche') || name.includes('prugne')) {
    return 0.15; // 15% per frutti con nocciolo
  } else if (name.includes('fragole') || name.includes('lamponi') || name.includes('mirtilli')) {
    return 0.05; // 5% per frutti di bosco
  } else if (name === 'zucchine' || name.includes('melanzane') || name.includes('peperoni')) {
    return 0.12; // 12% per verdure con buccia spessa
  } else if (name === 'pomodori' || name === 'cipolle') {
    return 0.08; // 8% per verdure standard  
  } else if (name === 'basilico' || name === 'menta' || name.includes('rosmarino') || name === 'peperoncino') {
    return 0.05; // 5% per erbe aromatiche e spezie
  } else if (name === 'olio evo' || name.includes('olio') || name.includes('aceto') || name.includes('succo')) {
    return 0.02; // 2% per liquidi (solo per travasi/versamenti)
  } else if (name.includes('sale') || name.includes('pepe') || name.includes('pectina')) {
    return 0.01; // 1% per ingredienti secchi/polveri
  }
  
  return 0.08; // 8% default per ingredienti non classificati
}

// Calcola quantità deterministiche per garantire consistenza
function calculateDeterministicQuantities(
  aiIngredients: any[], 
  userIngredients: string[], 
  targetQuantity: number,
  recipeType: string = 'salato',
  additionalInstructions: string = '',
  vegetablePercentage?: number,
  targetUnit?: string
) {
  // Rese realistiche per conserve: quantità cruda necessaria per ottenere 100g di prodotto finito
  const yieldFactors: Record<string, number> = {
    'zucchine': 180,      // 180g crudo → 100g cotto concentrato (perdita 44% acqua)
    'melanzane': 160,     // 160g crudo → 100g cotto (perdita 38% acqua + salatura)
    'peperoni': 140,      // 140g crudo → 100g cotto (perdita 29% acqua)
    'cipolle': 130,       // 130g crudo → 100g cotto concentrato (perdita 23% acqua)
    'menta': 105,         // 105g crudo → 100g essiccato (perdita 5% umidità)
    'basilico': 105,      // 105g crudo → 100g essiccato (perdita 5% umidità)
    'olio evo': 100,      // 100ml → 100ml (nessuna perdita)
    'olio di semi': 100,  // 100ml → 100ml (nessuna perdita)
    'olio': 100,          // 100ml → 100ml (nessuna perdita generico)
    'peperoncino': 110,   // 110g crudo → 100g essiccato (perdita 9% umidità)
    'aglio': 115,         // 115g crudo → 100g cotto (perdita 13% umidità)
    'pomodori': 200,      // 200g crudo → 100g concentrato (perdita 50% acqua)
    'sale': 100,          // 100g → 100g (nessuna perdita)
    'pepe nero': 100,     // 100g → 100g (nessuna perdita)
    'succo di limone': 100, // 100ml → 100ml (nessuna perdita)
    'aceto': 100,         // 100ml → 100ml (nessuna perdita)
    'pectina': 100,       // 100g → 100g (nessuna perdita)
    'acqua': 100,         // 100ml → 100ml (nessuna perdita)
    'mele': 120,          // 120g → 100ml succo (resa 83%)
    'pere': 120,          // 120g → 100ml succo (resa 83%)
    'albicocche': 130,    // 130g → 100ml succo (resa 77%)
    'albicocca': 130,     // 130g → 100ml succo (resa 77%)
    'pesche': 130,        // 130g → 100ml succo (resa 77%)
    'fragole': 110        // 110g → 100ml succo (resa 91%)
  };

  // Proporzioni target per 100ml di prodotto finito (adattate per tipo ricetta)
  const getTargetProportions = (recipeType: string, vegetablePercentage?: number): Record<string, number> => {
    if (recipeType === 'sottolio') {
      const vegPercent = vegetablePercentage || 65;
      const oilPercent = Math.max(15, 95 - vegPercent); // Minimo 15% olio, resto per verdura
      
      return {
        'melanzane': vegPercent,      // Percentuale personalizzata verdura
        'zucchine': vegPercent,       // Percentuale personalizzata verdura
        'peperoni': vegPercent,       // Percentuale personalizzata verdura
        'cipolle': vegPercent,        // Percentuale personalizzata verdura
        'pomodori': vegPercent,       // Percentuale personalizzata verdura
        'olio evo': oilPercent,       // Olio calcolato dinamicamente
        'olio di semi': oilPercent,   // Olio calcolato dinamicamente
        'olio': oilPercent,           // Olio calcolato dinamicamente
        'aglio': 2,           // 2g nel prodotto finito
        'basilico': 1,        // 1g nel prodotto finito
        'menta': 0.5,         // 0.5g nel prodotto finito (erba aromatica)
        'peperoncino': 0.3,   // 0.3g nel prodotto finito (spezia piccante)
        'origano': 0.5,       // 0.5g nel prodotto finito (erba aromatica)
        'sale': 1.5,          // 1.5g nel prodotto finito
        'aceto': 2,           // 2ml nel prodotto finito (acidificazione)
        'pepe nero': 0.2      // 0.2g nel prodotto finito
      };
    } else if (recipeType === 'succo') {
      const fruitPercent = vegetablePercentage || 85;
      const waterPercent = Math.max(5, 100 - fruitPercent); // Minimo 5% acqua
      
      return {
        'mele': fruitPercent,          // Percentuale personalizzata frutta
        'pere': fruitPercent,          // Percentuale personalizzata frutta
        'albicocche': fruitPercent,    // Percentuale personalizzata frutta
        'albicocca': fruitPercent,     // Percentuale personalizzata frutta (singolare)
        'pesche': fruitPercent,        // Percentuale personalizzata frutta
        'fragole': fruitPercent,       // Percentuale personalizzata frutta
        'acqua': waterPercent,         // Acqua calcolata dinamicamente
        'succo di limone': 2           // 2ml per conservazione (solo se richiesto)
      };
    } else if (recipeType === 'salato') {
      // Proporzioni per ricette salate con controllo percentuale verdura
      const vegPercent = vegetablePercentage || 65;
      const otherPercent = Math.max(10, 100 - vegPercent); // Minimo 10% per sale, olio, spezie
      
      return {
        'zucchine': vegPercent,       // Percentuale personalizzata verdura
        'cipolle': vegPercent,        // Percentuale personalizzata verdura
        'pomodori': vegPercent,       // Percentuale personalizzata verdura
        'passata di pomodoro': vegPercent, // Percentuale personalizzata verdura
        'melanzane': vegPercent,      // Percentuale personalizzata verdura
        'peperoni': vegPercent,       // Percentuale personalizzata verdura
        'carote': vegPercent,         // Percentuale personalizzata verdura
        'patate': vegPercent,         // Percentuale personalizzata verdura
        'sale': Math.min(3, otherPercent * 0.1),    // Massimo 3% sale
        'olio evo': Math.min(8, otherPercent * 0.3), // Massimo 8% olio
        'aglio': Math.min(2, otherPercent * 0.05),   // Massimo 2% aglio
        'basilico': Math.min(1, otherPercent * 0.03), // Massimo 1% erbe
        'menta': Math.min(1, otherPercent * 0.03),    // Massimo 1% erbe
        'peperoncino': Math.min(0.5, otherPercent * 0.01), // Massimo 0.5% spezie
        'pepe nero': Math.min(0.3, otherPercent * 0.01),   // Massimo 0.3% spezie
        'acqua': Math.min(15, otherPercent * 0.5)     // Acqua se necessaria
      };
    } else {
      // Proporzioni per conserve dolci (marmellate, etc.)
      const fruitPercent = vegetablePercentage || 65;
      const sugarPercent = Math.max(15, 95 - fruitPercent); // Minimo 15% zucchero
      
      return {
        'zucchine': fruitPercent,     // Per dolci salati con zucchine
        'mele': fruitPercent,         // Percentuale personalizzata frutta
        'pere': fruitPercent,         // Percentuale personalizzata frutta
        'fragole': fruitPercent,      // Percentuale personalizzata frutta
        'albicocche': fruitPercent,   // Percentuale personalizzata frutta
        'pesche': fruitPercent,       // Percentuale personalizzata frutta
        'zucchero': sugarPercent,     // Zucchero calcolato dinamicamente
        'succo di limone': 2,         // 2ml nel prodotto finito
        'pectina': 0.5,               // 0.5g nel prodotto finito
        'acqua': 5                    // 5ml se necessario
      };
    }
  };

  const targetProportions = getTargetProportions(recipeType, vegetablePercentage);

  // Converti la quantità target in kg basandosi sull'unità
  let targetKg: number;
  const unitStr = targetUnit ? targetUnit.toLowerCase() : '';
  
  if (unitStr.includes('litri') || (unitStr.includes('l') && !unitStr.includes('ml'))) {
    // Per litri: 1L = 1kg per liquidi come succhi
    targetKg = targetQuantity;
  } else if (unitStr.includes('ml')) {
    // Per millilitri: 1000ml = 1kg per liquidi
    targetKg = targetQuantity / 1000;
  } else if (unitStr.includes('g')) {
    // Per grammi o altre unità solide
    targetKg = targetQuantity / 1000;
  } else {
    // Default per unità non riconosciute (assumendo grammi)
    targetKg = targetQuantity / 1000;
  }
  
  console.log(`Target quantity: ${targetQuantity} ${targetUnit || 'g'} → ${targetKg}kg per calcolo`);
  
  // Aggiungi ingredienti base essenziali in base al tipo di ricetta
  const getEssentialIngredients = (type: string, userIngredients: string[], additionalInstructions: string = ''): string[] => {
    const essentials: string[] = [...userIngredients];
    const instructions = additionalInstructions.toLowerCase();
    
    // Controlli per esclusioni specifiche e preferenze acidificante
    const noLemon = instructions.includes('senza succo di limone') || instructions.includes('senza limone');
    const noSalt = instructions.includes('senza sale');
    const noOil = instructions.includes('senza olio');
    const prefersLemon = instructions.includes('acidificante: succo di limone fresco');
    const prefersVinegar = instructions.includes('acidificante: aceto di vino bianco');
    
    if (type === 'sottolio') {
      if (!noOil && !essentials.some(ing => ing.toLowerCase().includes('olio'))) {
        essentials.push('olio evo');
      }
      if (!noSalt && !essentials.some(ing => ing.toLowerCase().includes('sale'))) {
        essentials.push('sale');
      }
      // Aggiungi acidificante basato su preferenza utente (solo per sott'olio)
      if (prefersLemon && !noLemon && !essentials.some(ing => ing.toLowerCase().includes('limone'))) {
        essentials.push('succo di limone');
      } else if (prefersVinegar && !essentials.some(ing => ing.toLowerCase().includes('aceto'))) {
        essentials.push('aceto');
      }
    } else if (type === 'succo') {
      // Per succhi aggiungi limone solo se esplicitamente nei gusti dell'utente o se richiesto
      const wantsLemon = instructions.includes('con limone') || instructions.includes('con succo di limone');
      if (wantsLemon && !noLemon && !essentials.some(ing => ing.toLowerCase().includes('limone'))) {
        essentials.push('succo di limone');
      }
    } else if (type === 'dolce') {
      // Per dolci aggiungi ingredienti solo se esplicitamente richiesti
      const wantsLemon = instructions.includes('con limone') || instructions.includes('con succo di limone');
      const wantsSugar = instructions.includes('con zucchero') || instructions.includes('zucchero');
      const wantsPectin = instructions.includes('con pectina') || instructions.includes('pectina');
      
      if (wantsLemon && !noLemon && !essentials.some(ing => ing.toLowerCase().includes('limone'))) {
        essentials.push('succo di limone');
      }
      if (wantsSugar && !essentials.some(ing => ing.toLowerCase().includes('zucchero'))) {
        essentials.push('zucchero');
      }
      if (wantsPectin && !essentials.some(ing => ing.toLowerCase().includes('pectina'))) {
        essentials.push('pectina');
      }
    } else if (type === 'salato') {
      // Per conserve salate aggiungi acidificante solo se esplicitamente selezionato
      if (prefersLemon && !noLemon && !essentials.some(ing => ing.toLowerCase().includes('limone'))) {
        essentials.push('succo di limone');
      } else if (prefersVinegar && !essentials.some(ing => ing.toLowerCase().includes('aceto'))) {
        essentials.push('aceto');
      }
      if (!noSalt && !essentials.some(ing => ing.toLowerCase().includes('sale'))) {
        essentials.push('sale');
      }
      if (!noOil && !essentials.some(ing => ing.toLowerCase().includes('olio'))) {
        essentials.push('olio evo');
      }
    }
    
    return essentials;
  };
  
  const allIngredients = getEssentialIngredients(recipeType, userIngredients, additionalInstructions);
  
  // Identifica ingredienti principali (verdure/frutta) vs secondari (condimenti)
  const mainIngredients = allIngredients.filter(ing => {
    const lower = ing.toLowerCase();
    
    // Per tutti i tipi di ricetta, gli ingredienti dell'utente sono sempre principali
    if (userIngredients.some(userIng => userIng.toLowerCase() === lower)) {
      return true;
    }
    
    // Lista estesa di ingredienti principali per tutti i tipi
    const primaryIngredients = [
      // Verdure
      'zucchine', 'cipolle', 'pomodori', 'melanzane', 'peperoni', 'carote', 'patate',
      'broccoli', 'cavolfiori', 'spinaci', 'fagiolini', 'piselli', 'carciofi',
      // Frutta
      'mele', 'pere', 'fragole', 'albicocche', 'pesche', 'arance', 'limoni',
      'banane', 'kiwi', 'ananas', 'mango', 'lamponi', 'mirtilli', 'ciliegie',
      'prugne', 'uva', 'melone', 'anguria', 'fichi'
    ];
    
    return primaryIngredients.includes(lower);
  });
  
  // Calcola proporzioni distribuite per ingredienti principali
  const adjustedProportions = new Map<string, number>();
  
  allIngredients.forEach(ingredientName => {
    const lowerName = ingredientName.toLowerCase();
    let proportion = targetProportions[lowerName] || 10;
    
    // Identifica aromi e spezie che devono avere percentuali minime
    const spicesAndAromas = [
      'cannella', 'zenzero', 'vaniglia', 'cardamomo', 'noce moscata', 'chiodi di garofano',
      'pepe', 'peperoncino', 'paprika', 'curcuma', 'rosmarino', 'timo', 'basilico',
      'origano', 'salvia', 'alloro', 'menta', 'prezzemolo', 'aglio', 'cipolla in polvere'
    ];
    
    const isSpiceOrAroma = spicesAndAromas.some(spice => lowerName.includes(spice));
    
    // Controllo specifico per sale e acidificanti
    if (lowerName.includes('sale')) {
      if (recipeType === 'salato' || recipeType === 'sottolio') {
        proportion = Math.min(1.5, proportion); // Massimo 1.5% per conserve
      }
    } else if (lowerName.includes('aceto') || lowerName.includes('succo di limone')) {
      // Acidificanti hanno percentuali molto basse
      proportion = Math.min(3, proportion); // Massimo 3% per acidificanti
    } else if (lowerName.includes('zucchero') || lowerName.includes('miele')) {
      // Dolcificanti nelle ricette salate devono essere limitati
      if (recipeType === 'salato' || recipeType === 'sottolio') {
        proportion = Math.min(3, proportion); // Massimo 3% per conserve salate
      } else if (recipeType === 'dolce') {
        proportion = Math.min(40, proportion); // Massimo 40% per dolci
      }
    } else if (isSpiceOrAroma) {
      // Aromi e spezie hanno percentuali molto basse
      if (lowerName.includes('pepe')) {
        proportion = Math.min(0.5, proportion); // Massimo 0.5% per pepe
      } else if (recipeType === 'succo') {
        // Per succhi le spezie devono essere molto limitate
        if (lowerName.includes('zenzero') || lowerName.includes('peperoncino')) {
          proportion = Math.min(0.4, proportion); // Massimo 0.4% per spezie forti nei succhi
        } else {
          proportion = Math.min(1, proportion); // Massimo 1% per altre spezie nei succhi
        }
      } else if (recipeType === 'dolce') {
        proportion = Math.min(2, proportion); // Massimo 2% per dolci
      } else {
        proportion = Math.min(3, proportion); // Massimo 3% per salati
      }
      
      // Aggiusta proporzioni basato su istruzioni di intensità
      const intensityInstructions = additionalInstructions.toLowerCase();
      const isLightSpice = intensityInstructions.includes(`${lowerName} leggero`) || 
                          intensityInstructions.includes(`${lowerName.replace('zenzero', 'ginger')} leggero`) ||
                          (lowerName.includes('peperoncino') && (intensityInstructions.includes('piccante leggero') || intensityInstructions.includes('poco piccante')));
      
      if (isLightSpice) {
        // Per spezie forti come zenzero, "leggero" significa molto poco
        if (lowerName.includes('zenzero') || lowerName.includes('peperoncino')) {
          proportion = Math.min(proportion, 0.2); // Massimo 0.2% per spezie molto forti
        } else {
          proportion = Math.min(proportion, 0.5); // Massimo 0.5% per altre spezie
        }
      } else if (intensityInstructions.includes(`${lowerName} intenso`) || 
                 intensityInstructions.includes(`${lowerName.replace('zenzero', 'ginger')} intenso`) ||
                 (lowerName.includes('peperoncino') && (intensityInstructions.includes('molto piccante') || intensityInstructions.includes('piccante intenso')))) {
        // Per spezie forti nei succhi, intenso significa 0.6%
        if (recipeType === 'succo' && (lowerName.includes('zenzero') || lowerName.includes('peperoncino'))) {
          proportion = Math.min(proportion, 0.6); // Massimo 0.6% per spezie forti intenso nei succhi
        } else {
          proportion = Math.min(proportion * 1.5, 5); // Aumenta del 50% fino a max 5% per altri tipi
        }
      }
    } else if (mainIngredients.some(ing => ing.toLowerCase() === lowerName)) {
      // Logica per ingredienti principali (uno o più)
      const basePercent = targetProportions[lowerName];
      
      const isSignificantPercent = basePercent && (
        (recipeType === 'salato' && basePercent >= 50) ||
        (recipeType === 'succo' && basePercent >= 70) ||
        (recipeType === 'dolce' && basePercent >= 50) ||
        (recipeType === 'sottolio' && basePercent >= 60)
      );
      
      if (isSignificantPercent) {
        const mainIndex = mainIngredients.findIndex(ing => ing.toLowerCase() === lowerName);
        
        if (mainIndex === 0) {
          // Il primo ingrediente mantiene sempre la percentuale scelta dall'utente
          proportion = basePercent;
        } else if (mainIngredients.length > 1) {
          // Gli altri ingredienti ricevono una percentuale appropriata per tipo
          let secondaryPercent = 15; // Default
          
          if (recipeType === 'succo') {
            secondaryPercent = Math.min(20, (100 - basePercent) / 4);
          } else if (recipeType === 'dolce') {
            secondaryPercent = Math.min(25, (100 - basePercent) / 3);
          } else if (recipeType === 'sottolio') {
            secondaryPercent = Math.min(20, (100 - basePercent) / 3);
          }
          
          proportion = secondaryPercent;
        }
      }
    }
    
    adjustedProportions.set(lowerName, proportion);
  });
  
  return allIngredients.map(ingredientName => {
    const lowerName = ingredientName.toLowerCase();
    
    // Usa la proporzione aggiustata
    const proportion = adjustedProportions.get(lowerName) || 10;
    const targetInProduct = proportion * targetKg * 10; // x10 per convertire in grammi
    
    // Calcola quantità cruda necessaria usando il fattore di resa
    const yieldFactor = yieldFactors[lowerName] || 120;
    const baseQuantity = Math.round((targetInProduct * yieldFactor) / 100);
    
    // Applica fattore di scarto specifico
    const specificWasteFactor = getIngredientWasteFactor(lowerName);
    const wastePercent = Math.round(specificWasteFactor * 100);
    const finalQuantity = Math.round(baseQuantity / (1 - specificWasteFactor));
    
    // Determina unità di misura appropriata e converti liquidi in litri considerando densità
    const isLiquid = lowerName.includes('olio') || lowerName.includes('succo') || lowerName.includes('acqua');
    let displayQuantity = finalQuantity;
    let displayBaseQuantity = baseQuantity;
    let unit = isLiquid ? 'L' : 'g';
    
    if (isLiquid) {
      // Densità specifiche (g/ml)
      let density = 1.0; // Default per acqua
      if (lowerName.includes('olio')) {
        density = 0.92; // Olio EVO circa 920 kg/m³
      } else if (lowerName.includes('succo')) {
        density = 1.05; // Succo di limone circa 1050 kg/m³
      }
      
      // Converti grammi in litri usando la densità: L = g / (density * 1000)
      displayQuantity = Math.round(finalQuantity / (density * 1000) * 100) / 100;
      displayBaseQuantity = Math.round(baseQuantity / (density * 1000) * 100) / 100;
    }
    
    console.log(`${ingredientName}: ${targetInProduct}g prodotto → ${displayBaseQuantity}${unit} base → ${displayQuantity}${unit} da usare (scarto ${wastePercent}%) [proporzione: ${proportion}]`);
    
    return {
      name: ingredientName,
      quantity: displayQuantity,      // Quantità da pesare/acquistare (con scarto incluso)
      unit: unit,
      baseQuantity: displayBaseQuantity,   // Quantità prima dello scarto
      wastePercentage: wastePercent,
      productPercentage: proportion  // Percentuale nel prodotto finito
    };
  });
}

export interface RecipeGenerationRequest {
  ingredients: string[];
  type: 'dolce' | 'salato' | 'succo' | 'sottolio';
  servings?: number;
  targetQuantity?: number;
  targetUnit?: string;
  additionalInstructions?: string;
  vegetablePercentage?: number;
}

export interface GeneratedRecipe {
  name: string;
  category: string;
  description: string;
  ingredients: Array<{
    name: string;
    quantity: number;
    unit: string;
    baseQuantity?: number; // Quantità base senza scarti
    wastePercentage?: number; // Percentuale di scarto applicata
    productPercentage?: number; // Percentuale nel prodotto finito
  }>;
  instructions: string[];
  preparationTime: number;
  cookingTime: number;
  difficulty: 'facile' | 'medio' | 'difficile';
  notes?: string;
}

export async function generateRecipe(request: RecipeGenerationRequest): Promise<GeneratedRecipe> {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("Chiave API OpenAI non configurata. Aggiungila nelle impostazioni dei segreti.");
  }

  try {
    const { ingredients } = request;
    
    const prompt = createRecipePrompt(request);
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "Sei un chef industriale che deve calcolare ricette con scarti di produzione. Segui ESATTAMENTE le istruzioni nel prompt. Rispondi SOLO in JSON valido senza commenti."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2, // Bassa creatività per ricette consistenti
    });

    let result = JSON.parse(response.choices[0].message.content || '{}') as GeneratedRecipe;
    
    // Validazione della risposta
    if (!result.name || !result.ingredients || !result.instructions) {
      throw new Error("Risposta AI incompleta");
    }

    // Filtro post-generazione per rimuovere ingredienti non richiesti
    const instructionsText = (request.additionalInstructions || '').toLowerCase();
    const userIngredients = request.ingredients.map(ing => ing.toLowerCase());
    const hasLemonInUserIngredients = userIngredients.some(ing => ing.includes('limone'));
    const explicitlyRequestsLemon = instructionsText.includes('con limone') || instructionsText.includes('con succo di limone');
    const explicitlyDeniesLemon = instructionsText.includes('senza limone') || instructionsText.includes('senza succo di limone');

    // Rimuovi succo di limone se non esplicitamente richiesto o se esplicitamente negato
    const shouldRemoveLemon = (!hasLemonInUserIngredients && !explicitlyRequestsLemon) || explicitlyDeniesLemon;

    if (shouldRemoveLemon) {
      result.ingredients = result.ingredients.filter(ing => {
        const lowerName = ing.name.toLowerCase();
        const isLemon = lowerName.includes('limone') || 
                       lowerName.includes('lemon') || 
                       lowerName.includes('succo di limone') ||
                       lowerName.includes('succo limone') ||
                       lowerName.includes('lime') ||
                       lowerName === 'limone' ||
                       lowerName === 'succo di limone';
        return !isLemon;
      });
    }

    // Rimuovi aceto dai succhi di frutta (non dovrebbe mai esserci)
    if (request.type === 'succo') {
      result.ingredients = result.ingredients.filter(ing => {
        const lowerName = ing.name.toLowerCase();
        return !lowerName.includes('aceto') && !lowerName.includes('vinegar');
      });
    }

    // Rimuovi aceto dalle ricette salate se non esplicitamente richiesto
    if (request.type === 'salato') {
      const hasVinegarInUserIngredients = userIngredients.some(ing => ing.includes('aceto'));
      const explicitlyRequestsVinegar = instructionsText.includes('con aceto') || instructionsText.includes('acidificante: aceto');
      const shouldRemoveVinegar = !hasVinegarInUserIngredients && !explicitlyRequestsVinegar;
      
      if (shouldRemoveVinegar) {
        result.ingredients = result.ingredients.filter(ing => {
          const lowerName = ing.name.toLowerCase();
          return !lowerName.includes('aceto') && !lowerName.includes('vinegar');
        });
      }
    }

    // Rimuovi erbe aromatiche non richieste per conserve sott'olio
    if (request.type === 'sottolio') {
      const allowedHerbs = ['aglio']; // Solo aglio è sempre permesso
      userIngredients.forEach(ing => {
        if (ing.includes('basilico') || ing.includes('menta') || ing.includes('origano') || ing.includes('peperoncino')) {
          allowedHerbs.push(ing);
        }
      });
      
      result.ingredients = result.ingredients.filter(ing => {
        const lowerName = ing.name.toLowerCase();
        if (lowerName.includes('basilico') || lowerName.includes('menta') || lowerName.includes('origano') || lowerName.includes('peperoncino')) {
          return allowedHerbs.some(allowed => lowerName.includes(allowed));
        }
        return true;
      });
    }

    // Calcolo deterministico delle quantità basato sul target
    const { targetQuantity } = request;
    if (targetQuantity) {
      // Estrai tutti i nomi degli ingredienti dalla ricetta generata dall'AI
      const allIngredientNames = result.ingredients.map(ing => ing.name);
      const calculatedIngredients = calculateDeterministicQuantities(
        result.ingredients, 
        allIngredientNames,  // Usa tutti gli ingredienti generati, non solo quelli dell'utente
        targetQuantity,
        request.type,
        request.additionalInstructions || '',
        request.vegetablePercentage,
        request.targetUnit
      );
      
      // Usa direttamente tutti gli ingredienti calcolati per preservare tutto
      result.ingredients = calculatedIngredients;
    } else {
      // Proporzioni per modalità porzioni (diverse da quelle industriali)
      const portionProportions: Record<string, number> = {
        'zucchine': 60, 'cipolle': 8, 'menta': 2, 'basilico': 1.5, 'olio evo': 4,
        'peperoncino': 0.3, 'aglio': 1, 'pomodori': 25, 'sale': 0.8, 'pepe nero': 0.1,
        'pectina': 0.5, 'acqua': 22
      };
      
      // Calcolo scarti specifici per ogni ingrediente (modalità porzioni)
      result.ingredients = result.ingredients.map(ing => {
        // Include tutti gli ingredienti della ricetta AI, non solo quelli dell'utente
        const lowerIngName = ing.name.toLowerCase();
        if (ingredients.some(userIng => userIng.toLowerCase() === lowerIngName) || 
            lowerIngName.includes('sale') || lowerIngName.includes('olio') || 
            lowerIngName.includes('aceto') || lowerIngName.includes('succo di limone') ||
            lowerIngName.includes('aglio') || lowerIngName.includes('pepe')) {
          const baseQuantity = ing.quantity;
          const specificWasteFactor = getIngredientWasteFactor(ing.name);
          const wastePercent = Math.round(specificWasteFactor * 100);
          const adjustmentFactor = 1 + specificWasteFactor;
          const finalQuantity = Math.round(baseQuantity * adjustmentFactor);
          
          // Converti liquidi in litri
          const lowerName = ing.name.toLowerCase();
          const isLiquid = lowerName.includes('olio') || lowerName.includes('succo') || lowerName.includes('acqua');
          let displayQuantity = finalQuantity;
          let displayBaseQuantity = baseQuantity;
          let unit = isLiquid ? 'L' : ing.unit;
          
          if (isLiquid && ing.unit === 'ml') {
            // Densità specifiche (g/ml)
            let density = 1.0; // Default per acqua
            if (lowerName.includes('olio')) {
              density = 0.92; // Olio EVO circa 920 kg/m³
            } else if (lowerName.includes('succo')) {
              density = 1.05; // Succo di limone circa 1050 kg/m³
            }
            
            // Converti grammi in litri usando la densità: L = g / (density * 1000)
            displayQuantity = Math.round(finalQuantity / (density * 1000) * 100) / 100;
            displayBaseQuantity = Math.round(baseQuantity / (density * 1000) * 100) / 100;
          }
          
          console.log(`${ing.name}: ${displayBaseQuantity}${unit} → ${displayQuantity}${unit} (scarto ${wastePercent}% - fattore: ${specificWasteFactor.toFixed(3)})`);
          
          // Calcola percentuale del prodotto per modalità porzioni
          const productPercentage = portionProportions[lowerName] || 10;
          
          return {
            ...ing,
            quantity: displayQuantity,
            unit: unit,
            baseQuantity: displayBaseQuantity,
            wastePercentage: wastePercent,
            productPercentage: productPercentage
          };
        }
        return ing;
      });
    }

    // Filtra ingredienti non autorizzati
    const allowedIngredients = new Set([
      ...ingredients.map(i => i.toLowerCase()),
      'zucchero', 'zucchero di canna', 'zucchero semolato', 'stevia', 'eritritolo',
      'succo di limone', 'pectina', 'acqua', 'sale', 'pepe nero', 'olio evo',
      'aglio', 'aceto', 'basilico', 'menta', 'origano', 'peperoncino'
    ]);
    
    result.ingredients = result.ingredients.filter(ing => 
      allowedIngredients.has(ing.name.toLowerCase())
    );

    // Correggi le istruzioni per rimuovere riferimenti ad ingredienti non presenti
    const finalIngredientNames = new Set(result.ingredients.map(ing => ing.name.toLowerCase()));
    
    result.instructions = result.instructions.map(instruction => {
      let correctedInstruction = instruction;
      
      // Rimuovi riferimenti all'aceto se non presente negli ingredienti
      if (!finalIngredientNames.has('aceto') && !finalIngredientNames.has('aceto di vino bianco')) {
        correctedInstruction = correctedInstruction
          .replace(/Aggiungi l'aceto e mescola\.?/gi, '')
          .replace(/Aggiungi l'aceto.*?\.?/gi, '')
          .replace(/Incorpora l'aceto.*?\.?/gi, '')
          .replace(/.*aceto.*mescola.*?\.?/gi, '')
          .replace(/.*aceto.*acidità.*?\.?/gi, '')
          .replace(/.*aceto.*bilanciare.*?\.?/gi, '')
          .replace(/.*aceto.*?\.?/gi, '') // Rimuovi qualsiasi frase che contiene "aceto"
          .replace(/\s+e\s+mescola bene\.?$/gi, '.')
          .replace(/bene\./gi, '') // Rimuovi frammenti isolati come "bene."
          .replace(/\.\s*\./g, '.')
          .replace(/^\d+\.\s*$/gm, '') // Rimuovi numeri di punti isolati
          .trim();
      }
      
      // Rimuovi riferimenti al limone se non presente
      if (!finalIngredientNames.has('succo di limone') && !finalIngredientNames.has('limone')) {
        correctedInstruction = correctedInstruction
          .replace(/Aggiungi il succo di limone.*?\.?/gi, '')
          .replace(/.*limone.*?\.?/gi, '')
          .trim();
      }
      
      return correctedInstruction;
    }).filter(instruction => instruction.length > 0 && !/^\d+\.\s*$/.test(instruction));

    console.log(`Ricetta generata con scarti specifici per: ${ingredients.join(', ')}`);
    
    return result;
  } catch (error) {
    console.error("Errore nella generazione ricetta:", error);
    throw new Error("Impossibile generare la ricetta. Riprova più tardi.");
  }
}

function createRecipePrompt(request: RecipeGenerationRequest): string {
  const { ingredients, type, servings = 4, targetQuantity, targetUnit, additionalInstructions } = request;
  
  // Ottieni gli ingredienti disponibili dal database nutrizionale
  const ingredientCategories = getIngredientsByCategory();
  
  const productionInfo = targetQuantity && targetUnit ? 
    `- Quantità target: ${targetQuantity} ${targetUnit}
- Calcola le quantità degli ingredienti per produrre esattamente ${targetQuantity} ${targetUnit}` : 
    `- Porzioni: ${servings}`;

  // Controlla istruzioni speciali dell'utente
  const instructionsText = (additionalInstructions || '').toLowerCase();
  const ingredientsText = ingredients.join(' ').toLowerCase();
  const isNoSugar = instructionsText.includes('senza zucchero') || 
                   instructionsText.includes('sugar free') ||
                   instructionsText.includes('no sugar') ||
                   ingredientsText.includes('senza zucchero');
  
  const isNoLemon = instructionsText.includes('senza succo di limone') ||
                   instructionsText.includes('senza limone') ||
                   instructionsText.includes('no limone');
  
  const isNoSalt = instructionsText.includes('senza sale') ||
                  instructionsText.includes('no sale');
  
  const isNoOil = instructionsText.includes('senza olio') ||
                 instructionsText.includes('no olio');
  
  // Determina quale acidificante utilizzare
  const acidType = instructionsText.includes('acidificante: succo di limone fresco') ? 'limone' : 'aceto';

  // Calcola scarti di lavorazione basati sul tipo di ingrediente
  const calculateWasteFactors = (ingredients: string[]) => {
    let totalWasteFactor = 0;
    
    ingredients.forEach(ingredient => {
      const lowerIng = ingredient.toLowerCase();
      // Scarti per frutta (bucce, noccioli, liquidi persi)
      if (['albicocche', 'pesche', 'prugne'].some(fruit => lowerIng.includes(fruit))) {
        totalWasteFactor += 0.15; // 15% scarto (noccioli + bucce)
      } else if (['fragole', 'frutti di bosco'].some(fruit => lowerIng.includes(fruit))) {
        totalWasteFactor += 0.08; // 8% scarto (piccioli + liquidi)
      } else if (['mele', 'pere'].some(fruit => lowerIng.includes(fruit))) {
        totalWasteFactor += 0.20; // 20% scarto (torsolo + buccia)
      } else if (['pomodori', 'pomodoro'].some(veg => lowerIng.includes(veg))) {
        totalWasteFactor += 0.10; // 10% scarto (bucce + semi)
      } else if (['zucchine', 'carote', 'verdure'].some(veg => lowerIng.includes(veg))) {
        totalWasteFactor += 0.12; // 12% scarto (bucce + estremità)
      } else {
        totalWasteFactor += 0.05; // 5% scarto generico (evaporazione)
      }
    });
    
    return Math.min(totalWasteFactor, 0.25); // Massimo 25% di scarto
  };

  const wasteFactor = calculateWasteFactors(ingredients);
  const adjustmentFactor = 1 + wasteFactor;

  let typeDescription = '';
  let specificGuidelines = '';
  
  switch (type) {
    case 'dolce':
      typeDescription = 'Dolce/Dessert';
      specificGuidelines = `
- Focus su confetture, marmellate, dolci da forno
- Zucchero consentito se necessario per conservazione
- Considera tempi di cottura per gelificazione`;
      break;
    case 'salato':
      typeDescription = 'Conserva Salata in Vasetti';
      specificGuidelines = `
- Crea una conserva salata adatta per vasetti di vetro
- Deve essere stabile a temperatura ambiente dopo sterilizzazione
- Usa tecniche di conservazione: cottura prolungata, acidificazione con ${acidType === 'limone' ? 'succo di limone' : 'aceto'}
- Texture cremosa o a pezzi, adatta per invasettamento
- Bilancia sapori con sale, ${acidType === 'limone' ? 'succo di limone' : 'aceto'}, erbe aromatiche per conservazione
- Esempio: crema di verdure, paté vegetale, conserva agrodolce`;
      break;
    case 'succo':
      typeDescription = 'Succo di Frutta';
      specificGuidelines = `
- Estrai succo dalla frutta mantenendo sapore naturale
- Aggiungi solo acqua se necessario per consistenza
- Considera filtrazione e pastorizzazione per conservazione
- NO zuccheri aggiunti se non richiesti`;
      break;
    case 'sottolio':
      typeDescription = 'Conserva Sott\'olio';
      specificGuidelines = `
- Prepara verdure per conservazione in olio
- Usa olio EVO di qualità come liquido di governo
- Considera blanching o cottura preliminare delle verdure
- Aggiungi erbe aromatiche per sapore`;
      break;
  }

  return `
Crea una ricetta ${typeDescription} utilizzando SOLO: ${ingredients.join(', ')}.

CALCOLO SCARTI DI LAVORAZIONE:
- Scarto stimato per questa ricetta: ${Math.round(wasteFactor * 100)}%
- Fattore di aggiustamento: ${adjustmentFactor.toFixed(2)}
- Per produrre ${targetQuantity}${targetUnit}, calcola le quantità considerando gli scarti

REGOLE ASSOLUTE - NESSUNA ECCEZIONE:
1. INGREDIENTI PRINCIPALI: USA SOLO ${ingredients.join(', ')} come base della ricetta
2. AGGIUNGI AUTOMATICAMENTE solo gli ingredienti base ESSENZIALI per il tipo di ricetta:
   ${type === 'sottolio' ? `- ${isNoOil ? 'VIETATO olio (richiesta senza olio)' : 'olio evo (OBBLIGATORIO per sott\'olio)'}\n   - ${isNoSalt ? 'VIETATO sale (richiesta senza sale)' : 'sale (per salatura)'}\n   - ${acidType === 'limone' ? 'succo di limone (per acidificazione)' : 'aceto (per acidificazione)'}\n   - aglio (per sapore)` : ''}
   ${type === 'salato' ? `- ${isNoSalt ? 'VIETATO sale (richiesta senza sale)' : 'sale (per conservazione)'}\n   - ${isNoOil ? 'VIETATO olio (richiesta senza olio)' : 'olio evo (per condimento)'}\n   - ${acidType === 'limone' ? 'succo di limone (per acidificazione)' : 'aceto (per acidificazione)'}` : ''}
   ${type === 'succo' ? `- acqua (se necessario per consistenza)` : ''}
   ${type === 'dolce' ? `- ${isNoSugar ? 'VIETATO zucchero (richiesta senza zucchero)' : 'zucchero (se necessario per gelificazione)'}\n   - pectina (se necessario)` : ''}
3. ACIDIFICANTE: USA SOLO ${acidType === 'limone' ? 'succo di limone' : 'aceto'} - NON AGGIUNGERE ENTRAMBI
4. AGGIUNGI erbe/spezie SOLO se l'utente le ha incluse negli ingredienti principali
5. VIETATO aggiungere: vaniglia, cannella, altri frutti/verdure non correlati
6. RISPETTA SEMPRE le richieste "senza X" nelle istruzioni aggiuntive - NESSUNA ECCEZIONE
${isNoSugar ? '7. ASSOLUTAMENTE VIETATO aggiungere zucchero, miele o dolcificanti - ricetta SENZA ZUCCHERO' : ''}
${isNoLemon ? '8. ASSOLUTAMENTE VIETATO aggiungere succo di limone, limone - ricetta SENZA LIMONE - NON INCLUDERLO MAI' : ''}
${isNoSalt ? '9. ASSOLUTAMENTE VIETATO aggiungere sale - ricetta SENZA SALE' : ''}
${isNoOil ? '10. ASSOLUTAMENTE VIETATO aggiungere olio - ricetta SENZA OLIO' : ''}
IMPORTANTE: PER RICETTE SOTT'OLIO - NON includere mai succo di limone, basilico, menta o altre erbe se non specificate dall'utente
11. Nel JSON usa i nomi ESATTI dal database: "${ingredients.join('", "')}", "olio evo", "sale", "aglio"
12. NON usare nomi generici come "Frutta" - usa il nome specifico dell'ingrediente
13. AUMENTA le quantità del ${Math.round(wasteFactor * 100)}% per compensare gli scarti (moltiplicare per ${adjustmentFactor.toFixed(2)})
14. USA SOLO gli ingredienti specificati dall'utente più quelli base essenziali per il tipo di ricetta

INGREDIENTI DISPONIBILI NEL DATABASE (usa SOLO questi nomi esatti):
- Dolcificanti: ${ingredientCategories.dolcificanti.join(', ')}
- Spezie base: ${ingredientCategories.spezie.slice(0, 8).join(', ')}
- Oli: ${ingredientCategories.oli.join(', ')}
- Acidificanti: ${ingredientCategories.altro.filter(ing => ing.includes('limone') || ing.includes('aceto')).join(', ')}
- Addensanti: ${ingredientCategories.altro.filter(ing => ing.includes('pectina')).join(', ')}

Requisiti:
- Tipo: ${typeDescription}
${productionInfo}
- USA ESCLUSIVAMENTE gli ingredienti principali forniti: ${ingredients.join(', ')}
- Aggiungi solo ingredienti base essenziali dalla lista sopra
- Il nome della ricetta deve riflettere SOLO gli ingredienti principali forniti
- Ricetta semplice e realizzabile per produzione artigianale
${specificGuidelines}
${additionalInstructions ? `- Istruzioni aggiuntive: ${additionalInstructions}` : ''}

ESEMPI DI RICETTE COMPLETE:
- Se ingredienti utente: ["melanzane"] + tipo "sott'olio" → 
  Ingredienti finali: ["melanzane", "olio evo", "sale", "aceto", "aglio", "basilico"]
  Nome: "Melanzane Sott'olio"
- Se ingredienti utente: ["mele"] + tipo "succo" →
  Ingredienti finali: ["mele", "succo di limone", "acqua"]
  Nome: "Succo di Mele"
- Se ingredienti utente: ["fragole"] + tipo "dolce" →
  Ingredienti finali: ["fragole", "zucchero", "succo di limone", "pectina"]
  Nome: "Marmellata di Fragole"

CALCOLO MATEMATICO OBBLIGATORIO:
Quantità base per ${targetQuantity || 600}${targetUnit || 'ml'}: 
- Ingrediente principale: 800g base
- Con ${Math.round(wasteFactor * 100)}% scarto: 800 × ${adjustmentFactor.toFixed(2)} = ${Math.round(800 * adjustmentFactor)}g
- Altri ingredienti: moltiplicare sempre per ${adjustmentFactor.toFixed(2)}

UNITÀ DI MISURA OBBLIGATORIE:
- Ingredienti solidi: sempre in grammi (g)
- Liquidi (olio, succo, acqua): sempre in litri (L) - MAI in ml
- Sale, spezie: sempre in grammi (g)

ESEMPIO CORRETTO:
{
  "name": "Ricetta di ${ingredients[0]}",
  "ingredients": [
    {"name": "${ingredients[0]}", "quantity": ${Math.round(800 * adjustmentFactor)}, "unit": "g"},
    {"name": "sale", "quantity": ${Math.round(10 * adjustmentFactor)}, "unit": "g"},
    {"name": "olio evo", "quantity": ${(Math.round(8 * adjustmentFactor) / 1000).toFixed(2)}, "unit": "L"}
  ]
}

Rispondi in formato JSON con questa struttura esatta:
{
  "name": "Nome della ricetta",
  "category": "${type === 'dolce' ? 'Dolci' : 'Secondi'}",
  "description": "Breve descrizione appetitosa della ricetta",
  "ingredients": [
    {
      "name": "nome ingrediente ESATTO dal database nutrizionale",
      "quantity": numero,
      "unit": "unità di misura (g, ml, pz, cucchiai, etc.)"
    }
  ],
  "instructions": [
    "Passaggio 1 dettagliato",
    "Passaggio 2 dettagliato",
    "etc."
  ],
  "preparationTime": numero_minuti_preparazione,
  "cookingTime": numero_minuti_cottura,
  "difficulty": "facile|medio|difficile",
  "notes": "Consigli utili o varianti (opzionale)"
}

Assicurati che:
- AUMENTA tutte le quantità degli ingredienti del ${Math.round(wasteFactor * 100)}% moltiplicandole per ${adjustmentFactor.toFixed(2)}
- NON aggiungere ingredienti extra - usa SOLO quelli forniti dall'utente
- Le quantità finali devono essere maggiori delle quantità base per compensare gli scarti
- Le istruzioni siano chiare e dettagliate per produzione artigianale
- I tempi siano accurati per la quantità aumentata
- La ricetta deve produrre esattamente ${targetQuantity && targetUnit ? `${targetQuantity} ${targetUnit}` : `${servings} porzioni`} di prodotto finito
`;
}

export function calculateRecipeNutrition(recipe: GeneratedRecipe) {
  const ingredientsWithQuantities = recipe.ingredients.map(ing => ({
    name: ing.name,
    quantity: ing.quantity,
    unit: ing.unit
  }));
  
  return calculateNutritionalValues(ingredientsWithQuantities);
}