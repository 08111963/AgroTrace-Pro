import { exec } from 'child_process';
import { promisify } from 'util';
import { writeFile, mkdir, readdir, stat, unlink } from 'fs/promises';
import path from 'path';
import { format } from 'date-fns';

const execAsync = promisify(exec);

export class DatabaseBackupService {
  private backupDir = './backups';
  private maxBackups = 30; // Mantieni 30 backup (circa 1 mese)
  private isRunning = false;

  constructor() {
    this.ensureBackupDirectory();
  }

  private async ensureBackupDirectory() {
    try {
      await mkdir(this.backupDir, { recursive: true });
    } catch (error) {
      console.error('Errore nella creazione della directory backup:', error);
    }
  }

  /**
   * Esegue un backup completo del database
   */
  async createBackup(): Promise<string | null> {
    if (this.isRunning) {
      console.log('Backup già in corso, salto questa esecuzione');
      return null;
    }

    this.isRunning = true;
    const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm-ss');
    const backupFileName = `agrotrace_backup_${timestamp}.sql`;
    const backupPath = path.join(this.backupDir, backupFileName);

    try {
      console.log(`Avvio backup database: ${backupFileName}`);

      // Comando pg_dump per esportare il database
      const databaseUrl = process.env.DATABASE_URL;
      if (!databaseUrl) {
        throw new Error('DATABASE_URL non configurato');
      }

      // Estrai componenti dall'URL del database
      const url = new URL(databaseUrl);
      const dbName = url.pathname.slice(1); // Rimuovi il primo '/'
      const host = url.hostname;
      const port = url.port || '5432';
      const username = url.username;
      const password = url.password;

      // Comando per creare il backup
      const pgDumpCommand = `PGPASSWORD="${password}" pg_dump -h "${host}" -p "${port}" -U "${username}" -d "${dbName}" --no-password --verbose --clean --if-exists --create`;

      const { stdout, stderr } = await execAsync(pgDumpCommand);
      
      // Salva il backup su file
      await writeFile(backupPath, stdout);

      if (stderr && !stderr.includes('NOTICE:')) {
        console.warn('Warning durante il backup:', stderr);
      }

      console.log(`Backup completato: ${backupPath}`);
      
      // Pulisci i backup vecchi
      await this.cleanOldBackups();
      
      return backupPath;
    } catch (error) {
      console.error('Errore durante il backup:', error);
      // Rimuovi il file di backup parziale se esiste
      try {
        await unlink(backupPath);
      } catch {}
      return null;
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Rimuove i backup più vecchi mantenendo solo gli ultimi N
   */
  private async cleanOldBackups() {
    try {
      const files = await readdir(this.backupDir);
      const backupFiles = files
        .filter(file => file.startsWith('agrotrace_backup_') && file.endsWith('.sql'))
        .map(async file => {
          const filePath = path.join(this.backupDir, file);
          const stats = await stat(filePath);
          return { file, path: filePath, mtime: stats.mtime };
        });

      const backupsWithStats = await Promise.all(backupFiles);
      
      // Ordina per data di modifica (più recente prima)
      backupsWithStats.sort((a, b) => b.mtime.getTime() - a.mtime.getTime());

      // Rimuovi i backup in eccesso
      if (backupsWithStats.length > this.maxBackups) {
        const toDelete = backupsWithStats.slice(this.maxBackups);
        for (const backup of toDelete) {
          await unlink(backup.path);
          console.log(`Rimosso backup vecchio: ${backup.file}`);
        }
      }
    } catch (error) {
      console.error('Errore nella pulizia dei backup vecchi:', error);
    }
  }

  /**
   * Avvia il servizio di backup automatico
   */
  startAutoBackup() {
    // Backup ogni 6 ore (21600000 ms)
    const backupInterval = 6 * 60 * 60 * 1000;
    
    console.log('Avvio servizio backup automatico (ogni 6 ore)');
    
    // Primo backup dopo 5 minuti
    setTimeout(() => {
      this.createBackup();
    }, 5 * 60 * 1000);

    // Backup ricorrenti ogni 6 ore
    setInterval(() => {
      this.createBackup();
    }, backupInterval);
  }

  /**
   * Ottieni la lista dei backup disponibili
   */
  async getBackupList(): Promise<Array<{ file: string; date: Date; size: number }>> {
    try {
      const files = await readdir(this.backupDir);
      const backupFiles = files
        .filter(file => file.startsWith('agrotrace_backup_') && file.endsWith('.sql'))
        .map(async file => {
          const filePath = path.join(this.backupDir, file);
          const stats = await stat(filePath);
          return { 
            file, 
            date: stats.mtime, 
            size: stats.size 
          };
        });

      const backups = await Promise.all(backupFiles);
      return backups.sort((a, b) => b.date.getTime() - a.date.getTime());
    } catch (error) {
      console.error('Errore nel recupero lista backup:', error);
      return [];
    }
  }

  /**
   * Ripristina un backup specifico
   */
  async restoreBackup(backupFileName: string): Promise<boolean> {
    const backupPath = path.join(this.backupDir, backupFileName);
    
    try {
      console.log(`Ripristino backup: ${backupFileName}`);

      const databaseUrl = process.env.DATABASE_URL;
      if (!databaseUrl) {
        throw new Error('DATABASE_URL non configurato');
      }

      const url = new URL(databaseUrl);
      const dbName = url.pathname.slice(1);
      const host = url.hostname;
      const port = url.port || '5432';
      const username = url.username;
      const password = url.password;

      // Comando per ripristinare il backup
      const psqlCommand = `PGPASSWORD="${password}" psql -h "${host}" -p "${port}" -U "${username}" -d "${dbName}" -f "${backupPath}"`;

      const { stderr } = await execAsync(psqlCommand);
      
      if (stderr && !stderr.includes('NOTICE:')) {
        console.warn('Warning durante il ripristino:', stderr);
      }

      console.log(`Ripristino completato: ${backupFileName}`);
      return true;
    } catch (error) {
      console.error('Errore durante il ripristino:', error);
      return false;
    }
  }
}

// Istanza singleton del servizio backup
export const backupService = new DatabaseBackupService();