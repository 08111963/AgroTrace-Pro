import { db } from "./db";
import { licenseCodes, licenseActivations, users } from "@shared/schema";
import { eq, and, lt, gt } from "drizzle-orm";
import crypto from "crypto";

export interface LicenseCodeGeneration {
  planType: 'basic' | 'premium' | 'enterprise';
  duration: number; // giorni
  maxActivations?: number;
  generatedFor?: string; // email cliente
  orderReference?: string;
  notes?: string;
  expiresAt?: Date; // scadenza del codice stesso
}

export interface LicenseCodeValidation {
  isValid: boolean;
  planType?: string;
  duration?: number;
  message: string;
  activationsLeft?: number;
}

export class LicenseCodeService {
  
  /**
   * Genera un nuovo codice licenza
   */
  async generateLicenseCode(params: LicenseCodeGeneration): Promise<string> {
    // Genera un codice univoco formato: AGRO-XXXX-XXXX-XXXX
    const code = this.generateUniqueCode();
    
    // Verifica che il codice sia veramente univoco
    const existing = await db.select().from(licenseCodes).where(eq(licenseCodes.code, code));
    if (existing.length > 0) {
      // Retry con nuovo codice se esiste già
      return this.generateLicenseCode(params);
    }
    
    // Inserisci il nuovo codice
    await db.insert(licenseCodes).values({
      code,
      planType: params.planType,
      duration: params.duration,
      maxActivations: params.maxActivations || 1,
      generatedFor: params.generatedFor,
      orderReference: params.orderReference,
      notes: params.notes,
      expiresAt: params.expiresAt,
      generatedBy: 'system' // potrebbe essere l'admin che lo genera
    });
    
    return code;
  }
  
  /**
   * Valida un codice licenza prima dell'attivazione
   */
  async validateLicenseCode(code: string): Promise<LicenseCodeValidation> {
    const licenseCode = await db.select()
      .from(licenseCodes)
      .where(eq(licenseCodes.code, code.toUpperCase()));
    
    if (licenseCode.length === 0) {
      return {
        isValid: false,
        message: "Codice licenza non valido o inesistente"
      };
    }
    
    const license = licenseCode[0];
    
    // Controllo se il codice è attivo
    if (!license.isActive) {
      return {
        isValid: false,
        message: "Codice licenza disattivato"
      };
    }
    
    // Controllo se il codice è scaduto
    if (license.expiresAt && new Date() > license.expiresAt) {
      return {
        isValid: false,
        message: "Codice licenza scaduto"
      };
    }
    
    // Controllo attivazioni disponibili
    if (license.currentActivations >= license.maxActivations) {
      return {
        isValid: false,
        message: "Codice licenza già utilizzato il numero massimo di volte"
      };
    }
    
    const activationsLeft = license.maxActivations - license.currentActivations;
    
    return {
      isValid: true,
      planType: license.planType,
      duration: license.duration,
      activationsLeft,
      message: `Codice valido per piano ${license.planType} - ${license.duration} giorni`
    };
  }
  
  /**
   * Attiva un codice licenza per un utente
   */
  async activateLicenseCode(code: string, userId: number, deviceInfo?: string, ipAddress?: string): Promise<boolean> {
    const validation = await this.validateLicenseCode(code);
    
    if (!validation.isValid) {
      throw new Error(validation.message);
    }
    
    // Recupera il codice licenza
    const [licenseCode] = await db.select()
      .from(licenseCodes)
      .where(eq(licenseCodes.code, code.toUpperCase()));
    
    // Calcola data di scadenza della licenza
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + licenseCode.duration);
    
    // Inserisci l'attivazione
    await db.insert(licenseActivations).values({
      licenseCodeId: licenseCode.id,
      userId,
      expiresAt,
      deviceInfo,
      ipAddress
    });
    
    // Aggiorna il contatore delle attivazioni
    await db.update(licenseCodes)
      .set({ 
        currentActivations: licenseCode.currentActivations + 1,
        updatedAt: new Date()
      })
      .where(eq(licenseCodes.id, licenseCode.id));
    
    // Aggiorna l'utente con i dati della licenza
    await db.update(users)
      .set({
        licenseCode: code.toUpperCase(),
        licenseActivatedAt: new Date(),
        licenseExpiresAt: expiresAt,
        licenseType: licenseCode.planType,
        subscriptionStatus: 'active',
        subscriptionPlan: licenseCode.planType,
        subscriptionStartDate: new Date(),
        subscriptionEndDate: expiresAt,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));
    
    return true;
  }
  
  /**
   * Controlla lo stato della licenza di un utente
   */
  async checkUserLicense(userId: number): Promise<any> {
    const [user] = await db.select()
      .from(users)
      .where(eq(users.id, userId));
    
    if (!user || !user.licenseCode) {
      return {
        hasLicense: false,
        message: "Nessuna licenza attiva"
      };
    }
    
    // Controlla se la licenza è ancora valida
    if (user.licenseExpiresAt && new Date() > user.licenseExpiresAt) {
      return {
        hasLicense: false,
        expired: true,
        message: "Licenza scaduta",
        expiredAt: user.licenseExpiresAt
      };
    }
    
    const daysRemaining = user.licenseExpiresAt 
      ? Math.ceil((user.licenseExpiresAt.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
      : null;
    
    return {
      hasLicense: true,
      licenseCode: user.licenseCode,
      licenseType: user.licenseType,
      activatedAt: user.licenseActivatedAt,
      expiresAt: user.licenseExpiresAt,
      daysRemaining,
      message: `Licenza ${user.licenseType} attiva - ${daysRemaining} giorni rimanenti`
    };
  }
  
  /**
   * Genera codice univoco formato AGRO-XXXX-XXXX-XXXX
   */
  private generateUniqueCode(): string {
    const segments = [];
    
    // Primo segmento: sempre AGRO
    segments.push('AGRO');
    
    // Altri 3 segmenti: 4 caratteri alfanumerici ciascuno
    for (let i = 0; i < 3; i++) {
      const segment = crypto.randomBytes(2).toString('hex').toUpperCase() + 
                     Math.random().toString(36).substring(2, 4).toUpperCase();
      segments.push(segment.substring(0, 4));
    }
    
    return segments.join('-');
  }
  
  /**
   * Lista tutti i codici generati (per admin)
   */
  async getAllLicenseCodes(): Promise<any[]> {
    return await db.select().from(licenseCodes);
  }
  
  /**
   * Disattiva un codice licenza
   */
  async deactivateLicenseCode(code: string): Promise<boolean> {
    const result = await db.update(licenseCodes)
      .set({ 
        isActive: false,
        updatedAt: new Date()
      })
      .where(eq(licenseCodes.code, code.toUpperCase()));
    
    return (result.rowCount || 0) > 0;
  }
}

export const licenseCodeService = new LicenseCodeService();