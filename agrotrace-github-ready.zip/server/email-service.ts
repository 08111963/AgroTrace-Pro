import fetch from 'node-fetch';

interface EmailParams {
  to: string;
  toName?: string;
  subject: string;
  htmlContent: string;
  textContent?: string;
}

export class BrevoEmailService {
  private apiKey: string;
  private apiUrl = 'https://api.brevo.com/v3/smtp/email';

  constructor() {
    this.apiKey = process.env.BREVO_API_KEY || '';
    if (!this.apiKey) {
      console.warn('BREVO_API_KEY non configurata - invio email disabilitato');
    }
  }

  async sendLicenseCode(params: {
    recipientEmail: string;
    recipientName?: string;
    licenseCode: string;
    planType: string;
    duration: number;
    companyName?: string;
  }): Promise<boolean> {
    if (!this.apiKey) {
      console.error('BREVO_API_KEY non configurata');
      return false;
    }

    const { recipientEmail, recipientName, licenseCode, planType, duration, companyName } = params;

    const htmlContent = this.generateLicenseEmailHTML({
      licenseCode,
      planType,
      duration,
      recipientName: recipientName || recipientEmail,
      companyName: companyName || 'AgroTrace Pro'
    });

    const textContent = this.generateLicenseEmailText({
      licenseCode,
      planType,
      duration,
      recipientName: recipientName || recipientEmail
    });

    return await this.sendEmail({
      to: recipientEmail,
      toName: recipientName,
      subject: `La tua licenza AgroTrace Pro è pronta - Piano ${planType.toUpperCase()}`,
      htmlContent,
      textContent
    });
  }

  private async sendEmail(params: EmailParams): Promise<boolean> {
    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'api-key': this.apiKey
        },
        body: JSON.stringify({
          sender: {
            name: 'AgroTrace Pro',
            email: 'noreply@agrotrace.com'
          },
          to: [{
            email: params.to,
            name: params.toName || params.to
          }],
          subject: params.subject,
          htmlContent: params.htmlContent,
          textContent: params.textContent
        })
      });

      if (response.ok) {
        console.log(`Email inviata con successo a ${params.to}`);
        return true;
      } else {
        const errorData: any = await response.json().catch(async () => {
          const text = await response.text();
          return { message: text };
        });
        console.error('Errore invio email:', errorData);
        
        // Rilancia l'errore con dettagli per il frontend
        if (errorData.message && (
          errorData.message.includes('not authorized') ||
          errorData.message.includes('not verified') ||
          errorData.message.includes('permission_denied') ||
          errorData.code === 'permission_denied'
        )) {
          throw new Error(`AUTHORIZATION_REQUIRED: L'indirizzo ${params.to} deve essere autorizzato nel tuo account Brevo.`);
        }
        
        throw new Error(errorData.message || `Errore HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Errore invio email:', error);
      return false;
    }
  }

  private generateLicenseEmailHTML(params: {
    licenseCode: string;
    planType: string;
    duration: number;
    recipientName: string;
    companyName: string;
  }): string {
    const { licenseCode, planType, duration, recipientName, companyName } = params;
    
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>La tua Licenza AgroTrace Pro</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #4ade80 0%, #22c55e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 28px;">🌱 AgroTrace Pro</h1>
        <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Sistema di Tracciabilità Agroalimentare</p>
    </div>
    
    <div style="background: #f8fffe; padding: 30px; border-radius: 0 0 10px 10px; border: 1px solid #e5e7eb;">
        <h2 style="color: #059669; margin-top: 0;">Ciao ${recipientName}!</h2>
        
        <p>La tua licenza AgroTrace Pro è stata generata con successo. Ecco i dettagli:</p>
        
        <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #22c55e; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #059669;">📋 Dettagli Licenza</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">Codice Licenza:</td>
                    <td style="padding: 8px 0; font-family: monospace; font-size: 18px; color: #059669; font-weight: bold;">${licenseCode}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">Piano:</td>
                    <td style="padding: 8px 0;">${planType.toUpperCase()}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">Durata:</td>
                    <td style="padding: 8px 0;">${duration} giorni</td>
                </tr>
            </table>
        </div>
        
        <div style="background: #fef3c7; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b; margin: 20px 0;">
            <h4 style="margin-top: 0; color: #92400e;">🔑 Come Attivare la Licenza</h4>
            <ol style="margin: 0; padding-left: 20px;">
                <li>Accedi al tuo account AgroTrace Pro</li>
                <li>Vai nella sezione "Licenza"</li>
                <li>Inserisci il codice: <strong>${licenseCode}</strong></li>
                <li>Clicca su "Attiva Licenza"</li>
            </ol>
        </div>
        
        <div style="background: #dbeafe; padding: 15px; border-radius: 8px; border-left: 4px solid #3b82f6; margin: 20px 0;">
            <h4 style="margin-top: 0; color: #1e40af;">💡 Cosa Include il Piano ${planType.toUpperCase()}</h4>
            ${this.getPlanFeatures(planType)}
        </div>
        
        <p style="margin-top: 30px;">Se hai domande o hai bisogno di assistenza, non esitare a contattarci.</p>
        
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
            <p style="color: #6b7280; font-size: 14px; margin: 0;">
                Grazie per aver scelto AgroTrace Pro<br>
                ${companyName}
            </p>
        </div>
    </div>
</body>
</html>`;
  }

  private generateLicenseEmailText(params: {
    licenseCode: string;
    planType: string;
    duration: number;
    recipientName: string;
  }): string {
    const { licenseCode, planType, duration, recipientName } = params;
    
    return `
Ciao ${recipientName}!

La tua licenza AgroTrace Pro è stata generata con successo.

DETTAGLI LICENZA:
- Codice Licenza: ${licenseCode}
- Piano: ${planType.toUpperCase()}
- Durata: ${duration} giorni

COME ATTIVARE:
1. Accedi al tuo account AgroTrace Pro
2. Vai nella sezione "Licenza"
3. Inserisci il codice: ${licenseCode}
4. Clicca su "Attiva Licenza"

Se hai domande o hai bisogno di assistenza, non esitare a contattarci.

Grazie per aver scelto AgroTrace Pro!
`;
  }

  private getPlanFeatures(planType: string): string {
    switch (planType.toLowerCase()) {
      case 'basic':
        return `
            <ul style="margin: 0; padding-left: 20px;">
                <li>50 ricette</li>
                <li>100 lotti di produzione</li>
                <li>Reports di base</li>
                <li>Supporto email</li>
            </ul>
        `;
      case 'premium':
        return `
            <ul style="margin: 0; padding-left: 20px;">
                <li>Ricette illimitate</li>
                <li>Lotti illimitati</li>
                <li>Reports avanzati</li>
                <li>Export PDF</li>
                <li>Supporto prioritario</li>
            </ul>
        `;
      case 'enterprise':
        return `
            <ul style="margin: 0; padding-left: 20px;">
                <li>Tutte le funzionalità Premium</li>
                <li>Multi-utente</li>
                <li>API access</li>
                <li>Backup automatici</li>
                <li>Supporto dedicato 24/7</li>
            </ul>
        `;
      default:
        return '<p>Funzionalità complete del piano selezionato</p>';
    }
  }
}

export const emailService = new BrevoEmailService();