// Database nutrizionale per ingredienti comuni (valori per 100g)
export interface NutritionalData {
  calories: number; // kcal
  proteins: number; // g
  carbohydrates: number; // g
  sugars: number; // g
  fats: number; // g
  saturatedFats: number; // g
  fiber: number; // g
  sodium: number; // mg
  salt: number; // g (calcolato da sodium)
}

export const nutritionalDatabase: Record<string, NutritionalData> = {
  // Verdure
  "Cipolle": {
    calories: 40,
    proteins: 1.1,
    carbohydrates: 9.3,
    sugars: 4.2,
    fats: 0.1,
    saturatedFats: 0.04,
    fiber: 1.7,
    sodium: 4,
    salt: 0.01
  },
  
  // Oli e grassi
  "olio evo": {
    calories: 884,
    proteins: 0,
    carbohydrates: 0,
    sugars: 0,
    fats: 100,
    saturatedFats: 13.8,
    fiber: 0,
    sodium: 2,
    salt: 0.005
  },
  
  // Zuccheri
  "Zucchero di canna": {
    calories: 387,
    proteins: 0,
    carbohydrates: 100,
    sugars: 97,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 1,
    salt: 0.0025
  },
  
  // Sale
  "Sale": {
    calories: 0,
    proteins: 0,
    carbohydrates: 0,
    sugars: 0,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 38758, // Sale marino = 97% sodio
    salt: 98.5
  },
  
  // Aceto balsamico
  "Aceto balsamico": {
    calories: 88,
    proteins: 0.49,
    carbohydrates: 17.03,
    sugars: 14.95,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 23,
    salt: 0.058
  },
  
  // Condimenti
  "aceto balsamico": {
    calories: 88,
    proteins: 0.5,
    carbohydrates: 17,
    sugars: 14.9,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 23,
    salt: 0.058
  },
  
  // Altri ingredienti comuni
  "pomodoro": {
    calories: 18,
    proteins: 0.9,
    carbohydrates: 3.9,
    sugars: 2.6,
    fats: 0.2,
    saturatedFats: 0.03,
    fiber: 1.2,
    sodium: 5,
    salt: 0.0125
  },
  
  "aglio": {
    calories: 149,
    proteins: 6.4,
    carbohydrates: 33,
    sugars: 1,
    fats: 0.5,
    saturatedFats: 0.09,
    fiber: 2.1,
    sodium: 17,
    salt: 0.043
  },
  
  "basilico": {
    calories: 22,
    proteins: 3.2,
    carbohydrates: 2.6,
    sugars: 0.3,
    fats: 0.6,
    saturatedFats: 0.04,
    fiber: 1.6,
    sodium: 4,
    salt: 0.01
  },
  
  "menta": {
    calories: 70,
    proteins: 3.8,
    carbohydrates: 14.9,
    sugars: 0.0,
    fats: 0.9,
    saturatedFats: 0.2,
    fiber: 8.0,
    sodium: 31,
    salt: 0.08
  },
  
  "sale": {
    calories: 0,
    proteins: 0,
    carbohydrates: 0,
    sugars: 0,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 38758,
    salt: 97.4
  },
  
  "pepe nero": {
    calories: 251,
    proteins: 10.4,
    carbohydrates: 64,
    sugars: 0.6,
    fats: 3.3,
    saturatedFats: 1.4,
    fiber: 25.3,
    sodium: 20,
    salt: 0.05
  },
  
  "peperoncino": {
    calories: 40,
    proteins: 1.9,
    carbohydrates: 8.8,
    sugars: 5.3,
    fats: 0.4,
    saturatedFats: 0.1,
    fiber: 1.5,
    sodium: 9,
    salt: 0.02
  },
  
  // Frutta comune
  "fragole": {
    calories: 32,
    proteins: 0.7,
    carbohydrates: 7.7,
    sugars: 4.9,
    fats: 0.3,
    saturatedFats: 0.02,
    fiber: 2.0,
    sodium: 1,
    salt: 0.003
  },
  "albicocche": {
    calories: 48,
    proteins: 1.4,
    carbohydrates: 11.1,
    sugars: 9.2,
    fats: 0.4,
    saturatedFats: 0.02,
    fiber: 2.0,
    sodium: 1,
    salt: 0.003
  },
  "mele": {
    calories: 52,
    proteins: 0.3,
    carbohydrates: 13.8,
    sugars: 10.4,
    fats: 0.2,
    saturatedFats: 0.03,
    fiber: 2.4,
    sodium: 1,
    salt: 0.003
  },
  "limoni": {
    calories: 29,
    proteins: 1.1,
    carbohydrates: 9.3,
    sugars: 2.5,
    fats: 0.3,
    saturatedFats: 0.04,
    fiber: 2.8,
    sodium: 2,
    salt: 0.005
  },
  "succo di limone": {
    calories: 22,
    proteins: 0.4,
    carbohydrates: 6.9,
    sugars: 2.5,
    fats: 0.2,
    saturatedFats: 0.04,
    fiber: 0.3,
    sodium: 1,
    salt: 0.003
  },
  "arance": {
    calories: 47,
    proteins: 0.9,
    carbohydrates: 11.8,
    sugars: 9.4,
    fats: 0.1,
    saturatedFats: 0.02,
    fiber: 2.4,
    sodium: 1,
    salt: 0.003
  },
  "pesche": {
    calories: 39,
    proteins: 0.9,
    carbohydrates: 9.5,
    sugars: 8.4,
    fats: 0.3,
    saturatedFats: 0.02,
    fiber: 1.5,
    sodium: 1,
    salt: 0.003
  },
  
  // Verdure comuni
  "carote": {
    calories: 41,
    proteins: 0.9,
    carbohydrates: 9.6,
    sugars: 4.7,
    fats: 0.2,
    saturatedFats: 0.04,
    fiber: 2.8,
    sodium: 69,
    salt: 0.175
  },
  "zucchine": {
    calories: 17,
    proteins: 1.2,
    carbohydrates: 3.1,
    sugars: 2.5,
    fats: 0.3,
    saturatedFats: 0.1,
    fiber: 1.0,
    sodium: 8,
    salt: 0.02
  },
  "peperoni": {
    calories: 31,
    proteins: 1.0,
    carbohydrates: 7.3,
    sugars: 5.3,
    fats: 0.3,
    saturatedFats: 0.07,
    fiber: 2.5,
    sodium: 4,
    salt: 0.01
  },
  
  // Zuccheri e dolcificanti
  "zucchero": {
    calories: 387,
    proteins: 0,
    carbohydrates: 99.8,
    sugars: 99.8,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 1,
    salt: 0.003
  },
  "zucchero di canna": {
    calories: 380,
    proteins: 0,
    carbohydrates: 98.0,
    sugars: 97.3,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 39,
    salt: 0.1
  },
  "miele": {
    calories: 304,
    proteins: 0.3,
    carbohydrates: 82.4,
    sugars: 82.1,
    fats: 0,
    saturatedFats: 0,
    fiber: 0.2,
    sodium: 4,
    salt: 0.01
  },
  
  // Spezie e aromi
  "cannella": {
    calories: 247,
    proteins: 4.0,
    carbohydrates: 80.6,
    sugars: 2.2,
    fats: 1.2,
    saturatedFats: 0.3,
    fiber: 53.1,
    sodium: 10,
    salt: 0.025
  },
  "vaniglia": {
    calories: 288,
    proteins: 0.1,
    carbohydrates: 12.6,
    sugars: 12.6,
    fats: 0.1,
    saturatedFats: 0.01,
    fiber: 0,
    sodium: 9,
    salt: 0.023
  },
  "zenzero": {
    calories: 80,
    proteins: 1.8,
    carbohydrates: 17.8,
    sugars: 1.7,
    fats: 0.8,
    saturatedFats: 0.2,
    fiber: 2.0,
    sodium: 13,
    salt: 0.033
  },
  
  // Altro
  "acqua": {
    calories: 0,
    proteins: 0,
    carbohydrates: 0,
    sugars: 0,
    fats: 0,
    saturatedFats: 0,
    fiber: 0,
    sodium: 0,
    salt: 0
  },
  "pectina": {
    calories: 325,
    proteins: 0.6,
    carbohydrates: 82.0,
    sugars: 0,
    fats: 0.3,
    saturatedFats: 0.1,
    fiber: 78.0,
    sodium: 4,
    salt: 0.01
  }
};

// Sistema di mappatura intelligente per ingredienti
const ingredientMapping: Record<string, string> = {
  // Varianti cipolle
  "Cipolle Bianche": "Cipolle",
  "Cipolle bianche": "Cipolle", 
  "Cipolle rosse": "Cipolle",
  "Cipolle fresche": "Cipolle",
  "cipolle": "Cipolle",
  
  // Varianti olio
  "Olio extravergine": "olio evo",
  "Olio evo": "olio evo",
  "Olio EVO": "olio evo",
  "Olio di oliva": "olio evo",
  "olio extravergine di oliva": "olio evo",
  "olio extravergine": "olio evo",
  
  // Varianti sale
  "Sale marino": "Sale",
  "sale marino": "Sale",
  "Sale fino": "Sale",
  "sale": "Sale",
  
  // Varianti aceto
  "aceto balsamico": "Aceto balsamico",
  "Aceto balsamico": "Aceto balsamico",
  
  // Varianti frutta
  "Fragole": "fragole",
  "fragole fresche": "fragole",
  "Fragole fresche": "fragole",
  "strawberries": "fragole",
  "Albicocche": "albicocche",
  "albicocche fresche": "albicocche",
  "Albicocche fresche": "albicocche",
  "albicocche": "albicocche",
  "Mele": "mele",
  "mele rosse": "mele",
  "mele verdi": "mele",
  "Limoni": "limoni",
  "limone": "limoni",
  "Limone": "limoni",
  "succo limone": "succo di limone",
  "Succo di limone": "succo di limone",
  "Arance": "arance",
  "arancia": "arance",
  "Arancia": "arance",
  "Pesche": "pesche",
  "pesca": "pesche",
  "Pesca": "pesche",
  
  // Varianti verdure
  "Carote": "carote",
  "carota": "carote",
  "Carota": "carote",
  "Zucchine": "zucchine",
  "zucchina": "zucchine",
  "Zucchina": "zucchine",
  "Peperoni": "peperoni",
  "peperone": "peperoni",
  "Peperone": "peperoni",
  
  // Varianti zuccheri
  "Zucchero": "zucchero",
  "zucchero bianco": "zucchero",
  "Zucchero bianco": "zucchero",
  "zucchero semolato": "zucchero",
  "Zucchero semolato": "zucchero",
  "Zucchero di canna": "zucchero di canna",
  "zucchero di canna": "zucchero di canna",
  "zucchero canna": "zucchero di canna",
  "Miele": "miele",
  "miele di acacia": "miele",
  "Miele di acacia": "miele",
  
  // Varianti spezie
  "Cannella": "cannella",
  "cannella in polvere": "cannella",
  "Cannella in polvere": "cannella",
  "Vaniglia": "vaniglia",
  "estratto di vaniglia": "vaniglia",
  "Estratto di vaniglia": "vaniglia",
  "vanillina": "vaniglia",
  "Zenzero": "zenzero",
  "zenzero fresco": "zenzero",
  "Zenzero fresco": "zenzero",
  "aceto": "aceto balsamico"
};

function findNutritionalData(ingredientName: string): NutritionalData | null {
  // Prima prova il nome esatto
  if (nutritionalDatabase[ingredientName]) {
    return nutritionalDatabase[ingredientName];
  }
  
  // Poi prova con il mapping
  const mappedName = ingredientMapping[ingredientName];
  if (mappedName && nutritionalDatabase[mappedName]) {
    return nutritionalDatabase[mappedName];
  }
  
  // Infine prova una ricerca case-insensitive
  const lowerName = ingredientName.toLowerCase();
  for (const [dbName, data] of Object.entries(nutritionalDatabase)) {
    if (dbName.toLowerCase() === lowerName) {
      return data;
    }
  }
  
  return null;
}

export function calculateNutritionalValues(
  ingredients: Array<{ name: string; quantity: number; unit: string }>
): NutritionalData {
  let totalWeight = 0;
  let totalCalories = 0;
  let totalProteins = 0;
  let totalCarbohydrates = 0;
  let totalSugars = 0;
  let totalFats = 0;
  let totalSaturatedFats = 0;
  let totalFiber = 0;
  let totalSodium = 0;

  for (const ingredient of ingredients) {
    const nutritionalData = findNutritionalData(ingredient.name);
    if (!nutritionalData) {
      console.log(`Dati nutrizionali non trovati per: ${ingredient.name}`);
      continue;
    }

    // Converti tutto in grammi
    let weightInGrams = ingredient.quantity;
    switch (ingredient.unit.toLowerCase()) {
      case 'kg':
        weightInGrams = ingredient.quantity * 1000;
        break;
      case 'l':
        // Assumi densità dell'acqua per liquidi (1 L = 1 kg)
        weightInGrams = ingredient.quantity * 1000;
        break;
      case 'ml':
        weightInGrams = ingredient.quantity;
        break;
      case 'g':
      default:
        weightInGrams = ingredient.quantity;
        break;
    }

    totalWeight += weightInGrams;
    
    // Calcola i valori nutrizionali basati sul peso
    const factor = weightInGrams / 100; // fattore per 100g
    totalCalories += nutritionalData.calories * factor;
    totalProteins += nutritionalData.proteins * factor;
    totalCarbohydrates += nutritionalData.carbohydrates * factor;
    totalSugars += nutritionalData.sugars * factor;
    totalFats += nutritionalData.fats * factor;
    totalSaturatedFats += nutritionalData.saturatedFats * factor;
    totalFiber += nutritionalData.fiber * factor;
    totalSodium += nutritionalData.sodium * factor;
  }

  // Se non ci sono ingredienti alimentari, restituisci valori zero
  if (totalWeight === 0) {
    return {
      calories: 0,
      proteins: 0,
      carbohydrates: 0,
      sugars: 0,
      fats: 0,
      saturatedFats: 0,
      fiber: 0,
      sodium: 0,
      salt: 0
    };
  }

  // Calcola i valori per 100g di prodotto finito
  const factorPer100g = 100 / totalWeight;
  
  return {
    calories: Math.round(totalCalories * factorPer100g * 10) / 10,
    proteins: Math.round(totalProteins * factorPer100g * 10) / 10,
    carbohydrates: Math.round(totalCarbohydrates * factorPer100g * 10) / 10,
    sugars: Math.round(totalSugars * factorPer100g * 10) / 10,
    fats: Math.round(totalFats * factorPer100g * 10) / 10,
    saturatedFats: Math.round(totalSaturatedFats * factorPer100g * 10) / 10,
    fiber: Math.round(totalFiber * factorPer100g * 10) / 10,
    sodium: Math.round(totalSodium * factorPer100g),
    salt: Math.round(totalSodium * factorPer100g * 0.00251 * 10) / 10 // conversione da mg sodium a g salt
  };
}

// Funzione per ottenere tutti gli ingredienti disponibili nel database
export function getAvailableIngredients(): string[] {
  const baseIngredients = Object.keys(nutritionalDatabase);
  const mappedIngredients = Object.keys(ingredientMapping);
  const combined = [...baseIngredients, ...mappedIngredients];
  return Array.from(new Set(combined));
}

// Funzione per categorizzare gli ingredienti
export function getIngredientsByCategory() {
  const ingredients = getAvailableIngredients();
  return {
    frutta: ingredients.filter(ing => 
      ['fragole', 'mele', 'limoni', 'arance', 'pesche', 'albicocche'].some(fruit => 
        ing.toLowerCase().includes(fruit)
      )
    ),
    verdure: ingredients.filter(ing => 
      ['cipolle', 'carote', 'zucchine', 'peperoni', 'melanzane', 'pomodoro'].some(veg => 
        ing.toLowerCase().includes(veg)
      )
    ),
    dolcificanti: ingredients.filter(ing => 
      ['zucchero', 'miele', 'canna'].some(sweet => 
        ing.toLowerCase().includes(sweet)
      )
    ),
    spezie: ingredients.filter(ing => 
      ['cannella', 'vaniglia', 'zenzero', 'pepe', 'sale'].some(spice => 
        ing.toLowerCase().includes(spice)
      )
    ),
    oli: ingredients.filter(ing => 
      ['olio', 'evo'].some(oil => 
        ing.toLowerCase().includes(oil)
      )
    ),
    altro: ingredients.filter(ing => 
      ['pectina', 'acqua', 'aceto', 'succo'].some(other => 
        ing.toLowerCase().includes(other)
      )
    )
  };
}