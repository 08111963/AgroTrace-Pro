import { db } from "./db";
import { sql } from "drizzle-orm";

export async function runSubscriptionMigration() {
  try {
    console.log("Avvio migrazione per sistema abbonamenti...");
    
    // Aggiungi colonne alla tabella users per gestione abbonamenti
    await db.execute(sql`
      ALTER TABLE users 
      ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT 'trial',
      ADD COLUMN IF NOT EXISTS subscription_plan TEXT DEFAULT 'free',
      ADD COLUMN IF NOT EXISTS trial_start_date TIMESTAMP DEFAULT NOW(),
      ADD COLUMN IF NOT EXISTS trial_end_date TIMESTAMP,
      ADD COLUMN IF NOT EXISTS subscription_start_date TIMESTAMP,
      ADD COLUMN IF NOT EXISTS subscription_end_date TIMESTAMP,
      ADD COLUMN IF NOT EXISTS last_payment_date TIMESTAMP,
      ADD COLUMN IF NOT EXISTS next_billing_date TIMESTAMP,
      ADD COLUMN IF NOT EXISTS payment_method TEXT
    `);

    // Crea tabella subscription_plans
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS subscription_plans (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        display_name TEXT NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        currency TEXT NOT NULL DEFAULT 'EUR',
        billing_period TEXT NOT NULL,
        trial_days INTEGER NOT NULL DEFAULT 7,
        max_recipes INTEGER DEFAULT -1,
        max_batches INTEGER DEFAULT -1,
        max_inventory_items INTEGER DEFAULT -1,
        max_users INTEGER DEFAULT 1,
        max_storage_gb INTEGER DEFAULT 1,
        has_advanced_reports BOOLEAN DEFAULT false,
        has_qr_labels BOOLEAN DEFAULT false,
        has_traceability BOOLEAN DEFAULT false,
        has_backup BOOLEAN DEFAULT false,
        has_api_access BOOLEAN DEFAULT false,
        has_priority_support BOOLEAN DEFAULT false,
        is_active BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    // Crea tabella subscription_history
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS subscription_history (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        plan_id INTEGER NOT NULL REFERENCES subscription_plans(id),
        status TEXT NOT NULL,
        start_date TIMESTAMP NOT NULL,
        end_date TIMESTAMP,
        amount DECIMAL(10,2),
        payment_method TEXT,
        transaction_id TEXT,
        notes TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);

    // Aggiorna gli utenti esistenti con trial_end_date
    await db.execute(sql`
      UPDATE users 
      SET trial_end_date = created_at + INTERVAL '7 days'
      WHERE trial_end_date IS NULL
    `);

    console.log("Migrazione abbonamenti completata con successo");
    return true;
  } catch (error) {
    console.error("Errore durante la migrazione abbonamenti:", error);
    return false;
  }
}