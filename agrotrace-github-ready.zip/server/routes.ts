/**
 * AgroTrace Pro - Sistema di Tracciabilità Agroalimentare
 * 
 * Copyright (c) 2025 Marino Pizzuti
 * Tutti i diritti riservati
 * 
 * API Routes - Proprietario
 * 
 * @author Marino Pizzuti
 * @copyright 2025
 */

import { Express } from "express";
import { createServer, type Server } from "http";
import { 
  insertRecipeSchema, 
  insertBatchSchema, 
  insertInventorySchema, 
  insertQRLabelSchema, 
  insertAlertSchema,
  insertUserSchema,
  insertSaleSchema 
} from "@shared/schema";
import { storage } from "./storage";
import { calculateNutritionalValues } from "./nutritional-data";
import { backupService } from "./backup";
import { licenseService } from "./license-service";
import { licenseCodeService } from "./license-code-service";
import { emailService } from "./email-service";
import { runSubscriptionMigration } from "./migration-subscription";
import session from "express-session";
import connectPg from "connect-pg-simple";
import bcrypt from "bcryptjs";

// Middleware di autenticazione
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.session?.userId) {
    return next();
  }
  return res.status(401).json({ message: "Non autenticato" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // SEO routes
  app.get("/sitemap.xml", (req, res) => {
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://agrotracepro.replit.app/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/dashboard</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/recipes</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/batches</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/inventory</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/traceability</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/alerts</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/reports</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/ai-recipes</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://agrotracepro.replit.app/profile</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
</urlset>`;

    res.set('Content-Type', 'application/xml');
    res.send(sitemap);
  });

  app.get("/robots.txt", (req, res) => {
    const robots = `User-agent: *
Allow: /

# Sitemap
Sitemap: https://agrotracepro.replit.app/sitemap.xml

# Disallow admin/private areas
Disallow: /login
Disallow: /reset-password
Disallow: /forgot-password

# Allow important pages
Allow: /
Allow: /dashboard
Allow: /recipes
Allow: /batches
Allow: /inventory
Allow: /traceability
Allow: /alerts

# Crawl delay
Crawl-delay: 1`;

    res.set('Content-Type', 'text/plain');
    res.send(robots);
  });

  // Configurazione sessioni
  const pgStore = connectPg(session);
  app.use(session({
    store: new pgStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: false,
      tableName: 'sessions'
    }),
    secret: process.env.SESSION_SECRET || 'default-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Cambiare a true in produzione con HTTPS
      httpOnly: true,
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 giorni
    }
  }));

  // AI Recipe Generation
  app.post('/api/recipes/generate', async (req, res) => {
    try {
      const { generateRecipe, calculateRecipeNutrition } = await import('./ai-recipe-generator');
      const generatedRecipe = await generateRecipe(req.body);
      
      // Calcola valori nutrizionali
      const nutrition = calculateRecipeNutrition(generatedRecipe);
      
      res.json({
        recipe: generatedRecipe,
        nutrition
      });
    } catch (error) {
      console.error('Errore generazione ricetta AI:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : 'Errore nella generazione della ricetta' 
      });
    }
  });

  // Get available ingredients from nutritional database
  app.get('/api/ingredients/available', async (req, res) => {
    try {
      const { getAvailableIngredients, getIngredientsByCategory } = await import('./nutritional-data');
      const allIngredients = getAvailableIngredients();
      const categorized = getIngredientsByCategory();
      
      res.json({
        all: allIngredients,
        byCategory: categorized
      });
    } catch (error) {
      console.error('Errore nel recupero ingredienti:', error);
      res.status(500).json({ 
        message: 'Errore nel recupero degli ingredienti disponibili' 
      });
    }
  });

  // Route di autenticazione
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Controllo se l'utente esiste già
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username già esistente" });
      }

      // Hash della password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);
      
      // Creazione utente
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword
      });

      // Login automatico dopo registrazione
      (req as any).session.userId = user.id;
      
      res.status(201).json({ 
        message: "Utente creato con successo",
        user: { id: user.id, username: user.username, email: user.email }
      });
    } catch (error) {
      console.error("Errore registrazione:", error);
      res.status(400).json({ message: "Errore durante la registrazione" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username/Email e password sono richiesti" });
      }

      // Prova prima con username, poi con email
      let user = await storage.validateUserPassword(username, password);
      if (!user) {
        // Se non trova l'utente per username, prova con email
        user = await storage.validateUserPasswordByEmail(username, password);
      }
      
      if (!user) {
        return res.status(401).json({ message: "Credenziali non valide" });
      }

      // Salva l'ID utente nella sessione
      (req as any).session.userId = user.id;
      
      res.json({ 
        message: "Login effettuato con successo",
        user: { id: user.id, username: user.username, email: user.email }
      });
    } catch (error) {
      console.error("Errore login:", error);
      res.status(500).json({ message: "Errore durante il login" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    (req as any).session.destroy((err: any) => {
      if (err) {
        return res.status(500).json({ message: "Errore durante il logout" });
      }
      res.clearCookie('connect.sid');
      res.json({ message: "Logout effettuato con successo" });
    });
  });

  // Password reset routes
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { identifier } = req.body; // può essere username o email
      
      // Prova prima con username, poi con email
      let user = await storage.getUserByUsername(identifier);
      if (!user) {
        user = await storage.getUserByEmail(identifier);
      }
      
      if (!user) {
        return res.status(404).json({ message: "Utente non trovato con questo username o email" });
      }

      const token = await storage.createPasswordResetToken(user.id);
      
      // In un ambiente di produzione, qui invieresti l'email
      // Per ora restituiamo il token direttamente per test
      res.json({ 
        message: "Token di reset generato",
        token: token // Solo per testing - rimuovere in produzione
      });
    } catch (error) {
      console.error("Errore reset password:", error);
      res.status(500).json({ message: "Errore durante la richiesta di reset" });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, newPassword } = req.body;
      
      const tokenValidation = await storage.validatePasswordResetToken(token);
      if (!tokenValidation.valid) {
        return res.status(400).json({ message: "Token non valido o scaduto" });
      }

      const success = await storage.updateUserPassword(tokenValidation.userId, newPassword);
      if (!success) {
        return res.status(500).json({ message: "Errore durante l'aggiornamento della password" });
      }

      await storage.usePasswordResetToken(token);
      
      res.json({ message: "Password aggiornata con successo" });
    } catch (error) {
      console.error("Errore reset password:", error);
      res.status(500).json({ message: "Errore durante il reset della password" });
    }
  });

  // License Code Management API
  app.post("/api/license/activate", isAuthenticated, async (req, res) => {
    try {
      const { code } = req.body;
      const userId = (req as any).session.userId;
      
      if (!code) {
        return res.status(400).json({ message: "Codice licenza richiesto" });
      }
      
      const deviceInfo = req.headers['user-agent'] || 'Unknown';
      const ipAddress = req.ip || req.connection.remoteAddress || 'Unknown';
      
      const success = await licenseCodeService.activateLicenseCode(
        code.trim(),
        userId,
        deviceInfo,
        ipAddress
      );
      
      if (success) {
        res.json({ 
          message: "Licenza attivata con successo",
          success: true 
        });
      } else {
        res.status(400).json({ message: "Errore nell'attivazione della licenza" });
      }
    } catch (error) {
      console.error("Errore attivazione licenza:", error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Errore nell'attivazione della licenza"
      });
    }
  });
  
  app.post("/api/license/validate", async (req, res) => {
    try {
      const { code } = req.body;
      
      if (!code) {
        return res.status(400).json({ message: "Codice licenza richiesto" });
      }
      
      const validation = await licenseCodeService.validateLicenseCode(code.trim());
      res.json(validation);
    } catch (error) {
      console.error("Errore validazione licenza:", error);
      res.status(500).json({ message: "Errore nella validazione del codice" });
    }
  });
  
  app.get("/api/license/user-status", isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).session.userId;
      const licenseStatus = await licenseCodeService.checkUserLicense(userId);
      res.json(licenseStatus);
    } catch (error) {
      console.error("Errore controllo licenza utente:", error);
      res.status(500).json({ message: "Errore nel controllo della licenza" });
    }
  });

  // Admin routes per gestione codici licenza
  app.post("/api/admin/license/generate", isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).session.userId;
      
      const user = await storage.getUserById(userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Accesso negato" });
      }
      
      const { planType, duration, maxActivations, generatedFor, orderReference, notes, expiresAt } = req.body;
      
      const code = await licenseCodeService.generateLicenseCode({
        planType,
        duration: parseInt(duration),
        maxActivations: maxActivations ? parseInt(maxActivations) : 1,
        generatedFor,
        orderReference,
        notes,
        expiresAt: expiresAt ? new Date(expiresAt) : undefined
      });
      
      res.json({ 
        message: "Codice generato con successo",
        code,
        success: true 
      });
    } catch (error) {
      console.error("Errore generazione codice:", error);
      res.status(500).json({ message: "Errore nella generazione del codice" });
    }
  });
  
  app.get("/api/admin/license/codes", isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).session.userId;
      
      const user = await storage.getUserById(userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Accesso negato" });
      }
      
      const codes = await licenseCodeService.getAllLicenseCodes();
      res.json(codes);
    } catch (error) {
      console.error("Errore recupero codici:", error);
      res.status(500).json({ message: "Errore nel recupero dei codici" });
    }
  });

  app.post("/api/admin/license/deactivate", isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).session.userId;
      
      const user = await storage.getUserById(userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Accesso negato" });
      }

      const { code } = req.body;
      
      if (!code) {
        return res.status(400).json({ message: "Codice licenza richiesto" });
      }

      const success = await licenseCodeService.deactivateLicenseCode(code);
      
      if (success) {
        res.json({ 
          message: "Codice disattivato con successo",
          success: true 
        });
      } else {
        res.status(404).json({ message: "Codice non trovato" });
      }
    } catch (error) {
      console.error("Errore disattivazione codice:", error);
      res.status(500).json({ message: "Errore nella disattivazione del codice" });
    }
  });

  app.post("/api/admin/license/send-email", isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).session.userId;
      
      const user = await storage.getUserById(userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Accesso negato" });
      }

      const { licenseCode, recipientEmail, recipientName, planType, duration } = req.body;
      
      if (!licenseCode || !recipientEmail || !planType || !duration) {
        return res.status(400).json({ message: "Dati richiesti mancanti" });
      }

      const success = await emailService.sendLicenseCode({
        recipientEmail,
        recipientName,
        licenseCode,
        planType,
        duration,
        companyName: user.fullName || 'AgroTrace Pro'
      });
      
      if (success) {
        res.json({ 
          message: "Email inviata con successo",
          success: true 
        });
      } else {
        res.status(500).json({ message: "Errore nell'invio dell'email" });
      }
    } catch (error: any) {
      console.error("Errore invio email:", error);
      
      // Gestisce errori specifici di autorizzazione Brevo
      if (error.message && error.message.includes('AUTHORIZATION_REQUIRED')) {
        const cleanMessage = error.message.replace('AUTHORIZATION_REQUIRED: ', '');
        return res.status(403).json({ 
          message: cleanMessage,
          type: 'authorization_required',
          suggestion: 'Autorizza l\'indirizzo nel tuo account Brevo o usa il pulsante copia contenuto'
        });
      }
      
      res.status(500).json({ 
        message: error.message || "Errore nell'invio dell'email",
        suggestion: 'Verifica la configurazione Brevo o usa il pulsante copia contenuto'
      });
    }
  });

  app.get("/api/auth/user", isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).session.userId;
      const user = await storage.getUserById(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Utente non trovato" });
      }

      res.json({ 
        id: user.id, 
        username: user.username, 
        email: user.email,
        fullName: user.fullName,
        role: user.role
      });
    } catch (error) {
      console.error("Errore recupero utente:", error);
      res.status(500).json({ message: "Errore durante il recupero utente" });
    }
  });

  // Admin routes for user management
  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUserById(req.session.userId);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Accesso negato: privilegi admin richiesti" });
      }

      // Return all users without passwords
      const users = await storage.getAllUsers();
      const safeUsers = users.map(user => ({
        ...user,
        password: undefined
      }));
      
      res.json(safeUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Errore durante il recupero degli utenti" });
    }
  });

  app.post('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUserById(req.session.userId);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Accesso negato: privilegi admin richiesti" });
      }

      const { username, email, password, fullName, role } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username e password sono richiesti" });
      }

      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username già esistente" });
      }

      const existingEmail = email ? await storage.getUserByEmail(email) : null;
      if (existingEmail) {
        return res.status(400).json({ message: "Email già esistente" });
      }

      const newUser = await storage.createUser({
        username,
        email: email || null,
        password,
        fullName: fullName || null,
        role: role || 'user'
      });

      const { password: _, ...safeUser } = newUser;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Errore durante la creazione dell'utente" });
    }
  });

  app.post('/api/admin/users/:userId/reset-password', isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUserById(req.session.userId);
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Accesso negato: privilegi admin richiesti" });
      }

      const userId = parseInt(req.params.userId);
      const { newPassword } = req.body;
      
      if (!newPassword || newPassword.length < 6) {
        return res.status(400).json({ message: "Password deve essere almeno 6 caratteri" });
      }

      const success = await storage.updateUserPassword(userId, newPassword);
      if (!success) {
        return res.status(404).json({ message: "Utente non trovato" });
      }

      res.json({ message: "Password aggiornata con successo" });
    } catch (error) {
      console.error("Error resetting password:", error);
      res.status(500).json({ message: "Errore durante il reset della password" });
    }
  });

  // Company profile routes
  app.get('/api/company-profile', isAuthenticated, async (req: any, res) => {
    try {
      const profile = await storage.getCompanyProfile(req.session.userId);
      if (!profile) {
        return res.status(404).json({ message: "Profilo aziendale non trovato" });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error fetching company profile:", error);
      res.status(500).json({ message: "Errore durante il recupero del profilo aziendale" });
    }
  });

  app.post('/api/company-profile', isAuthenticated, async (req: any, res) => {
    try {
      const existingProfile = await storage.getCompanyProfile(req.session.userId);
      if (existingProfile) {
        return res.status(400).json({ message: "Profilo aziendale già esistente. Utilizzare PUT per aggiornare." });
      }

      const profileData = {
        userId: req.session.userId,
        ...req.body
      };

      const profile = await storage.createCompanyProfile(profileData);
      res.status(201).json(profile);
    } catch (error) {
      console.error("Error creating company profile:", error);
      res.status(500).json({ message: "Errore durante la creazione del profilo aziendale" });
    }
  });

  app.put('/api/company-profile', isAuthenticated, async (req: any, res) => {
    try {
      const profile = await storage.updateCompanyProfile(req.session.userId, req.body);
      if (!profile) {
        return res.status(404).json({ message: "Profilo aziendale non trovato" });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error updating company profile:", error);
      res.status(500).json({ message: "Errore durante l'aggiornamento del profilo aziendale" });
    }
  });

  // Dashboard routes (protette da autenticazione)
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error getting dashboard stats:", error);
      res.status(500).json({ error: "Failed to get dashboard stats" });
    }
  });

  // Recipe routes
  app.get("/api/recipes", async (req, res) => {
    try {
      const recipes = await storage.getRecipes();
      res.json(recipes);
    } catch (error) {
      console.error("Error getting recipes:", error);
      res.status(500).json({ error: "Failed to get recipes" });
    }
  });

  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const recipe = await storage.getRecipe(parseInt(req.params.id));
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      res.json(recipe);
    } catch (error) {
      console.error("Error getting recipe:", error);
      res.status(500).json({ error: "Failed to get recipe" });
    }
  });

  app.post("/api/recipes", async (req, res) => {
    try {
      const validatedData = insertRecipeSchema.parse(req.body);
      const recipe = await storage.createRecipe(validatedData);
      res.status(201).json(recipe);
    } catch (error) {
      console.error("Error creating recipe:", error);
      res.status(400).json({ error: "Failed to create recipe" });
    }
  });

  app.put("/api/recipes/:id", async (req, res) => {
    try {
      const recipeId = parseInt(req.params.id);
      const validatedData = insertRecipeSchema.partial().parse(req.body);
      const recipe = await storage.updateRecipe(recipeId, validatedData);
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      
      // Clear all caches related to this recipe to ensure immediate updates
      // Clear nutritional cache for this recipe
      const nutritionCacheKey = `nutrition_${recipeId}`;
      nutritionalCache.delete(nutritionCacheKey);
      
      // Clear all traceability cache since batches may use this recipe
      traceabilityCache.clear();
      
      res.json({ 
        recipe,
        message: "Ricetta aggiornata e sincronizzata con lotti e magazzino collegati"
      });
    } catch (error) {
      console.error("Error updating recipe:", error);
      res.status(400).json({ error: "Failed to update recipe" });
    }
  });

  // Endpoint per sincronizzazione manuale ricetta-lotti-magazzino
  app.post("/api/recipes/:id/sync", async (req, res) => {
    try {
      const recipeId = parseInt(req.params.id);
      const recipe = await storage.getRecipe(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }

      // Forza la sincronizzazione con tutti i campi della ricetta
      await (storage as any).syncRecipeToRelatedItems(recipe, {
        yield: recipe.yield,
        salePrice: recipe.salePrice,
        productionCost: recipe.productionCost
      });

      res.json({ 
        message: `Sincronizzazione forzata completata per ricetta ${recipe.name}`,
        recipeName: recipe.name
      });
    } catch (error) {
      console.error("Error syncing recipe:", error);
      res.status(500).json({ error: "Failed to sync recipe" });
    }
  });

  app.delete("/api/recipes/:id", async (req, res) => {
    try {
      const success = await storage.deleteRecipe(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting recipe:", error);
      res.status(500).json({ error: "Failed to delete recipe" });
    }
  });

  // Batch routes
  app.get("/api/batches", async (req, res) => {
    try {
      const batches = await storage.getBatches();
      res.json(batches);
    } catch (error) {
      console.error("Error getting batches:", error);
      res.status(500).json({ error: "Failed to get batches" });
    }
  });

  app.get("/api/batches/generate-code", async (req, res) => {
    try {
      const code = await storage.generateBatchCode();
      res.json({ code });
    } catch (error) {
      console.error("Error generating batch code:", error);
      res.status(500).json({ error: "Failed to generate batch code" });
    }
  });

  app.get("/api/batches/code/:code", async (req, res) => {
    try {
      const batch = await storage.getBatchByCode(req.params.code);
      if (!batch) {
        return res.status(404).json({ error: "Batch not found" });
      }
      res.json(batch);
    } catch (error) {
      console.error("Error getting batch by code:", error);
      res.status(500).json({ error: "Failed to get batch" });
    }
  });

  app.get("/api/batches/:id", async (req, res) => {
    try {
      const batch = await storage.getBatch(parseInt(req.params.id));
      if (!batch) {
        return res.status(404).json({ error: "Batch not found" });
      }
      res.json(batch);
    } catch (error) {
      console.error("Error getting batch:", error);
      res.status(500).json({ error: "Failed to get batch" });
    }
  });

  app.post("/api/batches", async (req, res) => {
    try {
      const validatedData = insertBatchSchema.parse(req.body);
      
      // Generate code if not provided
      if (!validatedData.code) {
        validatedData.code = await storage.generateBatchCode();
      }
      
      const batch = await storage.createBatch(validatedData);
      
      // If batch is linked to a recipe, deduct ingredients from inventory
      if (batch.recipeId && validatedData.quantity) {
        try {
          await storage.deductInventoryFromBatch(batch.recipeId, parseFloat(validatedData.quantity));
          console.log(`✅ Ingredienti detratti dall'inventario per lotto ${batch.code}`);
          
          // Crea automaticamente il prodotto finito nell'inventario con prezzi dal lotto
          await storage.createFinishedProductFromBatch(batch);
          console.log(`✅ Prodotto finito creato in inventario per lotto ${batch.code}`);
        } catch (inventoryError) {
          console.error("Error deducting inventory:", inventoryError);
          // Don't fail the batch creation if inventory deduction fails
          // Just log the error and continue
        }
      }
      
      res.status(201).json(batch);
    } catch (error) {
      console.error("Error creating batch:", error);
      res.status(400).json({ error: "Failed to create batch" });
    }
  });

  app.put("/api/batches/:id", async (req, res) => {
    try {
      const validatedData = insertBatchSchema.partial().parse(req.body);
      
      // Remove code from update data to preserve existing code
      if (validatedData.code === undefined || validatedData.code === '') {
        delete validatedData.code;
      }
      
      const batch = await storage.updateBatch(parseInt(req.params.id), validatedData);
      if (!batch) {
        return res.status(404).json({ error: "Batch not found" });
      }
      res.json(batch);
    } catch (error) {
      console.error("Error updating batch:", error);
      res.status(400).json({ error: "Failed to update batch" });
    }
  });

  app.delete("/api/batches/:id", async (req, res) => {
    try {
      const success = await storage.deleteBatch(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Batch not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting batch:", error);
      res.status(500).json({ error: "Failed to delete batch" });
    }
  });

  // Quality Controls endpoint
  app.post("/api/batches/:id/quality-controls", isAuthenticated, async (req, res) => {
    try {
      const batchId = parseInt(req.params.id);
      const qualityData = req.body;
      
      // Validate that the batch exists
      const batch = await storage.getBatch(batchId);
      if (!batch) {
        return res.status(404).json({ error: "Batch not found" });
      }
      
      // Update batch with quality controls
      const updatedBatch = await storage.updateBatch(batchId, {
        qualityControls: qualityData
      });
      
      res.json(updatedBatch);
    } catch (error) {
      console.error("Error saving quality controls:", error);
      res.status(500).json({ error: "Failed to save quality controls" });
    }
  });

  // Inventory routes
  app.get("/api/inventory", async (req, res) => {
    try {
      const inventory = await storage.getInventoryItems();
      res.json(inventory);
    } catch (error) {
      console.error("Error getting inventory:", error);
      res.status(500).json({ error: "Failed to get inventory" });
    }
  });

  app.get("/api/inventory/:id", async (req, res) => {
    try {
      const item = await storage.getInventoryItem(parseInt(req.params.id));
      if (!item) {
        return res.status(404).json({ error: "Inventory item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error getting inventory item:", error);
      res.status(500).json({ error: "Failed to get inventory item" });
    }
  });

  app.get("/api/inventory/code/:code", async (req, res) => {
    try {
      const item = await storage.getInventoryItemByCode(req.params.code);
      if (!item) {
        return res.status(404).json({ error: "Inventory item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error getting inventory item by code:", error);
      res.status(500).json({ error: "Failed to get inventory item" });
    }
  });

  app.post("/api/inventory", async (req, res) => {
    try {
      const validatedData = insertInventorySchema.parse(req.body);
      const item = await storage.createInventoryItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      console.error("Error creating inventory item:", error);
      res.status(400).json({ error: "Failed to create inventory item" });
    }
  });

  app.put("/api/inventory/:id", async (req, res) => {
    try {
      // Handle date conversion for expiryDate
      const data = { ...req.body };
      if (data.expiryDate && typeof data.expiryDate === 'string') {
        data.expiryDate = new Date(data.expiryDate);
      }
      
      const validatedData = insertInventorySchema.partial().parse(data);
      const item = await storage.updateInventoryItem(parseInt(req.params.id), validatedData);
      if (!item) {
        return res.status(404).json({ error: "Inventory item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error updating inventory item:", error);
      res.status(400).json({ error: "Failed to update inventory item" });
    }
  });

  app.delete("/api/inventory/:id", async (req, res) => {
    try {
      const success = await storage.deleteInventoryItem(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Inventory item not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting inventory item:", error);
      res.status(500).json({ error: "Failed to delete inventory item" });
    }
  });

  // Import ingredients from recipes and batches
  app.post("/api/inventory/import-ingredients", async (req, res) => {
    try {
      const { ingredients } = req.body;
      
      if (!ingredients || !Array.isArray(ingredients)) {
        return res.status(400).json({ error: "Invalid ingredients data" });
      }

      let imported = 0;
      let skipped = 0;

      for (const ingredient of ingredients) {
        try {
          // Check if item already exists by name
          const existingItems = await storage.getInventoryItems();
          const exists = existingItems.find(item => 
            item.name.toLowerCase() === ingredient.name.toLowerCase()
          );

          if (exists) {
            skipped++;
            continue;
          }

          // Generate appropriate code based on category
          const code = ingredient.category === "prodotti_finiti" && ingredient.batchCode
            ? ingredient.batchCode // Use batch code for finished products
            : `ING-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`.toUpperCase();
          
          // For finished products, get pricing from recipe
          let salePrice = null;
          let profit = null;
          let unitCost = ingredient.unitCost ? ingredient.unitCost.toString() : null;
          
          if (ingredient.category === "prodotti_finiti") {
            const recipes = await storage.getRecipes();
            const recipe = recipes.find(r => r.name === ingredient.name);
            
            if (recipe && recipe.salePrice) {
              salePrice = recipe.salePrice;
              const recipeCost = Number(recipe.productionCost) || 0;
              if (recipeCost > 0) {
                unitCost = recipeCost.toFixed(2);
              }
              profit = (Number(salePrice) - Number(unitCost || 0)).toFixed(2);
            }
          }
          
          const newItem = {
            code,
            name: ingredient.name,
            category: ingredient.category || "ingredienti",
            currentStock: ingredient.currentStock || "0",
            minimumStock: ingredient.minimumStock || "10",
            unit: ingredient.unit,
            unitCost,
            salePrice,
            profit,
            supplier: ingredient.supplier || null,
            location: ingredient.location || "Magazzino principale",
            status: ingredient.status || "out_of_stock",
            expiryDate: ingredient.expiryDate ? new Date(ingredient.expiryDate) : null,
            notes: ingredient.batchCode ? `Importato da lotto: ${ingredient.batchCode}` : "Importato automaticamente"
          };

          await storage.createInventoryItem(newItem);
          imported++;
        } catch (itemError) {
          console.error("Error importing ingredient:", ingredient.name, itemError);
          skipped++;
        }
      }

      res.json({ 
        imported, 
        skipped, 
        total: ingredients.length,
        message: `Importazione completata: ${imported} importati, ${skipped} saltati` 
      });
    } catch (error) {
      console.error("Error importing ingredients:", error);
      res.status(500).json({ error: "Failed to import ingredients" });
    }
  });

  // Import specific product manually
  app.post("/api/inventory/import-specific-product", async (req, res) => {
    try {
      const { productName, quantity } = req.body;
      
      if (!productName || !quantity) {
        return res.status(400).json({ error: "Product name and quantity are required" });
      }

      // Check if it's from a recipe
      const recipes = await storage.getRecipes();
      const recipe = recipes.find(r => r.name === productName);
      
      if (recipe) {
        // Import from recipe with sale price
        const salePrice = Number(recipe.salePrice) || 0;
        const unitCost = Number(recipe.productionCost) || salePrice / 3;
        const profit = salePrice - unitCost;

        await storage.createInventoryItem({
          name: productName,
          category: 'prodotti_finiti',
          code: `MANUAL-${Date.now()}`,
          currentStock: quantity,
          unit: 'vasetti',
          minimumStock: '5',
          unitCost: unitCost.toFixed(2),
          salePrice: salePrice.toFixed(2),
          profit: profit.toFixed(2),
          status: 'available',
          location: 'Magazzino prodotti finiti'
        });

        res.json({ success: true, message: `${productName} importato con successo` });
      } else {
        // Check if it's from a batch
        const batches = await storage.getBatches();
        const batch = batches.find(b => b.productName === productName);
        
        if (batch && batch.recipeId) {
          const batchRecipe = recipes.find(r => r.id === batch.recipeId);
          const salePrice = Number(batch.salePrice) || Number(batchRecipe?.salePrice) || 0;
          const unitCost = Number(batchRecipe?.productionCost) || salePrice / 3;
          const profit = salePrice - unitCost;

          await storage.createInventoryItem({
            name: productName,
            category: 'prodotti_finiti',
            code: batch.code || `MANUAL-${Date.now()}`,
            currentStock: quantity,
            unit: batch.unit || 'vasetti',
            minimumStock: '5',
            unitCost: unitCost.toFixed(2),
            salePrice: salePrice.toFixed(2),
            profit: profit.toFixed(2),
            status: 'available',
            location: 'Magazzino prodotti finiti'
          });

          res.json({ success: true, message: `${productName} importato con successo` });
        } else {
          res.status(404).json({ error: "Product not found in recipes or batches" });
        }
      }
    } catch (error) {
      console.error("Error importing specific product:", error);
      res.status(500).json({ error: "Failed to import specific product" });
    }
  });

  // Monitor inventory and create alerts automatically
  app.post("/api/inventory/monitor", async (req, res) => {
    try {
      const result = await storage.monitorInventoryStatus();
      res.json({
        success: true,
        alertsCreated: result.alertsCreated,
        alertsResolved: result.alertsResolved,
        message: `Monitoraggio completato: ${result.alertsCreated} nuovi alert, ${result.alertsResolved} alert risolti`
      });
    } catch (error) {
      console.error("Error monitoring inventory:", error);
      res.status(500).json({ error: "Failed to monitor inventory" });
    }
  });

  // Get inventory alerts for specific items
  app.get("/api/inventory/alerts", async (req, res) => {
    try {
      const alerts = await storage.checkInventoryAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error getting inventory alerts:", error);
      res.status(500).json({ error: "Failed to get inventory alerts" });
    }
  });

  // Auto-run monitoring every 30 minutes in background
  setInterval(async () => {
    try {
      console.log("🔍 Esecuzione monitoraggio automatico scorte...");
      const result = await storage.monitorInventoryStatus();
      if (result.alertsCreated > 0 || result.alertsResolved > 0) {
        console.log(`📊 Monitoraggio completato: ${result.alertsCreated} nuovi alert, ${result.alertsResolved} risolti`);
      }
    } catch (error) {
      console.error("Errore nel monitoraggio automatico:", error);
    }
  }, 30 * 60 * 1000); // 30 minuti

  // QR Label routes
  app.get("/api/qr-labels", async (req, res) => {
    try {
      const labels = await storage.getQRLabels();
      res.json(labels);
    } catch (error) {
      console.error("Error getting QR labels:", error);
      res.status(500).json({ error: "Failed to get QR labels" });
    }
  });

  app.get("/api/qr-labels/:id", async (req, res) => {
    try {
      const label = await storage.getQRLabel(parseInt(req.params.id));
      if (!label) {
        return res.status(404).json({ error: "QR label not found" });
      }
      res.json(label);
    } catch (error) {
      console.error("Error getting QR label:", error);
      res.status(500).json({ error: "Failed to get QR label" });
    }
  });

  app.get("/api/qr-labels/batch/:batchId", async (req, res) => {
    try {
      const label = await storage.getQRLabelByBatchId(parseInt(req.params.batchId));
      if (!label) {
        return res.status(404).json({ error: "QR label not found" });
      }
      res.json(label);
    } catch (error) {
      console.error("Error getting QR label by batch:", error);
      res.status(500).json({ error: "Failed to get QR label" });
    }
  });

  app.post("/api/qr-labels", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertQRLabelSchema.parse(req.body);
      
      // Check if QR label already exists for this batch
      if (validatedData.batchId) {
        const existingLabel = await storage.getQRLabelByBatchId(validatedData.batchId);
        if (existingLabel) {
          return res.json(existingLabel); // Return existing label instead of creating duplicate
        }
      }
      
      // Get user's company name for the producer field
      const userId = req.session.userId;
      const user = await storage.getUserById(userId);
      const companyName = user?.companyName || "Azienda Agricola";
      
      // If data includes producer info, update it with user's company name
      if (validatedData.data && typeof validatedData.data === 'object') {
        validatedData.data = {
          ...validatedData.data,
          producer: companyName
        };
      }
      
      const label = await storage.createQRLabel(validatedData);
      res.status(201).json(label);
    } catch (error) {
      console.error("Error creating QR label:", error);
      res.status(400).json({ error: "Failed to create QR label" });
    }
  });

  // Sales routes
  app.get("/api/sales", async (req, res) => {
    try {
      const sales = await storage.getSales();
      res.json(sales);
    } catch (error) {
      console.error("Error getting sales:", error);
      res.status(500).json({ error: "Failed to get sales" });
    }
  });

  app.post("/api/sales", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertSaleSchema.parse(req.body);
      
      // Get inventory item to validate stock and update
      const inventoryItem = await storage.getInventoryItem(validatedData.inventoryItemId);
      if (!inventoryItem) {
        return res.status(404).json({ error: "Prodotto non trovato in inventario" });
      }

      const quantitySold = Number(validatedData.quantitySold);
      const currentStock = Number(inventoryItem.currentStock);

      // Check if there's enough stock
      if (currentStock < quantitySold) {
        return res.status(400).json({ 
          error: `Scorta insufficiente. Disponibili: ${currentStock} ${inventoryItem.unit}, richiesti: ${quantitySold} ${inventoryItem.unit}` 
        });
      }

      // Calculate total amount
      const unitPrice = Number(validatedData.unitPrice) || Number(inventoryItem.salePrice);
      const totalAmount = quantitySold * unitPrice;

      // Create the sale record
      const saleData = {
        ...validatedData,
        unitPrice: unitPrice.toFixed(2),
        totalAmount: totalAmount.toFixed(2)
      };

      const sale = await storage.createSale(saleData);

      // Inventory updates are handled automatically in storage.createSale()

      // Batch updates are handled automatically in storage.createSale()

      // Alerts are handled automatically in storage.createSale()

      res.status(201).json({ 
        sale, 
        message: `Vendita registrata: ${quantitySold} ${inventoryItem.unit} di ${inventoryItem.name}`
      });
    } catch (error) {
      console.error("Error creating sale:", error);
      res.status(400).json({ error: "Failed to create sale" });
    }
  });

  app.get("/api/sales/stats", async (req, res) => {
    try {
      const sales = await storage.getSales();
      const totalSales = sales.reduce((sum, sale) => sum + Number(sale.totalAmount), 0);
      const totalTransactions = sales.length;
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      const todaySales = sales.filter(sale => 
        sale.saleDate && sale.saleDate.toISOString().split('T')[0] === todayStr
      );
      const todayRevenue = todaySales.reduce((sum, sale) => sum + Number(sale.totalAmount), 0);

      res.json({
        totalSales: totalSales.toFixed(2),
        totalTransactions,
        todayRevenue: todayRevenue.toFixed(2),
        todayTransactions: todaySales.length
      });
    } catch (error) {
      console.error("Error getting sales stats:", error);
      res.status(500).json({ error: "Failed to get sales stats" });
    }
  });

  app.delete("/api/sales/:id", isAuthenticated, async (req: any, res) => {
    try {
      const saleId = parseInt(req.params.id);
      const sale = await storage.getSale(saleId);
      
      if (!sale) {
        return res.status(404).json({ error: "Vendita non trovata" });
      }

      // Get inventory item info for response message
      const inventoryItem = await storage.getInventoryItem(sale.inventoryItemId);
      
      // Delete the sale (this will handle all stock restoration internally)
      const deleted = await storage.deleteSale(saleId);
      
      if (!deleted) {
        return res.status(500).json({ error: "Errore durante l'eliminazione della vendita" });
      }

      res.json({ 
        message: `Vendita eliminata e scorte ripristinate: +${sale.quantitySold} ${inventoryItem?.unit || 'unità'}`,
        restoredQuantity: Number(sale.quantitySold),
        productName: inventoryItem?.name
      });
    } catch (error) {
      console.error("Error deleting sale:", error);
      res.status(500).json({ error: "Failed to delete sale" });
    }
  });

  // Alert routes
  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error getting alerts:", error);
      res.status(500).json({ error: "Failed to get alerts" });
    }
  });

  app.get("/api/alerts/active", async (req, res) => {
    try {
      const alerts = await storage.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error getting active alerts:", error);
      res.status(500).json({ error: "Failed to get active alerts" });
    }
  });

  app.get("/api/alerts/:id", async (req, res) => {
    try {
      const alert = await storage.getAlert(parseInt(req.params.id));
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.json(alert);
    } catch (error) {
      console.error("Error getting alert:", error);
      res.status(500).json({ error: "Failed to get alert" });
    }
  });

  app.post("/api/alerts", async (req, res) => {
    try {
      const validatedData = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(validatedData);
      res.status(201).json(alert);
    } catch (error) {
      console.error("Error creating alert:", error);
      res.status(400).json({ error: "Failed to create alert" });
    }
  });

  app.put("/api/alerts/:id/resolve", async (req, res) => {
    try {
      const success = await storage.resolveAlert(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.status(200).json({ message: "Alert resolved" });
    } catch (error) {
      console.error("Error resolving alert:", error);
      res.status(500).json({ error: "Failed to resolve alert" });
    }
  });

  // Ingredient Tracking routes
  app.get("/api/ingredient-tracking", async (req, res) => {
    try {
      const tracking = await storage.getIngredientTracking();
      res.json(tracking);
    } catch (error) {
      console.error("Error getting ingredient tracking:", error);
      res.status(500).json({ error: "Failed to get ingredient tracking" });
    }
  });

  app.post("/api/ingredient-tracking", async (req, res) => {
    try {
      const tracking = await storage.createIngredientTracking(req.body);
      res.status(201).json(tracking);
    } catch (error) {
      console.error("Error creating ingredient tracking:", error);
      res.status(500).json({ error: "Failed to create ingredient tracking" });
    }
  });

  app.get("/api/ingredient-tracking/batch/:batchId", async (req, res) => {
    try {
      const tracking = await storage.getIngredientUsageByBatch(parseInt(req.params.batchId));
      res.json(tracking);
    } catch (error) {
      console.error("Error getting batch ingredient usage:", error);
      res.status(500).json({ error: "Failed to get batch ingredient usage" });
    }
  });

  app.get("/api/ingredient-availability/:ingredientName", async (req, res) => {
    try {
      const availability = await storage.getIngredientAvailability(req.params.ingredientName);
      res.json(availability);
    } catch (error) {
      console.error("Error getting ingredient availability:", error);
      res.status(500).json({ error: "Failed to get ingredient availability" });
    }
  });

  app.get("/api/ingredient-tracking/low-stock", async (req, res) => {
    try {
      const lowStockItems = await storage.checkLowStockIngredients();
      res.json(lowStockItems);
    } catch (error) {
      console.error("Error checking low stock ingredients:", error);
      res.status(500).json({ error: "Failed to check low stock ingredients" });
    }
  });

  // Cache multiplo per performance ottimali
  const nutritionalCache = new Map<string, any>();
  const traceabilityCache = new Map<string, any>();

  // Traceability routes
  app.get("/api/traceability/:batchCode", async (req, res) => {
    try {
      const batchCode = req.params.batchCode;
      
      // Set cache control headers to prevent browser caching
      res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      
      // Check if client explicitly requests fresh data (no-cache header)
      const forceRefresh = req.get('Cache-Control') === 'no-cache';
      
      // Skip cache if force refresh is requested
      if (!forceRefresh && traceabilityCache.has(batchCode)) {
        return res.json(traceabilityCache.get(batchCode));
      }
      
      const traceability = await storage.getTraceabilityByBatchCode(batchCode);
      
      if (!traceability) {
        return res.status(404).json({ error: "Batch not found" });
      }
      
      // Always calculate fresh nutritional values when force refresh is requested
      let nutritionalValues = null;
      if (traceability.recipe && traceability.recipe.ingredients) {
        const recipeId = traceability.recipe.id;
        const cacheKey = `nutrition_${recipeId}`;
        
        // Skip nutritional cache if force refresh is requested
        if (!forceRefresh && nutritionalCache.has(cacheKey)) {
          nutritionalValues = nutritionalCache.get(cacheKey);
        } else {
          // Calculate fresh nutritional values
          nutritionalValues = calculateNutritionalValues(traceability.recipe.ingredients);
          nutritionalCache.set(cacheKey, nutritionalValues);
          
          // Clear cache after 30 minutes
          setTimeout(() => {
            nutritionalCache.delete(cacheKey);
          }, 30 * 60 * 1000);
        }
      }
      
      // Add product percentages to ingredients for nutritional label
      let enrichedTraceability: any = { ...traceability };
      console.log('Processing traceability for:', batchCode);
      console.log('Has recipe?', !!traceability.recipe);
      console.log('Has ingredients?', !!traceability.recipe?.ingredients);
      
      if (traceability.recipe && traceability.recipe.ingredients) {
        console.log('Calculating real percentages for recipe:', traceability.recipe.name);
        
        // Calculate total weight of all ingredients
        let totalWeight = 0;
        const ingredientsWithWeights = traceability.recipe.ingredients.map((ing: any) => {
          // Convert all quantities to grams for percentage calculation
          let weightInGrams = 0;
          
          if (ing.unit === 'kg') {
            weightInGrams = ing.quantity * 1000;
          } else if (ing.unit === 'l') {
            // Assume liquid density ~1kg/l for most ingredients
            weightInGrams = ing.quantity * 1000;
          } else if (ing.unit === 'ml') {
            weightInGrams = ing.quantity; // ~1g/ml
          } else if (ing.unit === 'g') {
            weightInGrams = ing.quantity;
          } else {
            // For other units, use quantity as is
            weightInGrams = ing.quantity;
          }
          
          totalWeight += weightInGrams;
          return { ...ing, weightInGrams };
        });
        
        console.log('Total weight calculated:', totalWeight, 'grams');
        
        // Calculate actual percentages based on weight
        enrichedTraceability.recipe.ingredients = ingredientsWithWeights.map((ing: any) => {
          const percentage = totalWeight > 0 ? Math.round((ing.weightInGrams / totalWeight) * 100 * 100) / 100 : 0;
          console.log(`Ingredient: ${ing.name} -> ${ing.quantity}${ing.unit} (${ing.weightInGrams}g) -> ${percentage}%`);
          return {
            ...ing,
            productPercentage: percentage
          };
        });
        console.log('Finished calculating real percentages');
      }

      const result = {
        ...enrichedTraceability,
        nutritionalValues
      };
      
      // Only cache if not force refresh
      if (!forceRefresh) {
        traceabilityCache.set(batchCode, result);
        setTimeout(() => {
          traceabilityCache.delete(batchCode);
        }, 5 * 60 * 1000);
      }
      
      res.json(result);
    } catch (error) {
      console.error("Error getting traceability:", error);
      res.status(500).json({ error: "Failed to get traceability data" });
    }
  });

  // SEO Routes - Sitemap and Robots.txt
  app.get("/sitemap.xml", (req, res) => {
    res.set('Content-Type', 'application/xml');
    res.sendFile('sitemap.xml', { root: 'client/public' });
  });

  app.get("/robots.txt", (req, res) => {
    res.set('Content-Type', 'text/plain');
    res.sendFile('robots.txt', { root: 'client/public' });
  });

  // Health check endpoint for monitoring
  app.get("/health", (req, res) => {
    res.status(200).json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: "1.0.0"
    });
  });

  // Backup API routes
  app.post("/api/backup/create", isAuthenticated, async (req, res) => {
    try {
      const backupPath = await backupService.createBackup();
      if (backupPath) {
        res.json({ 
          success: true, 
          message: "Backup creato con successo",
          backupPath 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Errore nella creazione del backup" 
        });
      }
    } catch (error) {
      console.error("Errore API backup:", error);
      res.status(500).json({ 
        success: false, 
        message: "Errore interno del server" 
      });
    }
  });

  app.get("/api/backup/list", isAuthenticated, async (req, res) => {
    try {
      const backups = await backupService.getBackupList();
      res.json({ success: true, backups });
    } catch (error) {
      console.error("Errore lista backup:", error);
      res.status(500).json({ 
        success: false, 
        message: "Errore nel recupero della lista backup" 
      });
    }
  });

  app.post("/api/backup/restore", isAuthenticated, async (req, res) => {
    try {
      const { backupFileName } = req.body;
      if (!backupFileName) {
        return res.status(400).json({ 
          success: false, 
          message: "Nome file backup richiesto" 
        });
      }

      const success = await backupService.restoreBackup(backupFileName);
      if (success) {
        res.json({ 
          success: true, 
          message: "Backup ripristinato con successo" 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Errore nel ripristino del backup" 
        });
      }
    } catch (error) {
      console.error("Errore ripristino backup:", error);
      res.status(500).json({ 
        success: false, 
        message: "Errore interno del server" 
      });
    }
  });

  // License Management APIs
  app.get("/api/license/status", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      const status = await licenseService.checkUserLicense(userId);
      res.json(status);
    } catch (error) {
      console.error("Error checking license status:", error);
      res.status(500).json({ error: "Failed to check license status" });
    }
  });

  app.get("/api/license/plans", async (req, res) => {
    try {
      const plans = await licenseService.getAllPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error getting subscription plans:", error);
      res.status(500).json({ error: "Failed to get subscription plans" });
    }
  });

  app.post("/api/license/upgrade", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      const { planName, paymentMethod } = req.body;
      
      await licenseService.upgradePlan(userId, planName, paymentMethod);
      res.json({ success: true, message: "Piano aggiornato con successo" });
    } catch (error) {
      console.error("Error upgrading plan:", error);
      res.status(500).json({ error: "Failed to upgrade plan" });
    }
  });

  app.post("/api/license/validate-feature", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      const { feature } = req.body;
      
      const hasAccess = await licenseService.validateFeatureAccess(userId, feature);
      res.json({ hasAccess });
    } catch (error) {
      console.error("Error validating feature access:", error);
      res.status(500).json({ error: "Failed to validate feature access" });
    }
  });

  app.post("/api/license/check-limit", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId;
      const { resource, currentCount } = req.body;
      
      const canCreate = await licenseService.checkResourceLimit(userId, resource, currentCount);
      res.json({ canCreate });
    } catch (error) {
      console.error("Error checking resource limit:", error);
      res.status(500).json({ error: "Failed to check resource limit" });
    }
  });

  // Initialize subscription system on server start
  (async () => {
    await runSubscriptionMigration();
    await licenseService.initializeSubscriptionPlans();
  })().catch(console.error);

  const httpServer = createServer(app);
  return httpServer;
}