/**
 * AgroTrace Pro - Sistema di Tracciabilità Agroalimentare
 * 
 * Copyright (c) 2025 Marino Pizzuti
 * Tutti i diritti riservati
 * 
 * Database Schema e Types - Proprietario
 * 
 * @author Marino Pizzuti
 * @copyright 2025
 */

import { pgTable, text, serial, integer, boolean, decimal, timestamp, jsonb, varchar, index } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Schema per gli utenti
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  partitaIva: text("partita_iva"),
  fullName: text("full_name"),
  companyName: text("company_name").default("Azienda Agricola"),
  role: text("role").notNull().default("user"), // user, admin, owner
  isActive: boolean("is_active").notNull().default(true),
  
  // Gestione licenze e abbonamenti
  subscriptionStatus: text("subscription_status").notNull().default("trial"), // trial, active, expired, cancelled
  subscriptionPlan: text("subscription_plan").notNull().default("free"), // free, basic, premium, enterprise
  trialStartDate: timestamp("trial_start_date").defaultNow(),
  trialEndDate: timestamp("trial_end_date"), // Calcolato automaticamente (14 giorni dal start)
  subscriptionStartDate: timestamp("subscription_start_date"),
  subscriptionEndDate: timestamp("subscription_end_date"),
  lastPaymentDate: timestamp("last_payment_date"),
  nextBillingDate: timestamp("next_billing_date"),
  paymentMethod: text("payment_method"), // card, bank_transfer, paypal
  
  // Sistema codici licenza
  licenseCode: text("license_code").unique(), // Codice licenza univoco
  licenseActivatedAt: timestamp("license_activated_at"),
  licenseExpiresAt: timestamp("license_expires_at"),
  licenseType: text("license_type"), // personal, business, enterprise
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Tabella per i codici licenza
export const licenseCodes = pgTable("license_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // Codice alfanumerico univoco
  planType: text("plan_type").notNull(), // basic, premium, enterprise
  duration: integer("duration").notNull(), // durata in giorni
  maxActivations: integer("max_activations").notNull().default(1), // quante volte può essere usato
  currentActivations: integer("current_activations").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  
  // Metadati commerciali
  generatedFor: text("generated_for"), // email cliente o azienda
  orderReference: text("order_reference"), // riferimento ordine
  notes: text("notes"), // note interne
  
  // Scadenza del codice stesso (diversa dalla durata della licenza)
  expiresAt: timestamp("expires_at"), // il codice scade se non usato
  
  // Tracking
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
  generatedBy: text("generated_by"), // chi ha generato il codice
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Tabella per tenere traccia delle attivazioni
export const licenseActivations = pgTable("license_activations", {
  id: serial("id").primaryKey(),
  licenseCodeId: integer("license_code_id").references(() => licenseCodes.id),
  userId: integer("user_id").references(() => users.id),
  activatedAt: timestamp("activated_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  
  // Informazioni dispositivo/installazione
  deviceInfo: text("device_info"), // browser, OS, etc.
  ipAddress: text("ip_address"),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Session storage table per l'autenticazione
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Tabella per i token di recupero password
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Tabella per i profili aziendali
export const companyProfiles = pgTable("company_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id).unique(),
  ragioneSociale: text("ragione_sociale"),
  partitaIva: text("partita_iva"),
  codiceFiscale: text("codice_fiscale"),
  
  // Indirizzo
  indirizzo: text("indirizzo"),
  citta: text("citta"),
  provincia: text("provincia"),
  cap: text("cap"),
  paese: text("paese").default("Italia"),
  
  // Contatti
  telefono: text("telefono"),
  cellulare: text("cellulare"),
  emailAziendale: text("email_aziendale"),
  sitoweb: text("sito_web"),
  
  // Dati produttivi
  tipologiaProduzione: text("tipologia_produzione"), // biologica, convenzionale, biodinamica
  certificazioni: jsonb("certificazioni").$type<Array<{
    tipo: string;
    numero: string;
    dataRilascio: string;
    dataScadenza: string;
    enteRilascio: string;
  }>>(),
  
  settoriAttivita: jsonb("settori_attivita").$type<Array<string>>(), // ortofrutticola, cerealicola, zootecnica, etc.
  superficieAziendale: decimal("superficie_aziendale", { precision: 10, scale: 2 }),
  unitaMisuraSuperficie: text("unita_misura_superficie").default("ettari"),
  
  // Informazioni legali
  formaGiuridica: text("forma_giuridica"), // individuale, società, cooperativa
  dataCostituzione: timestamp("data_costituzione"),
  codiceAteco: text("codice_ateco"),
  
  // Informazioni bancarie
  iban: text("iban"),
  banca: text("banca"),
  
  // Note e descrizione
  descrizioneAttivita: text("descrizione_attivita"),
  note: text("note"),
  
  // Metadati
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Schema per le ricette
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  ingredients: jsonb("ingredients").notNull().$type<Array<{
    name: string;
    quantity: number;
    unit: string;
    cost?: number;
    allergens?: string[];
    supplier?: string;
    supplierLot?: string;
  }>>(),
  allergens: jsonb("allergens").$type<string[]>().default([]),
  instructions: text("instructions"),
  preparationInstructions: text("preparation_instructions"), // Istruzioni dettagliate di preparazione
  preparationTime: integer("preparation_time").notNull(),
  yield: integer("yield").notNull(), // numero vasetti
  jarWeight: integer("jar_weight").notNull(), // peso del singolo vasetto in grammi
  productionCost: decimal("production_cost", { precision: 10, scale: 2 }),
  salePrice: decimal("sale_price", { precision: 10, scale: 2 }),
  // Costi aggiuntivi per il calcolo completo
  packagingCosts: jsonb("packaging_costs").$type<{
    containerType: string;
    containerCost: number;
    labelCost?: number;
    closureCost?: number;
    quantity: number;
  }[]>().default([]),
  overheadCosts: jsonb("overhead_costs").$type<{
    electricityCostPerHour: number;
    machineryDepreciationPerHour: number;
    laborCostPerHour: number;
    facilityRentPerHour?: number;
    otherOverheadPerHour?: number;
  }>(),
  // Parametri qualità target per la ricetta
  qualityParameters: jsonb("quality_parameters").$type<{
    ph?: { min: number; max: number; unit: string };
    brix?: { min: number; max: number; unit: string };
    temperature?: { min: number; max: number; unit: string };
    viscosity?: { target: string; description?: string };
    color?: { target: string; description?: string };
    density?: { min: number; max: number; unit: string };
    acidity?: { min: number; max: number; unit: string };
    moisture?: { min: number; max: number; unit: string };
    saltContent?: { min: number; max: number; unit: string };
    custom?: Array<{
      name: string;
      target: string;
      min?: number;
      max?: number;
      unit?: string;
      description?: string;
    }>;
  }>(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Schema per i lotti
export const batches = pgTable("batches", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  recipeId: integer("recipe_id").references(() => recipes.id),
  productName: text("product_name").notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: text("unit").notNull(),
  status: text("status").notNull().default("active"), // active, sold, expired
  productionDate: timestamp("production_date").notNull(),
  expiryDate: timestamp("expiry_date"),
  salePrice: decimal("sale_price", { precision: 10, scale: 2 }),
  notes: text("notes"),
  qrCode: text("qr_code"),
  
  // Controlli qualità effettivi misurati durante la produzione
  qualityControls: jsonb("quality_controls").$type<{
    ph?: { value: number; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    brix?: { value: number; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    temperature?: { value: number; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    viscosity?: { value: string; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    color?: { value: string; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    density?: { value: number; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    acidity?: { value: number; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    moisture?: { value: number; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    saltContent?: { value: number; status: 'OK' | 'WARNING' | 'FAIL'; measuredAt: string; operator?: string };
    custom?: Array<{
      name: string;
      value: string | number;
      status: 'OK' | 'WARNING' | 'FAIL';
      measuredAt: string;
      operator?: string;
      notes?: string;
    }>;
  }>(),
  
  // Informazioni produzione
  productionDetails: jsonb("production_details").$type<{
    facility?: string;
    productionLine?: string;
    operator?: string;
    equipmentUsed?: string[];
    processingTemperature?: number;
    processingTime?: number;
    yieldPercentage?: number;
    qualityGrade?: string;
  }>(),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Schema per il magazzino
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  currentStock: decimal("current_stock", { precision: 10, scale: 2 }).notNull().default("0"),
  unit: text("unit").notNull(),
  minimumStock: decimal("minimum_stock", { precision: 10, scale: 2 }).notNull().default("0"),
  unitCost: decimal("unit_cost", { precision: 10, scale: 2 }),
  salePrice: decimal("sale_price", { precision: 10, scale: 2 }),
  profit: decimal("profit", { precision: 10, scale: 2 }),
  supplier: text("supplier"),
  location: text("location"),
  expiryDate: timestamp("expiry_date"),
  status: text("status").notNull().default("available"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Schema per le etichette QR
export const qrLabels = pgTable("qr_labels", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id").references(() => batches.id),
  code: text("code").notNull().unique(),
  data: jsonb("data").notNull().$type<{
    batchCode: string;
    productName: string;
    productionDate: string;
    expiryDate?: string;
    ingredients: string[];
    allergens: string[];
    producer: string;
    traceabilityCode: string;
  }>(),
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
});

// Schema per il tracking degli ingredienti
export const ingredientTracking = pgTable("ingredient_tracking", {
  id: serial("id").primaryKey(),
  ingredientName: text("ingredient_name").notNull(),
  inventoryId: integer("inventory_id").references(() => inventory.id),
  batchId: integer("batch_id").references(() => batches.id),
  quantityUsed: decimal("quantity_used", { precision: 10, scale: 2 }).notNull(),
  unit: text("unit").notNull(),
  usageDate: timestamp("usage_date").notNull().defaultNow(),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Schema per gli alert
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  message: text("message").notNull(),
  severity: text("severity").notNull().default("medium"),
  resolved: boolean("resolved").default(false),
  referenceTable: text("reference_table"),
  referenceId: integer("reference_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

// Schema per le vendite
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  inventoryItemId: integer("inventory_item_id").notNull().references(() => inventory.id),
  batchId: integer("batch_id").references(() => batches.id),
  quantitySold: decimal("quantity_sold", { precision: 10, scale: 2 }).notNull(),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  customerName: text("customer_name"),
  customerEmail: text("customer_email"),
  customerPhone: text("customer_phone"),
  paymentMethod: text("payment_method").notNull().default("contanti"), // contanti, carta, bonifico
  notes: text("notes"),
  saleDate: timestamp("sale_date").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Schema per i dettagli delle vendite (per vendite multiple)
export const saleItems = pgTable("sale_items", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id").notNull().references(() => sales.id),
  inventoryItemId: integer("inventory_item_id").notNull().references(() => inventory.id),
  batchId: integer("batch_id").references(() => batches.id),
  quantitySold: decimal("quantity_sold", { precision: 10, scale: 2 }).notNull(),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
});

// Insert schemas
export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  jarWeight: z.number().min(1, "Il peso del vasetto deve essere maggiore di 0"),
  yield: z.number().min(1, "Il numero di vasetti deve essere maggiore di 0"),
});

export const insertBatchSchema = createInsertSchema(batches).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  code: z.string().optional(),
  productionDate: z.union([z.string(), z.date()]).transform(val => 
    typeof val === 'string' ? new Date(val) : val
  ),
  expiryDate: z.union([z.string(), z.date()]).optional().transform(val => 
    val && typeof val === 'string' ? new Date(val) : val
  ),
});

export const insertInventorySchema = createInsertSchema(inventory).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertQRLabelSchema = createInsertSchema(qrLabels).omit({
  id: true,
  generatedAt: true,
});

export const insertIngredientTrackingSchema = createInsertSchema(ingredientTracking).omit({
  id: true,
  createdAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPasswordResetTokenSchema = createInsertSchema(passwordResetTokens).omit({
  id: true,
  createdAt: true,
});

export const insertCompanyProfileSchema = createInsertSchema(companyProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSaleSchema = createInsertSchema(sales).omit({
  id: true,
  createdAt: true,
}).extend({
  saleDate: z.union([z.string(), z.date()]).optional().transform(val => 
    val && typeof val === 'string' ? new Date(val) : val
  ),
});

export const insertSaleItemSchema = createInsertSchema(saleItems).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type InsertPasswordResetToken = z.infer<typeof insertPasswordResetTokenSchema>;

export type CompanyProfile = typeof companyProfiles.$inferSelect;
export type InsertCompanyProfile = z.infer<typeof insertCompanyProfileSchema>;

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;

export type Batch = typeof batches.$inferSelect;
export type InsertBatch = z.infer<typeof insertBatchSchema>;

export type InventoryItem = typeof inventory.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventorySchema>;

export type QRLabel = typeof qrLabels.$inferSelect;
export type InsertQRLabel = z.infer<typeof insertQRLabelSchema>;

export type IngredientTracking = typeof ingredientTracking.$inferSelect;
export type InsertIngredientTracking = z.infer<typeof insertIngredientTrackingSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type Sale = typeof sales.$inferSelect;
export type InsertSale = z.infer<typeof insertSaleSchema>;

export type SaleItem = typeof saleItems.$inferSelect;
export type InsertSaleItem = z.infer<typeof insertSaleItemSchema>;

// Relations
export const recipesRelations = relations(recipes, ({ many }) => ({
  batches: many(batches),
}));

export const batchesRelations = relations(batches, ({ one, many }) => ({
  recipe: one(recipes, {
    fields: [batches.recipeId],
    references: [recipes.id],
  }),
  qrLabels: many(qrLabels),
}));

export const qrLabelsRelations = relations(qrLabels, ({ one }) => ({
  batch: one(batches, {
    fields: [qrLabels.batchId],
    references: [batches.id],
  }),
}));

export const usersRelations = relations(users, ({ one }) => ({
  companyProfile: one(companyProfiles, {
    fields: [users.id],
    references: [companyProfiles.userId],
  }),
}));

export const companyProfilesRelations = relations(companyProfiles, ({ one }) => ({
  user: one(users, {
    fields: [companyProfiles.userId],
    references: [users.id],
  }),
}));

// Tabella per i piani di abbonamento
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // free, basic, premium, enterprise
  displayName: text("display_name").notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("EUR"),
  billingPeriod: text("billing_period").notNull(), // monthly, yearly
  trialDays: integer("trial_days").notNull().default(14),
  
  // Limiti del piano
  maxRecipes: integer("max_recipes").default(-1), // -1 = illimitato
  maxBatches: integer("max_batches").default(-1),
  maxInventoryItems: integer("max_inventory_items").default(-1),
  maxUsers: integer("max_users").default(1),
  maxStorageGB: integer("max_storage_gb").default(1),
  
  // Funzionalità incluse
  hasAdvancedReports: boolean("has_advanced_reports").default(false),
  hasQRLabels: boolean("has_qr_labels").default(false),
  hasTraceability: boolean("has_traceability").default(false),
  hasBackup: boolean("has_backup").default(false),
  hasAPIAccess: boolean("has_api_access").default(false),
  hasPrioritySupport: boolean("has_priority_support").default(false),
  
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Tabella per la cronologia degli abbonamenti
export const subscriptionHistory = pgTable("subscription_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  planId: integer("plan_id").notNull().references(() => subscriptionPlans.id),
  status: text("status").notNull(), // started, cancelled, expired, upgraded, downgraded
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  paymentMethod: text("payment_method"),
  transactionId: text("transaction_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Relazioni per i piani di abbonamento
export const subscriptionPlansRelations = relations(subscriptionPlans, ({ many }) => ({
  subscriptionHistory: many(subscriptionHistory),
}));

export const subscriptionHistoryRelations = relations(subscriptionHistory, ({ one }) => ({
  user: one(users, {
    fields: [subscriptionHistory.userId],
    references: [users.id],
  }),
  plan: one(subscriptionPlans, {
    fields: [subscriptionHistory.planId],
    references: [subscriptionPlans.id],
  }),
}));

// Tipi per i piani di abbonamento
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = typeof subscriptionPlans.$inferInsert;
export type SubscriptionHistoryRecord = typeof subscriptionHistory.$inferSelect;
export type InsertSubscriptionHistory = typeof subscriptionHistory.$inferInsert;

// Schema di validazione per i piani
export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans);
export const subscriptionPlanSchema = insertSubscriptionPlanSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSubscriptionHistorySchema = createInsertSchema(subscriptionHistory);
export const subscriptionHistorySchema = insertSubscriptionHistorySchema.omit({
  id: true,
  createdAt: true,
});
