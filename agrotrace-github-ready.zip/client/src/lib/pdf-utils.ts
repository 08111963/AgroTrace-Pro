import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
import type { InventoryItem, Batch, Recipe, Alert } from '@shared/schema';

// Extend jsPDF type to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: typeof autoTable;
  }
}

export class PDFExporter {
  private doc: jsPDF;

  constructor() {
    this.doc = new jsPDF();
    // Ensure autoTable is available
    this.doc.autoTable = autoTable;
    this.setupFonts();
  }

  private setupFonts() {
    // Set default font
    this.doc.setFont('helvetica');
  }

  private addHeader(title: string) {
    const pageWidth = this.doc.internal.pageSize.width;
    
    // Company header
    this.doc.setFontSize(20);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('AgroTrace Pro', 20, 25);
    
    // Report title
    this.doc.setFontSize(16);
    this.doc.setTextColor(60, 60, 60);
    this.doc.text(title, 20, 40);
    
    // Date
    this.doc.setFontSize(10);
    this.doc.setTextColor(120, 120, 120);
    const currentDate = new Date().toLocaleDateString('it-IT');
    this.doc.text(`Generato il: ${currentDate}`, pageWidth - 60, 25);
    
    // Line separator
    this.doc.setLineWidth(0.5);
    this.doc.setDrawColor(200, 200, 200);
    this.doc.line(20, 50, pageWidth - 20, 50);
  }

  private addFooter() {
    const pageHeight = this.doc.internal.pageSize.height;
    const pageWidth = this.doc.internal.pageSize.width;
    
    this.doc.setFontSize(8);
    this.doc.setTextColor(120, 120, 120);
    this.doc.text('AgroTrace Pro - Sistema di Gestione Agrifood', 20, pageHeight - 10);
    this.doc.text(`Pagina ${this.doc.getCurrentPageInfo().pageNumber}`, pageWidth - 40, pageHeight - 10);
  }

  // Export inventory report
  exportInventoryReport(inventory: InventoryItem[]): void {
    this.addHeader('Report Inventario');
    
    const tableData = inventory.map(item => [
      item.code || '-',
      item.name,
      item.category,
      `${item.currentStock} ${item.unit}`,
      `${item.minimumStock} ${item.unit}`,
      item.unitCost ? `€${parseFloat(item.unitCost).toFixed(2)}` : '-',
      item.salePrice ? `€${parseFloat(item.salePrice).toFixed(2)}` : '-',
      item.status === 'active' ? 'Attivo' : 
      item.status === 'low_stock' ? 'Scorte Basse' : 'Inattivo'
    ]);

    autoTable(this.doc, {
      startY: 60,
      head: [['Codice', 'Nome', 'Categoria', 'Scorta Attuale', 'Scorta Minima', 'Costo Unit.', 'Prezzo Vendita', 'Stato']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [41, 128, 185], textColor: 255 },
      alternateRowStyles: { fillColor: [245, 245, 245] },
      margin: { left: 20, right: 20 },
      styles: { fontSize: 8, cellPadding: 3 }
    });

    // Summary statistics
    const totalItems = inventory.length;
    const lowStockItems = inventory.filter(item => 
      parseFloat(item.currentStock) <= parseFloat(item.minimumStock)
    ).length;
    const totalValue = inventory.reduce((sum, item) => {
      const stock = parseFloat(item.currentStock) || 0;
      const price = parseFloat(item.salePrice || '0') || 0;
      return sum + (stock * price);
    }, 0);

    const finalY = (this.doc as any).lastAutoTable.finalY + 20;
    
    this.doc.setFontSize(12);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Riepilogo:', 20, finalY);
    
    this.doc.setFontSize(10);
    this.doc.text(`Totale Articoli: ${totalItems}`, 20, finalY + 15);
    this.doc.text(`Articoli con Scorte Basse: ${lowStockItems}`, 20, finalY + 25);
    this.doc.text(`Valore Totale Inventario: €${totalValue.toFixed(2)}`, 20, finalY + 35);

    this.addFooter();
    this.doc.save(`inventario_${new Date().toISOString().split('T')[0]}.pdf`);
  }

  // Export batch production report
  exportBatchReport(batches: Batch[], recipes: Recipe[]): void {
    this.addHeader('Report Lotti di Produzione');
    
    const tableData = batches.map(batch => {
      const recipe = recipes.find(r => r.id === batch.recipeId);
      return [
        batch.code,
        batch.productName,
        recipe?.name || '-',
        `${batch.quantity} ${batch.unit}`,
        new Date(batch.productionDate).toLocaleDateString('it-IT'),
        batch.expiryDate ? new Date(batch.expiryDate).toLocaleDateString('it-IT') : '-',
        batch.status === 'active' ? 'Attivo' : 
        batch.status === 'sold' ? 'Venduto' : 'Scaduto'
      ];
    });

    autoTable(this.doc, {
      startY: 60,
      head: [['Codice Lotto', 'Prodotto', 'Ricetta', 'Quantità', 'Produzione', 'Scadenza', 'Stato']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [46, 125, 50], textColor: 255 },
      alternateRowStyles: { fillColor: [245, 245, 245] },
      margin: { left: 20, right: 20 },
      styles: { fontSize: 8, cellPadding: 3 }
    });

    // Summary
    const finalY = (this.doc as any).lastAutoTable.finalY + 20;
    const totalBatches = batches.length;
    const activeBatches = batches.filter(b => b.status === 'active').length;
    const totalQuantity = batches.reduce((sum, batch) => sum + parseFloat(batch.quantity), 0);

    this.doc.setFontSize(12);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Riepilogo:', 20, finalY);
    
    this.doc.setFontSize(10);
    this.doc.text(`Totale Lotti: ${totalBatches}`, 20, finalY + 15);
    this.doc.text(`Lotti Attivi: ${activeBatches}`, 20, finalY + 25);
    this.doc.text(`Quantità Totale Prodotta: ${totalQuantity.toFixed(0)} unità`, 20, finalY + 35);

    this.addFooter();
    this.doc.save(`lotti_produzione_${new Date().toISOString().split('T')[0]}.pdf`);
  }

  // Export recipe cost analysis
  exportRecipeCostReport(recipe: Recipe, costBreakdown: any): void {
    this.addHeader(`Analisi Costi - ${recipe.name}`);
    
    // Recipe details
    this.doc.setFontSize(14);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Dettagli Ricetta:', 20, 70);
    
    this.doc.setFontSize(10);
    this.doc.text(`Nome: ${recipe.name}`, 25, 85);
    this.doc.text(`Categoria: ${recipe.category}`, 25, 95);
    this.doc.text(`Resa: ${recipe.yield} ${recipe.jarWeight}g`, 25, 105);
    this.doc.text(`Tempo Preparazione: ${recipe.preparationTime} minuti`, 25, 115);

    // Ingredients table
    const ingredientsData = recipe.ingredients.map(ing => [
      ing.name,
      `${ing.quantity} ${ing.unit}`,
      ing.cost ? `€${ing.cost.toFixed(2)}` : '-',
      ing.cost ? `€${(ing.cost * ing.quantity).toFixed(2)}` : '-'
    ]);

    autoTable(this.doc, {
      startY: 130,
      head: [['Ingrediente', 'Quantità', 'Costo Unit.', 'Costo Totale']],
      body: ingredientsData,
      theme: 'grid',
      headStyles: { fillColor: [156, 39, 176], textColor: 255 },
      margin: { left: 20, right: 20 },
      styles: { fontSize: 9, cellPadding: 3 }
    });

    // Cost breakdown
    const finalY = (this.doc as any).lastAutoTable.finalY + 20;
    
    this.doc.setFontSize(12);
    this.doc.text('Analisi Costi:', 20, finalY);
    
    this.doc.setFontSize(10);
    this.doc.text(`Costo Ingredienti: €${costBreakdown.ingredientsCost.toFixed(2)}`, 25, finalY + 15);
    this.doc.text(`Costo Confezionamento: €${costBreakdown.totalPackagingCost.toFixed(2)}`, 25, finalY + 25);
    this.doc.text(`Costi Generali: €${costBreakdown.overheadCosts.total.toFixed(2)}`, 25, finalY + 35);
    this.doc.text(`Costo Totale Lotto: €${costBreakdown.totalBatchCost.toFixed(2)}`, 25, finalY + 45);
    
    this.doc.setFontSize(12);
    this.doc.setTextColor(200, 0, 0);
    this.doc.text(`Costo per Unità: €${costBreakdown.costPerUnit.toFixed(2)}`, 25, finalY + 60);

    // Suggested pricing
    this.doc.setFontSize(10);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Prezzi Suggeriti:', 25, finalY + 80);
    this.doc.text(`Margine 30%: €${(costBreakdown.costPerUnit * 1.3).toFixed(2)}`, 30, finalY + 90);
    this.doc.text(`Margine 50%: €${(costBreakdown.costPerUnit * 1.5).toFixed(2)}`, 30, finalY + 100);
    this.doc.text(`Margine 100%: €${(costBreakdown.costPerUnit * 2).toFixed(2)}`, 30, finalY + 110);

    this.addFooter();
    this.doc.save(`analisi_costi_${recipe.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
  }

  // Export complete recipe details
  exportRecipeDetails(recipe: Recipe): void {
    this.addHeader(`Ricetta: ${recipe.name}`);
    
    // Recipe basic info
    this.doc.setFontSize(14);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Informazioni Generali:', 20, 70);
    
    this.doc.setFontSize(10);
    this.doc.text(`Nome: ${recipe.name}`, 25, 85);
    this.doc.text(`Categoria: ${recipe.category}`, 25, 95);
    this.doc.text(`Descrizione: ${recipe.description || 'Non specificata'}`, 25, 105);
    this.doc.text(`Tempo preparazione: ${recipe.preparationTime} minuti`, 25, 115);
    this.doc.text(`Resa: ${recipe.yield} vasetti da ${recipe.jarWeight}g`, 25, 125);
    
    // Database scarti per calcolo
    const wasteDatabase: Record<string, number> = {
      "pomodori": 20, "melanzane": 15, "zucchine": 15, "peperoni": 25,
      "cipolle": 10, "aglio": 15, "carote": 20, "patate": 25,
      "sedano": 30, "finocchi": 35, "carciofi": 60, "asparagi": 45,
      "broccoli": 40, "cavolfiori": 50, "spinaci": 15, "bietole": 20,
      "insalata": 25, "radicchio": 20, "rucola": 10, "prezzemolo": 10,
      "basilico": 5, "mele": 15, "pere": 20, "pesche": 25,
      "albicocche": 15, "uva": 5, "fragole": 10, "ciliegie": 10,
      "limoni": 30, "arance": 35, "mandarini": 25, "pollo": 25,
      "manzo": 20, "maiale": 15, "pesce": 35, "gamberi": 40,
      "piselli": 40, "fave": 35, "fagiolini": 10
    };

    // Calcola quantità con scarti
    const getWastePercentage = (ingredientName: string): number => {
      const cleanName = ingredientName.toLowerCase().trim();
      for (const [ingredient, waste] of Object.entries(wasteDatabase)) {
        if (cleanName.includes(ingredient)) {
          return waste;
        }
      }
      return 0;
    };

    // Ingredients table with waste calculations
    const ingredientsData = recipe.ingredients.map(ing => {
      const wastePercentage = getWastePercentage(ing.name);
      const netQuantity = ing.quantity;
      const grossQuantity = wastePercentage > 0 ? Math.round((netQuantity / (1 - wastePercentage / 100)) * 100) / 100 : netQuantity;
      const wasteAmount = grossQuantity - netQuantity;
      
      return [
        ing.name,
        `${netQuantity} ${ing.unit}`,
        wastePercentage > 0 ? `${wastePercentage}%` : '0%',
        wastePercentage > 0 ? `${wasteAmount.toFixed(1)} ${ing.unit}` : '-',
        `${grossQuantity} ${ing.unit}`,
        ing.supplier || 'N/A'
      ];
    });

    autoTable(this.doc, {
      startY: 140,
      head: [['Ingrediente', 'Quantità Ricetta', 'Scarto %', 'Quantità Scarto', 'Da Acquistare', 'Fornitore']],
      body: ingredientsData,
      theme: 'grid',
      styles: { fontSize: 8 },
      headStyles: { fillColor: [70, 130, 180] },
      margin: { left: 15, right: 15 },
      columnStyles: {
        0: { cellWidth: 35 },
        1: { cellWidth: 25 },
        2: { cellWidth: 15 },
        3: { cellWidth: 20 },
        4: { cellWidth: 25 },
        5: { cellWidth: 30 }
      }
    });

    // Summary of totals
    const finalY = (this.doc as any).lastAutoTable.finalY + 15;
    this.doc.setFontSize(12);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Riepilogo Quantità:', 20, finalY);
    
    const totalNet = recipe.ingredients.reduce((sum, ing) => sum + ing.quantity, 0);
    const totalGross = recipe.ingredients.reduce((sum, ing) => {
      const wastePercentage = getWastePercentage(ing.name);
      const grossQuantity = wastePercentage > 0 ? ing.quantity / (1 - wastePercentage / 100) : ing.quantity;
      return sum + grossQuantity;
    }, 0);
    const totalWaste = totalGross - totalNet;
    
    this.doc.setFontSize(10);
    this.doc.text(`Quantità totale ricetta (netta): ${totalNet.toFixed(1)}g`, 25, finalY + 15);
    this.doc.text(`Scarti totali: ${totalWaste.toFixed(1)}g`, 25, finalY + 25);
    this.doc.text(`Quantità totale da acquistare: ${totalGross.toFixed(1)}g`, 25, finalY + 35);

    // Instructions
    let currentY = finalY + 55;
    
    if (recipe.instructions) {
      this.doc.setFontSize(14);
      this.doc.setTextColor(40, 40, 40);
      this.doc.text('Istruzioni Brevi:', 20, currentY);
      
      this.doc.setFontSize(10);
      const splitInstructions = this.doc.splitTextToSize(recipe.instructions, 170);
      this.doc.text(splitInstructions, 25, currentY + 15);
      currentY += 15 + (splitInstructions.length * 5) + 15;
    }

    // Detailed preparation instructions
    if ((recipe as any).preparationInstructions) {
      // Check if we need a new page
      if (currentY > 250) {
        this.doc.addPage();
        this.addHeader(`Ricetta: ${recipe.name} (continua)`);
        currentY = 70;
      }
      
      this.doc.setFontSize(14);
      this.doc.setTextColor(40, 40, 40);
      this.doc.text('Istruzioni Dettagliate di Preparazione:', 20, currentY);
      
      this.doc.setFontSize(10);
      const splitDetailedInstructions = this.doc.splitTextToSize((recipe as any).preparationInstructions, 170);
      this.doc.text(splitDetailedInstructions, 25, currentY + 15);
    }

    this.addFooter();
    this.doc.save(`ricetta_${recipe.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
  }

  // Export QR code labels
  async exportQRLabels(qrLabels: any[]): Promise<void> {
    this.addHeader('Etichette QR Code');
    
    let yPosition = 70;
    const labelHeight = 50;
    const labelsPerPage = 5;
    
    for (let i = 0; i < qrLabels.length; i++) {
      const label = qrLabels[i];
      
      if (i > 0 && i % labelsPerPage === 0) {
        this.doc.addPage();
        this.addHeader('Etichette QR Code (continua)');
        yPosition = 70;
      }
      
      // Label frame
      this.doc.setDrawColor(150, 150, 150);
      this.doc.rect(20, yPosition, 170, labelHeight);
      
      // Label content
      this.doc.setFontSize(12);
      this.doc.setTextColor(40, 40, 40);
      this.doc.text(`Codice: ${label.code}`, 25, yPosition + 15);
      this.doc.text(`Lotto: ${label.batchId}`, 25, yPosition + 25);
      this.doc.text(`Generato: ${new Date(label.generatedAt).toLocaleDateString('it-IT')}`, 25, yPosition + 35);
      
      // QR placeholder (in a real implementation, you'd generate the actual QR code)
      this.doc.setDrawColor(0, 0, 0);
      this.doc.rect(140, yPosition + 5, 40, 40);
      this.doc.setFontSize(8);
      this.doc.text('QR CODE', 155, yPosition + 27);
      
      yPosition += labelHeight + 10;
    }

    this.addFooter();
    this.doc.save(`etichette_qr_${new Date().toISOString().split('T')[0]}.pdf`);
  }

  // Export traceability report
  exportTraceabilityReport(batchCode: string, traceabilityData: any): void {
    this.addHeader(`Report Tracciabilità - ${batchCode}`);
    
    const { batch, recipe, nutritionalValues, qrLabel } = traceabilityData;
    console.log('PDF generation - Recipe data:', recipe);
    console.log('PDF generation - Recipe ingredients:', recipe?.ingredients);
    
    // Company and product info section
    this.doc.setFontSize(14);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Informazioni Produttore:', 20, 70);
    
    this.doc.setFontSize(10);
    this.doc.text('Azienda Agraria Annessa al Convitto', 25, 85);
    this.doc.text('Sistema di tracciabilità AgroTrace Pro', 25, 95);
    this.doc.text(`Codice QR: ${qrLabel?.code || 'N/A'}`, 25, 105);

    // Batch information
    this.doc.setFontSize(14);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Informazioni Lotto:', 20, 125);
    
    this.doc.setFontSize(10);
    this.doc.text(`Codice Lotto: ${batch.code}`, 25, 140);
    this.doc.text(`Prodotto: ${batch.productName}`, 25, 150);
    this.doc.text(`Quantità Prodotta: ${batch.quantity} ${batch.unit}`, 25, 160);
    this.doc.text(`Data Produzione: ${new Date(batch.productionDate).toLocaleDateString('it-IT')}`, 25, 170);
    this.doc.text(`Data Scadenza: ${batch.expiryDate ? new Date(batch.expiryDate).toLocaleDateString('it-IT') : 'N/A'}`, 25, 180);
    this.doc.text(`Stato: ${batch.status === 'active' ? 'Attivo' : batch.status}`, 25, 190);

    // Always add recipe information page
    this.doc.addPage();
    this.addHeader(`Informazioni Ricetta - ${recipe?.name || 'N/A'}`);
    
    console.log('PDF: Adding recipe page');

    this.doc.setFontSize(14);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Dettagli Ricetta:', 20, 70);
    
    this.doc.setFontSize(10);
    this.doc.text(`Nome Ricetta: ${recipe?.name || 'N/A'}`, 25, 85);
    this.doc.text(`Categoria: ${recipe?.category || 'N/A'}`, 25, 95);
    
    let yPos = 105;
    if (recipe?.description && recipe.description.trim()) {
      this.doc.text(`Descrizione: ${recipe.description}`, 25, yPos);
      yPos += 10;
    }
    
    if (recipe?.preparationTime) {
      this.doc.text(`Tempo Preparazione: ${recipe.preparationTime} min`, 25, yPos);
      yPos += 10;
    }
    if (recipe?.cookingTime) {
      this.doc.text(`Tempo Cottura: ${recipe.cookingTime} min`, 25, yPos);
      yPos += 10;
    }
    if (recipe?.difficulty) {
      this.doc.text(`Difficoltà: ${recipe.difficulty}`, 25, yPos);
      yPos += 10;
    }

    // Always add ingredients table if recipe exists
    if (recipe?.ingredients && recipe.ingredients.length > 0) {
      this.doc.setFontSize(14);
      this.doc.setTextColor(40, 40, 40);
      this.doc.text('Ingredienti e Composizione:', 20, yPos + 20);
      
      console.log('PDF: Adding ingredients table with percentages');
      
      const ingredientsData = recipe.ingredients.map((ing: any) => {
        console.log('PDF ingredient mapping:', ing.name, 'percentage:', ing.productPercentage);
        return [
          ing.name || 'N/A',
          `${ing.quantity || 0} ${ing.unit || ''}`,
          ing.productPercentage ? `${ing.productPercentage}%` : '-',
          ing.supplier || '-',
          ing.supplierLot || '-',
          ing.allergens?.length > 0 ? ing.allergens.join(', ') : 'Nessuno'
        ];
      });

      autoTable(this.doc, {
        startY: yPos + 30,
        head: [['Ingrediente', 'Quantità', '% nel Prodotto', 'Fornitore', 'Lotto', 'Allergeni']],
        body: ingredientsData,
        theme: 'grid',
        headStyles: { fillColor: [76, 175, 80], textColor: 255 },
        margin: { left: 20, right: 20 },
        styles: { fontSize: 8, cellPadding: 3 },
        columnStyles: {
          0: { cellWidth: 30 },
          1: { cellWidth: 20 },
          2: { cellWidth: 20 },
          3: { cellWidth: 35 },
          4: { cellWidth: 25 },
          5: { cellWidth: 25 }
        }
      });
    } else {
      this.doc.text('Nessun ingrediente disponibile', 25, yPos + 30);
    }

    // Add new page for nutritional information
    this.doc.addPage();
    this.addHeader(`Etichetta Nutrizionale - ${batch.productName}`);

    // Nutritional values in official EU format
    if (nutritionalValues) {
      this.doc.setFontSize(16);
      this.doc.setTextColor(40, 40, 40);
      this.doc.text('INFORMAZIONI NUTRIZIONALI', 20, 80);
      
      this.doc.setFontSize(12);
      this.doc.text('Valori medi per 100g di prodotto:', 20, 95);
      
      // Create nutritional table in EU format
      const nutritionalData = [
        ['Energia', `${nutritionalValues.calories} kcal`],
        ['Grassi', `${nutritionalValues.fats}g`],
        ['  di cui acidi grassi saturi', `${nutritionalValues.saturatedFats}g`],
        ['Carboidrati', `${nutritionalValues.carbohydrates}g`],
        ['  di cui zuccheri', `${nutritionalValues.sugars}g`],
        ['Fibre', `${nutritionalValues.fiber}g`],
        ['Proteine', `${nutritionalValues.proteins}g`],
        ['Sale', `${nutritionalValues.salt}g`]
      ];

      autoTable(this.doc, {
        startY: 110,
        head: [['Componente', 'Per 100g']],
        body: nutritionalData,
        theme: 'grid',
        headStyles: { fillColor: [33, 37, 41], textColor: 255, fontSize: 12 },
        bodyStyles: { fontSize: 11 },
        margin: { left: 20, right: 20 },
        columnStyles: {
          0: { cellWidth: 100, fontStyle: 'normal' },
          1: { cellWidth: 50, halign: 'right', fontStyle: 'bold' }
        },
        didParseCell: function(data) {
          if (data.cell.text[0].startsWith('  ')) {
            data.cell.styles.fillColor = [248, 249, 250];
            data.cell.styles.textColor = [108, 117, 125];
          }
        }
      });

      // Allergens information
      let allergensList: string[] = [];
      if (recipe && recipe.ingredients) {
        allergensList = recipe.ingredients
          .filter((ing: any) => ing.allergens && ing.allergens.length > 0)
          .flatMap((ing: any) => ing.allergens)
          .filter((allergen: string, index: number, self: string[]) => self.indexOf(allergen) === index);
      }

      const finalY = (this.doc as any).lastAutoTable?.finalY + 30 || 220;
      
      this.doc.setFontSize(14);
      this.doc.setTextColor(220, 53, 69);
      this.doc.text('ALLERGENI:', 20, finalY);
      
      this.doc.setFontSize(11);
      this.doc.setTextColor(40, 40, 40);
      if (allergensList.length > 0) {
        this.doc.text(`Contiene: ${allergensList.join(', ')}`, 20, finalY + 15);
      } else {
        this.doc.text('Il prodotto non contiene allergeni dichiarati.', 20, finalY + 15);
      }

      // Storage instructions
      this.doc.setFontSize(12);
      this.doc.setTextColor(40, 40, 40);
      this.doc.text('CONSERVAZIONE:', 20, finalY + 40);
      this.doc.setFontSize(10);
      this.doc.text('Conservare in luogo fresco e asciutto.', 20, finalY + 55);
      this.doc.text('Dopo l\'apertura conservare in frigorifero e consumare entro 7 giorni.', 20, finalY + 65);
    }

    // Add Quality Controls section if available
    if (batch.qualityControls && Object.keys(batch.qualityControls).length > 0) {
      this.doc.addPage();
      this.addHeader(`Controlli Qualità - ${batch.productName}`);
      
      this.doc.setFontSize(16);
      this.doc.setTextColor(40, 40, 40);
      this.doc.text('CONTROLLI QUALITÀ CERTIFICATI', 20, 80);
      
      this.doc.setFontSize(12);
      this.doc.setTextColor(60, 60, 60);
      this.doc.text('Parametri verificati durante la produzione:', 20, 95);
      
      // Prepare quality controls data
      const qualityData = [];
      const controls = batch.qualityControls;
      
      if (controls.ph && controls.ph.value) {
        qualityData.push(['pH', controls.ph.value, '4.0-4.5', controls.ph.status]);
      }
      if (controls.brix && controls.brix.value) {
        qualityData.push(['Brix', `${controls.brix.value}°`, '5.5-6.0°', controls.brix.status]);
      }
      if (controls.temperature && controls.temperature.value) {
        qualityData.push(['Temperatura', `${controls.temperature.value}°C`, '80-90°C', controls.temperature.status]);
      }
      if (controls.viscosity && controls.viscosity.value) {
        qualityData.push(['Viscosità', controls.viscosity.value, 'Standard', controls.viscosity.status]);
      }
      if (controls.color && controls.color.value) {
        qualityData.push(['Colore', controls.color.value, 'Conforme', controls.color.status]);
      }
      
      if (qualityData.length > 0) {
        autoTable(this.doc, {
          startY: 110,
          head: [['Parametro', 'Valore Misurato', 'Target', 'Esito']],
          body: qualityData,
          theme: 'grid',
          headStyles: { fillColor: [34, 139, 34], textColor: 255, fontSize: 12 },
          bodyStyles: { fontSize: 11 },
          margin: { left: 20, right: 20 },
          columnStyles: {
            0: { cellWidth: 40 },
            1: { cellWidth: 40, halign: 'center' },
            2: { cellWidth: 40, halign: 'center' },
            3: { cellWidth: 30, halign: 'center' }
          },
          didParseCell: function(data) {
            if (data.column.index === 3) { // Status column
              const status = data.cell.text[0];
              if (status === 'OK') {
                data.cell.styles.fillColor = [220, 255, 220];
                data.cell.styles.textColor = [0, 100, 0];
              } else if (status === 'WARNING') {
                data.cell.styles.fillColor = [255, 255, 220];
                data.cell.styles.textColor = [150, 100, 0];
              } else if (status === 'FAIL') {
                data.cell.styles.fillColor = [255, 220, 220];
                data.cell.styles.textColor = [150, 0, 0];
              }
            }
          }
        });
        
        // Add operator and timestamp info
        const operatorInfo = controls.ph?.operator || controls.brix?.operator || controls.temperature?.operator || 'Non specificato';
        const timestamp = controls.ph?.timestamp || controls.brix?.timestamp || controls.temperature?.timestamp;
        
        const tableEndY = (this.doc as any).lastAutoTable?.finalY + 20 || 200;
        
        this.doc.setFontSize(12);
        this.doc.setTextColor(40, 40, 40);
        this.doc.text('INFORMAZIONI CONTROLLO:', 20, tableEndY);
        
        this.doc.setFontSize(10);
        this.doc.text(`Operatore: ${operatorInfo}`, 20, tableEndY + 15);
        
        if (timestamp) {
          const date = new Date(timestamp).toLocaleString('it-IT');
          this.doc.text(`Data e ora controllo: ${date}`, 20, tableEndY + 25);
        }
        
        if (controls.ph?.notes) {
          this.doc.text(`Note: ${controls.ph.notes}`, 20, tableEndY + 35);
        }
        
        // Add certification statement
        this.doc.setFontSize(11);
        this.doc.setTextColor(34, 139, 34);
        this.doc.text('✓ Controlli eseguiti secondo standard HACCP', 20, tableEndY + 55);
        this.doc.text('✓ Parametri conformi alle normative alimentari vigenti', 20, tableEndY + 65);
      }
    }

    this.addFooter();
    
    // Debug: Log total pages before saving
    console.log('PDF: Total pages before save:', this.doc.getNumberOfPages());
    
    this.doc.save(`tracciabilita_${batchCode}_${new Date().toISOString().split('T')[0]}.pdf`);
  }

  // Export alerts report
  exportAlertsReport(alerts: Alert[]): void {
    this.addHeader('Report Alert Sistema');
    
    const tableData = alerts.map(alert => [
      alert.type === 'low_stock' ? 'Scorte Basse' : 
      alert.type === 'expired' ? 'Scaduto' :
      alert.type === 'system' ? 'Sistema' : alert.type,
      alert.message,
      alert.severity === 'high' ? 'Alta' :
      alert.severity === 'medium' ? 'Media' : 'Bassa',
      new Date(alert.createdAt).toLocaleDateString('it-IT'),
      alert.resolved ? 'Risolto' : 'Attivo'
    ]);

    autoTable(this.doc, {
      startY: 60,
      head: [['Tipo', 'Messaggio', 'Severità', 'Data', 'Stato']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [244, 67, 54], textColor: 255 },
      alternateRowStyles: { fillColor: [245, 245, 245] },
      margin: { left: 20, right: 20 },
      styles: { fontSize: 9, cellPadding: 3 }
    });

    // Summary
    const finalY = (this.doc as any).lastAutoTable.finalY + 20;
    const totalAlerts = alerts.length;
    const activeAlerts = alerts.filter(a => !a.resolved).length;
    const highSeverityAlerts = alerts.filter(a => a.severity === 'high').length;

    this.doc.setFontSize(12);
    this.doc.setTextColor(40, 40, 40);
    this.doc.text('Riepilogo Alert:', 20, finalY);
    
    this.doc.setFontSize(10);
    this.doc.text(`Totale Alert: ${totalAlerts}`, 20, finalY + 15);
    this.doc.text(`Alert Attivi: ${activeAlerts}`, 20, finalY + 25);
    this.doc.text(`Alert Alta Priorità: ${highSeverityAlerts}`, 20, finalY + 35);

    this.addFooter();
    this.doc.save(`alert_sistema_${new Date().toISOString().split('T')[0]}.pdf`);
  }
}

// Export functions for use in components
export const exportInventoryToPDF = (inventory: InventoryItem[]) => {
  try {
    console.log('Avvio esportazione PDF inventario per', inventory.length, 'articoli');
    const exporter = new PDFExporter();
    exporter.exportInventoryReport(inventory);
    console.log('Esportazione PDF inventario completata');
  } catch (error) {
    console.error('Errore durante esportazione PDF inventario:', error);
    alert('Errore durante la creazione del PDF. Controlla la console per dettagli.');
  }
};

export const exportBatchesToPDF = (batches: Batch[], recipes: Recipe[]) => {
  try {
    console.log('Avvio esportazione PDF lotti per', batches.length, 'lotti');
    const exporter = new PDFExporter();
    exporter.exportBatchReport(batches, recipes);
    console.log('Esportazione PDF lotti completata');
  } catch (error) {
    console.error('Errore durante esportazione PDF lotti:', error);
    alert('Errore durante la creazione del PDF. Controlla la console per dettagli.');
  }
};

export const exportRecipeCostToPDF = (recipe: Recipe, costBreakdown: any) => {
  const exporter = new PDFExporter();
  exporter.exportRecipeCostReport(recipe, costBreakdown);
};

export const exportRecipeToPDF = (recipe: Recipe) => {
  const exporter = new PDFExporter();
  exporter.exportRecipeDetails(recipe);
};

export const exportQRLabelsToPDF = async (qrLabels: any[]) => {
  const exporter = new PDFExporter();
  await exporter.exportQRLabels(qrLabels);
};

export const exportTraceabilityToPDF = (batchCode: string, traceabilityData: any) => {
  const exporter = new PDFExporter();
  exporter.exportTraceabilityReport(batchCode, traceabilityData);
};

export const exportAlertsToPDF = (alerts: Alert[]) => {
  const exporter = new PDFExporter();
  exporter.exportAlertsReport(alerts);
};