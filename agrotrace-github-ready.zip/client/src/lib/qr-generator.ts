// QR Code generation utilities for agricultural traceability
import QRCode from 'qrcode';

interface QRCodeData {
  type: string;
  code: string;
  description: string;
  timestamp: string;
  company: string;
  additionalInfo?: Record<string, any>;
}

// Generate QR code using qrcode library
export const generateQRCode = async (data: string, canvas: HTMLCanvasElement): Promise<void> => {
  try {
    await QRCode.toCanvas(canvas, data, {
      width: 200,
      margin: 2,
      color: {
        dark: '#2D5016', // Agricultural green
        light: '#FFFFFF',
      },
      errorCorrectionLevel: 'M', // Medium error correction for agricultural environments
    });
  } catch (error) {
    console.error('Error generating QR code:', error);
    throw error;
  }
};

export const downloadQRCode = (canvas: HTMLCanvasElement, filename: string): void => {
  const link = document.createElement('a');
  link.download = filename;
  link.href = canvas.toDataURL();
  link.click();
};

export const printQRCode = (
  canvas: HTMLCanvasElement, 
  title: string = 'Etichetta QR',
  additionalInfo?: string
): void => {
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  // Convert canvas to base64 image for proper printing
  const qrImageData = canvas.toDataURL('image/png');

  const printContent = `
    <html>
      <head>
        <title>${title}</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            text-align: center; 
            margin: 20px;
            background: white;
          }
          .qr-container { 
            display: inline-block; 
            border: 2px solid #2D5016; 
            padding: 20px; 
            border-radius: 8px;
            background: white;
            max-width: 300px;
          }
          .title { 
            font-size: 18px; 
            font-weight: bold; 
            margin-bottom: 15px;
            color: #2D5016;
          }
          .qr-image { 
            display: block; 
            margin: 0 auto;
            width: 200px;
            height: 200px;
            border: 1px solid #ddd;
          }
          .info { 
            font-size: 12px; 
            margin-top: 15px; 
            color: #666;
            line-height: 1.4;
          }
          @media print {
            body { 
              margin: 0; 
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .qr-container { 
              border: 2px solid #2D5016; 
              page-break-inside: avoid;
            }
            .qr-image {
              border: 1px solid #2D5016;
            }
          }
        </style>
      </head>
      <body>
        <div class="qr-container">
          <div class="title">${title}</div>
          <img src="${qrImageData}" alt="QR Code" class="qr-image" />
          ${additionalInfo ? `<div class="info">${additionalInfo}</div>` : ''}
        </div>
      </body>
    </html>
  `;

  printWindow.document.write(printContent);
  printWindow.document.close();
  printWindow.focus();
  
  setTimeout(() => {
    printWindow.print();
    printWindow.close();
  }, 1000);
};

export const validateQRData = (data: QRCodeData): boolean => {
  return !!(data.type && data.code && data.description && data.timestamp && data.company);
};

export const parseQRData = (dataString: string): QRCodeData | null => {
  try {
    const parsed = JSON.parse(dataString);
    return validateQRData(parsed) ? parsed : null;
  } catch {
    return null;
  }
};

export const generateBatchQRData = (batchCode: string, productName: string, additionalInfo?: Record<string, any>): QRCodeData => {
  return {
    type: 'BATCH',
    code: batchCode,
    description: productName,
    timestamp: new Date().toISOString(),
    company: 'AgroTrace Pro',
    additionalInfo: additionalInfo || {}
  };
};

export const generateIngredientQRData = (ingredientCode: string, ingredientName: string, supplier?: string): QRCodeData => {
  return {
    type: 'INGREDIENT',
    code: ingredientCode,
    description: ingredientName,
    timestamp: new Date().toISOString(),
    company: 'AgroTrace Pro',
    additionalInfo: { supplier: supplier || 'N/A' }
  };
};

export const generateRecipeQRData = (recipeCode: string, recipeName: string, version?: string): QRCodeData => {
  return {
    type: 'RECIPE',
    code: recipeCode,
    description: recipeName,
    timestamp: new Date().toISOString(),
    company: 'AgroTrace Pro',
    additionalInfo: { version: version || '1.0' }
  };
};

export const QR_SIZE_PRESETS = {
  small: 150,
  medium: 200,
  large: 300,
  print: 400
};

export const AGRO_COLOR_SCHEMES = {
  default: {
    dark: '#2D5016',
    light: '#FFFFFF'
  },
  organic: {
    dark: '#228B22',
    light: '#F0FFF0'
  },
  premium: {
    dark: '#8B4513',
    light: '#FFF8DC'
  }
};