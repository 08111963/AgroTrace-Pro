/**
 * AgroTrace Pro - Sistema di Tracciabilità Agroalimentare
 * 
 * Copyright (c) 2025 Marino Pizzuti
 * Tutti i diritti riservati
 * 
 * Dashboard Frontend - Proprietario
 * 
 * @author Marino Pizzuti
 * @copyright 2025
 */

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ChefHat, 
  Package, 
  Warehouse, 
  AlertTriangle,
  TrendingUp,
  Calendar,
  Clock,
  Euro,
  Crown,
  Calculator
} from "lucide-react";
import { useSEO, seoConfigs } from "@/hooks/useSEO";
import { useAuth } from "@/hooks/useAuth";
import RecipeManagement from "@/components/recipe-management";
import BatchManagement from "@/components/batch-management";
import InventoryManagement from "@/components/inventory-management";
import IngredientAvailabilityTracker from "@/components/ingredient-availability-tracker";
import QRLabels from "@/components/qr-labels";
import TraceabilitySearch from "@/components/traceability-search";
import ReportsSection from "@/components/reports-section";
import HelpGuide from "@/components/help-guide";
import CompanyProfile from "@/components/company-profile";
import AlertsManagement from "@/components/alerts-management";
import AIRecipeGenerator from "@/components/ai-recipe-generator";
import SalesManagement from "@/components/sales-management";
import SubscriptionBanner from "@/components/subscription-banner";
import PricingModal from "@/components/pricing-modal";

interface DashboardProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const Dashboard = ({ activeSection, setActiveSection }: DashboardProps) => {
  const [pricingModalOpen, setPricingModalOpen] = useState(false);

  // Import useAuth to check authentication status
  const { user, isAuthenticated } = useAuth();

  // Fetch license status
  const { data: licenseStatus } = useQuery({
    queryKey: ["/api/license/status"],
    refetchInterval: 5 * 60 * 1000, // Aggiorna ogni 5 minuti
    staleTime: 2 * 60 * 1000, // 2 minuti
    enabled: isAuthenticated,
  });

  // Configurazione SEO dinamica basata sulla sezione attiva
  const getSEOConfig = () => {
    switch (activeSection) {
      case 'recipes':
        return seoConfigs.recipes;
      case 'batches':
        return seoConfigs.batches;
      case 'inventory':
        return seoConfigs.inventory;
      case 'reports':
        return seoConfigs.reports;
      case 'ai-recipes':
        return seoConfigs.aiRecipes;
      default:
        return seoConfigs.dashboard;
    }
  };

  // Applica configurazione SEO
  useSEO(getSEOConfig());

  // Fetch dashboard stats con cache aggressiva
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    staleTime: 2 * 60 * 1000, // 2 minuti
    gcTime: 5 * 60 * 1000, // 5 minuti
    enabled: isAuthenticated,
  });

  // Fetch active alerts con cache
  const { data: alerts = [], isLoading: alertsLoading } = useQuery({
    queryKey: ["/api/alerts/active"],
    staleTime: 1 * 60 * 1000, // 1 minuto
    gcTime: 3 * 60 * 1000, // 3 minuti
    enabled: isAuthenticated,
  });

  // Fetch recent batches con cache
  const { data: batches = [], isLoading: batchesLoading } = useQuery({
    queryKey: ["/api/batches"],
    staleTime: 3 * 60 * 1000, // 3 minuti
    gcTime: 10 * 60 * 1000, // 10 minuti
    enabled: isAuthenticated,
  });

  const renderDashboardOverview = () => (
    <div className="space-y-8">
      {/* Subscription Banner */}
      <SubscriptionBanner onUpgradeClick={() => setPricingModalOpen(true)} />
      
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-xl gradient-primary p-8 md:p-12 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-6">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <ChefHat className="h-10 w-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">AgroTrace Pro</h1>
              <p className="text-xl text-white/90 font-medium">
                Sistema di Tracciabilità Agroalimentare Avanzato
              </p>
            </div>
          </div>
          
          <p className="text-lg text-white/80 mb-8 max-w-3xl leading-relaxed">
            Gestisci l'intera filiera produttiva dei tuoi prodotti agroalimentari con precisione e trasparenza. 
            Dalla creazione delle ricette al controllo qualità, dalla gestione del magazzino alla tracciabilità completa.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex items-start gap-4 bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/15 transition-all duration-200">
              <div className="p-3 bg-white/20 backdrop-blur-sm rounded-lg">
                <ChefHat className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white mb-1">Ricette Dettagliate</h3>
                <p className="text-sm text-white/70">
                  Crea ricette con ingredienti, costi e allergeni per ogni prodotto
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-4 bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/15 transition-all duration-200 cursor-pointer" onClick={() => setActiveSection('recipe-calculator')}>
              <div className="p-3 bg-white/20 backdrop-blur-sm rounded-lg">
                <Calculator className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white mb-1">Calcolatore Ingredienti</h3>
                <p className="text-sm text-white/70">
                  Calcola quantità precise per produzione industriale con gestione scarti
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-4 bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/15 transition-all duration-200">
              <div className="p-3 bg-white/20 backdrop-blur-sm rounded-lg">
                <Package className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white mb-1">Tracciabilità Lotti</h3>
                <p className="text-sm text-white/70">
                  Monitora ogni lotto prodotto con codici QR e scadenze automatiche
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-4 bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/15 transition-all duration-200">
              <div className="p-3 bg-white/20 backdrop-blur-sm rounded-lg">
                <Warehouse className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white mb-1">Gestione Magazzino</h3>
                <p className="text-sm text-white/70">
                  Controlla scorte, fornitori e ricevi alerti automatici
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Background decoration */}
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
        <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-24 h-24 bg-white/20 rounded-full blur-xl"></div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card-feature cursor-pointer hover:scale-105 transition-transform duration-200" onClick={() => setActiveSection('ricette')}>
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 gradient-info rounded-lg shadow-glow">
              <ChefHat className="h-6 w-6 text-white" />
            </div>
            <TrendingUp className="h-5 w-5 text-green-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">Ricette Attive</h3>
            <div className="text-3xl font-bold text-foreground">{(stats as any)?.totalRecipes || 0}</div>
            <p className="text-xs text-muted-foreground">Clicca per gestire ricette</p>
          </div>
        </div>

        <div className="card-feature cursor-pointer hover:scale-105 transition-transform duration-200" onClick={() => setActiveSection('lotti')}>
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 gradient-accent rounded-lg shadow-glow">
              <Package className="h-6 w-6 text-white" />
            </div>
            <Clock className="h-5 w-5 text-blue-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">Lotti Attivi</h3>
            <div className="text-3xl font-bold text-foreground">{(stats as any)?.activeBatches || 0}</div>
            <p className="text-xs text-muted-foreground">Clicca per gestire lotti</p>
          </div>
        </div>

        <div className="card-feature cursor-pointer hover:scale-105 transition-transform duration-200" onClick={() => setActiveSection('magazzino')}>
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 gradient-primary rounded-lg shadow-glow">
              <Warehouse className="h-6 w-6 text-white" />
            </div>
            <Package className="h-5 w-5 text-green-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">Prodotti Magazzino</h3>
            <div className="text-3xl font-bold text-foreground">{(stats as any)?.inventoryItems || 0}</div>
            <p className="text-xs text-muted-foreground">Clicca per gestire inventario</p>
          </div>
        </div>

        <div className="card-feature cursor-pointer hover:scale-105 transition-transform duration-200" onClick={() => setActiveSection('magazzino')}>
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 gradient-warning rounded-lg shadow-glow">
              <Euro className="h-6 w-6 text-white" />
            </div>
            <TrendingUp className="h-5 w-5 text-yellow-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">Valore Inventario</h3>
            <div className="text-3xl font-bold text-foreground">
              €{((stats as any)?.totalInventoryValue?.toLocaleString('it-IT', { 
                minimumFractionDigits: 0,
                maximumFractionDigits: 0 
              })) || 0}
            </div>
            <p className="text-xs text-muted-foreground">Dettagli inventario</p>
          </div>
        </div>
      </div>

      {/* Alerts Section */}
      {(alerts as any[]).length > 0 && (
        <div className="card-feature border-red-200 dark:border-red-800 bg-red-50/50 dark:bg-red-950/30">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 gradient-error rounded-lg shadow-glow">
              <AlertTriangle className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Avvisi Attivi</h2>
              <p className="text-sm text-muted-foreground">{(alerts as any[]).length} elementi richiedono attenzione</p>
            </div>
          </div>
          <div className="space-y-3">
            {(alerts as any[]).slice(0, 3).map((alert: any) => (
              <div key={alert.id} className="flex items-start gap-4 p-4 bg-white dark:bg-card rounded-lg border border-border/50 shadow-soft">
                <div className="p-2 bg-red-100 dark:bg-red-950 rounded-lg">
                  <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={alert.severity === 'high' ? 'status-error' : alert.severity === 'medium' ? 'status-warning' : 'status-info'}>
                      {alert.severity === 'high' ? 'Alto' : alert.severity === 'medium' ? 'Medio' : 'Basso'}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {alert.type === 'low_stock' ? 'Scorte Basse' : alert.type}
                    </span>
                  </div>
                  <p className="font-medium text-foreground">{alert.message}</p>
                  <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {new Date(alert.createdAt).toLocaleTimeString('it-IT', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="card-feature">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 gradient-primary rounded-lg shadow-glow">
            <TrendingUp className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">Azioni Rapide</h2>
            <p className="text-sm text-muted-foreground">Inizia subito a lavorare con le funzionalità principali</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => setActiveSection('ricette')}
            className="card-elevated p-6 text-left group hover:scale-105 transition-all duration-200"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 gradient-info rounded-lg shadow-glow">
                <ChefHat className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-bold text-foreground">Crea Ricetta</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Aggiungi nuove ricette con ingredienti, costi e allergeni dettagliati
            </p>
          </button>
          
          <button
            onClick={() => setActiveSection('lotti')}
            className="card-elevated p-6 text-left group hover:scale-105 transition-all duration-200"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 gradient-accent rounded-lg shadow-glow">
                <Package className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-bold text-foreground">Nuovo Lotto</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Registra una nuova produzione con codice di tracciabilità automatico
            </p>
          </button>
          
          <button
            onClick={() => setActiveSection('magazzino')}
            className="card-elevated p-6 text-left group hover:scale-105 transition-all duration-200"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 gradient-warning rounded-lg shadow-glow">
                <Warehouse className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-bold text-foreground">Gestisci Inventario</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Aggiungi prodotti al magazzino e monitora le scorte
            </p>
          </button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Batches */}
        <div className="card-feature">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 gradient-accent rounded-lg shadow-glow">
              <Package className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Lotti Recenti</h2>
              <p className="text-sm text-muted-foreground">Ultimi lotti prodotti</p>
            </div>
          </div>
          {(batches as any[]).length === 0 ? (
            <div className="text-center py-8">
              <div className="p-4 bg-muted/30 rounded-full w-fit mx-auto mb-4">
                <Package className="h-12 w-12 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground mb-4">Nessun lotto registrato</p>
              <button
                onClick={() => setActiveSection('lotti')}
                className="btn-primary-modern"
              >
                Crea il tuo primo lotto
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {(batches as any[]).slice(0, 4).map((batch: any) => (
                <div key={batch.id} className="card-elevated p-4 hover:scale-102 transition-all duration-200">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-bold text-foreground">{batch.code}</div>
                      <div className="text-sm text-muted-foreground">{batch.productName}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {batch.quantity} {batch.unit}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={batch.status === 'active' ? 'status-success' : 'status-info'}>
                        {batch.status === 'active' ? 'Attivo' : batch.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Azioni Rapide</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => setActiveSection('ricette')} 
                className="p-4 border border-border rounded-lg hover:bg-accent transition-colors text-left"
              >
                <ChefHat className="h-6 w-6 text-primary mb-2" />
                <div className="font-medium">Nuova Ricetta</div>
                <div className="text-xs text-muted-foreground">Crea ricetta</div>
              </button>
              <button 
                onClick={() => setActiveSection('lotti')} 
                className="p-4 border border-border rounded-lg hover:bg-accent transition-colors text-left"
              >
                <Package className="h-6 w-6 text-primary mb-2" />
                <div className="font-medium">Nuovo Lotto</div>
                <div className="text-xs text-muted-foreground">Crea lotto</div>
              </button>
              <button 
                onClick={() => setActiveSection('magazzino')} 
                className="p-4 border border-border rounded-lg hover:bg-accent transition-colors text-left"
              >
                <Warehouse className="h-6 w-6 text-primary mb-2" />
                <div className="font-medium">Gestisci Scorte</div>
                <div className="text-xs text-muted-foreground">Inventario</div>
              </button>
              <button 
                onClick={() => setActiveSection('qr-labels')} 
                className="p-4 border border-border rounded-lg hover:bg-accent transition-colors text-left"
              >
                <Calendar className="h-6 w-6 text-primary mb-2" />
                <div className="font-medium">Genera QR</div>
                <div className="text-xs text-muted-foreground">Etichette</div>
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  // Render different sections based on activeSection
  switch (activeSection) {
    case "ricette":
      return <RecipeManagement />;
    case "lotti":
      return <BatchManagement onNavigateToQR={(batchId) => {
        setActiveSection('qr-labels');
        // Store the selected batch ID for QR generation
        sessionStorage.setItem('selectedBatchForQR', batchId.toString());
      }} />;
    case "magazzino":
      return <InventoryManagement />;
    case "vendite":
      return <SalesManagement />;
    case "disponibilita-ingredienti":
      return <IngredientAvailabilityTracker />;
    case "alert":
      return <AlertsManagement />;
    case "qr-labels":
      return <QRLabels />;
    case "tracciabilita":
      return <TraceabilitySearch />;
    case "reports":
      return <ReportsSection />;
    case "profilo-aziendale":
      return <CompanyProfile />;
    case "ai-ricette":
      return <AIRecipeGenerator />;
    case "guida":
      return <HelpGuide />;
    default:
      return (
        <>
          {renderDashboardOverview()}
          <PricingModal 
            open={pricingModalOpen} 
            onOpenChange={setPricingModalOpen}
            currentPlan={licenseStatus?.plan}
          />
        </>
      );
  }
};

export default Dashboard;