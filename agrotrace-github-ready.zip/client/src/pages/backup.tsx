import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  Download, 
  Upload, 
  Clock, 
  Database, 
  AlertCircle,
  CheckCircle,
  Trash2
} from "lucide-react";
import { format } from "date-fns";
import { it } from "date-fns/locale";

interface Backup {
  file: string;
  date: Date;
  size: number;
}

interface BackupResponse {
  success: boolean;
  backups: Backup[];
}

export default function BackupPage() {
  const [selectedBackup, setSelectedBackup] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Carica lista backup
  const { data: backupsData, isLoading } = useQuery({
    queryKey: ["/api/backup/list"],
    refetchInterval: 30000, // Aggiorna ogni 30 secondi
  });

  // Mutazione per creare backup
  const createBackupMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/backup/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Errore nella creazione del backup");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/backup/list"] });
      toast({
        title: "Backup creato",
        description: "Il backup è stato creato con successo",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore nella creazione del backup",
        variant: "destructive",
      });
    },
  });

  // Mutazione per ripristinare backup
  const restoreBackupMutation = useMutation({
    mutationFn: async (filename: string) => {
      const response = await fetch(`/api/backup/restore/${filename}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Errore nel ripristino del backup");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/backup/list"] });
      toast({
        title: "Backup ripristinato",
        description: "Il backup è stato ripristinato con successo",
      });
      setSelectedBackup(null);
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore nel ripristino del backup",
        variant: "destructive",
      });
    },
  });

  const backups: Backup[] = (backupsData as BackupResponse)?.backups || [];

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-primary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <Database className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Gestione Backup</h1>
              <p className="text-xl text-white/90">
                Monitora e gestisci i backup automatici del database
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      {/* Status and Actions */}
      <div className="grid gap-6 md:grid-cols-2">
        <div className="card-feature">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 gradient-info rounded-lg shadow-glow">
              <Clock className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Backup Automatici</h2>
              <p className="text-sm text-muted-foreground">Sistema automatico ogni 6 ore</p>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800">
              <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
              <span className="status-success">Servizio attivo</span>
            </div>
            <div className="p-4 bg-muted/30 rounded-lg">
              <p className="text-sm text-muted-foreground">
                <strong>Prossimo backup automatico:</strong><br />
                {format(new Date(Date.now() + 6 * 60 * 60 * 1000), "dd/MM/yyyy HH:mm", { locale: it })}
              </p>
            </div>
          </div>
        </div>

        <div className="card-feature">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 gradient-accent rounded-lg shadow-glow">
              <Database className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Backup Manuale</h2>
              <p className="text-sm text-muted-foreground">Crea backup immediato</p>
            </div>
          </div>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Crea un backup immediato del database per salvare lo stato attuale prima di operazioni importanti.
            </p>
            <Button 
              onClick={() => createBackupMutation.mutate()}
              disabled={createBackupMutation.isPending}
              className="btn-primary-modern w-full"
            >
              <Download className="w-4 h-4 mr-2" />
              {createBackupMutation.isPending ? "Creazione..." : "Crea Backup Ora"}
            </Button>
          </div>
        </div>
      </div>

      {/* Backup List */}
      <div className="card-feature">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 gradient-warning rounded-lg shadow-glow">
            <Database className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">Backup Disponibili</h2>
            <p className="text-sm text-muted-foreground">Lista dei backup disponibili per il ripristino</p>
          </div>
        </div>
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
              <p className="mt-2 text-sm text-gray-600">Caricamento backup...</p>
            </div>
          ) : backups.length === 0 ? (
            <div className="text-center py-8">
              <div className="p-4 bg-muted/30 rounded-full w-fit mx-auto mb-4">
                <Database className="w-12 h-12 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground mb-2">Nessun backup disponibile</p>
              <p className="text-sm text-muted-foreground">
                Crea il primo backup usando il pulsante sopra
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {backups.map((backup) => (
                <div
                  key={backup.file}
                  className={`card-elevated p-4 cursor-pointer transition-all duration-200 ${
                    selectedBackup === backup.file
                      ? "ring-2 ring-primary shadow-glow scale-102"
                      : "hover:scale-102 hover:shadow-glow-hover"
                  }`}
                  onClick={() => setSelectedBackup(backup.file)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 gradient-info rounded-lg">
                          <Database className="w-4 h-4 text-white" />
                        </div>
                        <span className="font-bold text-foreground">{backup.file}</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {format(new Date(backup.date), "dd/MM/yyyy HH:mm", { locale: it })}
                        </div>
                        <span className="status-info">{formatFileSize(backup.size)}</span>
                      </div>
                    </div>
                    {selectedBackup === backup.file && (
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <span className="status-success">Selezionato</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Restore Section */}
      {selectedBackup && (
        <div className="card-feature border-orange-200 dark:border-orange-800 bg-orange-50/50 dark:bg-orange-950/30">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 gradient-error rounded-lg shadow-glow">
              <AlertCircle className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Conferma Ripristino</h2>
              <p className="text-sm text-muted-foreground">Attenzione: questa operazione sostituirà tutti i dati attuali</p>
            </div>
          </div>
          <Alert className="mb-6 border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-950/50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-orange-800 dark:text-orange-200">
              <strong>ATTENZIONE:</strong> Il ripristino del backup sostituirà completamente il database attuale. 
              Tutti i dati inseriti dopo la data del backup selezionato ({format(new Date(backups.find(b => b.file === selectedBackup)?.date || new Date()), "dd/MM/yyyy HH:mm", { locale: it })}) 
              verranno persi definitivamente.
            </AlertDescription>
          </Alert>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setSelectedBackup(null)}
              className="flex-1"
            >
              Annulla
            </Button>
            <Button
              onClick={() => selectedBackup && restoreBackupMutation.mutate(selectedBackup)}
              disabled={restoreBackupMutation.isPending || !selectedBackup}
              className="flex-1 bg-orange-600 hover:bg-orange-700 text-white"
            >
              <Upload className="w-4 h-4 mr-2" />
              {restoreBackupMutation.isPending ? "Ripristino..." : "Ripristina"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}