import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, CheckCircle, ArrowRight, User, ClipboardList, Package2, QrCode, BarChart3 } from "lucide-react";
import { Link } from "wouter";

export default function QuickGuidePage() {
  const steps = [
    {
      number: 1,
      title: "Registrazione e Primo Accesso",
      icon: User,
      description: "Crea il tuo account e configura il profilo aziendale",
      details: [
        "Clicca su 'Inizia Ora' dalla homepage",
        "Compila il modulo di registrazione con i tuoi dati",
        "Verifica l'email ricevuta (controlla anche lo spam)",
        "Accedi con username e password",
        "Completa il profilo aziendale con ragione sociale e dati fiscali"
      ],
      tips: [
        "Usa un indirizzo email aziendale per maggiore professionalità",
        "Scegli una password sicura con almeno 8 caratteri",
        "Il profilo aziendale apparirà nelle etichette QR"
      ],
      time: "5 minuti"
    },
    {
      number: 2,
      title: "Prima Ricetta",
      icon: ClipboardList,
      description: "Crea la tua prima ricetta con ingredienti e costi",
      details: [
        "Vai nella sezione 'Ricette' dal menu laterale",
        "Clicca 'Nuova Ricetta' e inserisci nome e descrizione",
        "Aggiungi gli ingredienti uno per uno con quantità e unità di misura",
        "Il sistema calcolerà automaticamente i costi totali",
        "Salva la ricetta per utilizzarla nei lotti di produzione"
      ],
      tips: [
        "Inizia con ricette semplici per prendere confidenza",
        "I valori nutrizionali sono calcolati automaticamente",
        "Puoi modificare le ricette in qualsiasi momento"
      ],
      time: "10 minuti"
    },
    {
      number: 3,
      title: "Gestione Inventario",
      icon: Package2,
      description: "Configura l'inventario degli ingredienti",
      details: [
        "Accedi alla sezione 'Inventario'",
        "Aggiungi i tuoi ingredienti con codice, scorte attuali e limiti",
        "Imposta fornitori e costi per ogni ingrediente",
        "Configura le soglie di alert per scorte basse",
        "Il sistema ti avviserà automaticamente quando riordinare"
      ],
      tips: [
        "Imposta scorte minime realistiche per evitare rotture di stock",
        "Usa codici ingredienti coerenti (es. PM-001, SM-002)",
        "Aggiorna regolarmente i costi per calcoli precisi"
      ],
      time: "15 minuti"
    },
    {
      number: 4,
      title: "Primo Lotto di Produzione",
      icon: Package2,
      description: "Crea il tuo primo lotto tracciabile",
      details: [
        "Vai nella sezione 'Lotti' e clicca 'Nuovo Lotto'",
        "Seleziona la ricetta creata precedentemente",
        "Inserisci quantità da produrre e date di produzione/scadenza",
        "Il sistema genera automaticamente il codice lotto",
        "Registra le fasi di lavorazione per la tracciabilità completa"
      ],
      tips: [
        "I codici lotto seguono il formato BT-AAMMGG-XXX",
        "Registra temperature e tempi di lavorazione",
        "Le scorte inventario vengono scalate automaticamente"
      ],
      time: "8 minuti"
    },
    {
      number: 5,
      title: "Etichette QR",
      icon: QrCode,
      description: "Genera etichette QR per la tracciabilità pubblica",
      details: [
        "Dalla sezione 'Etichette QR', seleziona il lotto creato",
        "Il sistema genera automaticamente il QR code",
        "Scarica l'etichetta in formato PNG ad alta risoluzione",
        "Stampa e applica l'etichetta sui prodotti",
        "I consumatori potranno scansionare per vedere la tracciabilità"
      ],
      tips: [
        "Le etichette includono automaticamente tutti i dati del lotto",
        "Puoi personalizzare il design con il logo aziendale",
        "I QR code sono ottimizzati per la scansione da smartphone"
      ],
      time: "5 minuti"
    },
    {
      number: 6,
      title: "Dashboard e Report",
      icon: BarChart3,
      description: "Monitora la produzione con dashboard e statistiche",
      details: [
        "La dashboard mostra panoramica di ricette, lotti e inventario",
        "Visualizza grafici di produzione mensile e costi",
        "Monitora alert di scorte basse e scadenze",
        "Esporta report in PDF per analisi dettagliate",
        "Configura backup automatici per proteggere i dati"
      ],
      tips: [
        "Controlla giornalmente gli alert per ottimizzare la produzione",
        "I backup vengono creati automaticamente ogni 6 ore",
        "Usa i grafici per identificare trend e stagionalità"
      ],
      time: "Continuo"
    }
  ];

  const bestPractices = [
    {
      title: "Organizzazione Dati",
      points: [
        "Usa nomenclature coerenti per ricette e ingredienti",
        "Mantieni aggiornati costi e fornitori",
        "Registra sempre temperature e tempi di lavorazione",
        "Crea backup manuali prima di modifiche importanti"
      ]
    },
    {
      title: "Tracciabilità Efficace",
      points: [
        "Registra ogni fase di lavorazione nei lotti",
        "Annota eventuali variazioni dalle ricette standard",
        "Mantieni foto e documenti di qualità collegati",
        "Verifica regolarmente i QR code stampati"
      ]
    },
    {
      title: "Gestione Scorte",
      points: [
        "Controlla settimanalmente lo stato inventario",
        "Programma ordini in base ai consumi storici",
        "Verifica scadenze ingredienti prima della produzione",
        "Ottimizza le scorte per ridurre sprechi e costi"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/documentation">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Documentazione
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Inizia Ora
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Guida Rapida
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Inizia subito con AgroTrace Pro seguendo questi semplici passaggi
          </p>
          <div className="mt-6">
            <Badge variant="secondary" className="bg-green-100 text-green-800 px-4 py-2">
              Tempo totale stimato: 45 minuti
            </Badge>
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-8">
          {steps.map((step, index) => (
            <Card key={step.number} className="border-2 border-green-200 dark:border-green-800">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    {step.number}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2">
                      <step.icon className="w-6 h-6 text-green-600" />
                      {step.title}
                    </CardTitle>
                    <p className="text-gray-600 dark:text-gray-300">{step.description}</p>
                  </div>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {step.time}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 text-gray-900 dark:text-white">Passaggi Dettagliati:</h4>
                    <ol className="space-y-2">
                      {step.details.map((detail, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{detail}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3 text-gray-900 dark:text-white">Suggerimenti Utili:</h4>
                    <ul className="space-y-2">
                      {step.tips.map((tip, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-sm text-gray-600 dark:text-gray-400">{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Best Practices */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Best Practices
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {bestPractices.map((practice, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-lg">{practice.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {practice.points.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{point}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Pronto per Iniziare?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Segui questa guida passo-passo e avrai il sistema operativo in meno di un'ora
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                Inizia la Configurazione
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/documentation">
              <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                Altre Guide
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}