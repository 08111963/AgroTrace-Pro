import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Database, Shield, Clock, Download, RefreshCw, AlertTriangle } from "lucide-react";
import { Link } from "wouter";

export default function BackupInfoPage() {
  const backupFeatures = [
    {
      icon: Clock,
      title: "Backup Automatici",
      description: "Il sistema crea automaticamente backup completi ogni 6 ore",
      details: [
        "Backup programmati senza intervento manuale",
        "Esecuzione durante orari di minor carico",
        "Verifica automatica dell'integrità dei backup",
        "Notifica in caso di errori"
      ]
    },
    {
      icon: Database,
      title: "Backup Completi",
      description: "Tutti i dati vengono salvati: ricette, lotti, inventario, utenti",
      details: [
        "Database PostgreSQL completo",
        "Struttura tabelle e relazioni",
        "Dati di configurazione sistema",
        "Cronologia e log delle attività"
      ]
    },
    {
      icon: RefreshCw,
      title: "Conservazione",
      description: "Manteniamo gli ultimi 30 backup per massima sicurezza",
      details: [
        "30 backup storici sempre disponibili",
        "Rimozione automatica backup obsoleti",
        "Spazio ottimizzato con compressione",
        "Accesso rapido ai backup recenti"
      ]
    },
    {
      icon: Download,
      title: "Backup Manuali",
      description: "Puoi creare backup aggiuntivi quando necessario",
      details: [
        "Backup prima di aggiornamenti importanti",
        "Backup prima di modifiche massive",
        "Download locale per sicurezza extra",
        "Nessun limite al numero di backup manuali"
      ]
    }
  ];

  const securityMeasures = [
    {
      title: "Crittografia",
      description: "Tutti i backup sono crittografati con algoritmi AES-256"
    },
    {
      title: "Archiviazione Sicura",
      description: "Backup salvati su storage ridondante con protezione geografica"
    },
    {
      title: "Accesso Controllato",
      description: "Solo personale autorizzato può accedere ai sistemi di backup"
    },
    {
      title: "Test Periodici",
      description: "Verifichiamo regolarmente l'integrità e la ripristinabilità"
    }
  ];

  const restoreProcess = [
    {
      step: 1,
      title: "Identificazione Backup",
      description: "Selezione del backup da ripristinare dalla lista disponibile"
    },
    {
      step: 2,
      title: "Verifica Integrità",
      description: "Controllo automatico dell'integrità del file di backup"
    },
    {
      step: 3,
      title: "Ripristino Database",
      description: "Ripristino completo del database con tutti i dati"
    },
    {
      step: 4,
      title: "Verifica Funzionalità",
      description: "Test completo del sistema per confermare il successo"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/documentation">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Documentazione
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Inizia Ora
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-6">
            <Database className="w-8 h-8 text-blue-600 dark:text-blue-400" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Backup e Sicurezza
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Sistema completo di backup automatici per proteggere i tuoi dati aziendali
          </p>
          
          <div className="flex justify-center gap-4 mb-8">
            <Badge variant="secondary" className="bg-green-100 text-green-800 px-4 py-2">
              <Shield className="w-4 h-4 mr-2" />
              GDPR Compliant
            </Badge>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 px-4 py-2">
              <Database className="w-4 h-4 mr-2" />
              Backup ogni 6 ore
            </Badge>
          </div>
        </div>

        {/* Backup Features */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {backupFeatures.map((feature, index) => (
            <Card key={index} className="border-2 border-blue-200 dark:border-blue-800">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                    <feature.icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                    <p className="text-gray-600 dark:text-gray-300 text-sm">{feature.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {feature.details.map((detail, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-sm text-gray-700 dark:text-gray-300">{detail}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Security Measures */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Misure di Sicurezza
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {securityMeasures.map((measure, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-center text-lg">{measure.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-gray-600 dark:text-gray-300 text-sm">
                    {measure.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Restore Process */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Processo di Ripristino
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {restoreProcess.map((process, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-lg">
                    {process.step}
                  </div>
                  <CardTitle className="text-lg">{process.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">
                    {process.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Emergency Info */}
        <Card className="border-2 border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-900/20 mb-16">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
              Procedura di Emergenza
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">In Caso di Problemi:</h4>
                <ul className="space-y-2 text-sm">
                  <li>• Contatta immediatamente il supporto tecnico</li>
                  <li>• Descrivi dettagliatamente il problema riscontrato</li>
                  <li>• Indica l'ultimo backup disponibile che funzionava</li>
                  <li>• Non tentare operazioni di ripristino autonome</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Tempo di Ripristino:</h4>
                <ul className="space-y-2 text-sm">
                  <li>• Ripristino standard: 15-30 minuti</li>
                  <li>• Grandi volumi di dati: 1-2 ore</li>
                  <li>• Verifica completa: 30 minuti aggiuntivi</li>
                  <li>• Supporto disponibile 24/7 per emergenze</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Best Practices */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Best Practices
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Raccomandazioni Generali</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Crea backup manuali prima di modifiche importanti</li>
                  <li>• Verifica periodicamente la dashboard backup</li>
                  <li>• Mantieni aggiornati i contatti di emergenza</li>
                  <li>• Documenta le operazioni critiche</li>
                  <li>• Testa periodicamente i download di backup</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Monitoraggio</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Controlla gli alert di backup nella dashboard</li>
                  <li>• Verifica che i backup automatici funzionino</li>
                  <li>• Monitora lo spazio di archiviazione utilizzato</li>
                  <li>• Rivedi periodicamente la lista backup disponibili</li>
                  <li>• Aggiorna le procedure in caso di cambiamenti</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Proteggi i Tuoi Dati Aziendali
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Con AgroTrace Pro i tuoi dati sono sempre al sicuro grazie ai backup automatici
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                Inizia la Prova Gratuita
              </Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                Contatta il Supporto
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}