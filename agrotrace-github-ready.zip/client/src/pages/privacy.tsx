import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Shield, Lock, Eye, Database } from "lucide-react";
import { Link } from "wouter";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Accedi
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Privacy Policy
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            La tua privacy è importante per noi. Scopri come proteggiamo i tuoi dati.
          </p>
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <CardTitle>Raccolta dei Dati</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                Raccogliamo solo i dati necessari per fornire il servizio di tracciabilità agroalimentare:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-300">
                <li>Dati di registrazione dell'azienda (ragione sociale, P.IVA, indirizzo)</li>
                <li>Informazioni sui prodotti e ricette</li>
                <li>Dati di produzione e lotti</li>
                <li>Informazioni di inventario e magazzino</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <Lock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle>Sicurezza dei Dati</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                Implementiamo misure di sicurezza avanzate per proteggere i tuoi dati:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-300">
                <li>Crittografia SSL/TLS per tutte le comunicazioni</li>
                <li>Database PostgreSQL con backup automatici</li>
                <li>Autenticazione sicura con sessioni crittografate</li>
                <li>Accesso limitato ai dati solo al personale autorizzato</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                  <Eye className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
                <CardTitle>Utilizzo dei Dati</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                Utilizziamo i tuoi dati esclusivamente per:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-300">
                <li>Fornire il servizio di tracciabilità agroalimentare</li>
                <li>Generare report e analisi per la tua azienda</li>
                <li>Migliorare la qualità del servizio</li>
                <li>Comunicazioni relative al servizio</li>
              </ul>
              <p className="text-gray-600 dark:text-gray-300 font-medium">
                Non condividiamo mai i tuoi dati con terze parti senza il tuo consenso esplicito.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                  <Database className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                </div>
                <CardTitle>I Tuoi Diritti</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                In conformità al GDPR, hai diritto a:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-300">
                <li>Accedere ai tuoi dati personali</li>
                <li>Rettificare dati inesatti o incompleti</li>
                <li>Cancellare i tuoi dati (diritto all'oblio)</li>
                <li>Limitare il trattamento dei dati</li>
                <li>Portabilità dei dati</li>
                <li>Opporti al trattamento</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contatti</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Per qualsiasi domanda sulla privacy o per esercitare i tuoi diritti, contattaci a:
              </p>
              <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="font-medium">Email: privacy@agrotrace.pro</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Risponderemo entro 30 giorni dalla ricezione della richiesta.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Ultimo aggiornamento: Gennaio 2024
          </p>
        </div>
      </div>
    </div>
  );
}