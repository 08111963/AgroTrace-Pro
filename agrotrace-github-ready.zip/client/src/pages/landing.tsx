import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Leaf, 
  QrCode, 
  BarChart3, 
  Shield, 
  Package, 
  ClipboardList,
  ArrowRight,
  CheckCircle,
  Users,
  Globe,
  Star,
  Book,
  Scale
} from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 agricultural-gradient rounded-xl flex items-center justify-center text-white font-bold">
                <Leaf className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">AgroTrace Pro</h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">Tracciabilità Agroalimentare</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/login">
                <Button variant="outline" className="hidden sm:inline-flex">
                  Accedi
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-green-600 hover:bg-green-700">
                  Inizia Ora
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Key Features Highlight */}
      <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="flex items-center justify-center gap-3">
              <QrCode className="w-8 h-8 text-green-600" />
              <div>
                <div className="font-semibold text-gray-900 dark:text-white">Tracciabilità QR</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Codici univoci per ogni lotto</div>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3">
              <BarChart3 className="w-8 h-8 text-blue-600" />
              <div>
                <div className="font-semibold text-gray-900 dark:text-white">Analytics Avanzate</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Reports dettagliati e dashboard</div>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3">
              <Shield className="w-8 h-8 text-purple-600" />
              <div>
                <div className="font-semibold text-gray-900 dark:text-white">Sicurezza Dati</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Backup automatici e crittografia</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative py-2 lg:py-4 bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        {/* Background decorative elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-32 w-80 h-80 bg-green-200 dark:bg-green-900 rounded-full opacity-20 blur-3xl"></div>
          <div className="absolute -bottom-40 -left-32 w-80 h-80 bg-blue-200 dark:bg-blue-900 rounded-full opacity-20 blur-3xl"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="mb-2">
              <Badge variant="secondary" className="mb-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 px-4 py-2">
                <Leaf className="w-4 h-4 mr-2" />
                Sistema Professionale di Tracciabilità
              </Badge>
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-gray-900 dark:text-white mb-2 leading-tight">
              Gestione e{" "}
              <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                Tracciabilità
              </span>
              <br />
              Agroalimentare Completa
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto mb-4 leading-relaxed">
              Sistema avanzato per la gestione di ricette, lotti di produzione, inventario e tracciabilità completa 
              dei prodotti agroalimentari con codici QR e reporting dettagliato.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-4">
              <Link href="/login">
                <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all">
                  Inizia Subito
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="text-lg px-8 py-4 rounded-xl border-2">
                Scopri le Funzionalità
              </Button>
            </div>
            
            {/* Value propositions */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="flex items-center justify-center gap-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg p-4 shadow-sm">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <span className="text-gray-700 dark:text-gray-300 font-medium">Setup Immediato</span>
              </div>
              <div className="flex items-center justify-center gap-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg p-4 shadow-sm">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <span className="text-gray-700 dark:text-gray-300 font-medium">Supporto Completo</span>
              </div>
              <div className="flex items-center justify-center gap-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg p-4 shadow-sm">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <span className="text-gray-700 dark:text-gray-300 font-medium">Sicurezza Garantita</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white/50 dark:bg-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Funzionalità Complete
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Tutto ciò che serve per gestire la tua produzione agroalimentare con tracciabilità completa
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Gestione Ricette */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mb-4">
                  <ClipboardList className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <CardTitle>Gestione Ricette</CardTitle>
                <CardDescription>
                  Crea e gestisci ricette con ingredienti multipli, calcolo automatico dei costi e gestione allergenni
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Ingredienti e quantità</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Calcolo costi automatico</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Gestione allergenni</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/recipe-example">
                  <Button variant="outline" className="w-full">
                    Vedi Esempio Ricetta
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Documentazione */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                  <Book className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle>Documentazione</CardTitle>
                <CardDescription>
                  Guide complete, FAQ e documentazione API per utilizzare al meglio AgroTrace Pro
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Guida utente</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">FAQ dettagliate</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">API Reference</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/documentation">
                  <Button variant="outline" className="w-full">
                    Documentazione Completa
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Tracciabilità Lotti */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                  <Package className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle>Tracciabilità Lotti</CardTitle>
                <CardDescription>
                  Gestione lotti di produzione con numerazione automatica e tracking completo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Numerazione automatica</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Date produzione/scadenza</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Status tracking</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/batch-example">
                  <Button variant="outline" className="w-full">
                    Vedi Esempio Lotto
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Codici QR */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                  <QrCode className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <CardTitle>Etichette QR</CardTitle>
                <CardDescription>
                  Generazione automatica di etichette QR per tracciabilità completa dei prodotti
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Generazione automatica</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Informazioni complete</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Download e stampa</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/qr-example">
                  <Button variant="outline" className="w-full">
                    Vedi Esempio Etichetta QR
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Gestione Inventario */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center mb-4">
                  <Package className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                </div>
                <CardTitle>Gestione Inventario</CardTitle>
                <CardDescription>
                  Controllo scorte con alert automatici e gestione fornitori
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Alert scorte basse</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Gestione fornitori</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Tracking movimenti</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/inventory-example">
                  <Button variant="outline" className="w-full">
                    Vedi Esempio Inventario
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Sicurezza */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
                <CardTitle>Sicurezza</CardTitle>
                <CardDescription>
                  Sistema di autenticazione sicuro con gestione utenti e permessi
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Login sicuro</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Gestione sessioni</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Database PostgreSQL</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/backup-info">
                  <Button variant="outline" className="w-full">
                    Sicurezza e Backup
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Controlli Qualità */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                  <Scale className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <CardTitle>Controlli Qualità</CardTitle>
                <CardDescription>
                  Sistema completo per controlli qualità con parametri reali industria agroalimentare
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">pH, Brix, Temperatura</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Viscosità e Colore</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Parametri personalizzati</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/quality-control-example">
                  <Button variant="outline" className="w-full">
                    Vedi Esempio Controlli
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Reporting */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-teal-100 dark:bg-teal-900 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-teal-600 dark:text-teal-400" />
                </div>
                <CardTitle>Reporting Avanzato</CardTitle>
                <CardDescription>
                  Dashboard con KPI, grafici e report dettagliati per il controllo aziendale
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Dashboard KPI</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Grafici interattivi</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm">Export dati</span>
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link href="/documentation">
                  <Button variant="outline" className="w-full">
                    FAQ e Supporto
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </Card>


          </div>
        </div>
      </section>

      {/* Security Section */}
      <section id="security" className="py-20 bg-green-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Sicurezza e Affidabilità
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              I tuoi dati sono protetti con i più alti standard di sicurezza
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <CardTitle>Protezione Dati</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  Tutti i tuoi dati sono protetti durante il trasferimento e nessuno può intercettarli o leggerli.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                  <Package className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle>Backup Automatici</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  Backup automatici ogni 6 ore del database completo, con possibilità di ripristino immediato dei dati.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <CardTitle>Conformità GDPR</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300">
                  Piena conformità alle normative europee sulla protezione dei dati personali e aziendali.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">500+</h3>
              <p className="text-gray-600 dark:text-gray-300">Aziende Agroalimentari</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">25+</h3>
              <p className="text-gray-600 dark:text-gray-300">Paesi nel Mondo</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-yellow-100 dark:bg-yellow-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
              </div>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">99.9%</h3>
              <p className="text-gray-600 dark:text-gray-300">Uptime Garantito</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Piani Tariffari
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Scegli il piano più adatto alle esigenze della tua azienda agroalimentare
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 border-gray-200 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="text-center">Starter</CardTitle>
                <div className="text-center">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">€29</span>
                  <span className="text-gray-600 dark:text-gray-400">/mese</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Fino a 50 ricette</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>100 lotti/mese</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Etichette QR illimitate</span>
                  </li>
                </ul>
                <Link href="/login">
                  <Button className="w-full mt-6" variant="outline">
                    Inizia Gratis
                  </Button>
                </Link>
              </CardContent>
            </Card>
            
            <Card className="border-2 border-green-500 relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-green-600 text-white">Più Popolare</Badge>
              </div>
              <CardHeader>
                <CardTitle className="text-center">Professional</CardTitle>
                <div className="text-center">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">€79</span>
                  <span className="text-gray-600 dark:text-gray-400">/mese</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Ricette illimitate</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>1000 lotti/mese</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Analytics avanzati</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>API completa</span>
                  </li>
                </ul>
                <Link href="/login">
                  <Button className="w-full mt-6 bg-green-600 hover:bg-green-700">
                    Inizia Ora
                  </Button>
                </Link>
              </CardContent>
            </Card>
            
            <Card className="border-2 border-gray-200 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="text-center">Enterprise</CardTitle>
                <div className="text-center">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">Custom</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Tutto incluso</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Supporto dedicato</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Connessione con altri software</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Assistenza prioritaria 24/7</span>
                  </li>
                </ul>
                <Link href="/contact">
                  <Button className="w-full mt-6" variant="outline">
                    Contattaci
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600 dark:bg-green-700">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Pronto per la Tracciabilità Completa?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Inizia subito a gestire la tua produzione agroalimentare con il sistema più avanzato del mercato
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" variant="secondary" className="text-lg px-8">
                Registrati Gratuitamente
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 dark:bg-gray-950 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 agricultural-gradient rounded-lg flex items-center justify-center text-white font-bold">
                  <Leaf className="w-5 h-5" />
                </div>
                <span className="text-lg font-bold">AgroTrace Pro</span>
              </div>
              <p className="text-gray-400">
                La soluzione completa per la tracciabilità agroalimentare professionale.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Prodotto</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#features" className="hover:text-white transition-colors cursor-pointer">Funzionalità</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors cursor-pointer">Prezzi</a></li>
                <li><a href="#security" className="hover:text-white transition-colors cursor-pointer">Sicurezza</a></li>
                <li><Link href="/documentation" className="hover:text-white transition-colors">Aggiornamenti</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Supporto</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/documentation" className="hover:text-white transition-colors">Documentazione</Link></li>
                <li><Link href="/documentation" className="hover:text-white transition-colors">Guide</Link></li>
                <li><Link href="/documentation" className="hover:text-white transition-colors">FAQ</Link></li>
                <li><Link href="/contact" className="hover:text-white transition-colors">Contatti</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Azienda</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/about" className="hover:text-white transition-colors">Chi siamo</Link></li>
                <li><Link href="/contact" className="hover:text-white transition-colors">Carriere</Link></li>
                <li><Link href="/privacy" className="hover:text-white transition-colors">Privacy</Link></li>
                <li><Link href="/terms" className="hover:text-white transition-colors">Termini</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 AgroTrace Pro. Tutti i diritti riservati.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}