import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Package, AlertTriangle, TrendingDown, TrendingUp, Calendar, Truck } from "lucide-react";
import { Link } from "wouter";
import { useEffect } from "react";

export default function InventoryExamplePage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const inventoryItems = [
    {
      name: "Pomodori San Marzano DOP",
      code: "PM-001",
      currentStock: 150,
      minStock: 200,
      maxStock: 500,
      unit: "kg",
      cost: 3.00,
      supplier: "Az. Agricola Rossi",
      lastRestock: "2024-06-08",
      nextDelivery: "2024-06-15",
      status: "Scorta bassa",
      category: "Materie Prime",
      expiryDate: "2024-08-15"
    },
    {
      name: "Sale marino fino",
      code: "SM-002",
      currentStock: 45,
      minStock: 20,
      maxStock: 100,
      unit: "kg",
      cost: 0.80,
      supplier: "Saline di Trapani",
      lastRestock: "2024-06-05",
      nextDelivery: "2024-07-01",
      status: "Disponibile",
      category: "Condimenti",
      expiryDate: "2025-12-31"
    },
    {
      name: "Basilico fresco",
      code: "BF-003",
      currentStock: 3,
      minStock: 5,
      maxStock: 15,
      unit: "kg",
      cost: 12.50,
      supplier: "Serra Verde Bio",
      lastRestock: "2024-06-10",
      nextDelivery: "2024-06-13",
      status: "Urgente",
      category: "Erbe Aromatiche",
      expiryDate: "2024-06-18"
    },
    {
      name: "Barattoli vetro 500ml",
      code: "BV-004",
      currentStock: 1200,
      minStock: 500,
      maxStock: 2000,
      unit: "pz",
      cost: 0.45,
      supplier: "Vetreria Italiana",
      lastRestock: "2024-06-01",
      nextDelivery: "2024-06-20",
      status: "Disponibile",
      category: "Packaging",
      expiryDate: null
    },
    {
      name: "Etichette adesive",
      code: "EA-005",
      currentStock: 2500,
      minStock: 1000,
      maxStock: 5000,
      unit: "pz",
      cost: 0.02,
      supplier: "Stampa Pro",
      lastRestock: "2024-05-28",
      nextDelivery: "2024-06-25",
      status: "Disponibile",
      category: "Packaging",
      expiryDate: null
    }
  ];

  const alerts = [
    {
      type: "urgent",
      message: "Basilico fresco sotto scorta minima (3kg < 5kg)",
      item: "Basilico fresco",
      action: "Ordinare immediatamente"
    },
    {
      type: "warning",
      message: "Pomodori San Marzano in esaurimento (150kg < 200kg)",
      item: "Pomodori San Marzano DOP",
      action: "Programmare ordine"
    },
    {
      type: "expiry",
      message: "Basilico fresco scade tra 7 giorni",
      item: "Basilico fresco",
      action: "Utilizzare prioritariamente"
    }
  ];

  const movements = [
    {
      date: "2024-06-11",
      item: "Pomodori San Marzano DOP",
      type: "Uscita",
      quantity: -50,
      unit: "kg",
      reason: "Produzione lotto BT-240611-001",
      operator: "M. Bianchi"
    },
    {
      date: "2024-06-10",
      item: "Basilico fresco",
      type: "Entrata",
      quantity: +8,
      unit: "kg",
      reason: "Consegna fornitore",
      operator: "G. Verdi"
    },
    {
      date: "2024-06-10",
      item: "Barattoli vetro 500ml",
      type: "Uscita",
      quantity: -48,
      unit: "pz",
      reason: "Produzione lotto BT-240611-001",
      operator: "L. Neri"
    },
    {
      date: "2024-06-09",
      item: "Sale marino fino",
      type: "Uscita",
      quantity: -2.4,
      unit: "kg",
      reason: "Produzione lotto BT-240611-001",
      operator: "M. Bianchi"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Urgente": return "bg-red-100 text-red-800";
      case "Scorta bassa": return "bg-yellow-100 text-yellow-800";
      case "Disponibile": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStockPercentage = (current: number, min: number, max: number) => {
    return ((current - min) / (max - min)) * 100;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Inizia Ora
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Esempio Gestione Inventario
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Sistema completo per il controllo scorte con alert automatici e tracking fornitori
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Alerts */}
            <Card className="border-2 border-red-200 dark:border-red-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                  Alert Scorte
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {alerts.map((alert, index) => (
                    <div key={index} className={`p-4 rounded-lg ${
                      alert.type === 'urgent' ? 'bg-red-50 border-l-4 border-red-500' :
                      alert.type === 'warning' ? 'bg-yellow-50 border-l-4 border-yellow-500' :
                      'bg-blue-50 border-l-4 border-blue-500'
                    }`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium text-gray-900">{alert.message}</div>
                          <div className="text-sm text-gray-600 mt-1">Azione: {alert.action}</div>
                        </div>
                        <Badge variant="outline" className={
                          alert.type === 'urgent' ? 'border-red-500 text-red-700' :
                          alert.type === 'warning' ? 'border-yellow-500 text-yellow-700' :
                          'border-blue-500 text-blue-700'
                        }>
                          {alert.type === 'urgent' ? 'URGENTE' : alert.type === 'warning' ? 'ATTENZIONE' : 'SCADENZA'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Inventory Items */}
            <Card>
              <CardHeader>
                <CardTitle>Inventario Completo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {inventoryItems.map((item, index) => (
                    <div key={index} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-gray-500">Codice: {item.code} • {item.category}</div>
                        </div>
                        <div className="text-right">
                          <Badge className={getStatusColor(item.status)}>
                            {item.status}
                          </Badge>
                          <div className="text-sm text-gray-500 mt-1">€{item.cost}/{item.unit}</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mb-3">
                        <div className="text-center">
                          <div className="text-sm text-gray-500">Scorta Attuale</div>
                          <div className="text-lg font-bold">{item.currentStock} {item.unit}</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm text-gray-500">Minimo</div>
                          <div className="text-lg font-bold text-orange-600">{item.minStock} {item.unit}</div>
                        </div>
                        <div className="text-center">
                          <div className="text-sm text-gray-500">Massimo</div>
                          <div className="text-lg font-bold text-blue-600">{item.maxStock} {item.unit}</div>
                        </div>
                      </div>

                      <Progress 
                        value={getStockPercentage(item.currentStock, item.minStock, item.maxStock)} 
                        className="mb-3"
                      />

                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>
                          <div>Fornitore: {item.supplier}</div>
                          <div>Ultimo rifornimento: {new Date(item.lastRestock).toLocaleDateString('it-IT')}</div>
                        </div>
                        <div>
                          <div>Prossima consegna: {new Date(item.nextDelivery).toLocaleDateString('it-IT')}</div>
                          {item.expiryDate && (
                            <div>Scadenza: {new Date(item.expiryDate).toLocaleDateString('it-IT')}</div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Movements */}
            <Card>
              <CardHeader>
                <CardTitle>Movimenti Recenti</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {movements.map((movement, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          movement.type === 'Entrata' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                        }`}>
                          {movement.type === 'Entrata' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="font-medium">{movement.item}</div>
                          <div className="text-sm text-gray-500">{movement.reason}</div>
                          <div className="text-xs text-gray-400">Operatore: {movement.operator}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-bold ${movement.quantity > 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {movement.quantity > 0 ? '+' : ''}{movement.quantity} {movement.unit}
                        </div>
                        <div className="text-sm text-gray-500">{new Date(movement.date).toLocaleDateString('it-IT')}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Summary Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Statistiche Inventario</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-red-600" />
                    <div className="text-2xl font-bold text-red-600">2</div>
                    <div className="text-sm text-red-600">Articoli sotto scorta</div>
                  </div>
                  <div className="text-center p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <Calendar className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
                    <div className="text-2xl font-bold text-yellow-600">1</div>
                    <div className="text-sm text-yellow-600">Prossimo alla scadenza</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <Package className="w-8 h-8 mx-auto mb-2 text-green-600" />
                    <div className="text-2xl font-bold text-green-600">5</div>
                    <div className="text-sm text-green-600">Articoli totali</div>
                  </div>
                  <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <Truck className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                    <div className="text-2xl font-bold text-blue-600">3</div>
                    <div className="text-sm text-blue-600">Consegne programmate</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle>Categorie</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Materie Prime</span>
                    <Badge variant="outline">1</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Condimenti</span>
                    <Badge variant="outline">1</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Erbe Aromatiche</span>
                    <Badge variant="outline">1</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Packaging</span>
                    <Badge variant="outline">2</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle>Funzionalità Inventario</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Alert automatici scorte basse
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Tracking scadenze prodotti
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Gestione fornitori integrata
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Storico movimenti completo
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Calcolo automatico riordini
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Controllo Completo del Tuo Inventario
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Mai più scorte vuote o sprechi con il sistema di alert automatici
          </p>
          <Link href="/login">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
              Inizia la Prova Gratuita
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}