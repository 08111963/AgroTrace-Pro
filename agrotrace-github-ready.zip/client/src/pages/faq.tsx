import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ArrowLeft, ChevronDown, HelpCircle, Search, User, ClipboardList, Package2, QrCode, Shield, CreditCard } from "lucide-react";
import { Link } from "wouter";
import { useState, useEffect } from "react";

export default function FAQPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [openItems, setOpenItems] = useState<string[]>([]);

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const toggleItem = (id: string) => {
    setOpenItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const faqCategories = [
    {
      id: "account",
      title: "Account e Registrazione",
      icon: User,
      color: "bg-blue-100 text-blue-800",
      questions: [
        {
          id: "registration",
          question: "Come mi registro su AgroTrace Pro?",
          answer: "Clicca su 'Inizia Ora' dalla homepage, compila il modulo con i tuoi dati aziendali, verifica l'email ricevuta e accedi con le credenziali create. Hai 7 giorni di prova gratuita completa."
        },
        {
          id: "trial",
          question: "Cosa include la prova gratuita di 7 giorni?",
          answer: "La prova include accesso completo a tutte le funzionalità: ricette illimitate, lotti di produzione, inventario, QR code, dashboard e backup. Nessuna limitazione durante il periodo di prova."
        },
        {
          id: "forgot-password",
          question: "Ho dimenticato la password, come posso recuperarla?",
          answer: "Clicca su 'Password dimenticata?' nella pagina di login, inserisci la tua email e riceverai un link per reimpostare la password. Il link è valido per 1 ora."
        },
        {
          id: "company-profile",
          question: "Perché è importante completare il profilo aziendale?",
          answer: "Il profilo aziendale appare sulle etichette QR pubbliche e garantisce la trasparenza ai consumatori. Include ragione sociale, partita IVA, indirizzo e contatti."
        },
        {
          id: "subscription",
          question: "Come funziona l'abbonamento dopo la prova?",
          answer: "Dopo 7 giorni puoi scegliere tra i piani Basic (€29/mese) o Professional (€59/mese). Il pagamento si rinnova automaticamente ma puoi cancellare in qualsiasi momento."
        }
      ]
    },
    {
      id: "recipes",
      title: "Gestione Ricette",
      icon: ClipboardList,
      color: "bg-green-100 text-green-800",
      questions: [
        {
          id: "create-recipe",
          question: "Come creo la mia prima ricetta?",
          answer: "Vai in 'Ricette' > 'Nuova Ricetta', inserisci nome e descrizione, aggiungi ingredienti con quantità e unità di misura. Il sistema calcolerà automaticamente costi e valori nutrizionali."
        },
        {
          id: "ingredient-costs",
          question: "Come vengono calcolati i costi degli ingredienti?",
          answer: "I costi si basano sui prezzi inseriti nell'inventario. Il sistema moltiplica quantità × costo unitario per ogni ingrediente e somma il totale della ricetta."
        },
        {
          id: "nutritional-values",
          question: "I valori nutrizionali sono accurati?",
          answer: "Sì, utilizziamo il database nutrizionale italiano ufficiale CREA. I valori sono calcolati automaticamente in base agli ingredienti e alle quantità della ricetta."
        },
        {
          id: "recipe-scaling",
          question: "Posso modificare le quantità per più porzioni?",
          answer: "Assolutamente. Inserisci il numero di porzioni desiderato e il sistema ricalcolerà automaticamente tutte le quantità mantenendo le proporzioni originali."
        },
        {
          id: "allergens",
          question: "Come gestisco gli allergeni nelle ricette?",
          answer: "Gli allergeni vengono rilevati automaticamente in base agli ingredienti. Puoi aggiungere note specifiche e il sistema li mostrerà nelle etichette QR."
        }
      ]
    },
    {
      id: "batches",
      title: "Lotti di Produzione",
      icon: Package2,
      color: "bg-purple-100 text-purple-800",
      questions: [
        {
          id: "create-batch",
          question: "Come creo un lotto di produzione?",
          answer: "Vai in 'Lotti' > 'Nuovo Lotto', seleziona la ricetta, inserisci quantità da produrre e date. Il sistema genera automaticamente il codice lotto nel formato BT-AAMMGG-XXX."
        },
        {
          id: "batch-tracking",
          question: "Cosa significa tracciabilità completa del lotto?",
          answer: "Ogni lotto registra: ingredienti utilizzati con lotti fornitori, fasi di lavorazione, temperature, tempi, operatori, controlli qualità e distribuzione finale."
        },
        {
          id: "inventory-update",
          question: "Le scorte si aggiornano automaticamente?",
          answer: "Sì, quando crei un lotto le quantità degli ingredienti vengono automaticamente scalate dall'inventario. Riceverai alert se le scorte sono insufficienti."
        },
        {
          id: "batch-status",
          question: "Quali sono gli stati di un lotto?",
          answer: "Un lotto può essere: Pianificato, In Produzione, Completato, In Distribuzione, Venduto. Puoi aggiornare lo stato per tenere traccia del ciclo produttivo."
        },
        {
          id: "expiry-tracking",
          question: "Come gestisco le date di scadenza?",
          answer: "Inserisci la data di scadenza alla creazione del lotto. Il sistema calcolerà automaticamente la shelf-life e ti avviserà quando si avvicina la scadenza."
        }
      ]
    },
    {
      id: "inventory",
      title: "Gestione Inventario",
      icon: Package2,
      color: "bg-orange-100 text-orange-800",
      questions: [
        {
          id: "add-ingredient",
          question: "Come aggiungo ingredienti all'inventario?",
          answer: "Vai in 'Inventario' > 'Nuovo Articolo', inserisci nome, codice, scorte attuali, minime/massime, fornitore e costo. Il sistema monitorerà automaticamente le scorte."
        },
        {
          id: "stock-alerts",
          question: "Come funzionano gli alert di scorte basse?",
          answer: "Quando le scorte scendono sotto il minimo impostato, ricevi notifiche automatiche nella dashboard e via email. Puoi personalizzare le soglie per ogni ingrediente."
        },
        {
          id: "supplier-management",
          question: "Posso gestire più fornitori per lo stesso ingrediente?",
          answer: "Attualmente ogni ingrediente ha un fornitore principale. Puoi aggiornare il fornitore quando necessario e tenere uno storico nei movimenti di inventario."
        },
        {
          id: "inventory-movements",
          question: "Come vengono registrati i movimenti di inventario?",
          answer: "Ogni entrata/uscita è registrata automaticamente con data, quantità, motivo e operatore. I movimenti includono: carichi, scarichi produzione, vendite e correzioni."
        },
        {
          id: "stock-count",
          question: "Come eseguo un inventario fisico?",
          answer: "Puoi fare correzioni manuali inserendo la quantità reale. Il sistema registrerà la differenza come movimento di inventario con causale 'Inventario fisico'."
        }
      ]
    },
    {
      id: "qr-codes",
      title: "Etichette QR",
      icon: QrCode,
      color: "bg-red-100 text-red-800",
      questions: [
        {
          id: "generate-qr",
          question: "Come genero un'etichetta QR per un lotto?",
          answer: "Vai in 'Etichette QR', seleziona il lotto desiderato e clicca 'Genera QR'. L'etichetta conterrà automaticamente tutte le informazioni di tracciabilità."
        },
        {
          id: "qr-content",
          question: "Cosa vedono i consumatori scansionando il QR?",
          answer: "I consumatori vedono: nome prodotto, ingredienti, allergeni, valori nutrizionali, data produzione/scadenza, informazioni produttore e certificazioni."
        },
        {
          id: "qr-customization",
          question: "Posso personalizzare l'aspetto delle etichette?",
          answer: "L'etichetta include automaticamente il logo aziendale dal profilo. Puoi scaricare il QR in PNG ad alta risoluzione per stampa professionale."
        },
        {
          id: "qr-tracking",
          question: "Posso vedere quante volte è stato scansionato un QR?",
          answer: "Attualmente il sistema non traccia le scansioni per privacy dei consumatori. Il QR porta a una pagina pubblica con le informazioni del prodotto."
        },
        {
          id: "qr-printing",
          question: "Su che materiali posso stampare i QR code?",
          answer: "I QR sono ottimizzati per stampa su etichette adesive, cartone, plastica. Usa almeno 2x2 cm di dimensione per garantire la scansione da smartphone."
        }
      ]
    },
    {
      id: "technical",
      title: "Aspetti Tecnici",
      icon: Shield,
      color: "bg-gray-100 text-gray-800",
      questions: [
        {
          id: "data-security",
          question: "I miei dati sono sicuri?",
          answer: "Sì, utilizziamo database PostgreSQL crittografato, backup automatici ogni 6 ore, connessioni HTTPS e autenticazione sicura. I tuoi dati sono protetti secondo gli standard GDPR."
        },
        {
          id: "backup-restore",
          question: "Come funzionano i backup automatici?",
          answer: "Il sistema crea backup completi ogni 6 ore, mantenendo gli ultimi 30 backup. Puoi anche creare backup manuali prima di operazioni importanti."
        },
        {
          id: "data-export",
          question: "Posso esportare i miei dati?",
          answer: "Sì, puoi esportare report in PDF e dati in CSV. I backup completi sono disponibili su richiesta per la portabilità dei dati."
        },
        {
          id: "browser-compatibility",
          question: "Che browser supportate?",
          answer: "AgroTrace Pro funziona su tutti i browser moderni: Chrome, Firefox, Safari, Edge. Consigliamo di mantenere il browser aggiornato per prestazioni ottimali."
        },
        {
          id: "mobile-access",
          question: "Posso usare il sistema da smartphone?",
          answer: "Sì, l'interfaccia è completamente responsive. Puoi accedere da smartphone/tablet per consultazioni, anche se raccomandiamo il desktop per operazioni complesse."
        }
      ]
    },
    {
      id: "billing",
      title: "Fatturazione e Piani",
      icon: CreditCard,
      color: "bg-yellow-100 text-yellow-800",
      questions: [
        {
          id: "payment-methods",
          question: "Quali metodi di pagamento accettate?",
          answer: "Accettiamo carte di credito/debito Visa, Mastercard, American Express. I pagamenti sono processati in modo sicuro tramite gateway certificati."
        },
        {
          id: "plan-differences",
          question: "Qual è la differenza tra i piani Basic e Professional?",
          answer: "Basic (€29/mese): ricette illimitate, 50 lotti/mese, inventario base. Professional (€59/mese): lotti illimitati, report avanzati, API access, supporto prioritario."
        },
        {
          id: "cancel-subscription",
          question: "Posso cancellare l'abbonamento in qualsiasi momento?",
          answer: "Sì, puoi cancellare dalla sezione Account senza penali. L'accesso continua fino alla fine del periodo già pagato, poi i dati rimangono accessibili in sola lettura."
        },
        {
          id: "invoice-receipt",
          question: "Riceverò fattura per i pagamenti?",
          answer: "Sì, ricevi automaticamente fattura elettronica via email dopo ogni pagamento. Le fatture includono tutti i dati necessari per la contabilità aziendale."
        },
        {
          id: "refund-policy",
          question: "Offrite rimborsi?",
          answer: "Offriamo rimborso completo entro 30 giorni dall'acquisto se non sei soddisfatto del servizio. Contatta il supporto per richiedere il rimborso."
        }
      ]
    }
  ];

  const filteredCategories = faqCategories.map(category => ({
    ...category,
    questions: category.questions.filter(q => 
      q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.answer.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/documentation">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Documentazione
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Inizia Ora
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-6">
            <HelpCircle className="w-8 h-8 text-teal-600 dark:text-teal-400" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Domande Frequenti
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Trova rapidamente le risposte alle domande più comuni su AgroTrace Pro
          </p>

          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Cerca nelle FAQ..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* FAQ Categories */}
        <div className="space-y-8">
          {filteredCategories.map((category) => (
            <Card key={category.id}>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center">
                    <category.icon className="w-5 h-5 text-gray-600" />
                  </div>
                  {category.title}
                  <Badge variant="secondary" className={category.color}>
                    {category.questions.length} domande
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {category.questions.map((faq) => (
                    <Collapsible
                      key={faq.id}
                      open={openItems.includes(faq.id)}
                      onOpenChange={() => toggleItem(faq.id)}
                    >
                      <CollapsibleTrigger asChild>
                        <Button
                          variant="ghost"
                          className="w-full justify-between text-left h-auto p-4 hover:bg-gray-50 dark:hover:bg-gray-800"
                        >
                          <span className="font-medium">{faq.question}</span>
                          <ChevronDown className={`w-4 h-4 transition-transform ${
                            openItems.includes(faq.id) ? 'rotate-180' : ''
                          }`} />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="px-4 pb-4">
                        <div className="text-gray-700 dark:text-gray-300 leading-relaxed">
                          {faq.answer}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCategories.length === 0 && searchTerm && (
          <Card className="text-center py-12">
            <CardContent>
              <HelpCircle className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Nessun risultato trovato
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Non abbiamo trovato domande che corrispondono alla tua ricerca "{searchTerm}".
              </p>
              <Button onClick={() => setSearchTerm("")} variant="outline">
                Cancella ricerca
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Contact Support */}
        <div className="mt-16 text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Non Hai Trovato la Risposta?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Il nostro team di supporto è sempre disponibile per aiutarti
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" variant="outline" className="text-lg px-8 py-3">
                Contatta il Supporto
              </Button>
            </Link>
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                Inizia la Prova Gratuita
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}