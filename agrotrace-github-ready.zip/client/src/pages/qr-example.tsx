import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, QrCode, Download, Printer, Share2, Calendar, MapPin, User, Package, Leaf, Utensils } from "lucide-react";
import { Link } from "wouter";
import QRCodeLib from "qrcode";
import { useEffect, useRef, useState } from "react";

export default function QRExamplePage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [qrGenerated, setQrGenerated] = useState(false);

  const sampleBatch = {
    code: "BT-240611-001",
    productName: "Passata di Pomodoro Bio",
    productionDate: "2024-06-11",
    expiryDate: "2025-06-11",
    batchSize: 48,
    unit: "barattoli 500ml",
    producer: "Az. Agricola Sole del Sud",
    location: "Pachino, Sicilia",
    ingredients: ["Pomodori San Marzano DOP", "Sale marino", "Basilico fresco"],
    certifications: ["Biologico EU", "DOP", "Km Zero"],
    nutritionalInfo: {
      energy: "25 kcal/100g",
      proteins: "1.2g",
      carbs: "4.8g",
      fats: "0.2g"
    }
  };

  const qrUrl = `https://agrotracepro.replit.app/tracciabilita/${sampleBatch.code}`;

  useEffect(() => {
    if (canvasRef.current && !qrGenerated) {
      QRCodeLib.toCanvas(canvasRef.current, qrUrl, {
        width: 200,
        margin: 2,
        color: {
          dark: '#166534',
          light: '#FFFFFF'
        }
      }).then(() => {
        setQrGenerated(true);
      }).catch(err => {
        console.error('Error generating QR code:', err);
      });
    }
  }, [qrUrl, qrGenerated]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Inizia Ora
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Esempio Etichetta QR
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Ecco come apparirà un'etichetta QR generata dal sistema AgroTrace Pro
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* QR Code Display */}
          <Card className="border-2 border-green-200 dark:border-green-800">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <QrCode className="w-6 h-6 text-green-600" />
                Etichetta QR Generata
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="bg-white p-6 rounded-lg mx-auto inline-block shadow-lg">
                <canvas ref={canvasRef} className="mx-auto" />
                <div className="mt-4 text-sm text-gray-600">
                  <div className="font-semibold">{sampleBatch.productName}</div>
                  <div>Lotto: {sampleBatch.code}</div>
                  <div>Scansiona per tracciabilità completa</div>
                </div>
              </div>
              
              <div className="flex gap-2 justify-center">
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Scarica PNG
                </Button>
                <Button variant="outline" size="sm">
                  <Printer className="w-4 h-4 mr-2" />
                  Stampa
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Condividi
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Product Information */}
          <div className="space-y-6">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  Informazioni Prodotto
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-500">Prodotto</div>
                    <div className="font-medium">{sampleBatch.productName}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Lotto</div>
                    <div className="font-medium">{sampleBatch.code}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Produzione</div>
                    <div className="font-medium flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {new Date(sampleBatch.productionDate).toLocaleDateString('it-IT')}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Scadenza</div>
                    <div className="font-medium flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {new Date(sampleBatch.expiryDate).toLocaleDateString('it-IT')}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Producer Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Produttore
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="font-medium">{sampleBatch.producer}</div>
                  <div className="flex items-center gap-1 text-gray-600">
                    <MapPin className="w-4 h-4" />
                    {sampleBatch.location}
                  </div>
                  <div className="text-sm text-gray-500">
                    Quantità lotto: {sampleBatch.batchSize} {sampleBatch.unit}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Ingredients */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Leaf className="w-5 h-5" />
                  Ingredienti
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {sampleBatch.ingredients.map((ingredient, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      {ingredient}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Certifications */}
            <Card>
              <CardHeader>
                <CardTitle>Certificazioni</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {sampleBatch.certifications.map((cert, index) => (
                    <Badge key={index} variant="secondary" className="bg-green-100 text-green-800">
                      {cert}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Nutritional Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Utensils className="w-5 h-5" />
                  Valori Nutrizionali
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-gray-500">Energia</div>
                    <div className="font-medium">{sampleBatch.nutritionalInfo.energy}</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Proteine</div>
                    <div className="font-medium">{sampleBatch.nutritionalInfo.proteins}</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Carboidrati</div>
                    <div className="font-medium">{sampleBatch.nutritionalInfo.carbs}</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Grassi</div>
                    <div className="font-medium">{sampleBatch.nutritionalInfo.fats}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="mt-16 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
            Vantaggi delle Etichette QR
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <QrCode className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Tracciabilità Completa</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Ogni prodotto è completamente tracciabile dalla produzione al consumatore finale
              </p>
            </div>
            <div className="p-6 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <Printer className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Stampa Professionale</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Etichette pronte per la stampa in alta qualità su qualsiasi supporto
              </p>
            </div>
            <div className="p-6 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <Share2 className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Condivisione Facile</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Condividi informazioni dettagliate con clienti e partner commerciali
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Pronto a Iniziare?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Crea le tue etichette QR professionali in pochi minuti
          </p>
          <Link href="/login">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
              Inizia la Prova Gratuita
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}