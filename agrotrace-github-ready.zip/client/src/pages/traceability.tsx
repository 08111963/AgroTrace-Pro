import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useSEO } from "@/hooks/useSEO";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Package, 
  Calendar, 
  Factory, 
  Clock, 
  Users, 
  ShieldCheck,
  AlertCircle,
  CheckCircle,
  MapPin,
  FileDown,
  ChefHat,
  Timer,
  Star,
  PieChart,
  Beaker,
  Thermometer,
  Droplet,
  Eye,
  Scale
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { exportTraceabilityToPDF } from "@/lib/pdf-utils";

const TraceabilityPage = () => {
  const [, params] = useRoute("/tracciabilita/:batchCode");
  const batchCode = params?.batchCode;

  // SEO configuration for traceability page
  useSEO({
    title: `Tracciabilità ${batchCode ? `Lotto ${batchCode}` : ''} - AgroTrace Pro`,
    description: `Informazioni complete di tracciabilità per il lotto ${batchCode || 'selezionato'} con QR code, ingredienti, valori nutrizionali e conformità normative.`,
    keywords: 'tracciabilità lotto, QR code, ingredienti, valori nutrizionali, conformità normative',
    canonical: `https://agrotracepro.replit.app/traceability${batchCode ? `/${batchCode}` : ''}`
  });

  const { data: traceabilityData, isLoading, error } = useQuery<{
    batch: any;
    recipe?: any;
    qrLabel?: any;
    nutritionalValues?: any;
  }>({
    queryKey: [`/api/traceability/${batchCode}`],
    enabled: !!batchCode,
    staleTime: Infinity, // Non considerare mai stale - dati di tracciabilità sono immutabili
    gcTime: 24 * 60 * 60 * 1000, // 24 ore in cache
    retry: false, // No retry per massima velocità
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
            <div className="h-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-48 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !traceabilityData) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
        <div className="max-w-4xl mx-auto text-center py-12">
          <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Prodotto Non Trovato
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Il codice lotto "{batchCode}" non è stato trovato nel sistema di tracciabilità.
          </p>
        </div>
      </div>
    );
  }

  const batch = traceabilityData?.batch;
  const recipe = traceabilityData?.recipe;
  const qrLabel = traceabilityData?.qrLabel;
  const nutritionalValues = traceabilityData?.nutritionalValues;

  return (
    <div className="min-h-screen bg-background p-4 space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-primary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <ShieldCheck className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Tracciabilità Prodotto</h1>
              <p className="text-xl text-white/90">
                Informazioni complete e verificate per il lotto {batchCode}
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {/* Quick Actions */}
        <div className="flex flex-wrap gap-4 justify-center">
          <Button 
              onClick={() => {
                console.log('Generando PDF tracciabilità per:', batchCode);
                console.log('Dati tracciabilità ricevuti:', traceabilityData);
                try {
                  exportTraceabilityToPDF(batchCode!, traceabilityData);
                  console.log('PDF generato con successo');
                } catch (error) {
                  console.error('Errore durante la generazione del PDF:', error);
                  alert('Errore durante la generazione del PDF. Controlla la console per i dettagli.');
                }
              }}
              className="bg-red-600 hover:bg-red-700 text-white shadow-lg"
              disabled={!traceabilityData || !batchCode}
            >
              <FileDown className="h-4 w-4 mr-2" />
              Scarica Report PDF
            </Button>
        </div>

        {/* Main Product Info */}
        <Card className="border-l-4 border-l-green-600">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-6 w-6" />
              {batch.productName}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="text-lg px-3 py-1">
                    Lotto: {batch.code}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-blue-600" />
                    <span className="font-medium">Data Produzione:</span>
                    <span>{new Date(batch.productionDate).toLocaleDateString('it-IT')}</span>
                  </div>
                  
                  {batch.expiryDate && (
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-orange-600" />
                      <span className="font-medium">Data Scadenza:</span>
                      <span>{new Date(batch.expiryDate).toLocaleDateString('it-IT')}</span>
                    </div>
                  )}
                  

                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Factory className="h-4 w-4 text-gray-600" />
                  <span className="font-medium">Produttore:</span>
                </div>
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <p className="font-semibold">Azienda Agraria Annessa al Convitto</p>
                  <div className="flex items-center gap-1 mt-1">
                    <MapPin className="h-3 w-3 text-gray-500" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Produzione Artigianale di Qualità
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recipe Information */}
        {recipe && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Informazioni Ricetta
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">{recipe.name}</h4>
                  <p className="text-gray-600 dark:text-gray-400">{recipe.description}</p>
                </div>
                
                <Separator />
                
                <div>
                  <h5 className="font-medium mb-2">Ingredienti:</h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {recipe.ingredients.map((ingredient: any, index: number) => (
                      <div key={index} className="p-2 bg-gray-50 dark:bg-gray-800 rounded flex justify-between items-center">
                        <span>{ingredient.name}</span>
                        {ingredient.productPercentage && (
                          <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                            {ingredient.productPercentage}%
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                
                {recipe.allergens && recipe.allergens.length > 0 && (
                  <div>
                    <h5 className="font-medium mb-2 text-amber-700 dark:text-amber-300">Allergeni:</h5>
                    <div className="flex flex-wrap gap-2">
                      {recipe.allergens.map((allergen: string, index: number) => (
                        <Badge key={index} variant="secondary" className="bg-amber-100 text-amber-800">
                          {allergen}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Nutritional Information */}
        {nutritionalValues && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-blue-600" />
                Informazioni Nutrizionali
                <Badge variant="outline" className="ml-2">per 100g</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Valori Energetici */}
                <div className="space-y-3">
                  <h5 className="font-semibold text-lg border-b pb-1">Valori Energetici</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                      <span className="font-medium">Energia</span>
                      <span className="font-bold">{nutritionalValues.calories} kcal</span>
                    </div>
                  </div>
                </div>

                {/* Macronutrienti */}
                <div className="space-y-3">
                  <h5 className="font-semibold text-lg border-b pb-1">Macronutrienti</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <span>Grassi</span>
                      <span className="font-medium">{nutritionalValues.fats}g</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded ml-4">
                      <span className="text-sm">di cui saturi</span>
                      <span className="text-sm">{nutritionalValues.saturatedFats}g</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <span>Carboidrati</span>
                      <span className="font-medium">{nutritionalValues.carbohydrates}g</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded ml-4">
                      <span className="text-sm">di cui zuccheri</span>
                      <span className="text-sm">{nutritionalValues.sugars}g</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <span>Fibre</span>
                      <span className="font-medium">{nutritionalValues.fiber}g</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <span>Proteine</span>
                      <span className="font-medium">{nutritionalValues.proteins}g</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                      <span>Sale</span>
                      <span className="font-medium">{nutritionalValues.salt}g</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-400 rounded">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  <strong>Nota:</strong> I valori nutrizionali sono calcolati automaticamente basandosi sui quantitativi degli ingredienti utilizzati e potrebbero variare leggermente dal prodotto finale.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Production Process */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Processo di Produzione
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span>Materie prime certificate e controllate</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span>Lavorazione secondo standard HACCP</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span>Controllo qualità in ogni fase di produzione</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span>Confezionamento in ambiente controllato</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span>Tracciabilità completa dal campo alla tavola</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quality Controls */}
        {batch?.qualityControls && Object.keys(batch.qualityControls).length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-green-600" />
                Controlli Qualità Certificati
                <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
                  Verificato
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* pH */}
                {batch.qualityControls.ph && (
                  <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/50 dark:to-blue-900/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Droplet className="h-4 w-4 text-blue-600" />
                      <span className="font-medium">pH</span>
                      <Badge 
                        variant={batch.qualityControls.ph.status === 'OK' ? 'default' : 
                                batch.qualityControls.ph.status === 'WARNING' ? 'secondary' : 'destructive'}
                        className={batch.qualityControls.ph.status === 'OK' ? 'bg-green-100 text-green-800' : 
                                  batch.qualityControls.ph.status === 'WARNING' ? 'bg-yellow-100 text-yellow-800' : ''}
                      >
                        {batch.qualityControls.ph.status}
                      </Badge>
                    </div>
                    <div className="text-lg font-bold text-blue-700 dark:text-blue-300">
                      {batch.qualityControls.ph.value}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Target: 4.0-4.5
                    </div>
                    {batch.qualityControls.ph.timestamp && (
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(batch.qualityControls.ph.timestamp).toLocaleString('it-IT')}
                      </div>
                    )}
                  </div>
                )}

                {/* Brix */}
                {batch.qualityControls.brix && (
                  <div className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950/50 dark:to-orange-900/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Scale className="h-4 w-4 text-orange-600" />
                      <span className="font-medium">Brix</span>
                      <Badge 
                        variant={batch.qualityControls.brix.status === 'OK' ? 'default' : 
                                batch.qualityControls.brix.status === 'WARNING' ? 'secondary' : 'destructive'}
                        className={batch.qualityControls.brix.status === 'OK' ? 'bg-green-100 text-green-800' : 
                                  batch.qualityControls.brix.status === 'WARNING' ? 'bg-yellow-100 text-yellow-800' : ''}
                      >
                        {batch.qualityControls.brix.status}
                      </Badge>
                    </div>
                    <div className="text-lg font-bold text-orange-700 dark:text-orange-300">
                      {batch.qualityControls.brix.value}°
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Target: 5.5-6.0°
                    </div>
                    {batch.qualityControls.brix.timestamp && (
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(batch.qualityControls.brix.timestamp).toLocaleString('it-IT')}
                      </div>
                    )}
                  </div>
                )}

                {/* Temperature */}
                {batch.qualityControls.temperature && (
                  <div className="p-4 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950/50 dark:to-red-900/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Thermometer className="h-4 w-4 text-red-600" />
                      <span className="font-medium">Temperatura</span>
                      <Badge 
                        variant={batch.qualityControls.temperature.status === 'OK' ? 'default' : 
                                batch.qualityControls.temperature.status === 'WARNING' ? 'secondary' : 'destructive'}
                        className={batch.qualityControls.temperature.status === 'OK' ? 'bg-green-100 text-green-800' : 
                                  batch.qualityControls.temperature.status === 'WARNING' ? 'bg-yellow-100 text-yellow-800' : ''}
                      >
                        {batch.qualityControls.temperature.status}
                      </Badge>
                    </div>
                    <div className="text-lg font-bold text-red-700 dark:text-red-300">
                      {batch.qualityControls.temperature.value}°C
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Target: 80-90°C
                    </div>
                    {batch.qualityControls.temperature.timestamp && (
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(batch.qualityControls.temperature.timestamp).toLocaleString('it-IT')}
                      </div>
                    )}
                  </div>
                )}

                {/* Viscosity */}
                {batch.qualityControls.viscosity && (
                  <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/50 dark:to-purple-900/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Beaker className="h-4 w-4 text-purple-600" />
                      <span className="font-medium">Viscosità</span>
                      <Badge 
                        variant={batch.qualityControls.viscosity.status === 'OK' ? 'default' : 
                                batch.qualityControls.viscosity.status === 'WARNING' ? 'secondary' : 'destructive'}
                        className={batch.qualityControls.viscosity.status === 'OK' ? 'bg-green-100 text-green-800' : 
                                  batch.qualityControls.viscosity.status === 'WARNING' ? 'bg-yellow-100 text-yellow-800' : ''}
                      >
                        {batch.qualityControls.viscosity.status}
                      </Badge>
                    </div>
                    <div className="text-lg font-bold text-purple-700 dark:text-purple-300">
                      {batch.qualityControls.viscosity.value}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Target: Standard
                    </div>
                    {batch.qualityControls.viscosity.timestamp && (
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(batch.qualityControls.viscosity.timestamp).toLocaleString('it-IT')}
                      </div>
                    )}
                  </div>
                )}

                {/* Color */}
                {batch.qualityControls.color && (
                  <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/50 dark:to-green-900/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Eye className="h-4 w-4 text-green-600" />
                      <span className="font-medium">Colore</span>
                      <Badge 
                        variant={batch.qualityControls.color.status === 'OK' ? 'default' : 
                                batch.qualityControls.color.status === 'WARNING' ? 'secondary' : 'destructive'}
                        className={batch.qualityControls.color.status === 'OK' ? 'bg-green-100 text-green-800' : 
                                  batch.qualityControls.color.status === 'WARNING' ? 'bg-yellow-100 text-yellow-800' : ''}
                      >
                        {batch.qualityControls.color.status}
                      </Badge>
                    </div>
                    <div className="text-lg font-bold text-green-700 dark:text-green-300">
                      {batch.qualityControls.color.value}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Target: Conforme
                    </div>
                    {batch.qualityControls.color.timestamp && (
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(batch.qualityControls.color.timestamp).toLocaleString('it-IT')}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Quality Control Summary */}
              {batch.qualityControls.ph?.operator && (
                <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4" />
                    <span className="font-medium">Operatore:</span>
                    <span>{batch.qualityControls.ph.operator}</span>
                  </div>
                  {batch.qualityControls.ph.notes && (
                    <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                      <span className="font-medium">Note:</span> {batch.qualityControls.ph.notes}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Batch Notes */}
        {batch.notes && (
          <Card>
            <CardHeader>
              <CardTitle>Note di Produzione</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 dark:text-gray-300">{batch.notes}</p>
            </CardContent>
          </Card>
        )}

        {/* Footer */}
        <div className="text-center py-8 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-center gap-2 mb-2">
            <ShieldCheck className="h-5 w-5 text-green-600" />
            <span className="font-medium text-green-600">Prodotto Verificato</span>
          </div>
          <p className="text-sm text-gray-500">
            Questo prodotto è stato verificato attraverso il sistema di tracciabilità digitale.
            <br />
            Data verifica: {new Date().toLocaleDateString('it-IT')}
          </p>
        </div>
      </div>
    </div>
  );
};

export default TraceabilityPage;