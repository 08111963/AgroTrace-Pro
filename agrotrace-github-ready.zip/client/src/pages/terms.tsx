import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, FileText, Scale, AlertTriangle, Users } from "lucide-react";
import { Link } from "wouter";

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Accedi
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Termini di Servizio
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Condizioni d'uso del servizio AgroTrace Pro
          </p>
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <CardTitle>Accettazione dei Termini</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Utilizzando AgroTrace Pro, accetti integralmente questi termini di servizio. 
                Se non accetti questi termini, non utilizzare il servizio.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle>Descrizione del Servizio</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                AgroTrace Pro è una piattaforma software per la gestione e tracciabilità di prodotti agroalimentari che include:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-300">
                <li>Gestione ricette e ingredienti</li>
                <li>Tracciabilità lotti di produzione</li>
                <li>Controllo inventario e magazzino</li>
                <li>Generazione etichette QR</li>
                <li>Reporting e analisi</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                  <Scale className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
                <CardTitle>Responsabilità dell'Utente</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">L'utente si impegna a:</p>
              <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-300">
                <li>Fornire informazioni accurate e aggiornate</li>
                <li>Mantenere riservate le credenziali di accesso</li>
                <li>Utilizzare il servizio nel rispetto delle leggi vigenti</li>
                <li>Non tentare di compromettere la sicurezza del sistema</li>
                <li>Rispettare i diritti di proprietà intellettuale</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                </div>
                <CardTitle>Limitazioni di Responsabilità</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                Il servizio è fornito "così com'è". Non garantiamo:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-300">
                <li>Funzionamento ininterrotto del servizio</li>
                <li>Assenza di errori o bug</li>
                <li>Compatibilità con tutti i sistemi</li>
                <li>Risultati specifici dall'uso del software</li>
              </ul>
              <p className="text-gray-600 dark:text-gray-300 font-medium mt-4">
                La responsabilità massima è limitata all'importo pagato per il servizio negli ultimi 12 mesi.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Proprietà Intellettuale</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Tutti i diritti di proprietà intellettuale del software appartengono a AgroTrace Pro. 
                L'utente ottiene una licenza d'uso limitata, non esclusiva e revocabile.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Modifiche ai Termini</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Ci riserviamo il diritto di modificare questi termini in qualsiasi momento. 
                Le modifiche saranno comunicate via email e entreranno in vigore 30 giorni dopo la notifica.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Risoluzione delle Controversie</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Eventuali controversie saranno risolte secondo la legge italiana. 
                Il foro competente è quello di Milano, Italia.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contatti</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300">
                Per domande sui termini di servizio:
              </p>
              <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="font-medium">Email: legal@agrotrace.pro</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Sede legale: Milano, Italia
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Ultimo aggiornamento: Gennaio 2024
          </p>
        </div>
      </div>
    </div>
  );
}