import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Package2, Calendar, MapPin, Thermometer, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { useEffect } from "react";

export default function BatchExamplePage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const sampleBatch = {
    code: "BT-240611-001",
    productName: "Passata di Pomodoro Biologica",
    recipe: "Passata Bio Standard",
    productionDate: "2024-06-11",
    expiryDate: "2025-06-11",
    status: "Completato",
    quantity: 48,
    unit: "barattoli 500ml",
    location: "Stabilimento Pachino",
    temperature: "85°C",
    duration: "45 min",
    quality: {
      ph: 4.2,
      brix: 5.8,
      color: "Rosso intenso",
      consistency: "Omogenea"
    },
    traceability: {
      ingredients: [
        { name: "Pomodori San Marzano", lot: "PM-240610-15", supplier: "Az. Rossi", quantity: "240 kg" },
        { name: "Sale marino", lot: "SM-240605-03", supplier: "Saline di Trapani", quantity: "2.4 kg" },
        { name: "Basilico", lot: "BS-240611-08", supplier: "Serra Verde", quantity: "1.44 kg" }
      ],
      processing: [
        { step: "Lavaggio", time: "09:30", temperature: "20°C", operator: "M. Bianchi" },
        { step: "Sbollentatura", time: "10:15", temperature: "95°C", operator: "G. Verdi" },
        { step: "Passatura", time: "11:00", temperature: "25°C", operator: "M. Bianchi" },
        { step: "Cottura", time: "11:30", temperature: "85°C", operator: "L. Neri" },
        { step: "Invasamento", time: "12:45", temperature: "80°C", operator: "A. Russo" }
      ]
    },
    qualityChecks: [
      { parameter: "pH", value: "4.2", target: "4.0-4.5", status: "OK" },
      { parameter: "Brix", value: "5.8°", target: "5.5-6.0°", status: "OK" },
      { parameter: "Temperatura", value: "85°C", target: "80-90°C", status: "OK" },
      { parameter: "Viscosità", value: "Normale", target: "Standard", status: "OK" },
      { parameter: "Colore", value: "Conforme", target: "Rosso intenso", status: "OK" }
    ],
    distribution: [
      { client: "Supermercato Bio+", quantity: 20, date: "2024-06-12", invoice: "INV-2024-089" },
      { client: "Negozio Km Zero", quantity: 15, date: "2024-06-13", invoice: "INV-2024-091" },
      { client: "Ristorante Il Pomodoro", quantity: 10, date: "2024-06-14", invoice: "INV-2024-095" }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Inizia Ora
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Esempio Lotto di Produzione
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Tracciabilità completa dal ricevimento ingredienti alla distribuzione finale
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Batch Overview */}
            <Card className="border-2 border-green-200 dark:border-green-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Package2 className="w-6 h-6 text-green-600" />
                    Lotto {sampleBatch.code}
                  </CardTitle>
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    {sampleBatch.status}
                  </Badge>
                </div>
                <div className="text-lg font-medium">{sampleBatch.productName}</div>
                <div className="text-gray-600">Ricetta: {sampleBatch.recipe}</div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Package2 className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                    <div className="text-2xl font-bold">{sampleBatch.quantity}</div>
                    <div className="text-sm text-gray-500">{sampleBatch.unit}</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Calendar className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                    <div className="text-lg font-bold">{new Date(sampleBatch.productionDate).toLocaleDateString('it-IT')}</div>
                    <div className="text-sm text-gray-500">Produzione</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Thermometer className="w-6 h-6 mx-auto mb-2 text-red-600" />
                    <div className="text-2xl font-bold">{sampleBatch.temperature}</div>
                    <div className="text-sm text-gray-500">Temperatura</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Clock className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                    <div className="text-2xl font-bold">{sampleBatch.duration}</div>
                    <div className="text-sm text-gray-500">Durata</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Traceability - Ingredients */}
            <Card>
              <CardHeader>
                <CardTitle>Tracciabilità Ingredienti</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sampleBatch.traceability.ingredients.map((ingredient, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{ingredient.name}</div>
                        <div className="text-sm text-gray-500">
                          Lotto: {ingredient.lot} • {ingredient.supplier}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{ingredient.quantity}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Processing Steps */}
            <Card>
              <CardHeader>
                <CardTitle>Fasi di Lavorazione</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sampleBatch.traceability.processing.map((step, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex-shrink-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">{step.step}</div>
                        <div className="text-sm text-gray-500">
                          Operatore: {step.operator}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{step.time}</div>
                        <div className="text-sm text-gray-500">{step.temperature}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Distribuzione</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sampleBatch.distribution.map((dist, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{dist.client}</div>
                        <div className="text-sm text-gray-500">
                          Fattura: {dist.invoice}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{dist.quantity} unità</div>
                        <div className="text-sm text-gray-500">{new Date(dist.date).toLocaleDateString('it-IT')}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quality Control */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Controlli Qualità
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {sampleBatch.qualityChecks.map((check, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm">{check.parameter}</div>
                        <div className="text-xs text-gray-500">Target: {check.target}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-sm">{check.value}</div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                          {check.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Batch Info */}
            <Card>
              <CardHeader>
                <CardTitle>Informazioni Lotto</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Stabilimento</span>
                    <span className="font-medium">{sampleBatch.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Scadenza</span>
                    <span className="font-medium">{new Date(sampleBatch.expiryDate).toLocaleDateString('it-IT')}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">pH finale</span>
                    <span className="font-medium">{sampleBatch.quality.ph}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Grado Brix</span>
                    <span className="font-medium">{sampleBatch.quality.brix}°</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle>Funzionalità Tracciabilità</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Tracciabilità ingredienti completa
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Registrazione fasi di lavorazione
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Controlli qualità automatici
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Tracking distribuzione
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Alert scadenze automatici
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Tracciabilità Completa per i Tuoi Lotti
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Monitora ogni fase della produzione con controlli qualità integrati
          </p>
          <Link href="/login">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
              Inizia la Prova Gratuita
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}