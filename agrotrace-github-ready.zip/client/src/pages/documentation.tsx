import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Book, Video, Download, Search, Database, Shield } from "lucide-react";
import { Link } from "wouter";
import { useEffect } from "react";

export default function DocumentationPage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Accedi
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Documentazione
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Guide complete per utilizzare al meglio AgroTrace Pro
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Guida Rapida */}
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mb-4">
                <Book className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle>Guida Rapida</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Inizia subito con i concetti base e le funzionalità principali.
              </p>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• Primo accesso e configurazione</li>
                <li>• Creazione della prima ricetta</li>
                <li>• Gestione lotti di produzione</li>
                <li>• Generazione QR code</li>
              </ul>
              <Link href="/quick-guide">
                <Button className="w-full mt-4" variant="outline">
                  Leggi la Guida
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Gestione Ricette */}
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                <Book className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle>Gestione Ricette</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Come creare e gestire ricette con ingredienti e allergenici.
              </p>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• Creazione ricette dettagliate</li>
                <li>• Calcolo automatico costi</li>
                <li>• Gestione allergenici</li>
                <li>• Controllo delle versioni</li>
              </ul>
              <Link href="/recipe-example">
                <Button className="w-full mt-4" variant="outline">
                  Vedi Esempio Ricetta
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Tracciabilità Lotti */}
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                <Book className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle>Tracciabilità Lotti</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Sistema completo di tracciabilità dalla produzione alla vendita.
              </p>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• Numerazione automatica</li>
                <li>• Tracking ingredienti</li>
                <li>• Date produzione/scadenza</li>
                <li>• Collegamento con QR</li>
              </ul>
              <Link href="/batch-example">
                <Button className="w-full mt-4" variant="outline">
                  Vedi Esempio Lotto
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Video Tutorial */}
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-red-100 dark:bg-red-900 rounded-lg flex items-center justify-center mb-4">
                <Video className="w-6 h-6 text-red-600 dark:text-red-400" />
              </div>
              <CardTitle>Video Tutorial</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Tutorial video passo-passo per tutte le funzionalità.
              </p>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• Setup iniziale (5 min)</li>
                <li>• Gestione ricette (8 min)</li>
                <li>• Creazione lotti (6 min)</li>
                <li>• QR e tracciabilità (7 min)</li>
              </ul>
              <Link href="/video-tutorials">
                <Button className="w-full mt-4" variant="outline">
                  Guarda i Video
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Backup e Sicurezza */}
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                <Database className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle>Backup e Sicurezza</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Sistema completo di backup automatici per proteggere i tuoi dati.
              </p>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• Backup automatici ogni 6 ore</li>
                <li>• Backup manuali quando necessario</li>
                <li>• Ripristino completo del database</li>
                <li>• Conservazione ultimi 30 backup</li>
              </ul>
              <Link href="/backup-info">
                <Button className="w-full mt-4" variant="outline">
                  Informazioni Backup
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* API e Integrazioni */}
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center mb-4">
                <Download className="w-6 h-6 text-orange-600 dark:text-orange-400" />
              </div>
              <CardTitle>API e Integrazioni</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Documentazione tecnica per sviluppatori e integrazioni.
              </p>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• API REST completa</li>
                <li>• Webhook notifications</li>
                <li>• SDK e librerie</li>
                <li>• Esempi di codice</li>
              </ul>
              <Link href="/api-docs">
                <Button className="w-full mt-4" variant="outline">
                  Documentazione API
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* FAQ */}
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-teal-100 dark:bg-teal-900 rounded-lg flex items-center justify-center mb-4">
                <Search className="w-6 h-6 text-teal-600 dark:text-teal-400" />
              </div>
              <CardTitle>FAQ</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Risposte alle domande più frequenti dei nostri utenti.
              </p>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li>• Problemi comuni</li>
                <li>• Configurazione account</li>
                <li>• Gestione backup e ripristino</li>
                <li>• Troubleshooting</li>
              </ul>
              <Link href="/faq">
                <Button className="w-full mt-4" variant="outline">
                  Consulta le FAQ
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Non Trovi Quello che Cerchi?
          </h3>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Il nostro team di supporto è sempre disponibile per aiutarti
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button variant="outline" size="lg">
                Contatta il Supporto
              </Button>
            </Link>
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Inizia Subito
              </Button>
            </Link>
          </div>
        </div>

        {/* Sezione dettagliata Backup */}
        <div className="mt-16 bg-white dark:bg-gray-800 rounded-lg p-8 shadow-lg">
          <div className="flex items-center gap-3 mb-6">
            <Database className="w-8 h-8 text-blue-600" />
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
              Guida Completa ai Backup
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Backup Automatici */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-600" />
                Backup Automatici
              </h3>
              <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg border border-green-200 dark:border-green-800">
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  <strong>Il sistema esegue automaticamente un backup completo ogni 6 ore</strong>
                </p>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  <li>• Include tutti i dati: ricette, lotti, inventario, vendite</li>
                  <li>• Salvataggio automatico senza intervento umano</li>
                  <li>• Conservazione degli ultimi 30 backup</li>
                  <li>• Eliminazione automatica backup più vecchi</li>
                </ul>
              </div>
            </div>

            {/* Backup Manuali */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-blue-600" />
                Backup Manuali
              </h3>
              <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  <strong>Puoi creare backup quando vuoi dalla pagina Backup</strong>
                </p>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  <li>• Vai su "Backup" nel menu laterale</li>
                  <li>• Clicca "Crea Backup Ora"</li>
                  <li>• Il backup viene creato immediatamente</li>
                  <li>• Utile prima di modifiche importanti</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Ripristino - Sezione importante */}
          <div className="mt-8 bg-orange-50 dark:bg-orange-950 p-6 rounded-lg border border-orange-200 dark:border-orange-800">
            <h3 className="text-xl font-semibold text-orange-800 dark:text-orange-200 mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Ripristino Backup - IMPORTANTE
            </h3>
            
            <div className="bg-white dark:bg-gray-900 p-4 rounded border border-orange-300 dark:border-orange-700 mb-4">
              <h4 className="font-semibold text-red-600 dark:text-red-400 mb-2">⚠️ ATTENZIONE: Cosa significa "Il ripristino sostituirà tutti i dati"</h4>
              <p className="text-gray-700 dark:text-gray-300 mb-3">
                Quando ripristini un backup, <strong>il database torna esattamente come era al momento del backup</strong>.
              </p>
              
              <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2"><strong>Esempio pratico:</strong></p>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Backup del 10 giugno ore 10:00</li>
                  <li>• Oggi aggiungi 5 nuove ricette e 10 lotti</li>
                  <li>• Se ripristini il backup del 10 giugno:</li>
                  <li className="ml-4 text-red-600 dark:text-red-400">→ Perdi le 5 ricette e i 10 lotti aggiunti dopo le 10:00</li>
                </ul>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">❌ NON perdi:</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Dati "non salvati" (tutto si salva automaticamente)</li>
                  <li>• File sul tuo computer</li>
                  <li>• Altri backup</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">⚠️ Perdi invece:</h4>
                <ul className="text-sm text-red-600 dark:text-red-400 space-y-1">
                  <li>• Tutto quello fatto DOPO la data del backup</li>
                  <li>• Nuove ricette, lotti, vendite</li>
                  <li>• Modifiche ai dati esistenti</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Quando usare il ripristino */}
          <div className="mt-6 grid md:grid-cols-2 gap-6">
            <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg border border-green-200 dark:border-green-800">
              <h4 className="font-semibold text-green-800 dark:text-green-200 mb-3">✅ Quando usare il ripristino:</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Database danneggiato o corrotto</li>
                <li>• Errori gravi nei dati</li>
                <li>• Problemi tecnici seri</li>
                <li>• Ripristino dopo attacco informatico</li>
              </ul>
            </div>

            <div className="bg-red-50 dark:bg-red-950 p-4 rounded-lg border border-red-200 dark:border-red-800">
              <h4 className="font-semibold text-red-800 dark:text-red-200 mb-3">❌ NON usare per:</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Cancellare una singola ricetta sbagliata</li>
                <li>• Correggere piccoli errori</li>
                <li>• "Tornare indietro" per curiosità</li>
                <li>• Operazioni quotidiane normali</li>
              </ul>
            </div>
          </div>

          {/* Suggerimento sicurezza */}
          <div className="mt-6 bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
            <h4 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">💡 Suggerimento per la sicurezza:</h4>
            <p className="text-gray-700 dark:text-gray-300">
              <strong>Prima di ripristinare un backup vecchio, crea sempre un backup manuale dello stato attuale.</strong> 
              Così hai una "copia di sicurezza" dei dati attuali nel caso cambi idea.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}