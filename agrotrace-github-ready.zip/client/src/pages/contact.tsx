import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Mail, Phone, MapPin, Clock } from "lucide-react";
import { Link } from "wouter";

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Accedi
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Contattaci
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Siamo qui per aiutarti. Contattaci per qualsiasi domanda o supporto.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card>
            <CardHeader>
              <CardTitle>Invia un Messaggio</CardTitle>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Nome</label>
                    <Input placeholder="Il tuo nome" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Cognome</label>
                    <Input placeholder="Il tuo cognome" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input type="email" placeholder="la-tua-email@esempio.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Azienda</label>
                  <Input placeholder="Nome della tua azienda" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Oggetto</label>
                  <Input placeholder="Di cosa hai bisogno?" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Messaggio</label>
                  <Textarea 
                    placeholder="Descrivi la tua richiesta o domanda..."
                    className="min-h-[120px]"
                  />
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  Invia Messaggio
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                    <Mail className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <CardTitle>Email</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300 mb-2">
                  Per supporto tecnico e informazioni generali:
                </p>
                <p className="font-medium">info@agrotrace.pro</p>
                <p className="font-medium">support@agrotrace.pro</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                    <Phone className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <CardTitle>Telefono</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300 mb-2">
                  Assistenza telefonica dal lunedì al venerdì:
                </p>
                <p className="font-medium">+39 02 1234 5678</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <CardTitle>Sede</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300 mb-2">
                  Vieni a trovarci presso la nostra sede:
                </p>
                <p className="font-medium">
                  Via della Tecnologia, 123<br />
                  20100 Milano, Italia
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                    <Clock className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                  </div>
                  <CardTitle>Orari di Supporto</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-gray-600 dark:text-gray-300">
                  <p><span className="font-medium">Lunedì - Venerdì:</span> 9:00 - 18:00</p>
                  <p><span className="font-medium">Sabato:</span> 9:00 - 13:00</p>
                  <p><span className="font-medium">Domenica:</span> Chiuso</p>
                </div>
                <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                  Supporto email disponibile 24/7 con risposta entro 24 ore
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Hai Bisogno di Aiuto Immediato?
          </h3>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Consulta la nostra documentazione o inizia subito con AgroTrace Pro
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="outline" size="lg">
              Documentazione
            </Button>
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Inizia Subito
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}