import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Key, CheckCircle, XCircle, Clock, Shield } from "lucide-react";

export default function LicenseActivation() {
  const [licenseCode, setLicenseCode] = useState("");
  const [validationResult, setValidationResult] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query per lo status della licenza utente
  const { data: userLicenseStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/license/user-status"]
  });

  // Mutation per validare il codice
  const validateMutation = useMutation({
    mutationFn: (code: string) => apiRequest("POST", "/api/license/validate", { code }),
    onSuccess: (data) => {
      setValidationResult(data);
      if (data.isValid) {
        toast({
          title: "Codice Valido",
          description: data.message,
        });
      } else {
        toast({
          title: "Codice Non Valido",
          description: data.message,
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Errore Validazione",
        description: error.message || "Errore durante la validazione del codice",
        variant: "destructive"
      });
    }
  });

  // Mutation per attivare il codice
  const activateMutation = useMutation({
    mutationFn: (code: string) => apiRequest("POST", "/api/license/activate", { code }),
    onSuccess: () => {
      toast({
        title: "Licenza Attivata",
        description: "La tua licenza è stata attivata con successo!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/license/user-status"] });
      setLicenseCode("");
      setValidationResult(null);
    },
    onError: (error: any) => {
      toast({
        title: "Errore Attivazione",
        description: error.message || "Errore durante l'attivazione della licenza",
        variant: "destructive"
      });
    }
  });

  const handleValidate = () => {
    if (!licenseCode.trim()) {
      toast({
        title: "Codice Richiesto",
        description: "Inserisci un codice licenza per continuare",
        variant: "destructive"
      });
      return;
    }
    validateMutation.mutate(licenseCode.trim());
  };

  const handleActivate = () => {
    if (!validationResult?.isValid) {
      toast({
        title: "Validazione Richiesta",
        description: "Valida prima il codice licenza",
        variant: "destructive"
      });
      return;
    }
    activateMutation.mutate(licenseCode.trim());
  };

  if (statusLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Caricamento status licenza...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Shield className="h-6 w-6 text-blue-600" />
        <h1 className="text-2xl font-bold">Gestione Licenza</h1>
      </div>

      {/* Status Licenza Corrente */}
      {userLicenseStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {userLicenseStatus.hasLicense ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <XCircle className="h-5 w-5 text-red-600" />
              )}
              Status Licenza Attuale
            </CardTitle>
          </CardHeader>
          <CardContent>
            {userLicenseStatus.hasLicense ? (
              <div className="space-y-3">
                <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                  <p className="text-green-800 dark:text-green-200 font-medium">
                    {userLicenseStatus.message}
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Codice Licenza</label>
                    <p className="font-mono text-sm bg-gray-100 dark:bg-gray-800 p-2 rounded">
                      {userLicenseStatus.licenseCode}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Tipo Licenza</label>
                    <p className="font-medium capitalize">{userLicenseStatus.licenseType}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Data Attivazione</label>
                    <p>{new Date(userLicenseStatus.activatedAt).toLocaleDateString('it-IT')}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Scadenza</label>
                    <p className={userLicenseStatus.daysRemaining < 30 ? 'text-orange-600 font-medium' : ''}>
                      {new Date(userLicenseStatus.expiresAt).toLocaleDateString('it-IT')}
                      {userLicenseStatus.daysRemaining && (
                        <span className="text-sm text-gray-500 ml-2">
                          ({userLicenseStatus.daysRemaining} giorni rimanenti)
                        </span>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                <p className="text-yellow-800 dark:text-yellow-200">
                  {userLicenseStatus.message}
                </p>
                {userLicenseStatus.expired && (
                  <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-2">
                    Licenza scaduta il: {new Date(userLicenseStatus.expiredAt).toLocaleDateString('it-IT')}
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Attivazione Nuova Licenza */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Attiva Nuova Licenza
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">
              Codice Licenza
            </label>
            <div className="flex gap-2">
              <Input
                placeholder="AGRO-XXXX-XXXX-XXXX"
                value={licenseCode}
                onChange={(e) => {
                  setLicenseCode(e.target.value.toUpperCase());
                  setValidationResult(null);
                }}
                className="font-mono"
                maxLength={19}
              />
              <Button 
                onClick={handleValidate}
                disabled={validateMutation.isPending || !licenseCode.trim()}
                variant="outline"
              >
                {validateMutation.isPending ? "Validando..." : "Valida"}
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Formato: AGRO-XXXX-XXXX-XXXX (inserisci il codice ricevuto dopo l'acquisto)
            </p>
          </div>

          {/* Risultato Validazione */}
          {validationResult && (
            <div className={`p-4 rounded-lg ${
              validationResult.isValid 
                ? 'bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800'
                : 'bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800'
            }`}>
              <div className="flex items-center gap-2 mb-2">
                {validationResult.isValid ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600" />
                )}
                <p className={`font-medium ${
                  validationResult.isValid ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'
                }`}>
                  {validationResult.message}
                </p>
              </div>
              
              {validationResult.isValid && (
                <div className="space-y-1 text-sm text-green-700 dark:text-green-300">
                  <p>Piano: <span className="font-medium capitalize">{validationResult.planType}</span></p>
                  <p>Durata: <span className="font-medium">{validationResult.duration} giorni</span></p>
                  <p>Attivazioni disponibili: <span className="font-medium">{validationResult.activationsLeft}</span></p>
                </div>
              )}
            </div>
          )}

          {/* Pulsante Attivazione */}
          {validationResult?.isValid && (
            <Button 
              onClick={handleActivate}
              disabled={activateMutation.isPending}
              className="w-full"
            >
              {activateMutation.isPending ? (
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 animate-spin" />
                  Attivando Licenza...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Attiva Licenza
                </div>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Informazioni sui Piani */}
      <Card>
        <CardHeader>
          <CardTitle>Piani Disponibili</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold text-blue-600">Basic</h3>
              <p className="text-sm text-gray-600 mt-1">
                Ideale per piccole aziende agricole
              </p>
              <ul className="text-xs text-gray-500 mt-2 space-y-1">
                <li>• 50 ricette</li>
                <li>• 100 lotti</li>
                <li>• Reports di base</li>
              </ul>
            </div>
            
            <div className="p-4 border rounded-lg border-blue-200 bg-blue-50 dark:bg-blue-950">
              <h3 className="font-semibold text-blue-600">Premium</h3>
              <p className="text-sm text-gray-600 mt-1">
                Per aziende in crescita
              </p>
              <ul className="text-xs text-gray-500 mt-2 space-y-1">
                <li>• Ricette illimitate</li>
                <li>• Lotti illimitati</li>
                <li>• Reports avanzati</li>
                <li>• Export PDF</li>
              </ul>
            </div>
            
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold text-blue-600">Enterprise</h3>
              <p className="text-sm text-gray-600 mt-1">
                Soluzione completa per grandi aziende
              </p>
              <ul className="text-xs text-gray-500 mt-2 space-y-1">
                <li>• Tutte le funzionalità</li>
                <li>• Multi-utente</li>
                <li>• API access</li>
                <li>• Supporto prioritario</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}