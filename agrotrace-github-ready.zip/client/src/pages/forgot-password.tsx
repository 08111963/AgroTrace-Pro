import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Mail } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ForgotPassword() {
  const [identifier, setIdentifier] = useState(""); // username o email
  const [resetToken, setResetToken] = useState("");
  const [step, setStep] = useState<"identifier" | "token">("identifier");
  const { toast } = useToast();

  const forgotPasswordMutation = useMutation({
    mutationFn: async (identifier: string) => {
      const response = await apiRequest("POST", "/api/auth/forgot-password", { identifier });
      return await response.json();
    },
    onSuccess: (data: any) => {

      toast({
        title: "Token generato",
        description: "Il token di reset è stato generato con successo",
      });
      if (data.token) {
        setResetToken(data.token);
        setStep("token");
      } else {
        console.error("Token mancante nella risposta:", data);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante la richiesta di reset",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (identifier.trim()) {
      forgotPasswordMutation.mutate(identifier);
    }
  };

  const handleBackToLogin = () => {
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBackToLogin}
              className="p-1"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <CardTitle className="text-2xl">Password dimenticata?</CardTitle>
          </div>
          <CardDescription>
            {step === "identifier"
              ? "Inserisci il tuo username o email per recuperare l'accesso"
              : "Il token di reset è stato generato"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {step === "identifier" ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="identifier">Username o Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="identifier"
                    type="text"
                    placeholder="Il tuo username o email"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={forgotPasswordMutation.isPending}
              >
                {forgotPasswordMutation.isPending ? "Generazione..." : "Genera Token Reset"}
              </Button>
            </form>
          ) : (
            <div className="space-y-4">
              <Alert>
                <AlertDescription>
                  Il tuo token di reset password è stato generato. Copialo e usalo nella pagina di reset.
                </AlertDescription>
              </Alert>
              
              <div className="space-y-2">
                <Label>Token di Reset</Label>
                <div className="p-3 bg-muted rounded-md font-mono text-sm break-all">
                  {resetToken}
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => navigator.clipboard.writeText(resetToken)}
                  variant="outline"
                  className="flex-1"
                >
                  Copia Token
                </Button>
                <Button
                  onClick={() => window.location.href = "/reset-password"}
                  className="flex-1"
                >
                  Vai al Reset
                </Button>
              </div>
            </div>
          )}

          <div className="text-center">
            <Button
              variant="link"
              onClick={handleBackToLogin}
              className="text-sm"
            >
              Torna al login
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}