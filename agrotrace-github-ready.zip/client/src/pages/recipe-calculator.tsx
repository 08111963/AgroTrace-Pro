import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calculator, Plus, Trash2, Save } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Ingredient {
  name: string;
  percentage: number;
  unit: string;
  calculatedQuantity: number;
  wastePercentage: number;
  netQuantity: number;
  grossQuantity: number;
}

const RecipeCalculatorPage = () => {
  const [totalWeight, setTotalWeight] = useState<number>(24000);
  const [targetJars, setTargetJars] = useState<number>(120);
  const [jarWeight, setJarWeight] = useState<number>(200);
  const [recipeType, setRecipeType] = useState<string>("Conserve");
  const [recipeName, setRecipeName] = useState<string>("");
  const [recipeDescription, setRecipeDescription] = useState<string>("");
  const [ingredients, setIngredients] = useState<Ingredient[]>([
    { name: "Zucchine", percentage: 70, unit: "g", calculatedQuantity: 16800, wastePercentage: 15, netQuantity: 16800, grossQuantity: 19764.71 },
    { name: "Cipolle", percentage: 7, unit: "g", calculatedQuantity: 1680, wastePercentage: 10, netQuantity: 1680, grossQuantity: 1866.67 },
    { name: "olio evo", percentage: 5, unit: "g", calculatedQuantity: 1200, wastePercentage: 0, netQuantity: 1200, grossQuantity: 1200 },
    { name: "sale", percentage: 1, unit: "g", calculatedQuantity: 240, wastePercentage: 0, netQuantity: 240, grossQuantity: 240 },
    { name: "menta", percentage: 0.5, unit: "g", calculatedQuantity: 120, wastePercentage: 0, netQuantity: 120, grossQuantity: 120 },
    { name: "pepe", percentage: 0.5, unit: "g", calculatedQuantity: 120, wastePercentage: 0, netQuantity: 120, grossQuantity: 120 },
    { name: "limone", percentage: 0.5, unit: "g", calculatedQuantity: 120, wastePercentage: 30, netQuantity: 120, grossQuantity: 171.43 }
  ]);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Auto-ricalcola quando cambiano parametri principali e ci sono già calcoli
  useEffect(() => {
    const hasCalculations = ingredients.some(ing => ing.calculatedQuantity > 0);
    if (hasCalculations) {
      calculateQuantities();
    }
  }, [targetJars, jarWeight]);

  // Mutation per salvare la ricetta
  const saveRecipeMutation = useMutation({
    mutationFn: async (recipeData: any) => {
      return apiRequest("POST", "/api/recipes", recipeData);
    },
    onSuccess: () => {
      toast({
        title: "Ricetta salvata",
        description: "La ricetta è stata salvata con successo",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      // Reset form
      setRecipeName("");
      setRecipeDescription("");
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante il salvataggio della ricetta",
        variant: "destructive",
      });
    },
  });

  // Database degli scarti comuni degli ingredienti
  const wasteDatabase: Record<string, number> = {
    // Verdure
    "pomodori": 20,
    "zucchine": 15,
    "melanzane": 20,
    "peperoni": 25,
    "cipolle": 10,
    "carote": 15,
    "patate": 20,
    "carciofi": 40,
    "asparagi": 30,
    "broccoli": 25,
    "cavolfiore": 30,
    "spinaci": 10,
    
    // Frutta
    "mele": 15,
    "pere": 15,
    "pesche": 20,
    "albicocche": 15,
    "prugne": 10,
    "fragole": 5,
    "ciliegie": 10,
    "uva": 5,
    "agrumi": 30,
    "limoni": 30,
    "arance": 35,
    "mandarini": 25,
    
    // Proteine
    "pollo": 25,
    "manzo": 20,
    "maiale": 15,
    "pesce": 35,
    "gamberi": 40,
    
    // Legumi freschi
    "piselli": 40,
    "fave": 35,
    "fagiolini": 10,
    
    // Erbe aromatiche
    "basilico": 5,
    "prezzemolo": 10,
    "rosmarino": 5,
    "salvia": 5,
    
    // Ingredienti senza scarto
    "acqua": 0,
    "olio": 0,
    "aceto": 0,
    "sale": 0,
    "zucchero": 0,
    "farina": 0,
    "pectina": 0
  };

  // Database densità ingredienti (g/ml)
  const densityDatabase: Record<string, number> = {
    "olio": 0.92,
    "olio d'oliva": 0.92,
    "olio extravergine": 0.92,
    "olio evo": 0.92,
    "aceto": 1.05,
    "aceto balsamico": 1.34,
    "vino": 0.99,
    "alcool": 0.79,
    "miele": 1.4,
    "sciroppo": 1.3,
    "acqua": 1.0,
    "latte": 1.03,
    "panna": 0.99,
    "limone": 1.03,
    "succo di limone": 1.03,
    "succo limone": 1.03
  };

  // Funzione per ottenere la percentuale di scarto automaticamente
  const getWastePercentage = (ingredientName: string): number => {
    const cleanName = ingredientName.toLowerCase().trim();
    for (const [ingredient, waste] of Object.entries(wasteDatabase)) {
      if (cleanName.includes(ingredient)) {
        return waste;
      }
    }
    return 0; // Default nessuno scarto
  };

  // Funzione per ottenere la densità dell'ingrediente
  const getDensity = (ingredientName: string): number => {
    const cleanName = ingredientName.toLowerCase().trim();
    for (const [ingredient, density] of Object.entries(densityDatabase)) {
      if (cleanName.includes(ingredient)) {
        return density;
      }
    }
    return 1.0; // Default densità dell'acqua
  };

  // Funzione per convertire grammi in volume (ml o litri)
  const convertToVolume = (grams: number, ingredientName: string): string => {
    const density = getDensity(ingredientName);
    const milliliters = Math.round((grams / density) * 10) / 10; // Arrotonda a 1 decimale
    
    if (milliliters >= 1000) {
      const liters = Math.round((milliliters / 1000) * 100) / 100; // Arrotonda a 2 decimali
      return `${liters} litri`;
    } else {
      return `${milliliters} ml`;
    }
  };

  const recipePresets = {
    "Conserve": [
      { name: "Verdura principale", percentage: 70, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Acqua/brodo", percentage: 25, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Olio/aceto", percentage: 5, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Confetture": [
      { name: "Frutta", percentage: 60, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Zucchero", percentage: 35, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Limone/pectina", percentage: 5, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Succhi di Frutta": [
      { name: "Frutta", percentage: 80, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Acqua", percentage: 20, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Sott'oli": [
      { name: "Verdura", percentage: 85, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Olio extravergine", percentage: 15, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Marmellate": [
      { name: "Frutta", percentage: 55, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Zucchero", percentage: 40, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Pectina", percentage: 5, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Composte": [
      { name: "Frutta", percentage: 75, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Zucchero", percentage: 20, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Acqua", percentage: 5, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Sciroppi": [
      { name: "Frutta/Erbe", percentage: 30, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Zucchero", percentage: 40, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Acqua", percentage: 30, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Bevande": [
      { name: "Base frutta/erbe", percentage: 25, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Acqua", percentage: 70, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Zucchero/dolcificante", percentage: 5, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Latte e Derivati": [
      { name: "Latte", percentage: 85, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Fermenti/caglio", percentage: 10, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Sale/aromi", percentage: 5, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Salse": [
      { name: "Base verdura", percentage: 60, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Olio", percentage: 25, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Condimenti", percentage: 15, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ],
    "Pesti": [
      { name: "Erbe aromatiche", percentage: 40, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Olio extravergine", percentage: 35, unit: "ml", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Formaggio/noci", percentage: 20, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 },
      { name: "Sale", percentage: 5, unit: "g", wastePercentage: 0, netQuantity: 0, grossQuantity: 0, calculatedQuantity: 0 }
    ]
  };

  const calculateQuantities = () => {
    // Calcolo semplice: numero vasetti × peso per vasetto
    const actualTotalWeight = targetJars * jarWeight;
    
    const updatedIngredients = ingredients.map(ingredient => {
      const netQuantity = Math.round((actualTotalWeight * ingredient.percentage / 100) * 100) / 100;
      const wastePercentage = getWastePercentage(ingredient.name);
      const grossQuantity = wastePercentage > 0 
        ? Math.round((netQuantity / (1 - wastePercentage / 100)) * 100) / 100
        : netQuantity;
      
      return {
        ...ingredient,
        calculatedQuantity: netQuantity,
        wastePercentage,
        netQuantity,
        grossQuantity
      };
    });
    
    setIngredients(updatedIngredients);
  };

  const loadPreset = (type: string) => {
    setRecipeType(type);
    const preset = recipePresets[type as keyof typeof recipePresets];
    if (preset) {
      setIngredients(preset);
    }
  };

  const addIngredient = () => {
    setIngredients([...ingredients, {
      name: "Nuovo ingrediente",
      percentage: 0,
      unit: "g",
      calculatedQuantity: 0,
      wastePercentage: 0,
      netQuantity: 0,
      grossQuantity: 0
    }]);
  };

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const updateIngredient = (index: number, field: keyof Ingredient, value: string | number) => {
    const updated = [...ingredients];
    updated[index] = { ...updated[index], [field]: value };
    
    // Se viene modificato il nome o la percentuale, ricalcola automaticamente se già calcolato
    if ((field === 'name' || field === 'percentage') && updated[index].calculatedQuantity > 0) {
      const actualTotalWeight = targetJars * jarWeight;
      const newPercentage = field === 'percentage' ? Number(value) : updated[index].percentage;
      
      const netQuantity = Math.round((actualTotalWeight * newPercentage / 100) * 100) / 100;
      const wastePercentage = getWastePercentage(updated[index].name);
      const grossQuantity = wastePercentage > 0 
        ? Math.round((netQuantity / (1 - wastePercentage / 100)) * 100) / 100
        : netQuantity;
      
      updated[index] = {
        ...updated[index],
        calculatedQuantity: netQuantity,
        wastePercentage,
        netQuantity,
        grossQuantity
      };
    }
    
    setIngredients(updated);
  };

  const saveRecipe = () => {
    if (!recipeName.trim()) {
      toast({
        title: "Nome richiesto",
        description: "Inserisci un nome per la ricetta",
        variant: "destructive",
      });
      return;
    }

    if (ingredients.length === 0 || !ingredients.some(ing => ing.netQuantity > 0)) {
      toast({
        title: "Calcolo richiesto",
        description: "Effettua prima il calcolo delle quantità",
        variant: "destructive",
      });
      return;
    }

    const recipeIngredients = ingredients
      .filter(ing => ing.netQuantity > 0)
      .map(ing => ({
        name: ing.name,
        quantity: ing.netQuantity,
        unit: ing.unit
      }));

    const recipeData = {
      name: recipeName,
      description: recipeDescription || `Ricetta calcolata per ${targetJars} vasetti da ${jarWeight}g`,
      category: recipeType,
      status: "attiva",
      ingredients: recipeIngredients,
      instructions: `Preparare ${targetJars} vasetti da ${jarWeight}g ciascuno. Seguire le proporzioni calcolate per ogni ingrediente. Considerare gli scarti indicati durante la preparazione.`,
      preparationTime: 30,
      yield: targetJars,
      jarWeight: jarWeight,
      targetJars: targetJars
    };

    saveRecipeMutation.mutate(recipeData);
  };

  const totalPercentage = ingredients.reduce((sum, ing) => sum + ing.percentage, 0);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Calcolatore Ingredienti
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Calcola automaticamente le quantità degli ingredienti per il numero di vasetti desiderato
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Parametri di Input */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Parametri di Produzione
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Tipo di Ricetta */}
              <div>
                <label className="text-sm font-medium mb-2 block">Tipo di Ricetta</label>
                <Select value={recipeType} onValueChange={loadPreset}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Conserve">🥒 Conserve</SelectItem>
                    <SelectItem value="Confetture">🍓 Confetture</SelectItem>
                    <SelectItem value="Succhi di Frutta">🍊 Succhi di Frutta</SelectItem>
                    <SelectItem value="Sott'oli">🫒 Sott'oli</SelectItem>
                    <SelectItem value="Marmellate">🍑 Marmellate</SelectItem>
                    <SelectItem value="Composte">🍒 Composte</SelectItem>
                    <SelectItem value="Sciroppi">🍯 Sciroppi</SelectItem>
                    <SelectItem value="Bevande">🥤 Bevande</SelectItem>
                    <SelectItem value="Latte e Derivati">🥛 Latte e Derivati</SelectItem>
                    <SelectItem value="Salse">🍅 Salse</SelectItem>
                    <SelectItem value="Pesti">🌿 Pesti</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Input Numerici */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Vasetti da Produrre</label>
                  <Input
                    type="number"
                    value={targetJars}
                    onChange={(e) => setTargetJars(Number(e.target.value))}
                    placeholder="10"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Peso per Vasetto (g)</label>
                  <Input
                    type="number"
                    value={jarWeight}
                    onChange={(e) => setJarWeight(Number(e.target.value))}
                    placeholder="200"
                  />
                </div>
              </div>

              {/* Peso Totale Calcolato Automaticamente */}
              <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <div className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">
                  Peso Totale Produzione
                </div>
                <div className="text-lg font-bold text-blue-900 dark:text-blue-100">
                  {targetJars} vasetti × {jarWeight}g = {targetJars * jarWeight}g
                </div>
              </div>



              {/* Riepilogo */}
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                <h3 className="font-medium mb-2">Riepilogo Produzione</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Vasetti:</span>
                    <span className="font-medium">{targetJars}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Peso per vasetto:</span>
                    <span className="font-medium">{jarWeight}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Peso totale:</span>
                    <span className="font-medium">{targetJars * jarWeight}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Percentuali totali:</span>
                    <span className={`font-medium ${totalPercentage === 100 ? 'text-green-600' : 'text-red-600'}`}>
                      {totalPercentage}%
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Ingredienti e Risultati */}
          <Card>
            <CardHeader>
              <CardTitle>Ingredienti e Quantità</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {ingredients.map((ingredient, index) => (
                  <div key={index} className="p-4 border rounded-lg bg-gray-50 dark:bg-gray-800">
                    <div className="flex items-center justify-between mb-3">
                      <Input
                        value={ingredient.name}
                        onChange={(e) => updateIngredient(index, 'name', e.target.value)}
                        placeholder="Nome ingrediente"
                        className="flex-1 mr-2"
                      />
                      {ingredients.length > 1 && (
                        <Button
                          onClick={() => removeIngredient(index)}
                          size="sm"
                          variant="destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div>
                        <label className="text-xs text-muted-foreground">Percentuale %</label>
                        <Input
                          type="number"
                          value={ingredient.percentage}
                          onChange={(e) => updateIngredient(index, 'percentage', Number(e.target.value))}
                          placeholder="0"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground">Unità</label>
                        <Select 
                          value={ingredient.unit} 
                          onValueChange={(value) => updateIngredient(index, 'unit', value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="g">g</SelectItem>
                            <SelectItem value="kg">kg</SelectItem>
                            <SelectItem value="ml">ml</SelectItem>
                            <SelectItem value="l">l</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Risultati calcolo con scarti */}
                    {ingredient.calculatedQuantity > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
                        <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                          <div className="text-xs text-green-700 dark:text-green-300 font-medium mb-1">
                            Quantità Ricetta (netta)
                          </div>
                          <div className="text-lg font-bold text-green-800 dark:text-green-200">
                            {ingredient.netQuantity} {ingredient.unit}
                          </div>
                        </div>
                        
                        {ingredient.wastePercentage > 0 && (
                          <div className="p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                            <div className="text-xs text-orange-700 dark:text-orange-300 font-medium mb-1">
                              Scarto ({ingredient.wastePercentage}%)
                            </div>
                            <div className="text-lg font-bold text-orange-800 dark:text-orange-200">
                              {Math.round((ingredient.grossQuantity - ingredient.netQuantity) * 100) / 100} {ingredient.unit}
                            </div>
                          </div>
                        )}
                        
                        <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                          <div className="text-xs text-blue-700 dark:text-blue-300 font-medium mb-1">
                            {ingredient.wastePercentage > 0 ? 'Da Acquistare (lordo)' : 'Quantità Necessaria'}
                          </div>
                          <div className="text-lg font-bold text-blue-800 dark:text-blue-200">
                            {ingredient.grossQuantity} {ingredient.unit}
                          </div>
                          {ingredient.unit === 'g' && (getDensity(ingredient.name) !== 1.0 || ingredient.name.toLowerCase().includes('acqua')) && (
                            <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                              ≈ {convertToVolume(ingredient.grossQuantity, ingredient.name)}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Pulsante Aggiungi Ingrediente alla fine della lista */}
              <div className="flex justify-center mt-4">
                <Button onClick={addIngredient} variant="outline" className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Aggiungi Altro Ingrediente
                </Button>
              </div>

              {/* Riepilogo Produzione 120 Vasetti */}
              {ingredients.some(ing => ing.calculatedQuantity > 0) && (
                <div className="mt-6 space-y-4">
                  {/* Riepilogo Totale */}
                  <div className="p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg border-2 border-yellow-200 dark:border-yellow-800">
                    <h3 className="font-bold text-yellow-800 dark:text-yellow-200 mb-3 text-lg">
                      RIEPILOGO PRODUZIONE - 120 VASETTI DA 200G (24 KG TOTALI)
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium text-yellow-700 dark:text-yellow-300 mb-2">Target Produzione:</h4>
                        <div className="space-y-1 text-sm">
                          <div>• 120 vasetti da 200g ciascuno</div>
                          <div>• Peso totale: 24.000g (24 kg)</div>
                          <div>• Con calcolo scarti industriali</div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium text-yellow-700 dark:text-yellow-300 mb-2">Quantità Totali:</h4>
                        <div className="space-y-1 text-sm">
                          <div>• Ricetta (netta): {ingredients.reduce((sum, ing) => sum + ing.netQuantity, 0).toLocaleString()}g</div>
                          <div>• Scarti: {ingredients.reduce((sum, ing) => sum + (ing.grossQuantity - ing.netQuantity), 0).toFixed(0)}g</div>
                          <div className="text-lg font-bold">• Da acquistare: {ingredients.reduce((sum, ing) => sum + ing.grossQuantity, 0).toFixed(0)}g</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Lista ingredienti per ricetta */}
                  <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <h3 className="font-medium text-green-800 dark:text-green-200 mb-3">
                      Ingredienti Necessari (quantità esatte)
                    </h3>
                    <div className="space-y-2">
                      {ingredients
                        .filter(ing => ing.calculatedQuantity > 0)
                        .map((ingredient, index) => (
                          <div key={index} className="flex justify-between items-center p-2 bg-white dark:bg-gray-800 rounded">
                            <span className="font-medium">{ingredient.name}</span>
                            <div className="text-right">
                              <div className="font-bold text-green-700 dark:text-green-300">
                                {ingredient.netQuantity.toLocaleString()} {ingredient.unit}
                              </div>
                              {ingredient.unit === 'g' && (getDensity(ingredient.name) !== 1.0 || ingredient.name.toLowerCase().includes('acqua')) && (
                                <div className="text-xs text-green-600 dark:text-green-400">
                                  ≈ {convertToVolume(ingredient.netQuantity, ingredient.name)}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>

                  {/* Lista della spesa con scarti */}
                  <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <h3 className="font-medium text-blue-800 dark:text-blue-200 mb-3">
                      🛒 Lista della Spesa (da acquistare)
                    </h3>
                    <div className="space-y-3">
                      {ingredients
                        .filter(ing => ing.calculatedQuantity > 0)
                        .map((ingredient, index) => (
                          <div key={index} className="flex justify-between items-center p-2 bg-white dark:bg-gray-800 rounded">
                            <div className="flex flex-col">
                              <span className="text-sm font-medium">{ingredient.name}</span>
                              {ingredient.wastePercentage > 0 && (
                                <span className="text-xs text-gray-500">
                                  (include scarto {ingredient.wastePercentage}%)
                                </span>
                              )}
                            </div>
                            <div className="text-right">
                              <span className="font-bold text-blue-700 dark:text-blue-300">
                                {ingredient.grossQuantity} {ingredient.unit}
                              </span>
                              {ingredient.unit === 'g' && (getDensity(ingredient.name) !== 1.0 || ingredient.name.toLowerCase().includes('acqua')) && (
                                <div className="text-xs text-blue-600 dark:text-blue-400">
                                  ≈ {convertToVolume(ingredient.grossQuantity, ingredient.name)}
                                </div>
                              )}
                              {ingredient.wastePercentage > 0 && (
                                <div className="text-xs text-gray-500">
                                  netto: {ingredient.netQuantity} {ingredient.unit}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                    </div>
                    <div className="mt-3 pt-3 border-t border-blue-200 dark:border-blue-700">
                      <div className="flex justify-between items-center font-semibold">
                        <span>Produzione finale:</span>
                        <span className="text-blue-700 dark:text-blue-300">
                          {targetJars} vasetti da {jarWeight}g
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Sezione Salva come Ricetta */}
              {ingredients.some(ing => ing.netQuantity > 0) && (
                <div className="mt-6 p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg border border-yellow-200 dark:border-yellow-800">
                  <h3 className="font-medium text-yellow-800 dark:text-yellow-200 mb-4">
                    Salva come Ricetta
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Nome Ricetta *</label>
                      <Input
                        value={recipeName}
                        onChange={(e) => setRecipeName(e.target.value)}
                        placeholder="Es: Conserva di Pomodori"
                        className="bg-white dark:bg-gray-700"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Descrizione (opzionale)</label>
                      <Input
                        value={recipeDescription}
                        onChange={(e) => setRecipeDescription(e.target.value)}
                        placeholder="Breve descrizione della ricetta..."
                        className="bg-white dark:bg-gray-700"
                      />
                    </div>
                    <Button 
                      onClick={saveRecipe}
                      disabled={saveRecipeMutation.isPending || !recipeName.trim()}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {saveRecipeMutation.isPending ? "Salvando..." : "Salva Ricetta"}
                    </Button>
                  </div>
                </div>
              )}

              {/* Pulsante Calcola Quantità - Posizionato in fondo */}
              <div className="mt-6 flex justify-center">
                <Button 
                  onClick={calculateQuantities} 
                  className="bg-blue-600 hover:bg-blue-700 px-8 py-3 text-lg font-semibold"
                  size="lg"
                >
                  <Calculator className="h-5 w-5 mr-3" />
                  Calcola Quantità Ingredienti
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default RecipeCalculatorPage;