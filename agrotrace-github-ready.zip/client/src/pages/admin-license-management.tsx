import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Copy, Eye, EyeOff, Key, Users, Calendar, CheckCircle, XCircle, AlertCircle, Ban, Mail, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface LicenseCode {
  id: number;
  code: string;
  planType: string;
  duration: number;
  maxActivations: number;
  currentActivations: number;
  isActive: boolean;
  generatedFor?: string;
  orderReference?: string;
  notes?: string;
  expiresAt?: string;
  generatedAt: string;
  generatedBy?: string;
}

export default function AdminLicenseManagement() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [formData, setFormData] = useState({
    planType: "basic",
    duration: "30",
    maxActivations: "1",
    generatedFor: "",
    orderReference: "",
    notes: "",
    expiresAt: ""
  });
  const [showCodes, setShowCodes] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Controllo accesso admin
  if (authLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Verificando autorizzazioni...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user || user.role !== 'admin') {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <XCircle className="h-6 w-6 text-red-600" />
              </div>
              <CardTitle className="text-red-800">Accesso Negato</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-600">
                Questa pagina è riservata esclusivamente agli amministratori del sistema.
              </p>
              <p className="text-sm text-gray-500">
                Solo utenti con ruolo <span className="font-mono bg-gray-100 px-2 py-1 rounded">admin</span> possono accedere alla gestione licenze.
              </p>
              <div className="pt-4">
                <Button variant="outline" onClick={() => window.history.back()}>
                  Torna Indietro
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Query per ottenere tutti i codici licenza
  const { data: licenseCodes = [], isLoading: codesLoading } = useQuery<LicenseCode[]>({
    queryKey: ["/api/admin/license/codes"],
    enabled: showCodes
  });

  // Mutation per generare un nuovo codice
  const generateMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/admin/license/generate", data),
    onSuccess: (response: any) => {
      toast({
        title: "Codice Generato",
        description: `Nuovo codice: ${response.code}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/license/codes"] });
      
      // Reset form
      setFormData({
        planType: "basic",
        duration: "30",
        maxActivations: "1",
        generatedFor: "",
        orderReference: "",
        notes: "",
        expiresAt: ""
      });
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore nella generazione del codice",
        variant: "destructive"
      });
    }
  });

  // Mutation per disattivare un codice
  const deactivateMutation = useMutation({
    mutationFn: (code: string) => apiRequest("POST", "/api/admin/license/deactivate", { code }),
    onSuccess: () => {
      toast({
        title: "Codice Disattivato",
        description: "Il codice licenza è stato disattivato con successo",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/license/codes"] });
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore nella disattivazione del codice",
        variant: "destructive"
      });
    }
  });

  // Mutation per inviare email
  const sendEmailMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/admin/license/send-email", data),
    onSuccess: () => {
      toast({
        title: "Email Inviata",
        description: "Il codice licenza è stato inviato via email con successo",
      });
    },
    onError: (error: any) => {
      if (error.type === 'authorization_required') {
        toast({
          title: "Autorizzazione Richiesta",
          description: error.message + " Usa il pulsante viola per copiare il contenuto email.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Errore Invio Email",
          description: error.message || "Errore nell'invio dell'email. Usa il pulsante copia contenuto come alternativa.",
          variant: "destructive"
        });
      }
    }
  });

  const handleGenerate = () => {
    if (!formData.planType || !formData.duration) {
      toast({
        title: "Campi Richiesti",
        description: "Piano e durata sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    const data = {
      planType: formData.planType,
      duration: parseInt(formData.duration),
      maxActivations: parseInt(formData.maxActivations),
      generatedFor: formData.generatedFor || undefined,
      orderReference: formData.orderReference || undefined,
      notes: formData.notes || undefined,
      expiresAt: formData.expiresAt ? new Date(formData.expiresAt) : undefined
    };

    generateMutation.mutate(data);
  };

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Copiato",
      description: "Codice copiato negli appunti",
    });
  };

  const handleDeactivate = (code: string) => {
    if (confirm(`Sei sicuro di voler disattivare il codice ${code}? Questa azione non può essere annullata.`)) {
      deactivateMutation.mutate(code);
    }
  };

  const handleSendEmail = (code: LicenseCode) => {
    if (!code.generatedFor) {
      toast({
        title: "Email Mancante",
        description: "Nessuna email specificata per questo codice licenza",
        variant: "destructive"
      });
      return;
    }

    sendEmailMutation.mutate({
      licenseCode: code.code,
      recipientEmail: code.generatedFor,
      recipientName: code.generatedFor.split('@')[0],
      planType: code.planType,
      duration: code.duration
    });
  };

  const handleCopyEmailContent = (code: LicenseCode) => {
    const emailContent = `
Oggetto: La tua licenza AgroTrace Pro è pronta - Piano ${code.planType.toUpperCase()}

Ciao!

La tua licenza AgroTrace Pro è stata generata con successo.

DETTAGLI LICENZA:
• Codice Licenza: ${code.code}
• Piano: ${code.planType.toUpperCase()}
• Durata: ${code.duration} giorni

COME ATTIVARE:
1. Accedi al tuo account AgroTrace Pro
2. Vai nella sezione "Licenza"
3. Inserisci il codice: ${code.code}
4. Clicca su "Attiva Licenza"

Una volta attivata, potrai utilizzare tutte le funzionalità del piano ${code.planType}.

Se hai domande o hai bisogno di assistenza, non esitare a contattarci.

Grazie per aver scelto AgroTrace Pro!
    `.trim();

    navigator.clipboard.writeText(emailContent);
    toast({
      title: "Email Copiata",
      description: "Contenuto email copiato negli appunti. Puoi incollarlo nel tuo client email.",
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPlanBadgeColor = (plan: string) => {
    switch (plan) {
      case 'basic': return 'bg-blue-100 text-blue-800';
      case 'premium': return 'bg-green-100 text-green-800';
      case 'enterprise': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Key className="h-6 w-6 text-blue-600" />
        <h1 className="text-2xl font-bold">Gestione Codici Licenza (Admin)</h1>
      </div>

      {/* Form Generazione Codice */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Genera Nuovo Codice Licenza
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="planType">Tipo Piano *</Label>
              <Select value={formData.planType} onValueChange={(value) => setFormData(prev => ({ ...prev, planType: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona piano" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">Basic</SelectItem>
                  <SelectItem value="premium">Premium</SelectItem>
                  <SelectItem value="enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="duration">Durata (giorni) *</Label>
              <Input
                id="duration"
                type="number"
                value={formData.duration}
                onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
                placeholder="30"
                min="1"
              />
            </div>

            <div>
              <Label htmlFor="maxActivations">Max Attivazioni</Label>
              <Input
                id="maxActivations"
                type="number"
                value={formData.maxActivations}
                onChange={(e) => setFormData(prev => ({ ...prev, maxActivations: e.target.value }))}
                placeholder="1"
                min="1"
              />
            </div>

            <div>
              <Label htmlFor="expiresAt">Scadenza Codice</Label>
              <Input
                id="expiresAt"
                type="datetime-local"
                value={formData.expiresAt}
                onChange={(e) => setFormData(prev => ({ ...prev, expiresAt: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="generatedFor">Generato Per</Label>
              <Input
                id="generatedFor"
                value={formData.generatedFor}
                onChange={(e) => setFormData(prev => ({ ...prev, generatedFor: e.target.value }))}
                placeholder="email@cliente.com"
              />
            </div>

            <div>
              <Label htmlFor="orderReference">Riferimento Ordine</Label>
              <Input
                id="orderReference"
                value={formData.orderReference}
                onChange={(e) => setFormData(prev => ({ ...prev, orderReference: e.target.value }))}
                placeholder="ORD-2025-001"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Note</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Note interne..."
              rows={3}
            />
          </div>

          <Button 
            onClick={handleGenerate} 
            disabled={generateMutation.isPending}
            className="w-full"
          >
            {generateMutation.isPending ? "Generando..." : "Genera Codice Licenza"}
          </Button>
        </CardContent>
      </Card>

      {/* Lista Codici Esistenti */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Codici Licenza Esistenti
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowCodes(!showCodes)}
            >
              {showCodes ? (
                <>
                  <EyeOff className="h-4 w-4 mr-2" />
                  Nascondi
                </>
              ) : (
                <>
                  <Eye className="h-4 w-4 mr-2" />
                  Visualizza
                </>
              )}
            </Button>
          </CardTitle>
        </CardHeader>
        {showCodes && (
          <CardContent>
            {codesLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p>Caricamento codici...</p>
              </div>
            ) : (licenseCodes as LicenseCode[]).length === 0 ? (
              <p className="text-center text-gray-500 py-8">Nessun codice generato</p>
            ) : (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium text-blue-800 mb-1">Invio Email con Brevo</h4>
                      <p className="text-sm text-blue-700 mb-2">
                        Per l'invio automatico, gli indirizzi email devono essere autorizzati nel tuo account Brevo.
                      </p>
                      <div className="text-sm text-blue-700 space-y-1">
                        <p>• <Mail className="inline h-4 w-4 mr-1" /> Invio automatico (solo indirizzi autorizzati)</p>
                        <p>• <FileText className="inline h-4 w-4 mr-1" /> Copia contenuto per invio manuale (sempre disponibile)</p>
                      </div>
                    </div>
                  </div>
                </div>
                {(licenseCodes as LicenseCode[]).map((code: LicenseCode) => (
                  <div key={code.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-lg font-semibold">{code.code}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(code.code)}
                          title="Copia codice"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        {code.generatedFor && code.isActive && (
                          <>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleSendEmail(code)}
                              disabled={sendEmailMutation.isPending}
                              className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                              title={`Invia via email a ${code.generatedFor}`}
                            >
                              <Mail className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleCopyEmailContent(code)}
                              className="text-purple-600 hover:text-purple-700 hover:bg-purple-50"
                              title="Copia contenuto email"
                            >
                              <FileText className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getPlanBadgeColor(code.planType)}>
                          {code.planType.toUpperCase()}
                        </Badge>
                        {code.isActive ? (
                          <>
                            <CheckCircle className="h-5 w-5 text-green-600" />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeactivate(code.code)}
                              disabled={deactivateMutation.isPending}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Ban className="h-4 w-4 mr-1" />
                              Disattiva
                            </Button>
                          </>
                        ) : (
                          <div className="flex items-center gap-2">
                            <XCircle className="h-5 w-5 text-red-600" />
                            <span className="text-sm text-red-600 font-medium">Disattivato</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Durata:</span>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {code.duration} giorni
                        </div>
                      </div>
                      <div>
                        <span className="text-gray-600">Attivazioni:</span>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {code.currentActivations} / {code.maxActivations}
                        </div>
                      </div>
                      <div>
                        <span className="text-gray-600">Creato:</span>
                        <div>{formatDate(code.generatedAt)}</div>
                      </div>
                    </div>

                    {(code.generatedFor || code.orderReference || code.notes) && (
                      <div className="border-t pt-3 space-y-1 text-sm">
                        {code.generatedFor && (
                          <div><span className="text-gray-600">Cliente:</span> {code.generatedFor}</div>
                        )}
                        {code.orderReference && (
                          <div><span className="text-gray-600">Ordine:</span> {code.orderReference}</div>
                        )}
                        {code.notes && (
                          <div><span className="text-gray-600">Note:</span> {code.notes}</div>
                        )}
                      </div>
                    )}

                    {code.expiresAt && (
                      <div className="flex items-center gap-1 text-sm text-orange-600">
                        <AlertCircle className="h-4 w-4" />
                        Scade il: {formatDate(code.expiresAt)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        )}
      </Card>
    </div>
  );
}