import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  Beaker, 
  Thermometer, 
  Droplet, 
  Eye, 
  Scale,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Calendar,
  User,
  Building,
  TrendingUp,
  BarChart3
} from "lucide-react";
import { Link } from "wouter";

export default function QualityControlExamplePage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Dati reali per esempio passata di pomodoro
  const recipeQualityTargets = {
    ph: { min: 4.0, max: 4.5, unit: "pH" },
    brix: { min: 5.5, max: 6.0, unit: "°Brix" },
    temperature: { min: 80, max: 90, unit: "°C" },
    viscosity: { target: "Standard", description: "Consistenza tipica passata" },
    color: { target: "Rosso intenso", description: "Colore pomodoro maturo" },
    custom: [
      { name: "Licopene", min: 50, max: 80, unit: "mg/kg" },
      { name: "Acidità titolabile", min: 0.35, max: 0.45, unit: "%" }
    ]
  };

  const batchQualityControls = {
    ph: { 
      value: 4.2, 
      status: "OK" as const, 
      measuredAt: "2024-06-11T10:30:00Z", 
      operator: "Mario Rossi" 
    },
    brix: { 
      value: 5.8, 
      status: "OK" as const, 
      measuredAt: "2024-06-11T10:32:00Z", 
      operator: "Mario Rossi" 
    },
    temperature: { 
      value: 85, 
      status: "OK" as const, 
      measuredAt: "2024-06-11T09:45:00Z", 
      operator: "Mario Rossi" 
    },
    viscosity: { 
      value: "Standard", 
      status: "OK" as const, 
      measuredAt: "2024-06-11T11:00:00Z", 
      operator: "Laura Bianchi" 
    },
    color: { 
      value: "Conforme", 
      status: "OK" as const, 
      measuredAt: "2024-06-11T11:15:00Z", 
      operator: "Laura Bianchi" 
    },
    custom: [
      {
        name: "Licopene",
        value: 65,
        unit: "mg/kg",
        status: "OK" as const,
        measuredAt: "2024-06-11T14:30:00Z",
        operator: "Lab Qualità",
        notes: "Analisi laboratorio esterno"
      },
      {
        name: "Acidità titolabile",
        value: 0.38,
        unit: "%",
        status: "OK" as const,
        measuredAt: "2024-06-11T14:45:00Z",
        operator: "Lab Qualità"
      }
    ]
  };

  const productionDetails = {
    facility: "Stabilimento Pachino",
    productionLine: "Linea A - Conserve",
    operator: "Mario Rossi",
    equipmentUsed: ["Pastorizzatore P1", "Riempitrice R2", "Sigillatrice S1"],
    processingTemperature: 85,
    processingTime: 45,
    yieldPercentage: 92.5,
    qualityGrade: "Premium"
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'OK': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'WARNING': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'FAIL': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OK': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'WARNING': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'FAIL': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateConformityPercentage = () => {
    const totalTests = 7; // 5 standard + 2 custom
    const passedTests = 7; // Tutti OK in questo esempio
    return Math.round((passedTests / totalTests) * 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Home
              </Button>
            </Link>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="bg-green-50 dark:bg-green-900">
                <Beaker className="w-3 h-3 mr-1" />
                Controlli Qualità
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Intestazione */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Controlli Qualità - Esempio Reale
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Sistema di controllo qualità per "Passata di Pomodoro Biologica" con parametri reali dell'industria agroalimentare
          </p>
        </div>

        {/* Riepilogo Conformità */}
        <Card className="mb-8 border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Riepilogo Conformità Qualità
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-1">
                  {calculateConformityPercentage()}%
                </div>
                <div className="text-sm text-gray-600">Conformità Totale</div>
                <Progress value={calculateConformityPercentage()} className="mt-2" />
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-1">7</div>
                <div className="text-sm text-gray-600">Test Superati</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-400 mb-1">0</div>
                <div className="text-sm text-gray-600">Warning</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-400 mb-1">0</div>
                <div className="text-sm text-gray-600">Non Conformi</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Parametri Target Ricetta */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-blue-600" />
                Parametri Target Ricetta
              </CardTitle>
              <p className="text-sm text-gray-600">
                Specifiche qualità definite nella ricetta "Passata di Pomodoro Biologica"
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* pH Target */}
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <Droplet className="w-4 h-4 text-blue-600" />
                  <div>
                    <div className="font-medium">pH</div>
                    <div className="text-sm text-gray-600">Acidità</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">{recipeQualityTargets.ph.min} - {recipeQualityTargets.ph.max}</div>
                  <div className="text-sm text-gray-600">{recipeQualityTargets.ph.unit}</div>
                </div>
              </div>

              {/* Brix Target */}
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <Beaker className="w-4 h-4 text-orange-600" />
                  <div>
                    <div className="font-medium">Grado Brix</div>
                    <div className="text-sm text-gray-600">Concentrazione zuccheri</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">{recipeQualityTargets.brix.min} - {recipeQualityTargets.brix.max}</div>
                  <div className="text-sm text-gray-600">{recipeQualityTargets.brix.unit}</div>
                </div>
              </div>

              {/* Temperatura Target */}
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <Thermometer className="w-4 h-4 text-red-600" />
                  <div>
                    <div className="font-medium">Temperatura</div>
                    <div className="text-sm text-gray-600">Pastorizzazione</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">{recipeQualityTargets.temperature.min} - {recipeQualityTargets.temperature.max}</div>
                  <div className="text-sm text-gray-600">{recipeQualityTargets.temperature.unit}</div>
                </div>
              </div>

              {/* Viscosità Target */}
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <Scale className="w-4 h-4 text-purple-600" />
                  <div>
                    <div className="font-medium">Viscosità</div>
                    <div className="text-sm text-gray-600">Consistenza</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">{recipeQualityTargets.viscosity.target}</div>
                  <div className="text-sm text-gray-600">Standard</div>
                </div>
              </div>

              {/* Colore Target */}
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <Eye className="w-4 h-4 text-green-600" />
                  <div>
                    <div className="font-medium">Colore</div>
                    <div className="text-sm text-gray-600">Aspetto visivo</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">{recipeQualityTargets.color.target}</div>
                  <div className="text-sm text-gray-600">Tipico</div>
                </div>
              </div>

              <Separator className="my-4" />
              
              {/* Parametri Custom */}
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700 dark:text-gray-300">Parametri Specifici</h4>
                {recipeQualityTargets.custom.map((param, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                    <div className="font-medium text-sm">{param.name}</div>
                    <div className="text-sm">{param.min} - {param.max} {param.unit}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Controlli Effettivi Lotto */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Controlli Effettivi Lotto
              </CardTitle>
              <p className="text-sm text-gray-600">
                Misurazioni reali durante la produzione del lotto BT-240611-001
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* pH Misurato */}
              <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <Droplet className="w-4 h-4 text-blue-600" />
                  <div>
                    <div className="font-medium">pH</div>
                    <div className="text-xs text-gray-600">
                      Target: {recipeQualityTargets.ph.min}-{recipeQualityTargets.ph.max}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{batchQualityControls.ph.value}</span>
                    <Badge className={getStatusColor(batchQualityControls.ph.status)}>
                      {getStatusIcon(batchQualityControls.ph.status)}
                      {batchQualityControls.ph.status}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-600">
                    {new Date(batchQualityControls.ph.measuredAt).toLocaleString('it-IT')}
                  </div>
                </div>
              </div>

              {/* Brix Misurato */}
              <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <Beaker className="w-4 h-4 text-orange-600" />
                  <div>
                    <div className="font-medium">Grado Brix</div>
                    <div className="text-xs text-gray-600">
                      Target: {recipeQualityTargets.brix.min}-{recipeQualityTargets.brix.max}°
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{batchQualityControls.brix.value}°</span>
                    <Badge className={getStatusColor(batchQualityControls.brix.status)}>
                      {getStatusIcon(batchQualityControls.brix.status)}
                      {batchQualityControls.brix.status}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-600">
                    {new Date(batchQualityControls.brix.measuredAt).toLocaleString('it-IT')}
                  </div>
                </div>
              </div>

              {/* Temperatura Misurata */}
              <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <Thermometer className="w-4 h-4 text-red-600" />
                  <div>
                    <div className="font-medium">Temperatura</div>
                    <div className="text-xs text-gray-600">
                      Target: {recipeQualityTargets.temperature.min}-{recipeQualityTargets.temperature.max}°C
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{batchQualityControls.temperature.value}°C</span>
                    <Badge className={getStatusColor(batchQualityControls.temperature.status)}>
                      {getStatusIcon(batchQualityControls.temperature.status)}
                      {batchQualityControls.temperature.status}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-600">
                    {new Date(batchQualityControls.temperature.measuredAt).toLocaleString('it-IT')}
                  </div>
                </div>
              </div>

              {/* Viscosità Misurata */}
              <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <Scale className="w-4 h-4 text-purple-600" />
                  <div>
                    <div className="font-medium">Viscosità</div>
                    <div className="text-xs text-gray-600">
                      Target: {recipeQualityTargets.viscosity.target}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{batchQualityControls.viscosity.value}</span>
                    <Badge className={getStatusColor(batchQualityControls.viscosity.status)}>
                      {getStatusIcon(batchQualityControls.viscosity.status)}
                      {batchQualityControls.viscosity.status}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-600">
                    {new Date(batchQualityControls.viscosity.measuredAt).toLocaleString('it-IT')}
                  </div>
                </div>
              </div>

              {/* Colore Misurato */}
              <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <Eye className="w-4 h-4 text-green-600" />
                  <div>
                    <div className="font-medium">Colore</div>
                    <div className="text-xs text-gray-600">
                      Target: {recipeQualityTargets.color.target}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{batchQualityControls.color.value}</span>
                    <Badge className={getStatusColor(batchQualityControls.color.status)}>
                      {getStatusIcon(batchQualityControls.color.status)}
                      {batchQualityControls.color.status}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-600">
                    {new Date(batchQualityControls.color.measuredAt).toLocaleString('it-IT')}
                  </div>
                </div>
              </div>

              <Separator className="my-4" />
              
              {/* Controlli Custom */}
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700 dark:text-gray-300">Analisi Laboratorio</h4>
                {batchQualityControls.custom.map((control, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded">
                    <div>
                      <div className="font-medium text-sm">{control.name}</div>
                      {control.notes && (
                        <div className="text-xs text-gray-600">{control.notes}</div>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{control.value} {control.unit}</span>
                        <Badge className={getStatusColor(control.status)}>
                          {getStatusIcon(control.status)}
                          {control.status}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-600">{control.operator}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Dettagli Produzione */}
        <Card className="mt-8 border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="w-5 h-5 text-gray-600" />
              Dettagli Produzione e Tracciabilità
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <div className="text-sm text-gray-600">Stabilimento</div>
                <div className="font-medium">{productionDetails.facility}</div>
              </div>
              <div className="space-y-2">
                <div className="text-sm text-gray-600">Linea Produttiva</div>
                <div className="font-medium">{productionDetails.productionLine}</div>
              </div>
              <div className="space-y-2">
                <div className="text-sm text-gray-600">Operatore Principale</div>
                <div className="font-medium flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {productionDetails.operator}
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm text-gray-600">Resa Produzione</div>
                <div className="font-medium flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-green-600" />
                  {productionDetails.yieldPercentage}%
                </div>
              </div>
            </div>
            
            <Separator className="my-4" />
            
            <div className="space-y-3">
              <div>
                <div className="text-sm text-gray-600 mb-1">Attrezzature Utilizzate</div>
                <div className="flex flex-wrap gap-2">
                  {productionDetails.equipmentUsed.map((equipment, index) => (
                    <Badge key={index} variant="outline">{equipment}</Badge>
                  ))}
                </div>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-gray-600">Temperatura Processo</div>
                  <div className="font-medium">{productionDetails.processingTemperature}°C</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Tempo Processo</div>
                  <div className="font-medium">{productionDetails.processingTime} min</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Grado Qualità</div>
                  <div className="font-medium">
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      {productionDetails.qualityGrade}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="mt-8 border-l-4 border-l-blue-500 bg-blue-50 dark:bg-blue-900/20">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Beaker className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                  Parametri Reali dell'Industria Agroalimentare
                </h3>
                <p className="text-blue-800 dark:text-blue-200 text-sm leading-relaxed">
                  Tutti i parametri mostrati sono basati su standard reali utilizzati nell'industria di trasformazione del pomodoro:
                  pH per sicurezza microbiologica, Grado Brix per concentrazione, temperatura di pastorizzazione per conservazione,
                  e controlli qualità organolettici per conformità prodotto. Il sistema supporta sia parametri standard che personalizzati
                  per ogni esigenza produttiva specifica.
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge variant="outline" className="text-xs">HACCP Compatibile</Badge>
                  <Badge variant="outline" className="text-xs">ISO 22000</Badge>
                  <Badge variant="outline" className="text-xs">Certificazioni BIO</Badge>
                  <Badge variant="outline" className="text-xs">Export Ready</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Implementa controlli qualità professionali nella tua produzione
          </p>
          <div className="flex justify-center gap-3">
            <Link href="/register">
              <Button size="lg">
                Inizia Prova Gratuita
              </Button>
            </Link>
            <Link href="/documentation">
              <Button variant="outline" size="lg">
                Documentazione Tecnica
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}