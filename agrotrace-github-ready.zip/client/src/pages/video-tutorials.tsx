import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Video, Clock, User, Star } from "lucide-react";
import { Link } from "wouter";

export default function VideoTutorialsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/documentation">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Documentazione
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Inizia Ora
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center mx-auto mb-6">
            <Video className="w-8 h-8 text-red-600 dark:text-red-400" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Video Tutorial
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Tutorial video passo-passo per padroneggiare tutte le funzionalità di AgroTrace Pro
          </p>
          
          {/* Coming Soon Card */}
          <Card className="max-w-2xl mx-auto border-2 border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-900/20">
            <CardHeader>
              <div className="flex items-center justify-center gap-3">
                <Badge variant="secondary" className="bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200">
                  In Arrivo
                </Badge>
                <Clock className="w-5 h-5 text-orange-600" />
              </div>
              <CardTitle className="text-2xl text-orange-900 dark:text-orange-100">
                Questa funzione verrà implementata a breve
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-orange-800 dark:text-orange-200 mb-6">
                Stiamo preparando una libreria completa di video tutorial professionali per aiutarti 
                a utilizzare al meglio tutte le funzionalità di AgroTrace Pro.
              </p>
              
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mb-6">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Video in Programma:</h3>
                <div className="grid gap-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Video className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">Setup Iniziale e Configurazione</span>
                    </div>
                    <Badge variant="outline">5 min</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Video className="w-4 h-4 text-green-600" />
                      <span className="font-medium">Creazione e Gestione Ricette</span>
                    </div>
                    <Badge variant="outline">8 min</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Video className="w-4 h-4 text-purple-600" />
                      <span className="font-medium">Produzione Lotti e Tracciabilità</span>
                    </div>
                    <Badge variant="outline">6 min</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Video className="w-4 h-4 text-orange-600" />
                      <span className="font-medium">Generazione QR Code e Etichette</span>
                    </div>
                    <Badge variant="outline">7 min</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Video className="w-4 h-4 text-teal-600" />
                      <span className="font-medium">Gestione Inventario e Alert</span>
                    </div>
                    <Badge variant="outline">9 min</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Video className="w-4 h-4 text-red-600" />
                      <span className="font-medium">Dashboard e Report Avanzati</span>
                    </div>
                    <Badge variant="outline">10 min</Badge>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-blue-900 dark:text-blue-100">Caratteristiche dei Video:</span>
                </div>
                <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                  <li>• Qualità HD con audio cristallino</li>
                  <li>• Sottotitoli in italiano</li>
                  <li>• Esempi pratici con dati reali</li>
                  <li>• Scaricabili per visualizzazione offline</li>
                  <li>• Aggiornati con ogni nuova funzionalità</li>
                </ul>
              </div>

              <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                <strong>Notifica di Disponibilità:</strong> Ti invieremo un'email non appena i video tutorial saranno pronti. 
                Nel frattempo, puoi utilizzare la nostra guida rapida testuale e gli esempi interattivi.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Alternative Resources */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
            Risorse Disponibili Ora
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-green-600" />
                  Guida Rapida Testuale
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Guida passo-passo completa per iniziare subito con AgroTrace Pro.
                </p>
                <Link href="/quick-guide">
                  <Button className="w-full">
                    Leggi la Guida
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Video className="w-5 h-5 text-blue-600" />
                  Esempi Interattivi
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Esplora le funzionalità con esempi reali e dati di dimostrazione.
                </p>
                <Link href="/recipe-example">
                  <Button variant="outline" className="w-full">
                    Vedi Esempi
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Non Aspettare i Video
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Inizia subito con la guida testuale e gli esempi pratici. 
            Il sistema è intuitivo e sarai operativo in pochi minuti.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                Inizia Subito
              </Button>
            </Link>
            <Link href="/quick-guide">
              <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                Guida Rapida
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}