import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Code, Key, Globe, Webhook, Download, Shield } from "lucide-react";
import { Link } from "wouter";

export default function APIDocsPage() {
  const endpoints = [
    {
      method: "GET",
      path: "/api/recipes",
      description: "Recupera tutte le ricette dell'utente",
      auth: "Bearer Token",
      response: "Array di oggetti Recipe"
    },
    {
      method: "POST",
      path: "/api/recipes",
      description: "Crea una nuova ricetta",
      auth: "Bearer Token",
      response: "Oggetto Recipe creato"
    },
    {
      method: "GET",
      path: "/api/batches",
      description: "Lista tutti i lotti di produzione",
      auth: "Bearer Token",
      response: "Array di oggetti Batch"
    },
    {
      method: "POST",
      path: "/api/batches",
      description: "Crea un nuovo lotto di produzione",
      auth: "Bearer Token",
      response: "Oggetto Batch creato"
    },
    {
      method: "GET",
      path: "/api/inventory",
      description: "Inventario completo ingredienti",
      auth: "Bearer Token",
      response: "Array di oggetti Inventory"
    },
    {
      method: "GET",
      path: "/api/qr-labels",
      description: "Lista etichette QR generate",
      auth: "Bearer Token",
      response: "Array di oggetti QRLabel"
    },
    {
      method: "GET",
      path: "/api/tracciabilita/:code",
      description: "Informazioni pubbliche tracciabilità",
      auth: "Nessuna",
      response: "Oggetto TraceabilityData"
    }
  ];

  const sdkLanguages = [
    {
      name: "JavaScript/Node.js",
      code: `const agrotrace = require('@agrotrace/sdk');
const client = new agrotrace.Client('your-api-key');

// Recupera tutte le ricette
const recipes = await client.recipes.list();

// Crea una nuova ricetta
const recipe = await client.recipes.create({
  name: "Passata di Pomodoro",
  ingredients: [...],
  instructions: [...]
});`
    },
    {
      name: "Python",
      code: `import agrotrace

client = agrotrace.Client('your-api-key')

# Recupera tutte le ricette
recipes = client.recipes.list()

# Crea una nuova ricetta
recipe = client.recipes.create({
    'name': 'Passata di Pomodoro',
    'ingredients': [...],
    'instructions': [...]
})`
    },
    {
      name: "PHP",
      code: `<?php
require_once 'vendor/autoload.php';

$client = new AgroTrace\\Client('your-api-key');

// Recupera tutte le ricette
$recipes = $client->recipes->list();

// Crea una nuova ricetta
$recipe = $client->recipes->create([
    'name' => 'Passata di Pomodoro',
    'ingredients' => [...],
    'instructions' => [...]
]);`
    }
  ];

  const webhookEvents = [
    {
      event: "batch.created",
      description: "Nuovo lotto di produzione creato",
      payload: "Dati completi del lotto appena creato"
    },
    {
      event: "inventory.low_stock",
      description: "Scorte sotto soglia minima",
      payload: "Dettagli ingrediente e livelli attuali"
    },
    {
      event: "qr.generated",
      description: "Nuova etichetta QR generata",
      payload: "Informazioni etichetta e lotto collegato"
    },
    {
      event: "backup.completed",
      description: "Backup automatico completato",
      payload: "Timestamp e dimensioni backup"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-green-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/documentation">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Torna alla Documentazione
              </Button>
            </Link>
            <Link href="/login">
              <Button className="bg-green-600 hover:bg-green-700">
                Ottieni API Key
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mx-auto mb-6">
            <Code className="w-8 h-8 text-orange-600 dark:text-orange-400" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            API e Integrazioni
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Documentazione completa per integrare AgroTrace Pro nei tuoi sistemi
          </p>
          
          <div className="flex justify-center gap-4 mb-8">
            <Badge variant="secondary" className="bg-green-100 text-green-800 px-4 py-2">
              <Globe className="w-4 h-4 mr-2" />
              REST API
            </Badge>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 px-4 py-2">
              <Webhook className="w-4 h-4 mr-2" />
              Webhooks
            </Badge>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800 px-4 py-2">
              <Shield className="w-4 h-4 mr-2" />
              OAuth 2.0
            </Badge>
          </div>
        </div>

        {/* Authentication */}
        <Card className="mb-12 border-2 border-green-200 dark:border-green-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="w-6 h-6 text-green-600" />
              Autenticazione
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">API Key</h4>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Disponibile solo per utenti con piano Professional. Genera la tua API key dalla dashboard account.
                </p>
                <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
                  <code className="text-sm">
                    Authorization: Bearer your-api-key-here
                  </code>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Rate Limiting</h4>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                  <li>• 1000 richieste/ora per piano Professional</li>
                  <li>• 100 richieste/ora per piano Basic</li>
                  <li>• Headers di risposta includono limiti attuali</li>
                  <li>• Errore 429 se limite superato</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Endpoints */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Endpoint Principali
          </h2>
          <div className="space-y-4">
            {endpoints.map((endpoint, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <Badge 
                      variant="outline" 
                      className={
                        endpoint.method === 'GET' ? 'bg-blue-100 text-blue-800 border-blue-200' :
                        endpoint.method === 'POST' ? 'bg-green-100 text-green-800 border-green-200' :
                        'bg-orange-100 text-orange-800 border-orange-200'
                      }
                    >
                      {endpoint.method}
                    </Badge>
                    <code className="text-lg font-mono">{endpoint.path}</code>
                  </div>
                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Descrizione:</span>
                      <p className="text-gray-600 dark:text-gray-300">{endpoint.description}</p>
                    </div>
                    <div>
                      <span className="font-medium">Autenticazione:</span>
                      <p className="text-gray-600 dark:text-gray-300">{endpoint.auth}</p>
                    </div>
                    <div>
                      <span className="font-medium">Risposta:</span>
                      <p className="text-gray-600 dark:text-gray-300">{endpoint.response}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* SDK Examples */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            SDK e Esempi di Codice
          </h2>
          <div className="space-y-6">
            {sdkLanguages.map((lang, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle>{lang.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                    <pre className="text-sm">
                      <code>{lang.code}</code>
                    </pre>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Webhooks */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Webhook Notifications
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {webhookEvents.map((webhook, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Webhook className="w-5 h-5 text-purple-600" />
                    {webhook.event}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300 mb-3">{webhook.description}</p>
                  <div className="text-sm">
                    <span className="font-medium">Payload: </span>
                    <span className="text-gray-600 dark:text-gray-300">{webhook.payload}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Schema Documentation */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-6 h-6 text-blue-600" />
              Schema e Documentazione
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">OpenAPI Specification</h4>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Schema completo OpenAPI 3.0 con tutti gli endpoint, parametri e modelli dati.
                </p>
                <Button variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Scarica Schema OpenAPI
                </Button>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Postman Collection</h4>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Collection Postman completa per testare tutti gli endpoint API rapidamente.
                </p>
                <Button variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Importa in Postman
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Access Requirements */}
        <Card className="border-2 border-yellow-200 dark:border-yellow-800 bg-yellow-50 dark:bg-yellow-900/20 mb-12">
          <CardHeader>
            <CardTitle className="text-yellow-900 dark:text-yellow-100">
              Requisiti di Accesso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">Piano Professional Richiesto</h4>
                <ul className="space-y-2 text-sm text-yellow-800 dark:text-yellow-200">
                  <li>• Accesso completo alle API REST</li>
                  <li>• Generazione e gestione API keys</li>
                  <li>• Configurazione webhook endpoints</li>
                  <li>• Download documentazione tecnica</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Supporto Tecnico</h4>
                <ul className="space-y-2 text-sm text-yellow-800 dark:text-yellow-200">
                  <li>• Supporto prioritario via email</li>
                  <li>• Assistenza integrazione personalizzata</li>
                  <li>• Documentazione aggiornata in tempo reale</li>
                  <li>• Esempi di codice e best practices</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center bg-white/80 dark:bg-gray-800/80 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Inizia l'Integrazione
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Upgrade al piano Professional per accesso completo alle API
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                Upgrade al Professional
              </Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                Contatta il Team Tecnico
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}