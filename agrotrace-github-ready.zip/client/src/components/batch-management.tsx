import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { insertBatchSchema, type Batch, type InsertBatch, type Recipe } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  Package, 
  Calendar, 
  Clock, 
  Filter,
  Save,
  QrCode,
  Beaker,
  CheckCircle,
  AlertTriangle,
  XCircle,
  ChevronDown,
  ChevronUp,
  FlaskConical
} from "lucide-react";
import { trackEvent } from "@/lib/analytics";

const batchFormSchema = z.object({
  code: z.string().optional(),
  recipeId: z.string().optional(),
  productName: z.string().min(1, "Nome prodotto richiesto"),
  quantity: z.string().min(1, "Quantità richiesta"),
  unit: z.string().min(1, "Unità richiesta"),
  status: z.string().optional(),
  productionDate: z.string().min(1, "Data di produzione richiesta"),
  expiryDate: z.string().optional(),
  salePrice: z.string().optional(),
  notes: z.string().optional(),
  qrCode: z.string().optional()
});

type BatchFormData = z.infer<typeof batchFormSchema>;

const QualityControlForm = ({ batch, onSave }: { batch: Batch; onSave: (qualityData: any) => void }) => {
  const [formData, setFormData] = useState({
    ph: { value: '', operator: '', notes: '' },
    brix: { value: '', operator: '', notes: '' },
    temperature: { value: '', operator: '', notes: '' },
    viscosity: { value: '', operator: '', notes: '' },
    color: { value: '', operator: '', notes: '' }
  });

  const handleInputChange = (parameter: keyof typeof formData, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [parameter]: {
        ...prev[parameter],
        [field]: value
      }
    }));
  };

  const evaluateStatus = (parameter: string, value: string | number): 'OK' | 'WARNING' | 'FAIL' => {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    
    switch (parameter) {
      case 'ph':
        if (numValue >= 4.0 && numValue <= 4.5) return 'OK';
        if (numValue >= 3.8 && numValue <= 4.7) return 'WARNING';
        return 'FAIL';
      case 'brix':
        if (numValue >= 5.5 && numValue <= 6.0) return 'OK';
        if (numValue >= 5.0 && numValue <= 6.5) return 'WARNING';
        return 'FAIL';
      case 'temperature':
        if (numValue >= 80 && numValue <= 90) return 'OK';
        if (numValue >= 75 && numValue <= 95) return 'WARNING';
        return 'FAIL';
      case 'viscosity':
        return value === 'Standard' ? 'OK' : value === 'Normale' ? 'WARNING' : 'FAIL';
      case 'color':
        return value === 'Conforme' ? 'OK' : value === 'Parzialmente conforme' ? 'WARNING' : 'FAIL';
      default:
        return 'OK';
    }
  };

  const handleSubmit = () => {
    const qualityControls = Object.entries(formData).reduce((acc, [key, data]) => {
      if (data.value) {
        acc[key] = {
          value: key === 'ph' || key === 'brix' || key === 'temperature' ? parseFloat(data.value) : data.value,
          status: evaluateStatus(key, data.value),
          measuredAt: new Date().toISOString(),
          operator: data.operator || 'Operatore',
          notes: data.notes
        };
      }
      return acc;
    }, {} as any);

    onSave({ qualityControls });
  };

  return (
    <div className="space-y-4 p-4 border rounded-lg bg-gray-50 dark:bg-gray-800">
      <div className="flex items-center justify-between">
        <h4 className="font-medium flex items-center gap-2">
          <FlaskConical className="w-4 h-4" />
          Inserisci Controlli Qualità
        </h4>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {/* pH */}
        <div className="space-y-2">
          <label className="text-sm font-medium">pH (Target: 4.0-4.5)</label>
          <Input
            type="number"
            step="0.1"
            placeholder="Es. 4.2"
            value={formData.ph.value}
            onChange={(e) => handleInputChange('ph', 'value', e.target.value)}
          />
        </div>

        {/* Grado Brix */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Grado Brix (Target: 5.5-6.0°)</label>
          <Input
            type="number"
            step="0.1"
            placeholder="Es. 5.8"
            value={formData.brix.value}
            onChange={(e) => handleInputChange('brix', 'value', e.target.value)}
          />
        </div>

        {/* Temperatura */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Temperatura (Target: 80-90°C)</label>
          <Input
            type="number"
            placeholder="Es. 85"
            value={formData.temperature.value}
            onChange={(e) => handleInputChange('temperature', 'value', e.target.value)}
          />
        </div>

        {/* Viscosità */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Viscosità</label>
          <Select value={formData.viscosity.value} onValueChange={(value) => handleInputChange('viscosity', 'value', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Seleziona viscosità" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Liquida">Liquida</SelectItem>
              <SelectItem value="Normale">Normale</SelectItem>
              <SelectItem value="Standard">Standard</SelectItem>
              <SelectItem value="Densa">Densa</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Colore */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Colore</label>
          <Select value={formData.color.value} onValueChange={(value) => handleInputChange('color', 'value', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Valutazione colore" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Conforme">Conforme</SelectItem>
              <SelectItem value="Parzialmente conforme">Parzialmente conforme</SelectItem>
              <SelectItem value="Non conforme">Non conforme</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Operatore */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Operatore</label>
          <Input
            placeholder="Nome operatore"
            value={formData.ph.operator}
            onChange={(e) => {
              // Applica lo stesso operatore a tutti i controlli
              const keys: (keyof typeof formData)[] = ['ph', 'brix', 'temperature', 'viscosity', 'color'];
              keys.forEach(key => {
                handleInputChange(key, 'operator', e.target.value);
              });
            }}
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Note Generali</label>
        <Textarea
          placeholder="Note sui controlli qualità..."
          rows={2}
          value={formData.ph.notes}
          onChange={(e) => {
            // Applica le stesse note a tutti i controlli
            const keys: (keyof typeof formData)[] = ['ph', 'brix', 'temperature', 'viscosity', 'color'];
            keys.forEach(key => {
              handleInputChange(key, 'notes', e.target.value);
            });
          }}
        />
      </div>

      <div className="flex gap-2">
        <Button onClick={handleSubmit} size="sm" className="flex-1">
          <Save className="w-3 h-3 mr-1" />
          Salva Controlli
        </Button>
      </div>
    </div>
  );
};

const QualityControlsDisplay = ({ batch, onUpdate }: { batch: Batch; onUpdate: () => void }) => {
  const [showQuality, setShowQuality] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Controlli qualità reali dal database del lotto
  const qualityControls = batch.qualityControls;

  // Form data for quality controls
  const [formData, setFormData] = useState({
    ph: { value: '', status: 'OK' as 'OK' | 'WARNING' | 'FAIL', operator: '', notes: '', timestamp: new Date().toISOString() },
    brix: { value: '', status: 'OK' as 'OK' | 'WARNING' | 'FAIL', operator: '', notes: '', timestamp: new Date().toISOString() },
    temperature: { value: '', status: 'OK' as 'OK' | 'WARNING' | 'FAIL', operator: '', notes: '', timestamp: new Date().toISOString() },
    viscosity: { value: '', status: 'OK' as 'OK' | 'WARNING' | 'FAIL', operator: '', notes: '', timestamp: new Date().toISOString() },
    color: { value: '', status: 'OK' as 'OK' | 'WARNING' | 'FAIL', operator: '', notes: '', timestamp: new Date().toISOString() }
  });

  // Load existing quality controls when form opens
  useEffect(() => {
    if (showForm && qualityControls) {
      setFormData({
        ph: qualityControls.ph || { value: '', status: 'OK' as const, operator: '', notes: '', timestamp: new Date().toISOString() },
        brix: qualityControls.brix || { value: '', status: 'OK' as const, operator: '', notes: '', timestamp: new Date().toISOString() },
        temperature: qualityControls.temperature || { value: '', status: 'OK' as const, operator: '', notes: '', timestamp: new Date().toISOString() },
        viscosity: qualityControls.viscosity || { value: '', status: 'OK' as const, operator: '', notes: '', timestamp: new Date().toISOString() },
        color: qualityControls.color || { value: '', status: 'OK' as const, operator: '', notes: '', timestamp: new Date().toISOString() }
      });
    }
  }, [showForm, qualityControls]);

  // Handle input changes and automatic status evaluation
  const handleInputChange = (parameter: keyof typeof formData, field: string, value: string) => {
    setFormData(prev => {
      const updated = { ...prev };
      (updated[parameter] as any)[field] = value;
      
      // Auto-evaluate status based on value
      if (field === 'value') {
        let newStatus: 'OK' | 'WARNING' | 'FAIL' = 'OK';
        
        if (parameter === 'ph') {
          const numValue = parseFloat(value);
          if (numValue >= 4.0 && numValue <= 4.5) newStatus = 'OK';
          else if ((numValue >= 3.8 && numValue < 4.0) || (numValue > 4.5 && numValue <= 4.7)) newStatus = 'WARNING';
          else newStatus = 'FAIL';
        } else if (parameter === 'brix') {
          const numValue = parseFloat(value);
          if (numValue >= 5.5 && numValue <= 6.0) newStatus = 'OK';
          else if ((numValue >= 5.0 && numValue < 5.5) || (numValue > 6.0 && numValue <= 6.5)) newStatus = 'WARNING';
          else newStatus = 'FAIL';
        } else if (parameter === 'temperature') {
          const numValue = parseFloat(value);
          if (numValue >= 80 && numValue <= 90) newStatus = 'OK';
          else if ((numValue >= 75 && numValue < 80) || (numValue > 90 && numValue <= 95)) newStatus = 'WARNING';
          else newStatus = 'FAIL';
        } else if (parameter === 'viscosity') {
          if (value === 'Standard' || value === 'Normale') newStatus = 'OK';
          else if (value === 'Liquida') newStatus = 'WARNING';
          else newStatus = 'FAIL';
        } else if (parameter === 'color') {
          if (value === 'Conforme' || value === 'Eccellente') newStatus = 'OK';
          else newStatus = 'FAIL';
        }
        
        updated[parameter].status = newStatus;
      }
      
      return updated;
    });
  };

  const updateQualityMutation = useMutation({
    mutationFn: async (qualityData: any) => {
      return apiRequest('POST', `/api/batches/${batch.id}/quality-controls`, qualityData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/batches'] });
      toast({
        title: "Controlli qualità salvati",
        description: "I controlli qualità sono stati aggiornati con successo"
      });
      setShowForm(false);
      onUpdate();
    },
    onError: () => {
      toast({
        title: "Errore",
        description: "Impossibile salvare i controlli qualità",
        variant: "destructive"
      });
    }
  });

  const handleSaveQuality = () => {
    updateQualityMutation.mutate(formData);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'OK': return <CheckCircle className="w-3 h-3 text-green-600" />;
      case 'WARNING': return <AlertTriangle className="w-3 h-3 text-yellow-600" />;
      case 'FAIL': return <XCircle className="w-3 h-3 text-red-600" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OK': return 'text-green-600';
      case 'WARNING': return 'text-yellow-600';
      case 'FAIL': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const hasQualityData = qualityControls && Object.keys(qualityControls).length > 0;

  if (showForm) {
    return (
      <div className="border-t pt-3 mt-3 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-medium">Inserimento Controlli Qualità</h4>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowForm(false)}
            className="text-xs"
          >
            Annulla
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* pH */}
          <div className="space-y-2">
            <Label className="text-xs">pH (Target: 4.0-4.5)</Label>
            <Input
              type="number"
              step="0.1"
              placeholder="Es. 4.2"
              value={formData.ph.value}
              onChange={(e) => handleInputChange('ph', 'value', e.target.value)}
              className="text-xs"
            />
            <div className="text-xs text-gray-600">
              Status: <span className={getStatusColor(formData.ph.status)}>{formData.ph.status}</span>
            </div>
          </div>

          {/* Brix */}
          <div className="space-y-2">
            <Label className="text-xs">Brix (Target: 5.5-6.0°)</Label>
            <Input
              type="number"
              step="0.1"
              placeholder="Es. 5.8"
              value={formData.brix.value}
              onChange={(e) => handleInputChange('brix', 'value', e.target.value)}
              className="text-xs"
            />
            <div className="text-xs text-gray-600">
              Status: <span className={getStatusColor(formData.brix.status)}>{formData.brix.status}</span>
            </div>
          </div>

          {/* Temperature */}
          <div className="space-y-2">
            <Label className="text-xs">Temperatura (Target: 80-90°C)</Label>
            <Input
              type="number"
              placeholder="Es. 85"
              value={formData.temperature.value}
              onChange={(e) => handleInputChange('temperature', 'value', e.target.value)}
              className="text-xs"
            />
            <div className="text-xs text-gray-600">
              Status: <span className={getStatusColor(formData.temperature.status)}>{formData.temperature.status}</span>
            </div>
          </div>

          {/* Viscosity */}
          <div className="space-y-2">
            <Label className="text-xs">Viscosità (Target: Standard)</Label>
            <Select value={formData.viscosity.value} onValueChange={(value) => handleInputChange('viscosity', 'value', value)}>
              <SelectTrigger className="text-xs">
                <SelectValue placeholder="Seleziona viscosità" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Liquida">Liquida</SelectItem>
                <SelectItem value="Normale">Normale</SelectItem>
                <SelectItem value="Standard">Standard</SelectItem>
                <SelectItem value="Densa">Densa</SelectItem>
              </SelectContent>
            </Select>
            <div className="text-xs text-gray-600">
              Status: <span className={getStatusColor(formData.viscosity.status)}>{formData.viscosity.status}</span>
            </div>
          </div>

          {/* Color */}
          <div className="space-y-2">
            <Label className="text-xs">Colore (Target: Conforme)</Label>
            <Select value={formData.color.value} onValueChange={(value) => handleInputChange('color', 'value', value)}>
              <SelectTrigger className="text-xs">
                <SelectValue placeholder="Seleziona colore" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Non conforme">Non conforme</SelectItem>
                <SelectItem value="Conforme">Conforme</SelectItem>
                <SelectItem value="Eccellente">Eccellente</SelectItem>
              </SelectContent>
            </Select>
            <div className="text-xs text-gray-600">
              Status: <span className={getStatusColor(formData.color.status)}>{formData.color.status}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Operatore</Label>
          <Input
            placeholder="Nome operatore"
            value={formData.ph.operator}
            onChange={(e) => {
              const keys: (keyof typeof formData)[] = ['ph', 'brix', 'temperature', 'viscosity', 'color'];
              keys.forEach(key => {
                handleInputChange(key, 'operator', e.target.value);
              });
            }}
            className="text-xs"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Note</Label>
          <Textarea
            placeholder="Note sui controlli qualità..."
            rows={2}
            value={formData.ph.notes}
            onChange={(e) => {
              const keys: (keyof typeof formData)[] = ['ph', 'brix', 'temperature', 'viscosity', 'color'];
              keys.forEach(key => {
                handleInputChange(key, 'notes', e.target.value);
              });
            }}
            className="text-xs"
          />
        </div>

        <div className="flex gap-2">
          <Button
            onClick={handleSaveQuality}
            size="sm"
            disabled={updateQualityMutation.isPending}
            className="text-xs"
          >
            {updateQualityMutation.isPending ? 'Salvando...' : 'Salva Controlli'}
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowForm(false)}
            size="sm"
            className="text-xs"
          >
            Annulla
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="border-t pt-3 mt-3">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setShowQuality(!showQuality)}
        className="w-full justify-between p-2 h-auto text-xs"
      >
        <div className="flex items-center gap-2">
          <Beaker className="h-3 w-3" />
          <span>Controlli Qualità</span>
          {hasQualityData ? (
            <Badge variant="outline" className="text-xs px-1 py-0">
              Completati
            </Badge>
          ) : (
            <Badge variant="outline" className="text-xs px-1 py-0">
              Da inserire
            </Badge>
          )}
        </div>
        {showQuality ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
      </Button>
      
      {showQuality && (
        <div className="mt-2 space-y-2 text-xs bg-gray-50 dark:bg-gray-800 rounded p-2">
          {hasQualityData ? (
            <>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">pH:</span>
                  <div className="flex items-center gap-1">
                    <span className={getStatusColor(qualityControls?.ph?.status || 'OK')}>
                      {qualityControls?.ph?.value || '--'}
                    </span>
                    {getStatusIcon(qualityControls?.ph?.status || 'OK')}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Brix:</span>
                  <div className="flex items-center gap-1">
                    <span className={getStatusColor(qualityControls?.brix?.status || 'OK')}>
                      {qualityControls?.brix?.value || '--'}°
                    </span>
                    {getStatusIcon(qualityControls?.brix?.status || 'OK')}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Temp:</span>
                  <div className="flex items-center gap-1">
                    <span className={getStatusColor(qualityControls?.temperature?.status || 'OK')}>
                      {qualityControls?.temperature?.value || '--'}°C
                    </span>
                    {getStatusIcon(qualityControls?.temperature?.status || 'OK')}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Viscosità:</span>
                  <div className="flex items-center gap-1">
                    <span className={getStatusColor(qualityControls?.viscosity?.status || 'OK')}>
                      {qualityControls?.viscosity?.value || '--'}
                    </span>
                    {getStatusIcon(qualityControls?.viscosity?.status || 'OK')}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-1 border-t">
                <span className="text-muted-foreground">Colore:</span>
                <div className="flex items-center gap-1">
                  <span className={getStatusColor(qualityControls?.color?.status || 'OK')}>
                    {qualityControls?.color?.value || '--'}
                  </span>
                  {getStatusIcon(qualityControls?.color?.status || 'OK')}
                </div>
              </div>
              
              <div className="pt-1 border-t flex items-center justify-between">
                <div className="text-xs text-green-600 font-medium flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" />
                  Controlli completati
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowForm(true)}
                  className="text-xs h-6 px-2"
                >
                  Modifica
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-4">
              <div className="text-muted-foreground mb-2">
                Nessun controllo qualità inserito
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowForm(true)}
                className="text-xs"
              >
                <FlaskConical className="w-3 h-3 mr-1" />
                Inserisci Controlli
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const BatchForm = ({ batch, onClose }: { batch?: Batch; onClose: () => void }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch recipes for selection
  const { data: recipes = [] } = useQuery({
    queryKey: ["/api/recipes"],
  });

  const form = useForm<BatchFormData>({
    resolver: zodResolver(batchFormSchema),
    defaultValues: {
      code: "",
      recipeId: undefined,
      productName: "",
      quantity: "",
      unit: "vasetti",
      status: "active",
      productionDate: "",
      expiryDate: "",
      notes: "",
      salePrice: ""
    }
  });

  // Reset form values when batch changes
  useEffect(() => {
    if (batch) {
      form.reset({
        code: batch.code || "",
        recipeId: batch.recipeId ? String(batch.recipeId) : "",
        productName: batch.productName || "",
        quantity: batch.quantity || "",
        unit: batch.unit || "vasetti",
        status: batch.status || "active",
        productionDate: batch.productionDate ? new Date(batch.productionDate).toISOString().split('T')[0] : "",
        expiryDate: batch.expiryDate ? new Date(batch.expiryDate).toISOString().split('T')[0] : "",
        notes: batch.notes || "",
        salePrice: batch.salePrice ? batch.salePrice.toString() : ""
      });
    } else {
      form.reset({
        code: "",
        recipeId: undefined,
        productName: "",
        quantity: "",
        unit: "vasetti",
        status: "active",
        productionDate: "",
        expiryDate: "",
        notes: "",
        salePrice: ""
      });
    }
  }, [batch, form]);

  // Watch for recipe selection changes to auto-populate sale price
  const selectedRecipeId = form.watch("recipeId");
  
  useEffect(() => {
    if (selectedRecipeId && recipes && Array.isArray(recipes)) {
      const selectedRecipe = recipes.find((r: any) => r.id === parseInt(selectedRecipeId.toString()));
      if (selectedRecipe) {
        form.setValue("productName", selectedRecipe.name);
        if (selectedRecipe.salePrice) {
          form.setValue("salePrice", selectedRecipe.salePrice.toString());
        }
      }
    }
  }, [selectedRecipeId, recipes, form]);

  const createMutation = useMutation({
    mutationFn: async (data: InsertBatch) => {
      // Generate batch code if not provided
      if (!data.code) {
        const codeResponse: any = await apiRequest("GET", "/api/batches/generate-code");
        data.code = codeResponse.code;
      }
      return apiRequest("POST", "/api/batches", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      toast({ title: "Lotto creato con successo" });
      trackEvent('batch_created', 'production', 'batch_management');
      onClose();
    },
    onError: () => {
      toast({ title: "Errore nella creazione del lotto", variant: "destructive" });
    }
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertBatch) => apiRequest("PUT", `/api/batches/${batch?.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Lotto aggiornato con successo" });
      trackEvent('batch_updated', 'production', 'batch_management');
      onClose();
    },
    onError: () => {
      toast({ title: "Errore nell'aggiornamento del lotto", variant: "destructive" });
    }
  });

  const onSubmit = (data: BatchFormData) => {
    const submitData: any = {
      ...data,
      recipeId: data.recipeId && data.recipeId !== "" ? parseInt(data.recipeId) : null,
      productionDate: new Date(data.productionDate),
      expiryDate: data.expiryDate ? new Date(data.expiryDate) : undefined,
      salePrice: data.salePrice && data.salePrice !== "" ? data.salePrice : null
    };

    if (batch) {
      updateMutation.mutate(submitData);
    } else {
      createMutation.mutate(submitData);
    }
  };

  return (
    <DialogContent className="max-w-2xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          {batch ? "Modifica Lotto" : "Nuovo Lotto"}
        </DialogTitle>
      </DialogHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Codice Lotto</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Autogenerato se vuoto" 
                      {...field} 
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="recipeId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ricetta</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value || ""}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleziona ricetta" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {recipes && Array.isArray(recipes) && recipes.map((recipe: any) => (
                        <SelectItem key={recipe.id} value={recipe.id.toString()}>
                          {recipe.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="productName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome Prodotto</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Nome del prodotto"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantità</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="es. 24"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="unit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unità</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="vasetti">Vasetti</SelectItem>
                      <SelectItem value="bottiglie">Bottiglie</SelectItem>
                      <SelectItem value="kg">Kg</SelectItem>
                      <SelectItem value="g">g</SelectItem>
                      <SelectItem value="l">Litri</SelectItem>
                      <SelectItem value="ml">ml</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="salePrice"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Prezzo di Vendita (€)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Stato</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="active">Attivo</SelectItem>
                      <SelectItem value="sold">Venduto</SelectItem>
                      <SelectItem value="expired">Scaduto</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="productionDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Data di Produzione</FormLabel>
                  <FormControl>
                    <Input 
                      type="date"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="expiryDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Data di Scadenza</FormLabel>
                  <FormControl>
                    <Input 
                      type="date"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Note</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Note aggiuntive sul lotto..."
                    {...field}
                    value={field.value || ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Annulla
            </Button>
            <Button 
              type="submit" 
              disabled={createMutation.isPending || updateMutation.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              {createMutation.isPending || updateMutation.isPending 
                ? "Salvando..." 
                : batch ? "Aggiorna" : "Crea Lotto"
              }
            </Button>
          </div>
        </form>
      </Form>
    </DialogContent>
  );
};

interface BatchManagementProps {
  onNavigateToQR?: (batchId: number) => void;
}

const BatchManagement = ({ onNavigateToQR }: BatchManagementProps = {}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [selectedBatch, setSelectedBatch] = useState<Batch | undefined>();
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: batches = [], isLoading } = useQuery({
    queryKey: ["/api/batches"],
  });

  const { data: recipes = [] } = useQuery({
    queryKey: ["/api/recipes"]
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/batches/${id}`),
    onSuccess: (_, deletedId) => {
      queryClient.setQueryData(["/api/batches"], (old: Batch[]) => {
        return old.filter((batch: Batch) => batch.id !== deletedId);
      });
      toast({ title: "Lotto eliminato con successo" });
      trackEvent('batch_deleted', 'production', 'batch_management');
    },
    onError: () => {
      toast({ title: "Errore nell'eliminazione del lotto", variant: "destructive" });
    }
  });

  const filteredBatches = batches.filter((batch: Batch) => {
    const matchesSearch = batch.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         batch.productName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !statusFilter || statusFilter === "all" || batch.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleEdit = (batch: Batch) => {
    setSelectedBatch(batch);
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    deleteMutation.mutate(id);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "active": return "default";
      case "sold": return "secondary";
      case "expired": return "destructive";
      default: return "outline";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active": return "Attivo";
      case "sold": return "Venduto";
      case "expired": return "Scaduto";
      default: return status;
    }
  };

  const getRecipeName = (recipeId: number | null) => {
    if (!recipeId) return "Nessuna ricetta";
    const recipe = recipes.find((r: any) => r.id === recipeId);
    return recipe?.name || "Ricetta non trovata";
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-info p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <Package className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Gestione Lotti</h1>
              <p className="text-xl text-white/90">
                Monitora i lotti di produzione e le scorte
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div></div>
        
        <Dialog open={showForm} onOpenChange={(open) => {
          setShowForm(open);
          if (!open) {
            setSelectedBatch(undefined);
          }
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Nuovo Lotto
            </Button>
          </DialogTrigger>
          <BatchForm 
            batch={selectedBatch}
            onClose={() => {
              setShowForm(false);
              setSelectedBatch(undefined);
            }}
          />
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cerca per codice lotto o nome prodotto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex gap-2 items-center">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Stato" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutti</SelectItem>
                  <SelectItem value="active">Attivo</SelectItem>
                  <SelectItem value="sold">Venduto</SelectItem>
                  <SelectItem value="expired">Scaduto</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Batches Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBatches.map((batch: Batch) => (
          <Card key={batch.id} className="card-hover">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{batch.code}</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">{batch.productName}</p>
                </div>
                <Badge variant={getStatusBadgeVariant(batch.status)}>
                  {getStatusLabel(batch.status)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Quantità:</span>
                  <span className="font-medium">{batch.quantity} {batch.unit}</span>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Ricetta:</span>
                  <span className="font-medium text-right">
                    {getRecipeName(batch.recipeId)}
                  </span>
                </div>

                {batch.salePrice && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Prezzo:</span>
                    <span className="font-medium">€{batch.salePrice}</span>
                  </div>
                )}

                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Produzione:</span>
                  <span className="font-medium">
                    <Calendar className="h-3 w-3 inline mr-1" />
                    {new Date(batch.productionDate).toLocaleDateString()}
                  </span>
                </div>

                {batch.expiryDate && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Scadenza:</span>
                    <span className="font-medium">
                      <Clock className="h-3 w-3 inline mr-1" />
                      {new Date(batch.expiryDate).toLocaleDateString()}
                    </span>
                  </div>
                )}

                {/* Controlli Qualità */}
                <QualityControlsDisplay batch={batch} onUpdate={() => {}} />

                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(batch)}
                    className="flex-1"
                  >
                    <Edit className="h-3 w-3 mr-1" />
                    Modifica
                  </Button>
                  
                  {onNavigateToQR && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onNavigateToQR(batch.id)}
                      className="flex-1"
                    >
                      <QrCode className="h-3 w-3 mr-1" />
                      QR Code
                    </Button>
                  )}

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Elimina Lotto</AlertDialogTitle>
                        <AlertDialogDescription>
                          Sei sicuro di voler eliminare il lotto "{batch.code}"? 
                          Questa azione non può essere annullata.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Annulla</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDelete(batch.id)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Elimina
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredBatches.length === 0 && !isLoading && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nessun lotto trovato</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm || statusFilter 
                  ? "Prova a modificare i filtri di ricerca"
                  : "Inizia creando il tuo primo lotto di produzione"
                }
              </p>
              {!searchTerm && !statusFilter && (
                <Button onClick={() => setShowForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Crea Primo Lotto
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default BatchManagement;