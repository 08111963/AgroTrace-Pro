import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CheckCircle, Clock, Package, Calendar, RefreshCw } from "lucide-react";
import { format } from "date-fns";
import { it } from "date-fns/locale";
import { apiRequest } from "@/lib/queryClient";
import TestAlertSystem from "@/components/test-alert-system";

interface Alert {
  id: number;
  type: string;
  message: string;
  severity: 'low' | 'medium' | 'high';
  resolved: boolean;
  relatedEntity: string;
  relatedEntityId: number | null;
  createdAt: Date;
  updatedAt: Date;
}

export default function AlertsManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isMonitoring, setIsMonitoring] = useState(false);

  // Query per gli alert attivi
  const { data: alerts = [], isLoading } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    refetchInterval: 30000, // Aggiorna ogni 30 secondi
  });

  // Query per le statistiche dashboard
  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    refetchInterval: 30000,
  });

  // Mutation per risolvere un alert
  const resolveAlertMutation = useMutation({
    mutationFn: async (alertId: number) => {
      return await apiRequest(`/api/alerts/${alertId}/resolve`, {
        method: "POST",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Alert risolto",
        description: "L'alert è stato risolto con successo",
      });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: "Impossibile risolvere l'alert",
        variant: "destructive",
      });
    },
  });

  // Mutation per monitoraggio automatico
  const monitorInventoryMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/inventory/monitor");
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      
      toast({
        title: "Monitoraggio completato",
        description: data.message || `${data.alertsCreated} nuovi alert, ${data.alertsResolved} risolti`,
      });
    },
    onError: (error) => {
      toast({
        title: "Errore monitoraggio",
        description: "Impossibile completare il monitoraggio delle scorte",
        variant: "destructive",
      });
    },
  });

  // Monitoraggio automatico ogni 5 minuti
  useEffect(() => {
    if (isMonitoring) {
      const interval = setInterval(() => {
        monitorInventoryMutation.mutate();
      }, 5 * 60 * 1000); // 5 minuti

      return () => clearInterval(interval);
    }
  }, [isMonitoring]);

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "high":
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case "medium":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <Package className="h-4 w-4 text-blue-500" />;
    }
  };

  const getSeverityBadge = (severity: string) => {
    const variants = {
      high: "destructive",
      medium: "secondary",
      low: "outline"
    } as const;
    
    const labels = {
      high: "Alta",
      medium: "Media", 
      low: "Bassa"
    };

    return (
      <Badge variant={variants[severity as keyof typeof variants] || "outline"}>
        {labels[severity as keyof typeof labels] || severity}
      </Badge>
    );
  };

  const getTypeLabel = (type: string) => {
    const labels = {
      low_stock: "Scorte basse",
      out_of_stock: "Esaurito",
      expiry_warning: "In scadenza",
      expired: "Scaduto"
    };
    return labels[type as keyof typeof labels] || type;
  };

  const activeAlerts = alerts.filter(alert => !alert.resolved);
  const criticalAlerts = activeAlerts.filter(alert => alert.severity === 'high');
  const mediumAlerts = activeAlerts.filter(alert => alert.severity === 'medium');

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-gray-200 rounded animate-pulse"></div>
        <div className="grid gap-4 md:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-24 bg-gray-200 rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-error p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <AlertTriangle className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Sistema Alert</h1>
              <p className="text-xl text-white/90">
                Monitoraggio automatico delle scorte e notifiche
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <div className="flex justify-between items-center">
        <div></div>
        <div className="flex gap-2">
          <Button
            variant={isMonitoring ? "default" : "outline"}
            onClick={() => setIsMonitoring(!isMonitoring)}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            {isMonitoring ? "Monitoraggio Attivo" : "Avvia Monitoraggio"}
          </Button>
          <Button
            onClick={() => monitorInventoryMutation.mutate()}
            disabled={monitorInventoryMutation.isPending}
          >
            <AlertTriangle className="h-4 w-4 mr-2" />
            {monitorInventoryMutation.isPending ? "Controllo..." : "Controlla Ora"}
          </Button>
        </div>
      </div>

      {/* Statistiche Alert */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alert Attivi</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeAlerts.length}</div>
            <p className="text-xs text-muted-foreground">
              {activeAlerts.length === 0 ? "Tutto sotto controllo" : "Richiedono attenzione"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critici</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{criticalAlerts.length}</div>
            <p className="text-xs text-muted-foreground">
              Priorità alta
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Medi</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{mediumAlerts.length}</div>
            <p className="text-xs text-muted-foreground">
              Priorità media
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Prodotti con Scorte Basse</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.lowStockItems || 0}</div>
            <p className="text-xs text-muted-foreground">
              Da rifornire
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Lista Alert Attivi */}
      <Card>
        <CardHeader>
          <CardTitle>Alert Attivi</CardTitle>
          <CardDescription>
            Gestione delle notifiche per scorte basse e prodotti in scadenza
          </CardDescription>
        </CardHeader>
        <CardContent>
          {activeAlerts.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium">Nessun alert attivo</h3>
              <p className="text-muted-foreground">Tutte le scorte sono sotto controllo</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeAlerts
                .sort((a, b) => {
                  const severityOrder = { high: 3, medium: 2, low: 1 };
                  return severityOrder[b.severity as keyof typeof severityOrder] - 
                         severityOrder[a.severity as keyof typeof severityOrder];
                })
                .map((alert) => (
                  <div
                    key={alert.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {getSeverityIcon(alert.severity)}
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">{getTypeLabel(alert.type)}</span>
                          {getSeverityBadge(alert.severity)}
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">
                          {alert.message}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(alert.createdAt), "dd MMM yyyy, HH:mm", { locale: it })}
                          </span>
                          <span>Entità: {alert.relatedEntity}</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => resolveAlertMutation.mutate(alert.id)}
                      disabled={resolveAlertMutation.isPending}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Risolvi
                    </Button>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Informazioni Monitoraggio */}
      <Card>
        <CardHeader>
          <CardTitle>Configurazione Monitoraggio</CardTitle>
          <CardDescription>
            Il sistema controlla automaticamente le scorte e genera alert per:
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <h4 className="font-medium flex items-center gap-2">
                <Package className="h-4 w-4" />
                Controlli Scorte
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Prodotti con scorte ≤ soglia minima</li>
                <li>• Prodotti completamente esauriti</li>
                <li>• Aggiornamento automatico stato prodotti</li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-medium flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Controlli Scadenze
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Prodotti in scadenza entro 7 giorni</li>
                <li>• Priorità basata sui giorni rimanenti</li>
                <li>• Risoluzione automatica post-scadenza</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <RefreshCw className="h-4 w-4 text-blue-600" />
              <span className="font-medium text-blue-800">Monitoraggio Automatico</span>
            </div>
            <p className="text-sm text-blue-700">
              {isMonitoring 
                ? "Il monitoraggio automatico è attivo e controlla le scorte ogni 5 minuti."
                : "Attiva il monitoraggio automatico per controlli programmati delle scorte."
              }
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}