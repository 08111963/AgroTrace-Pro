import { 
  Home, 
  ChefHat, 
  Package, 
  Warehouse, 
  QrCode, 
  Search, 
  AlertTriangle,
  BarChart3,
  TrendingDown,
  BookOpen,
  Building2,
  ShoppingCart,
  Database,
  X,
  ChevronDown,
  ChevronRight,
  User,
  HelpCircle,
  Clock,
  Crown,
  Calculator,
  Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";

interface SidebarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const menuItems = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: Home
  },
  {
    id: "ricette",
    label: "Ricette",
    icon: ChefHat
  },
  {
    id: "recipe-calculator",
    label: "Calcolatore Ingredienti",
    icon: Calculator,
    path: "/recipe-calculator"
  },
  {
    id: "ai-ricette",
    label: "Crea Ricette",
    icon: BookOpen
  },
  {
    id: "lotti",
    label: "Lotti",
    icon: Package
  },
  {
    id: "magazzino",
    label: "Magazzino",
    icon: Warehouse
  },
  {
    id: "vendite",
    label: "Vendite",
    icon: ShoppingCart
  },
  {
    id: "disponibilita-ingredienti",
    label: "Disponibilità",
    icon: TrendingDown
  },
  {
    id: "alert",
    label: "Alert Scorte",
    icon: AlertTriangle
  },
  {
    id: "qr-labels",
    label: "QR Labels",
    icon: QrCode
  },
  {
    id: "tracciabilita",
    label: "Tracciabilità",
    icon: Search
  },
  {
    id: "reports",
    label: "Reports",
    icon: BarChart3
  },
  {
    id: "profilo-aziendale",
    label: "Profilo",
    icon: Building2
  },
  {
    id: "backup",
    label: "Backup",
    icon: Database,
    path: "/backup"
  },
  {
    id: "license",
    label: "Licenza",
    icon: Shield,
    path: "/license"
  },
  {
    id: "admin-licenses",
    label: "Gestione Licenze (Admin)",
    icon: Crown,
    path: "/admin/licenses",
    adminOnly: true
  },
  {
    id: "guida",
    label: "Guida",
    icon: HelpCircle
  }
];

const Sidebar = ({ activeSection, setActiveSection, sidebarOpen, setSidebarOpen }: SidebarProps) => {
  const [, setLocation] = useLocation();
  
  // Import useAuth to check authentication status
  const { user, isAuthenticated } = useAuth();

  // Get active alerts for badge
  const { data: alerts = [] } = useQuery({
    queryKey: ["/api/alerts/active"],
    enabled: isAuthenticated,
  });

  // Get license status for trial banner
  const { data: licenseStatus } = useQuery({
    queryKey: ["/api/license/status"],
    refetchInterval: 5 * 60 * 1000, // Aggiorna ogni 5 minuti
    staleTime: 2 * 60 * 1000, // 2 minuti
    enabled: isAuthenticated,
  });

  return (
    <>
      <aside className={`fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-card border-r border-border z-50 transform transition-transform duration-300 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } md:translate-x-0`}>
        
        {/* Mobile close button */}
        <div className="flex items-center justify-between p-4 md:hidden">
          <h2 className="text-lg font-semibold">Menu</h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>



        {/* Navigation */}
        <nav className="px-2 py-1 space-y-0.5">
          {menuItems
            .filter(item => {
              // Filtra gli elementi admin solo per utenti admin
              const isAdminItem = (item as any).adminOnly;
              if (isAdminItem && (!user || user.role !== 'admin')) {
                return false;
              }
              return true;
            })
            .map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            const isGuide = item.id === "guida";
            
            return (
              <button
                key={item.id}
                onClick={() => {
                  // Se l'item ha un path personalizzato, naviga direttamente
                  if ((item as any).path) {
                    setLocation((item as any).path);
                  } else if (window.location.pathname.includes('/tracciabilita/') || window.location.pathname.includes('/backup') || window.location.pathname.includes('/recipe-calculator')) {
                    // Se siamo su una pagina speciale, torna al dashboard principale
                    setLocation('/');
                    setTimeout(() => {
                      setActiveSection(item.id);
                    }, 50);
                  } else {
                    setActiveSection(item.id);
                  }
                  if (window.innerWidth < 768) {
                    setSidebarOpen(false);
                  }
                }}
                className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-all duration-200 group ${
                  isActive 
                    ? 'bg-primary text-primary-foreground shadow-glow' 
                    : isGuide 
                      ? 'text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/30 hover:text-blue-700 border border-blue-200 dark:border-blue-800 shadow-soft' 
                      : 'text-muted-foreground hover:bg-primary/10 hover:text-primary hover:shadow-soft'
                }`}
              >
                <div className={`p-1 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'bg-white/20' 
                    : isGuide
                      ? 'bg-blue-100 dark:bg-blue-950/50 group-hover:bg-blue-200 dark:group-hover:bg-blue-900/50'
                      : 'bg-muted/50 group-hover:bg-primary/20'
                }`}>
                  <Icon className={`h-3.5 w-3.5 ${
                    isActive 
                      ? 'text-white' 
                      : isGuide 
                        ? 'text-blue-600 dark:text-blue-400' 
                        : 'text-muted-foreground group-hover:text-primary'
                  }`} />
                </div>
                <div className="flex-1 min-w-0 flex items-center justify-between">
                  <span className={`font-medium truncate text-sm ${
                    isActive 
                      ? 'text-white font-semibold' 
                      : isGuide 
                        ? 'text-blue-600 dark:text-blue-400 font-semibold' 
                        : 'group-hover:text-primary'
                  }`}>
                    {item.label}
                  </span>
                  {(item.id === "dashboard" || item.id === "alert") && (alerts as any[]).length > 0 && (
                    <Badge variant="destructive" className="ml-2 h-4 px-1 text-xs">
                      {(alerts as any[]).length}
                    </Badge>
                  )}
                </div>
              </button>
            );
          })}
        </nav>

        {/* Trial Status Banner */}
        {licenseStatus && licenseStatus.status === 'trial' && (
          <div className="mx-2 mb-2 p-3 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 border border-blue-200 dark:border-blue-800 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-blue-600" />
              <Badge variant="outline" className="text-xs border-blue-200 text-blue-700 bg-blue-50">
                Prova Gratuita
              </Badge>
            </div>
            <div className="text-xs space-y-1">
              <div className="font-semibold text-blue-900 dark:text-blue-100">
                {licenseStatus.trialDaysRemaining} giorni rimanenti
              </div>
              <div className="text-blue-700 dark:text-blue-300">
                Piano: {licenseStatus.plan === 'free' ? 'Gratuito' : licenseStatus.plan}
              </div>
              <div className="flex items-center gap-1 text-blue-600 dark:text-blue-400 text-xs">
                <Crown className="h-3 w-3" />
                <span>Sblocca tutte le funzioni</span>
              </div>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-border bg-muted/30">
          <div className="text-xs text-muted-foreground space-y-1">
            <div className="flex justify-between">
              <span>Stato Sistema:</span>
              <span className="text-green-600 font-medium">Online</span>
            </div>
            <div className="flex justify-between">
              <span>Ultimo Aggiornamento:</span>
              <span>{new Date().toLocaleTimeString('it-IT', { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;