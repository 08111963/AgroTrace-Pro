import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Batch, type QRLabel, type Recipe, type User, type CompanyProfile } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  QrCode, 
  Download, 
  Printer, 
  Search, 
  Package,
  Calendar,
  AlertTriangle,
  Eye
} from "lucide-react";
import { generateQRCode, downloadQRCode, printQRCode } from "@/lib/qr-generator";

const QRLabels = () => {
  const [selectedBatchId, setSelectedBatchId] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [generatedQR, setGeneratedQR] = useState<string | null>(null);
  const [showQRDisplay, setShowQRDisplay] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: batches = [] } = useQuery<Batch[]>({
    queryKey: ["/api/batches"],
  });

  const { data: recipes = [] } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const { data: qrLabels = [] } = useQuery<QRLabel[]>({
    queryKey: ["/api/qr-labels"],
  });

  const { data: user } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });

  const { data: companyProfile } = useQuery<CompanyProfile>({
    queryKey: ["/api/company-profile"],
    retry: false,
  });

  // Check for preselected batch from navigation
  useEffect(() => {
    const preselectedBatchId = sessionStorage.getItem('selectedBatchForQR');
    if (preselectedBatchId) {
      setSelectedBatchId(preselectedBatchId);
      sessionStorage.removeItem('selectedBatchForQR');
    }
  }, []);

  const createQRMutation = useMutation({
    mutationFn: async (batchId: number) => {
      const batch = batches.find((b: Batch) => b.id === batchId);
      
      if (!batch) throw new Error("Batch not found");

      // Get recipe details for additional info
      const recipe = batch.recipeId ? recipes.find((r: Recipe) => r.id === batch.recipeId) : null;
      const companyName = companyProfile?.ragioneSociale || user?.username || "Azienda Agricola";
      
      // Create enhanced QR data with URL and additional details
      const baseUrl = window.location.origin;
      const traceabilityUrl = `${baseUrl}/tracciabilita/${batch.code}`;
      
      // Create a simple, smartphone-readable QR code with URL
      const qrData = traceabilityUrl;

      return apiRequest("POST", "/api/qr-labels", {
        batchId: batch.id,
        code: `QR-${batch.code}`,
        data: qrData
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/qr-labels"] });
      // Use the QR data that was sent to create the label
      const batch = batches.find((b: Batch) => b.id === parseInt(selectedBatchId));
      if (batch) {
        const batchRecipe = batch.recipeId ? recipes.find((r: Recipe) => r.id === batch.recipeId) : null;
        const companyName = companyProfile?.ragioneSociale || user?.username || "Azienda Agricola";
        const baseUrl = window.location.origin;
        const traceabilityUrl = `${baseUrl}/tracciabilita/${batch.code}`;
        
        generateQRCodeDisplay(traceabilityUrl);
      }
      toast({ title: "Etichetta QR generata con successo" });
    },
    onError: () => {
      toast({ title: "Errore nella generazione dell'etichetta QR", variant: "destructive" });
    }
  });

  const generateQRCodeDisplay = async (data: string) => {
    console.log('generateQRCodeDisplay called with data:', data);
    
    // First show the QR display section
    setShowQRDisplay(true);
    
    // Wait for the next frame to ensure canvas is rendered
    await new Promise(resolve => requestAnimationFrame(resolve));
    
    if (!canvasRef.current) {
      console.error('Canvas ref is still null after render');
      return;
    }

    console.log('Canvas ref exists, generating QR code...');
    
    try {
      await generateQRCode(data, canvasRef.current);
      console.log('QR code generated successfully');
      setGeneratedQR(data);
    } catch (error) {
      console.error('Error generating QR code:', error);
      toast({ title: "Errore nella generazione del codice QR", variant: "destructive" });
    }
  };

  const handleDownloadQR = () => {
    console.log('Download button clicked');
    if (!canvasRef.current) {
      console.error('Canvas ref is null, cannot download');
      toast({ title: "Errore nel download", description: "Canvas non disponibile", variant: "destructive" });
      return;
    }
    
    try {
      console.log('Attempting to download QR code...');
      const batch = batches.find((b: Batch) => b.id.toString() === selectedBatchId);
      const filename = batch ? `qr-${batch.code}.png` : `qr-label-${selectedBatchId}.png`;
      console.log('Download filename:', filename);
      
      downloadQRCode(canvasRef.current, filename);
      console.log('Download initiated successfully');
      toast({ title: "Download avviato", description: "Il file QR è stato scaricato" });
    } catch (error) {
      console.error('Error during download:', error);
      toast({ title: "Errore nel download", description: "Si è verificato un errore durante il download", variant: "destructive" });
    }
  };

  const handlePrintQR = () => {
    if (!canvasRef.current) return;
    
    const batch = batches.find((b: Batch) => b.id.toString() === selectedBatchId);
    const title = batch ? `Etichetta QR - ${batch.productName}` : 'Etichetta QR';
    const info = batch ? `Lotto: ${batch.code} | Produzione: ${new Date(batch.productionDate).toLocaleDateString('it-IT')}` : '';
    
    printQRCode(canvasRef.current, title, info);
  };

  const handleGenerateQR = () => {
    if (!selectedBatchId) return;
    createQRMutation.mutate(parseInt(selectedBatchId));
  };

  const viewExistingQR = async (label: QRLabel) => {
    console.log('viewExistingQR called with label:', label);
    
    if (label.data && label.batchId) {
      // Find the corresponding batch to get current data
      const batch = batches.find((b: Batch) => b.id === label.batchId);
      
      if (batch) {
        // Always use the enhanced format with URL and company name
        const batchRecipe = batch.recipeId ? recipes.find((r: Recipe) => r.id === batch.recipeId) : null;
        const companyName = companyProfile?.ragioneSociale || user?.username || "Azienda Agricola";
        const baseUrl = window.location.origin;
        const traceabilityUrl = `${baseUrl}/tracciabilita/${batch.code}`;
        
        console.log('QR data to display:', traceabilityUrl);
        await generateQRCodeDisplay(traceabilityUrl);
        setSelectedBatchId(label.batchId.toString());
      }
    }
  };

  // Filter batches based on search term
  const filteredBatches = batches.filter((batch: Batch) =>
    batch.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    batch.productName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get recipe name for display
  const getRecipeName = (recipeId: number | null) => {
    const recipe = recipes.find((r: Recipe) => r.id === recipeId);
    return recipe?.name || "Ricetta non trovata";
  };

  // Check if QR label exists for batch
  const hasQRLabel = (batchId: number) => {
    return qrLabels.some((label: QRLabel) => label.batchId === batchId);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-secondary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <QrCode className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Etichette QR</h1>
              <p className="text-xl text-white/90">
                Genera e gestisci etichette QR per la tracciabilità digitale
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      {/* QR Generation Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5" />
            Genera Nuova Etichetta QR
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Seleziona Lotto</label>
              <Select value={selectedBatchId} onValueChange={setSelectedBatchId}>
                <SelectTrigger>
                  <SelectValue placeholder="Scegli un lotto..." />
                </SelectTrigger>
                <SelectContent>
                  {filteredBatches.map((batch: Batch) => (
                    <SelectItem key={batch.id} value={batch.id.toString()}>
                      <div className="flex flex-col">
                        <span className="font-medium">{batch.code}</span>
                        <span className="text-sm text-gray-500">{batch.productName}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Cerca Lotti</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cerca per codice o prodotto..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
          </div>

          {selectedBatchId && (
            <div className="space-y-4">
              {(() => {
                const batch = batches.find((b: Batch) => b.id.toString() === selectedBatchId);
                if (!batch) return null;

                return (
                  <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Dettagli Lotto Selezionato:</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Codice:</span> {batch.code}
                      </div>
                      <div>
                        <span className="font-medium">Prodotto:</span> {batch.productName}
                      </div>
                      <div>
                        <span className="font-medium">Produzione:</span> {new Date(batch.productionDate).toLocaleDateString('it-IT')}
                      </div>
                      <div>
                        <span className="font-medium">Quantità:</span> {batch.quantity} {batch.unit}
                      </div>
                    </div>
                  </div>
                );
              })()}

              <div className="flex gap-2">
                <Button 
                  onClick={handleGenerateQR}
                  disabled={createQRMutation.isPending}
                  className="flex-1"
                >
                  {createQRMutation.isPending ? "Generazione..." : "Genera Etichetta QR"}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* QR Code Display */}
      {showQRDisplay && (
        <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-blue-600" />
                Anteprima Etichetta QR
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowQRDisplay(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="flex justify-center bg-white dark:bg-gray-800 p-4 rounded-lg">
              <canvas 
                ref={canvasRef}
                className="border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm"
                width={200}
                height={200}
              />
            </div>
            
            <div className="flex justify-center gap-2">
              <Button variant="outline" onClick={handleDownloadQR}>
                <Download className="h-4 w-4 mr-2" />
                Scarica
              </Button>
              <Button variant="outline" onClick={handlePrintQR}>
                <Printer className="h-4 w-4 mr-2" />
                Stampa
              </Button>
            </div>

            {generatedQR && (
              <div className="text-sm text-gray-600 dark:text-gray-400 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 p-3 rounded-lg">
                <div className="font-medium mb-1 text-green-800 dark:text-green-300">QR Code generato con successo</div>
                <div className="text-green-600 dark:text-green-400">✓ Codice pronto per la stampa e distribuzione</div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Existing QR Labels */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Etichette QR Esistenti
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {qrLabels.length === 0 ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <QrCode className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Nessuna etichetta QR generata</p>
                <p className="text-sm">Genera la prima etichetta per iniziare la tracciabilità</p>
              </div>
            ) : (
              qrLabels.map((label: QRLabel) => {
                const batch = batches.find((b: Batch) => b.id === label.batchId);
                if (!batch) return null;

                return (
                  <div 
                    key={label.id} 
                    className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline">{label.code}</Badge>
                        <div>
                          <div className="font-medium">{batch.productName}</div>
                          <div className="text-sm text-gray-500">
                            Lotto: {batch.code} • Produzione: {new Date(batch.productionDate).toLocaleDateString('it-IT')}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="secondary"
                        className="flex items-center gap-1"
                      >
                        <Calendar className="h-3 w-3" />
                        {new Date(label.generatedAt || '').toLocaleDateString('it-IT')}
                      </Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => viewExistingQR(label)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Visualizza
                      </Button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default QRLabels;