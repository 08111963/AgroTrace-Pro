import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { TestTube, Package, Calendar, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function TestAlertSystem() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mutation per creare dati di test
  const createTestDataMutation = useMutation({
    mutationFn: async () => {
      // Crea prodotti di test con diverse condizioni per attivare gli alert
      const testProducts = [
        {
          name: "Olio Extravergine di Oliva",
          category: "Condimenti", 
          currentStock: "2", // Scorte molto basse
          minimumStock: "10",
          unit: "litri",
          unitCost: "12.50",
          supplier: "Oleificio Toscano",
          location: "Magazzino A",
          status: "low_stock",
          expiryDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // Scade tra 3 giorni
          notes: "Prodotto di test - scorte basse e in scadenza"
        },
        {
          name: "Vasetti di Vetro 250ml",
          category: "Packaging",
          currentStock: "0", // Completamente esaurito
          minimumStock: "50", 
          unit: "pezzi",
          unitCost: "0.45",
          supplier: "Vetreria Italiana",
          location: "Magazzino B",
          status: "out_of_stock",
          expiryDate: null,
          notes: "Prodotto di test - esaurito"
        },
        {
          name: "Etichette Adesive",
          category: "Packaging",
          currentStock: "5", // Sotto soglia minima
          minimumStock: "20",
          unit: "rotoli", 
          unitCost: "3.20",
          supplier: "Stampa Veloce",
          location: "Ufficio",
          status: "low_stock", 
          expiryDate: null,
          notes: "Prodotto di test - scorte sotto soglia"
        },
        {
          name: "Conservante Naturale E200",
          category: "Additivi",
          currentStock: "1", // Scorte critiche
          minimumStock: "5",
          unit: "kg",
          unitCost: "25.00",
          supplier: "Chimica Food",
          location: "Magazzino Sicurezza",
          status: "low_stock",
          expiryDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // Scade domani
          notes: "Prodotto di test - critico per scadenza e scorte"
        },
        {
          name: "Tappi per Vasetti",
          category: "Packaging", 
          currentStock: "0", // Esaurito
          minimumStock: "100",
          unit: "pezzi",
          unitCost: "0.12",
          supplier: "Tappi & Co",
          location: "Magazzino B",
          status: "out_of_stock",
          expiryDate: null,
          notes: "Prodotto di test - completamente esaurito"
        }
      ];

      // Crea ogni prodotto
      for (const product of testProducts) {
        const code = `TEST-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`.toUpperCase();
        await apiRequest("/api/inventory", {
          method: "POST",
          body: JSON.stringify({ ...product, code }),
          headers: { "Content-Type": "application/json" }
        });
      }

      return { created: testProducts.length };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      
      toast({
        title: "Dati di test creati",
        description: `${data.created} prodotti di test aggiunti per testare il sistema di alert`,
      });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: "Impossibile creare i dati di test",
        variant: "destructive",
      });
    },
  });

  // Mutation per attivare il monitoraggio manuale
  const triggerMonitoringMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/inventory/monitor", {
        method: "POST",
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      
      toast({
        title: "Monitoraggio eseguito",
        description: data.message || `${data.alertsCreated} nuovi alert creati`,
      });
    },
    onError: (error) => {
      toast({
        title: "Errore monitoraggio",
        description: "Impossibile eseguire il monitoraggio",
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="border-blue-200 bg-blue-50/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-800">
          <TestTube className="h-5 w-5" />
          Test Sistema Alert
        </CardTitle>
        <CardDescription>
          Crea dati di test per verificare il funzionamento del sistema di monitoraggio automatico delle scorte
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid gap-3 text-sm">
            <div className="flex items-center gap-2">
              <Package className="h-4 w-4 text-red-500" />
              <span>Prodotti con scorte critiche (≤ soglia minima)</span>
            </div>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-orange-500" />
              <span>Prodotti completamente esauriti</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-yellow-500" />
              <span>Prodotti in scadenza entro 7 giorni</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => createTestDataMutation.mutate()}
              disabled={createTestDataMutation.isPending}
              className="flex-1"
            >
              <TestTube className="h-4 w-4 mr-2" />
              {createTestDataMutation.isPending ? "Creazione..." : "Crea Dati Test"}
            </Button>
            
            <Button
              onClick={() => triggerMonitoringMutation.mutate()}
              disabled={triggerMonitoringMutation.isPending}
              variant="outline"
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              {triggerMonitoringMutation.isPending ? "Controllo..." : "Avvia Controllo"}
            </Button>
          </div>

          <div className="p-3 bg-blue-100 rounded-lg text-xs text-blue-700">
            <strong>Come testare:</strong>
            <ol className="mt-1 space-y-1 list-decimal list-inside">
              <li>Clicca "Crea Dati Test" per aggiungere prodotti con problematiche</li>
              <li>Clicca "Avvia Controllo" per generare gli alert</li>
              <li>Vai alla sezione "Alert Scorte" per vedere i risultati</li>
              <li>Il sistema controllerà automaticamente ogni 30 minuti</li>
            </ol>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}