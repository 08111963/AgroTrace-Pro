import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  BookOpen, 
  ChefHat, 
  Package, 
  Warehouse, 
  TrendingDown,
  QrCode,
  Search,
  BarChart3,
  Monitor,
  Users,
  Shield,
  HelpCircle,
  ArrowRight,
  CheckCircle,
  Info,
  AlertTriangle,
  Lightbulb,
  FileText,
  Settings,
  Clock,
  Calculator,
  Eye,
  Download,
  Upload,
  RefreshCw,
  Zap
} from "lucide-react";

export default function HelpGuide() {
  const [activeSection, setActiveSection] = useState<string>("overview");

  const guideSection = {
    overview: {
      title: "Panoramica Generale",
      icon: Monitor,
      content: (
        <div className="space-y-8">
          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg border border-green-200">
            <h3 className="text-xl font-bold text-green-800 mb-4">Benvenuto in AgroTrace Pro</h3>
            <p className="text-green-700 mb-6 text-lg">
              Sistema completo per la gestione e trasformazione di prodotti agroalimentari con tracciabilità avanzata e conformità normativa.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="font-medium">Tracciabilità completa da materia prima a prodotto finito</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="font-medium">Monitoraggio scorte in tempo reale</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="font-medium">Gestione avanzata ricette e allergeni</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="font-medium">QR codes automatici per etichettatura</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="font-medium">Calcolo automatico valori nutrizionali</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="font-medium">Conformità HACCP e normative UE</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Moduli del Sistema</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { 
                  icon: ChefHat, 
                  name: "Ricette e Allergeni", 
                  desc: "Gestione completa ricette con ingredienti, fornitori, lotti acquisto e allergeni",
                  features: ["Tracciabilità ingredienti", "Gestione allergeni", "Calcolo costi", "Valori nutrizionali"]
                },
                { 
                  icon: Package, 
                  name: "Lotti di Produzione", 
                  desc: "Controllo completo lotti con date di produzione, scadenza e stato",
                  features: ["Codici lotto automatici", "Gestione date", "Stati produzione", "QR generation"]
                },
                { 
                  icon: Warehouse, 
                  name: "Gestione Magazzino", 
                  desc: "Inventario completo con controllo scorte e soglie minime",
                  features: ["Controllo scorte", "Soglie automatiche", "Calcolo valori", "Categorizzazione"]
                },
                { 
                  icon: TrendingDown, 
                  name: "Monitoraggio Disponibilità", 
                  desc: "Controllo in tempo reale delle disponibilità ingredienti",
                  features: ["Aggiornamento real-time", "Stati disponibilità", "Previsioni scorte", "Avvisi automatici"]
                },
                { 
                  icon: QrCode, 
                  name: "Etichette QR", 
                  desc: "Generazione automatica QR codes per tracciabilità prodotti",
                  features: ["QR automatici", "Dati completi", "Download etichette", "Tracciabilità pubblica"]
                },
                { 
                  icon: Search, 
                  name: "Sistema Tracciabilità", 
                  desc: "Ricerca e verifica completa prodotti tramite codice lotto",
                  features: ["Ricerca per codice", "Dati completi", "Accesso pubblico", "Verifica autenticità"]
                }
              ].map((module, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-3">
                      <module.icon className="h-8 w-8 text-primary" />
                      <CardTitle className="text-lg">{module.name}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{module.desc}</p>
                    <div className="space-y-2">
                      {module.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Importante:</strong> AgroTrace Pro è progettato per garantire la conformità alle normative europee sulla tracciabilità alimentare, 
              inclusi i requisiti HACCP e le disposizioni del Regolamento (CE) n. 178/2002.
            </AlertDescription>
          </Alert>
        </div>
      )
    },
    recipes: {
      title: "Gestione Ricette",
      icon: ChefHat,
      content: (
        <div className="space-y-8">
          <Tabs defaultValue="creation" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="creation">Creazione</TabsTrigger>
              <TabsTrigger value="ingredients">Ingredienti</TabsTrigger>
              <TabsTrigger value="allergens">Allergeni</TabsTrigger>
              <TabsTrigger value="nutrition">Nutrizione</TabsTrigger>
            </TabsList>

            <TabsContent value="creation" className="space-y-6">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg border border-blue-200">
                <h4 className="text-xl font-bold text-blue-800 mb-4">Procedura Creazione Ricetta</h4>
                <div className="space-y-4">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                    <div>
                      <h5 className="font-semibold text-blue-700">Accesso al Modulo</h5>
                      <p className="text-blue-600">Clicca su "Ricette" nella barra laterale sinistra per accedere al modulo di gestione ricette.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                    <div>
                      <h5 className="font-semibold text-blue-700">Inizializzazione</h5>
                      <p className="text-blue-600">Clicca il pulsante "Nuova Ricetta" per aprire il form di creazione.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                    <div>
                      <h5 className="font-semibold text-blue-700">Dati Base</h5>
                      <p className="text-blue-600">Compila nome ricetta, categoria (es: Conserve, Dolci, Bevande) e descrizione dettagliata.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                    <div>
                      <h5 className="font-semibold text-blue-700">Configurazione Avanzata</h5>
                      <p className="text-blue-600">Imposta tempo di preparazione, porzioni, note speciali e istruzioni di conservazione.</p>
                    </div>
                  </div>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Settings className="h-5 w-5" />
                    <span>Campi del Form Ricetta</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <h6 className="font-semibold mb-2">Informazioni Base</h6>
                        <ul className="space-y-2 text-sm">
                          <li><strong>Nome:</strong> Denominazione commerciale del prodotto</li>
                          <li><strong>Categoria:</strong> Classificazione merceologica</li>
                          <li><strong>Descrizione:</strong> Descrizione dettagliata del prodotto</li>
                          <li><strong>Tempo Prep.:</strong> Minuti necessari per la preparazione</li>
                        </ul>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <h6 className="font-semibold mb-2">Parametri Produttivi</h6>
                        <ul className="space-y-2 text-sm">
                          <li><strong>Porzioni:</strong> Numero porzioni ottenute dalla ricetta</li>
                          <li><strong>Temperatura:</strong> Temperatura di conservazione (°C)</li>
                          <li><strong>Shelf Life:</strong> Durata di conservazione in giorni</li>
                          <li><strong>Note:</strong> Istruzioni speciali e avvertenze</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="ingredients" className="space-y-6">
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  <strong>Attenzione:</strong> Tutti gli ingredienti devono avere informazioni complete su fornitore e lotto di acquisto per garantire la tracciabilità.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg text-red-600">Campi Obbligatori</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 border-l-4 border-red-500 bg-red-50">
                      <h6 className="font-bold text-red-700 mb-2">Fornitore</h6>
                      <p className="text-red-600 text-sm mb-2">Nome completo dell'azienda fornitrice dell'ingrediente</p>
                      <p className="text-xs text-red-500">Esempio: "Caseificio Alpino S.r.l.", "Oleificio Toscano", "Mulino Bianco"</p>
                    </div>
                    <div className="p-4 border-l-4 border-red-500 bg-red-50">
                      <h6 className="font-bold text-red-700 mb-2">Lotto Acquisto</h6>
                      <p className="text-red-600 text-sm mb-2">Codice identificativo del lotto di acquisto dell'ingrediente</p>
                      <p className="text-xs text-red-500">Esempio: "LA2025001", "BATCH-240315", "LOT-OLI-2025-03"</p>
                    </div>
                    <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                      <p className="text-yellow-800 text-sm">
                        <Lightbulb className="h-4 w-4 inline mr-1" />
                        <strong>Suggerimento:</strong> Mantieni un registro cartaceo/digitale dei codici lotto per facilitare l'inserimento.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg text-blue-600">Campi Aggiuntivi</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h6 className="font-semibold mb-2">Quantità e Unità</h6>
                      <p className="text-sm text-muted-foreground mb-2">Specifica la quantità esatta e l'unità di misura</p>
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <p className="text-blue-700 text-sm">Unità supportate: kg, g, l, ml, pz, cucchiai, cucchiaini</p>
                      </div>
                    </div>
                    <div>
                      <h6 className="font-semibold mb-2">Costo (Opzionale)</h6>
                      <p className="text-sm text-muted-foreground mb-2">Prezzo per unità per calcolo costi ricetta</p>
                      <div className="bg-green-50 p-3 rounded-lg">
                        <p className="text-green-700 text-sm">Il sistema calcolerà automaticamente il costo totale della ricetta</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Esempio Pratico: Ingrediente Farina</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg font-mono text-sm">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p><strong>Nome:</strong> Farina 00 Biologica</p>
                        <p><strong>Quantità:</strong> 500</p>
                        <p><strong>Unità:</strong> g</p>
                      </div>
                      <div>
                        <p><strong>Fornitore:</strong> Mulino Biologico Valle Verde S.r.l.</p>
                        <p><strong>Lotto Acquisto:</strong> BIO-FAR-2025-001</p>
                        <p><strong>Costo:</strong> €2.50/kg</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="allergens" className="space-y-6">
              <div className="bg-orange-50 p-6 rounded-lg border border-orange-200">
                <h4 className="text-xl font-bold text-orange-800 mb-4">Gestione Allergeni - Conformità UE</h4>
                <p className="text-orange-700 mb-4">
                  Il sistema gestisce automaticamente i 14 allergeni principali secondo il Regolamento UE 1169/2011.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Allergeni Supportati</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      {[
                        "Cereali contenenti glutine", "Crostacei", "Uova", "Pesce",
                        "Arachidi", "Soia", "Latte", "Frutta a guscio",
                        "Sedano", "Senape", "Semi di sesamo", "Anidride solforosa",
                        "Lupini", "Molluschi"
                      ].map((allergen, idx) => (
                        <div key={idx} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          <span>{allergen}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Processo Automatico</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-start space-x-3">
                        <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs">1</div>
                        <div>
                          <p className="font-medium">Selezione per Ingrediente</p>
                          <p className="text-sm text-muted-foreground">Seleziona allergeni per ogni singolo ingrediente</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs">2</div>
                        <div>
                          <p className="font-medium">Calcolo Automatico</p>
                          <p className="text-sm text-muted-foreground">Il sistema aggrega tutti gli allergeni della ricetta</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs">3</div>
                        <div>
                          <p className="font-medium">Etichettatura</p>
                          <p className="text-sm text-muted-foreground">Inclusione automatica nelle etichette QR</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  <strong>Conformità Normativa:</strong> Il sistema garantisce la conformità al Regolamento UE 1169/2011 
                  sull'etichettatura degli allergeni, con aggiornamento automatico delle informazioni sui prodotti finali.
                </AlertDescription>
              </Alert>
            </TabsContent>

            <TabsContent value="nutrition" className="space-y-6">
              <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                <h4 className="text-xl font-bold text-green-800 mb-4">Calcolo Valori Nutrizionali Automatico</h4>
                <p className="text-green-700">
                  Il sistema calcola automaticamente i valori nutrizionali basandosi su un database completo di ingredienti alimentari.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Calculator className="h-5 w-5" />
                      <span>Valori Calcolati</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span>Energia (kcal)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Proteine (g)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Carboidrati (g)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>di cui zuccheri (g)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Grassi (g)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>di cui saturi (g)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Fibre (g)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Sodio (mg)</span>
                        <Badge variant="outline">Automatico</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Sale (g)</span>
                        <Badge variant="outline">Calcolato</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <FileText className="h-5 w-5" />
                      <span>Database Nutrizionale</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        Il sistema utilizza un database nutrizionale completo con oltre 200 ingredienti comuni.
                      </p>
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h6 className="font-semibold text-blue-700 mb-2">Ingredienti Supportati:</h6>
                        <ul className="text-sm text-blue-600 space-y-1">
                          <li>• Cereali e derivati</li>
                          <li>• Latticini e formaggi</li>
                          <li>• Carni e pesce</li>
                          <li>• Frutta e verdura</li>
                          <li>• Oli e grassi</li>
                          <li>• Zuccheri e dolcificanti</li>
                          <li>• Spezie e condimenti</li>
                        </ul>
                      </div>
                      <Alert>
                        <Info className="h-4 w-4" />
                        <AlertDescription className="text-sm">
                          I valori sono calcolati per 100g di prodotto finito e rispettano le linee guida EFSA.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Esempio Calcolo Nutrizionale</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h6 className="font-semibold mb-3">Ricetta: Pane Integrale (100g)</h6>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="font-medium">Energia</p>
                        <p className="text-lg font-bold text-blue-600">247 kcal</p>
                      </div>
                      <div>
                        <p className="font-medium">Proteine</p>
                        <p className="text-lg font-bold text-green-600">8.2 g</p>
                      </div>
                      <div>
                        <p className="font-medium">Carboidrati</p>
                        <p className="text-lg font-bold text-orange-600">45.1 g</p>
                      </div>
                      <div>
                        <p className="font-medium">Grassi</p>
                        <p className="text-lg font-bold text-red-600">3.5 g</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )
    },
    batches: {
      title: "Gestione Lotti",
      icon: Package,
      content: (
        <div className="space-y-8">
          <Tabs defaultValue="creation" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="creation">Creazione</TabsTrigger>
              <TabsTrigger value="management">Gestione</TabsTrigger>
              <TabsTrigger value="tracking">Tracking</TabsTrigger>
              <TabsTrigger value="qr">QR Generation</TabsTrigger>
            </TabsList>

            <TabsContent value="creation" className="space-y-6">
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-lg border border-purple-200">
                <h4 className="text-xl font-bold text-purple-800 mb-4">Procedura Creazione Lotto di Produzione</h4>
                <p className="text-purple-700 mb-4">
                  I lotti rappresentano una specifica produzione di un prodotto basata su una ricetta, con tracciabilità completa.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Clock className="h-5 w-5" />
                      <span>Processo Step-by-Step</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                        <div>
                          <h6 className="font-semibold text-purple-700">Selezione Ricetta</h6>
                          <p className="text-sm text-purple-600">Scegli la ricetta da utilizzare per la produzione dal menu a tendina</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                        <div>
                          <h6 className="font-semibold text-purple-700">Auto-compilazione</h6>
                          <p className="text-sm text-purple-600">Il sistema carica automaticamente nome prodotto e lista ingredienti</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                        <div>
                          <h6 className="font-semibold text-purple-700">Parametri Produzione</h6>
                          <p className="text-sm text-purple-600">Imposta quantità, date di produzione e scadenza, note operative</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                        <div>
                          <h6 className="font-semibold text-purple-700">Generazione Codice</h6>
                          <p className="text-sm text-purple-600">Il sistema genera automaticamente un codice lotto univoco</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <FileText className="h-5 w-5" />
                      <span>Campi del Form</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <h6 className="font-semibold">Ricetta Base</h6>
                        <p className="text-sm text-muted-foreground">Selezione dalla lista ricette esistenti</p>
                      </div>
                      <div>
                        <h6 className="font-semibold">Quantità Produzione</h6>
                        <p className="text-sm text-muted-foreground">Quantità totale da produrre (kg, l, pz)</p>
                      </div>
                      <div>
                        <h6 className="font-semibold">Data Produzione</h6>
                        <p className="text-sm text-muted-foreground">Data di inizio produzione del lotto</p>
                      </div>
                      <div>
                        <h6 className="font-semibold">Data Scadenza</h6>
                        <p className="text-sm text-muted-foreground">Data di scadenza calcolata o manuale</p>
                      </div>
                      <div>
                        <h6 className="font-semibold">Note Operative</h6>
                        <p className="text-sm text-muted-foreground">Annotazioni specifiche per il lotto</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Alert>
                <Zap className="h-4 w-4" />
                <AlertDescription>
                  <strong>Codici Automatici:</strong> Il sistema genera automaticamente codici lotto progressivi nel formato 
                  LT2025001, LT2025002, ecc. garantendo unicità e tracciabilità.
                </AlertDescription>
              </Alert>
            </TabsContent>

            <TabsContent value="management" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-green-200 bg-green-50">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-green-700">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span>Attivo</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-green-600 text-sm mb-3">Lotto in produzione o pronto per distribuzione</p>
                    <div className="space-y-2 text-xs">
                      <div>• Produzione in corso</div>
                      <div>• Controlli qualità</div>
                      <div>• Preparazione spedizione</div>
                      <div>• Disponibile per vendita</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-blue-200 bg-blue-50">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-blue-700">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span>Completato</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-blue-600 text-sm mb-3">Lotto terminato e distribuito</p>
                    <div className="space-y-2 text-xs">
                      <div>• Produzione completata</div>
                      <div>• Controlli superati</div>
                      <div>• Lotto spedito/venduto</div>
                      <div>• Archiviazione dati</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-red-200 bg-red-50">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-red-700">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <span>Scaduto</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-red-600 text-sm mb-3">Lotto oltre la data di scadenza</p>
                    <div className="space-y-2 text-xs">
                      <div>• Data scadenza superata</div>
                      <div>• Non più commerciabile</div>
                      <div>• Procedure smaltimento</div>
                      <div>• Analisi cause</div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Operazioni sui Lotti</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h6 className="font-semibold text-lg">Azioni Disponibili</h6>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <Eye className="h-4 w-4 text-blue-500" />
                          <span className="text-sm">Visualizza dettagli completi</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Settings className="h-4 w-4 text-orange-500" />
                          <span className="text-sm">Modifica parametri lotto</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <QrCode className="h-4 w-4 text-green-500" />
                          <span className="text-sm">Genera/visualizza QR code</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Download className="h-4 w-4 text-purple-500" />
                          <span className="text-sm">Esporta etichetta prodotto</span>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h6 className="font-semibold text-lg">Filtri e Ricerca</h6>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <Search className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">Ricerca per codice lotto</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Package className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">Filtra per ricetta/prodotto</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Clock className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">Filtra per data produzione</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <AlertTriangle className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">Filtra per stato lotto</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tracking" className="space-y-6">
              <div className="bg-indigo-50 p-6 rounded-lg border border-indigo-200">
                <h4 className="text-xl font-bold text-indigo-800 mb-4">Sistema di Tracking Avanzato</h4>
                <p className="text-indigo-700">
                  Ogni lotto mantiene una traccia completa di tutti gli ingredienti utilizzati, fornitori e lotti di acquisto.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Search className="h-5 w-5" />
                      <span>Informazioni Tracciabili</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="p-3 bg-blue-50 rounded-lg">
                        <h6 className="font-semibold text-blue-700">Ingredienti</h6>
                        <p className="text-sm text-blue-600">Lista completa con quantità utilizzate</p>
                      </div>
                      <div className="p-3 bg-green-50 rounded-lg">
                        <h6 className="font-semibold text-green-700">Fornitori</h6>
                        <p className="text-sm text-green-600">Dati completi di ogni fornitore</p>
                      </div>
                      <div className="p-3 bg-orange-50 rounded-lg">
                        <h6 className="font-semibold text-orange-700">Lotti Acquisto</h6>
                        <p className="text-sm text-orange-600">Codici lotto di ogni ingrediente</p>
                      </div>
                      <div className="p-3 bg-purple-50 rounded-lg">
                        <h6 className="font-semibold text-purple-700">Date e Tempi</h6>
                        <p className="text-sm text-purple-600">Timeline completa di produzione</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <FileText className="h-5 w-5" />
                      <span>Esempio Tracking</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h6 className="font-bold mb-3">Lotto: LT2025001 - Pane Integrale</h6>
                      <div className="space-y-3 text-sm">
                        <div>
                          <strong>Farina 00:</strong> 2kg
                          <br />
                          <span className="text-muted-foreground">Fornitore: Mulino Valle Verde</span>
                          <br />
                          <span className="text-muted-foreground">Lotto: BIO-FAR-2025-001</span>
                        </div>
                        <div>
                          <strong>Lievito:</strong> 25g
                          <br />
                          <span className="text-muted-foreground">Fornitore: Lievitificio Romano</span>
                          <br />
                          <span className="text-muted-foreground">Lotto: LIE-2025-15</span>
                        </div>
                        <div>
                          <strong>Sale:</strong> 40g
                          <br />
                          <span className="text-muted-foreground">Fornitore: Salina Trapanese</span>
                          <br />
                          <span className="text-muted-foreground">Lotto: SAL-MAR-2025</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  <strong>Conformità HACCP:</strong> Il sistema di tracking garantisce la piena conformità ai requisiti HACCP 
                  per la rintracciabilità degli alimenti, mantenendo registri completi per ispezioni e controlli.
                </AlertDescription>
              </Alert>
            </TabsContent>

            <TabsContent value="qr" className="space-y-6">
              <div className="bg-cyan-50 p-6 rounded-lg border border-cyan-200">
                <h4 className="text-xl font-bold text-cyan-800 mb-4">Generazione QR Codes Automatica</h4>
                <p className="text-cyan-700">
                  Ogni lotto può generare automaticamente un QR code contenente tutte le informazioni di tracciabilità.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <QrCode className="h-5 w-5" />
                      <span>Contenuto QR Code</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Codice lotto di produzione</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Nome e descrizione prodotto</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Date produzione e scadenza</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Lista ingredienti completa</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Allergeni presenti</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Valori nutrizionali calcolati</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Dati fornitori e lotti</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Informazioni produttore</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Download className="h-5 w-5" />
                      <span>Utilizzo Pratico</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <h6 className="font-semibold">Etichettatura Prodotti</h6>
                        <p className="text-sm text-muted-foreground">Stampa QR code su etichette adesive per confezioni</p>
                      </div>
                      <div>
                        <h6 className="font-semibold">Tracciabilità Pubblica</h6>
                        <p className="text-sm text-muted-foreground">Consumatori possono scansionare per informazioni complete</p>
                      </div>
                      <div>
                        <h6 className="font-semibold">Controlli Interni</h6>
                        <p className="text-sm text-muted-foreground">Verifica rapida durante movimentazione e stoccaggio</p>
                      </div>
                      <div>
                        <h6 className="font-semibold">Conformità Normativa</h6>
                        <p className="text-sm text-muted-foreground">Facilita ispezioni e controlli delle autorità</p>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-3 rounded-lg">
                      <p className="text-blue-700 text-sm">
                        <Info className="h-4 w-4 inline mr-1" />
                        <strong>Accesso Universale:</strong> I QR codes sono accessibili anche senza login 
                        tramite URL pubblico dedicato.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Processo Generazione QR</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-cyan-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                      <span>Clicca su "Genera QR" nella pagina dettagli lotto</span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-cyan-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                      <span>Il sistema raccoglie automaticamente tutti i dati del lotto</span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-cyan-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                      <span>Viene generato il QR code con tutti i dati di tracciabilità</span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-cyan-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                      <span>Scarica l'immagine PNG per stampa su etichette</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )
    },
    inventory: {
      title: "Gestione Magazzino",
      icon: Warehouse,
      content: (
        <div className="space-y-8">
          <Tabs defaultValue="setup" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="setup">Configurazione</TabsTrigger>
              <TabsTrigger value="operations">Operazioni</TabsTrigger>
              <TabsTrigger value="monitoring">Monitoraggio</TabsTrigger>
              <TabsTrigger value="integration">Integrazione</TabsTrigger>
            </TabsList>

            <TabsContent value="setup" className="space-y-6">
              <div className="bg-gradient-to-r from-orange-50 to-yellow-50 p-6 rounded-lg border border-orange-200">
                <h4 className="text-xl font-bold text-orange-800 mb-4">Sistema di Gestione Inventario Avanzato</h4>
                <p className="text-orange-700 mb-4">
                  Il modulo magazzino gestisce completamente l'inventario degli ingredienti con controllo automatico delle scorte e soglie personalizzabili.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Upload className="h-5 w-5" />
                      <span>Aggiunta Nuovo Articolo</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                        <div>
                          <h6 className="font-semibold text-orange-700">Accesso Modulo</h6>
                          <p className="text-sm text-orange-600">Clicca su "Magazzino" nella barra laterale</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                        <div>
                          <h6 className="font-semibold text-orange-700">Nuovo Articolo</h6>
                          <p className="text-sm text-orange-600">Clicca "Aggiungi Articolo" per aprire il form</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                        <div>
                          <h6 className="font-semibold text-orange-700">Dati Base</h6>
                          <p className="text-sm text-orange-600">Compila nome, categoria, unità di misura</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                        <div>
                          <h6 className="font-semibold text-orange-700">Parametri Stock</h6>
                          <p className="text-sm text-orange-600">Imposta quantità, soglie e prezzi</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <FileText className="h-5 w-5" />
                      <span>Campi del Form Inventario</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="p-3 bg-blue-50 rounded-lg">
                        <h6 className="font-bold text-blue-700">Nome Articolo</h6>
                        <p className="text-sm text-blue-600">Denominazione dell'ingrediente (es: "Farina 00", "Olio EVO")</p>
                      </div>
                      <div className="p-3 bg-green-50 rounded-lg">
                        <h6 className="font-bold text-green-700">Categoria</h6>
                        <p className="text-sm text-green-600">Classificazione (es: "Cereali", "Oli", "Latticini")</p>
                      </div>
                      <div className="p-3 bg-purple-50 rounded-lg">
                        <h6 className="font-bold text-purple-700">Unità Misura</h6>
                        <p className="text-sm text-purple-600">kg, g, l, ml, pz secondo l'ingrediente</p>
                      </div>
                      <div className="p-3 bg-yellow-50 rounded-lg">
                        <h6 className="font-bold text-yellow-700">Codice Articolo</h6>
                        <p className="text-sm text-yellow-600">Codice interno univoco (opzionale)</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Parametri di Stock Critici</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="border-l-4 border-blue-500 pl-4">
                        <h6 className="font-bold text-blue-700">Quantità Attuale</h6>
                        <p className="text-sm text-blue-600 mb-2">Stock effettivamente disponibile in magazzino</p>
                        <p className="text-xs text-blue-500">Aggiornata automaticamente con l'uso in produzione</p>
                      </div>
                      <div className="border-l-4 border-red-500 pl-4">
                        <h6 className="font-bold text-red-700">Quantità Minima</h6>
                        <p className="text-sm text-red-600 mb-2">Soglia di allarme per scorte basse</p>
                        <p className="text-xs text-red-500">Genera avvisi automatici quando raggiunta</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="border-l-4 border-green-500 pl-4">
                        <h6 className="font-bold text-green-700">Prezzo Unitario</h6>
                        <p className="text-sm text-green-600 mb-2">Costo per unità di misura (€/kg, €/l)</p>
                        <p className="text-xs text-green-500">Calcola automaticamente il valore inventario</p>
                      </div>
                      <div className="border-l-4 border-purple-500 pl-4">
                        <h6 className="font-bold text-purple-700">Note</h6>
                        <p className="text-sm text-purple-600 mb-2">Informazioni aggiuntive sull'articolo</p>
                        <p className="text-xs text-purple-500">Condizioni conservazione, scadenze tipiche</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Alert>
                <Lightbulb className="h-4 w-4" />
                <AlertDescription>
                  <strong>Consiglio:</strong> Imposta soglie minime basate sui consumi medi settimanali. 
                  Per ingredienti con lead time lunghi, considera scorte di sicurezza maggiori.
                </AlertDescription>
              </Alert>
            </TabsContent>

            <TabsContent value="operations" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <RefreshCw className="h-5 w-5" />
                      <span>Aggiornamento Stock</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <h6 className="font-semibold text-green-600">Carichi Merce</h6>
                        <p className="text-sm text-muted-foreground">Aumenta stock per arrivi nuove forniture</p>
                      </div>
                      <div>
                        <h6 className="font-semibold text-blue-600">Utilizzi Produzione</h6>
                        <p className="text-sm text-muted-foreground">Diminuisce automaticamente con creazione lotti</p>
                      </div>
                      <div>
                        <h6 className="font-semibold text-orange-600">Correzioni Inventario</h6>
                        <p className="text-sm text-muted-foreground">Aggiustamenti manuali per discrepanze</p>
                      </div>
                      <div>
                        <h6 className="font-semibold text-red-600">Scarti e Perdite</h6>
                        <p className="text-sm text-muted-foreground">Registrazione articoli deteriorati/scaduti</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Search className="h-5 w-5" />
                      <span>Ricerca e Filtri</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <span className="text-sm">Ricerca per nome articolo</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm">Filtro per categoria</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span className="text-sm">Visualizza solo scorte basse</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-sm">Articoli sotto soglia critica</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <span className="text-sm">Ordina per valore inventario</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Esempio Gestione Articolo: Farina Biologica</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <h6 className="font-bold">Dati Articolo</h6>
                        <div className="text-sm space-y-1">
                          <p><strong>Nome:</strong> Farina 00 Biologica</p>
                          <p><strong>Categoria:</strong> Cereali e Derivati</p>
                          <p><strong>Unità:</strong> kg</p>
                          <p><strong>Codice:</strong> FAR-BIO-001</p>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <h6 className="font-bold">Parametri Stock</h6>
                        <div className="text-sm space-y-1">
                          <p><strong>Stock Attuale:</strong> 45 kg</p>
                          <p><strong>Soglia Minima:</strong> 20 kg</p>
                          <p><strong>Prezzo:</strong> €2.50/kg</p>
                          <p><strong>Valore:</strong> €112.50</p>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-green-100 rounded-lg">
                      <p className="text-green-700 text-sm">
                        <CheckCircle className="h-4 w-4 inline mr-1" />
                        Stato: Stock OK - Disponibilità sufficiente per produzione
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="monitoring" className="space-y-6">
              <div className="bg-red-50 p-6 rounded-lg border border-red-200">
                <h4 className="text-xl font-bold text-red-800 mb-4">Sistema di Monitoraggio Automatico</h4>
                <p className="text-red-700">
                  Il sistema monitora costantemente le scorte e genera avvisi automatici per prevenire interruzioni di produzione.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-green-200 bg-green-50">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-green-700">
                      <CheckCircle className="h-5 w-5" />
                      <span>Stock OK</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-green-600 text-sm mb-3">Quantità superiore alla soglia minima</p>
                    <div className="space-y-2 text-xs">
                      <div>• Produzione garantita</div>
                      <div>• Nessun intervento richiesto</div>
                      <div>• Monitoraggio routine</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-yellow-200 bg-yellow-50">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-yellow-700">
                      <AlertTriangle className="h-5 w-5" />
                      <span>Scorte Basse</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-yellow-600 text-sm mb-3">Quantità vicina alla soglia minima</p>
                    <div className="space-y-2 text-xs">
                      <div>• Pianificare rifornimento</div>
                      <div>• Avviso dashboard</div>
                      <div>• Controllo quotidiano</div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-red-200 bg-red-50">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-red-700">
                      <AlertTriangle className="h-5 w-5" />
                      <span>Critiche</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-red-600 text-sm mb-3">Quantità sotto soglia minima</p>
                    <div className="space-y-2 text-xs">
                      <div>• Rifornimento urgente</div>
                      <div>• Blocco produzione possibile</div>
                      <div>• Alert immediato</div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5" />
                    <span>Dashboard Inventario</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h6 className="font-semibold">Statistiche Principali</h6>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Articoli Totali</span>
                          <Badge variant="outline">Contatore automatico</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Valore Inventario</span>
                          <Badge variant="outline">Calcolo in tempo reale</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Articoli Scorte Basse</span>
                          <Badge variant="destructive">Alert sistema</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Ultimo Aggiornamento</span>
                          <Badge variant="secondary">Timestamp automatico</Badge>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h6 className="font-semibold">Azioni Rapide</h6>
                      <div className="space-y-3">
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Download className="h-4 w-4 mr-2" />
                          Esporta Inventario
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Upload className="h-4 w-4 mr-2" />
                          Importa Aggiornamenti
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <AlertTriangle className="h-4 w-4 mr-2" />
                          Report Scorte Basse
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Calculator className="h-4 w-4 mr-2" />
                          Calcola Valore Totale
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="integration" className="space-y-6">
              <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                <h4 className="text-xl font-bold text-purple-800 mb-4">Integrazione con Altri Moduli</h4>
                <p className="text-purple-700">
                  Il magazzino si integra automaticamente con ricette, lotti e sistema di disponibilità per garantire coerenza dei dati.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <ChefHat className="h-5 w-5" />
                      <span>Integrazione Ricette</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <h6 className="font-semibold text-blue-700">Verifica Disponibilità</h6>
                      <p className="text-sm text-blue-600">Controllo automatico ingredienti durante creazione ricette</p>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg">
                      <h6 className="font-semibold text-green-700">Calcolo Costi</h6>
                      <p className="text-sm text-green-600">Prezzi ingredienti per costo ricette automatico</p>
                    </div>
                    <div className="p-3 bg-yellow-50 rounded-lg">
                      <h6 className="font-semibold text-yellow-700">Aggiornamento Automatico</h6>
                      <p className="text-sm text-yellow-600">Sincronizzazione dati tra moduli in tempo reale</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Package className="h-5 w-5" />
                      <span>Integrazione Lotti</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-3 bg-orange-50 rounded-lg">
                      <h6 className="font-semibold text-orange-700">Consumo Automatico</h6>
                      <p className="text-sm text-orange-600">Decremento stock con creazione lotti produzione</p>
                    </div>
                    <div className="p-3 bg-red-50 rounded-lg">
                      <h6 className="font-semibold text-red-700">Controllo Disponibilità</h6>
                      <p className="text-sm text-red-600">Blocco produzione se ingredienti insufficienti</p>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <h6 className="font-semibold text-purple-700">Tracking Utilizzi</h6>
                      <p className="text-sm text-purple-600">Registro completo utilizzi per ogni ingrediente</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingDown className="h-5 w-5" />
                    <span>Sistema Disponibilità Real-time</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      Il modulo "Disponibilità Ingredienti" utilizza i dati del magazzino per fornire monitoraggio in tempo reale:
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <RefreshCw className="h-4 w-4 text-blue-500" />
                          <span className="text-sm">Aggiornamento ogni 30 secondi</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <AlertTriangle className="h-4 w-4 text-orange-500" />
                          <span className="text-sm">Avvisi automatici scorte basse</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Calculator className="h-4 w-4 text-green-500" />
                          <span className="text-sm">Previsioni giorni rimanenti</span>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <Eye className="h-4 w-4 text-purple-500" />
                          <span className="text-sm">Dashboard visuale stato stock</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Search className="h-4 w-4 text-cyan-500" />
                          <span className="text-sm">Ricerca rapida ingredienti</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <BarChart3 className="h-4 w-4 text-red-500" />
                          <span className="text-sm">Statistiche consumo</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Sincronizzazione Automatica:</strong> Tutti i moduli sono costantemente sincronizzati. 
                  Ogni modifica in magazzino si riflette immediatamente su ricette, lotti e disponibilità.
                </AlertDescription>
              </Alert>
            </TabsContent>
          </Tabs>
        </div>
      )
    },
    availability: {
      title: "Disponibilità Ingredienti",
      icon: TrendingDown,
      content: (
        <div className="space-y-6">
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h4 className="font-semibold text-green-800 mb-2">Accesso al Monitoraggio</h4>
            <p className="text-green-700 mb-3">
              Vai su "Disponibilità Ingredienti" per accedere al dashboard di monitoraggio in tempo reale.
            </p>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">Auto-refresh</Badge>
              <span className="text-sm">Aggiornamento automatico ogni 30 secondi</span>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Funzionalità Dashboard</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <h5 className="font-medium">Statistiche Generali</h5>
                <ul className="space-y-1 text-sm">
                  <li>• Totale articoli in inventario</li>
                  <li>• Articoli con scorte basse</li>
                  <li>• Articoli con scorte critiche</li>
                  <li>• Ultimo aggiornamento</li>
                </ul>
              </div>
              <div className="space-y-3">
                <h5 className="font-medium">Monitoraggio Articoli</h5>
                <ul className="space-y-1 text-sm">
                  <li>• Ricerca ingredienti per nome</li>
                  <li>• Visualizzazione stato disponibilità</li>
                  <li>• Dettagli specifici per articolo</li>
                  <li>• Giorni rimanenti stimati</li>
                </ul>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Stati di Disponibilità</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-3 border rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <Badge variant="outline">OK</Badge>
                </div>
                <p className="text-sm">Scorte sufficienti per la produzione</p>
              </div>
              <div className="p-3 border rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <Badge variant="outline">Basse</Badge>
                </div>
                <p className="text-sm">Scorte sotto la soglia minima</p>
              </div>
              <div className="p-3 border rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <Badge variant="outline">Critiche</Badge>
                </div>
                <p className="text-sm">Scorte esaurite o quasi esaurite</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    traceability: {
      title: "Sistema di Tracciabilità",
      icon: Search,
      content: (
        <div className="space-y-6">
          <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-200">
            <h4 className="font-semibold text-indigo-800 mb-2">Come Funziona</h4>
            <p className="text-indigo-700 mb-3">
              Il sistema permette di tracciare completamente l'origine di ogni prodotto attraverso i codici lotto.
            </p>
            <ol className="list-decimal list-inside space-y-1 text-indigo-700">
              <li>Vai su "Tracciabilità"</li>
              <li>Inserisci il codice lotto del prodotto</li>
              <li>Visualizza tutte le informazioni di tracciabilità</li>
            </ol>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Informazioni Disponibili</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h5 className="font-medium">Dati Prodotto</h5>
                <ul className="space-y-1 text-sm">
                  <li>• Nome e categoria prodotto</li>
                  <li>• Date produzione e scadenza</li>
                  <li>• Quantità prodotta</li>
                  <li>• Stato del lotto</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h5 className="font-medium">Tracciabilità Ingredienti</h5>
                <ul className="space-y-1 text-sm">
                  <li>• Lista completa ingredienti</li>
                  <li>• Fornitori per ogni ingrediente</li>
                  <li>• Lotti di acquisto specifici</li>
                  <li>• Allergeni presenti</li>
                </ul>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Accesso Pubblico</h4>
            <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
              <p className="text-yellow-800 text-sm">
                <strong>Importante:</strong> La tracciabilità è accessibile anche senza login tramite URL pubblico 
                <code className="ml-1 bg-yellow-200 px-1 rounded">/tracciabilita/[CODICE_LOTTO]</code>
              </p>
            </div>
          </div>
        </div>
      )
    },
    workflow: {
      title: "Flusso di Lavoro Consigliato",
      icon: BarChart3,
      content: (
        <div className="space-y-6">
          <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-200">
            <h4 className="font-semibold text-emerald-800 mb-3">Setup Iniziale</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-emerald-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                <div>
                  <div className="font-medium">Configura Inventario</div>
                  <div className="text-sm text-emerald-700">Aggiungi tutti gli ingredienti base nel magazzino</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-emerald-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                <div>
                  <div className="font-medium">Crea Ricette</div>
                  <div className="text-sm text-emerald-700">Inserisci ricette con ingredienti, fornitori e lotti</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-emerald-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                <div>
                  <div className="font-medium">Imposta Soglie</div>
                  <div className="text-sm text-emerald-700">Configura quantità minime per monitoraggio scorte</div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Operazioni Quotidiane</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 border rounded-lg">
                <Monitor className="h-5 w-5 text-blue-500" />
                <div>
                  <div className="font-medium">Controlla Dashboard</div>
                  <div className="text-sm text-muted-foreground">Verifica avvisi e statistiche generali</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 border rounded-lg">
                <TrendingDown className="h-5 w-5 text-orange-500" />
                <div>
                  <div className="font-medium">Monitora Scorte</div>
                  <div className="text-sm text-muted-foreground">Usa "Disponibilità Ingredienti" per controllo stock</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 border rounded-lg">
                <Package className="h-5 w-5 text-green-500" />
                <div>
                  <div className="font-medium">Gestisci Produzione</div>
                  <div className="text-sm text-muted-foreground">Crea lotti e aggiorna inventario</div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-3">Produzione di un Lotto</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <ArrowRight className="h-4 w-4 text-gray-400" />
                <span className="text-sm">Seleziona ricetta per la produzione</span>
              </div>
              <div className="flex items-center space-x-2">
                <ArrowRight className="h-4 w-4 text-gray-400" />
                <span className="text-sm">Verifica disponibilità ingredienti nel tracker</span>
              </div>
              <div className="flex items-center space-x-2">
                <ArrowRight className="h-4 w-4 text-gray-400" />
                <span className="text-sm">Crea nuovo lotto di produzione</span>
              </div>
              <div className="flex items-center space-x-2">
                <ArrowRight className="h-4 w-4 text-gray-400" />
                <span className="text-sm">Genera QR per tracciabilità</span>
              </div>
              <div className="flex items-center space-x-2">
                <ArrowRight className="h-4 w-4 text-gray-400" />
                <span className="text-sm">Aggiorna scorte ingredienti utilizzati</span>
              </div>
            </div>
          </div>
        </div>
      )
    }
  };

  const menuItems = [
    { id: "overview", label: "Panoramica", icon: Monitor },
    { id: "recipes", label: "Ricette", icon: ChefHat },
    { id: "batches", label: "Lotti", icon: Package },
    { id: "inventory", label: "Magazzino", icon: Warehouse },
    { id: "availability", label: "Disponibilità", icon: TrendingDown },
    { id: "traceability", label: "Tracciabilità", icon: Search },
    { id: "workflow", label: "Flusso di Lavoro", icon: BarChart3 }
  ];

  const currentSection = guideSection[activeSection as keyof typeof guideSection];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-tertiary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Guida all'Uso</h1>
              <p className="text-xl text-white/90">
                Documentazione completa per AgroTrace Pro
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Navigation Menu */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Sezioni</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="space-y-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 text-left hover:bg-accent transition-colors ${
                      activeSection === item.id ? 'bg-primary text-primary-foreground' : ''
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="text-sm font-medium">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Content */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <currentSection.icon className="h-6 w-6 text-primary" />
              <CardTitle className="text-xl">{currentSection.title}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {currentSection.content}
          </CardContent>
        </Card>
      </div>

      {/* Quick Access */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <HelpCircle className="h-5 w-5" />
            <span>Accesso Rapido</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="font-semibold mb-2">Per Iniziare</h4>
              <p className="text-sm text-muted-foreground mb-3">
                Configurazione iniziale dell'applicazione
              </p>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setActiveSection("workflow")}
              >
                Vedi Flusso di Lavoro
              </Button>
            </div>
            <div className="p-4 border rounded-lg">
              <h4 className="font-semibold mb-2">Problemi Comuni</h4>
              <p className="text-sm text-muted-foreground mb-3">
                Soluzioni ai problemi più frequenti
              </p>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setActiveSection("overview")}
              >
                Vedi Panoramica
              </Button>
            </div>
            <div className="p-4 border rounded-lg">
              <h4 className="font-semibold mb-2">Tracciabilità</h4>
              <p className="text-sm text-muted-foreground mb-3">
                Come garantire la tracciabilità completa
              </p>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setActiveSection("traceability")}
              >
                Vedi Tracciabilità
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}