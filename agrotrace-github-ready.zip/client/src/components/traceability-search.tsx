import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { type Batch, type Recipe, type QRLabel, type CompanyProfile } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import NutritionalLabel from "@/components/nutritional-label";
import { 
  Search, 
  Package, 
  Calendar, 
  Clock, 
  ChefHat,
  QrCode,
  AlertTriangle,
  MapPin,
  FileText,
  Scan,
  Phone,
  Mail
} from "lucide-react";

const TraceabilitySearch = () => {
  const [, setLocation] = useLocation();
  const [selectedBatchCode, setSelectedBatchCode] = useState("");
  const [searchResults, setSearchResults] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Carica tutti i lotti disponibili con stale time per evitare richieste frequenti
  const { data: batches = [] } = useQuery<Batch[]>({
    queryKey: ["/api/batches"],
    staleTime: 5 * 60 * 1000, // 5 minuti
    gcTime: 10 * 60 * 1000, // 10 minuti
  });

  const { data: companyProfile } = useQuery<CompanyProfile>({
    queryKey: ["/api/company-profile"],
    retry: false,
    staleTime: 30 * 60 * 1000, // 30 minuti (profilo aziendale cambia raramente)
    gcTime: 60 * 60 * 1000, // 1 ora
  });

  const performSearch = async () => {
    if (!selectedBatchCode) return;
    
    setIsLoading(true);
    try {
      // Forza sempre un fetch fresco per avere i dati più aggiornati
      const response = await fetch(`/api/traceability/${encodeURIComponent(selectedBatchCode)}`, {
        cache: 'no-cache',
        headers: {
          'Cache-Control': 'no-cache'
        }
      });
      const data = await response.json();
      console.log("Dati tracciabilità ricevuti:", data);
      
      // Force update ingredients with percentages for display
      if (data.recipe && data.recipe.ingredients) {
        data.recipe.ingredients = data.recipe.ingredients.map((ing: any) => ({
          ...ing,
          productPercentage: ing.productPercentage || 10 // Fallback for testing
        }));
        console.log("Ingredients with percentages:", data.recipe.ingredients);
      }
      
      setSearchResults(data);
    } catch (error) {
      console.error("Errore nella ricerca:", error);
      setSearchResults(null);
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('it-IT', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "active": return "default";
      case "sold": return "secondary";
      case "expired": return "destructive";
      default: return "outline";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active": return "Attivo";
      case "sold": return "Venduto";
      case "expired": return "Scaduto";
      default: return status;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-secondary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <Search className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Tracciabilità</h1>
              <p className="text-xl text-white/90">
                Ricerca completa della filiera per numero lotto
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      {/* Search Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Ricerca Tracciabilità
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <Select value={selectedBatchCode} onValueChange={setSelectedBatchCode}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Seleziona un lotto per la tracciabilità" />
                </SelectTrigger>
                <SelectContent>
                  {batches.map((batch: Batch) => (
                    <SelectItem key={batch.id} value={batch.code}>
                      {batch.code} - {batch.productName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button 
              onClick={() => {
                if (selectedBatchCode) {
                  setLocation(`/tracciabilita/${selectedBatchCode}`);
                }
              }}
              disabled={!selectedBatchCode}
              className="bg-green-600 hover:bg-green-700"
            >
              <Search className="h-4 w-4 mr-2" />
              Vai alla Tracciabilità Completa
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchResults && (
        <div className="space-y-6">
          {/* Batch Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Informazioni Lotto
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-2xl font-bold">{searchResults?.batch?.code}</h3>
                    <p className="text-lg text-muted-foreground">{searchResults?.batch?.productName}</p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant={getStatusBadgeVariant(searchResults?.batch?.status)}>
                      {getStatusLabel(searchResults?.batch?.status)}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Quantità:</span>
                      <span className="font-medium">
                        {searchResults?.batch?.quantity} {searchResults?.batch?.unit}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Data Produzione:</span>
                      <span className="font-medium">
                        {formatDate(searchResults?.batch?.productionDate)}
                      </span>
                    </div>

                    {searchResults?.batch?.expiryDate && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Data Scadenza:</span>
                        <span className="font-medium">
                          {formatDate(searchResults?.batch?.expiryDate)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  {searchResults?.batch?.notes && (
                    <div>
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Note
                      </h4>
                      <p className="text-sm text-muted-foreground bg-muted p-3 rounded-lg">
                        {searchResults?.batch?.notes}
                      </p>
                    </div>
                  )}

                  <div className="text-xs text-muted-foreground">
                    <div className="flex items-center justify-between">
                      <span>Creato:</span>
                      <span>{formatDate(searchResults?.batch?.createdAt)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Ultimo aggiornamento:</span>
                      <span>{formatDate(searchResults?.batch?.updatedAt)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recipe Information */}
          {searchResults?.recipe && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ChefHat className="h-5 w-5" />
                  Ricetta Utilizzata
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-bold">{searchResults.recipe.name}</h3>
                    <Badge variant="outline" className="mt-1">
                      {searchResults.recipe.category}
                    </Badge>
                  </div>

                  {searchResults.recipe.description && (
                    <p className="text-muted-foreground">{searchResults.recipe.description}</p>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        {searchResults.recipe.preparationTime} minuti
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{searchResults.recipe.yield}</span>
                    </div>
                    {searchResults.recipe.productionCost && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm">
                          Costo: €{Number(searchResults.recipe.productionCost).toFixed(2)}
                        </span>
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Ingredients with Fixed Percentages */}
                  <div>
                    <h4 className="font-medium mb-3">Ingredienti e Composizione</h4>
                    <div className="space-y-2">
                      <div className="text-xs text-green-700 mb-3 font-medium">Le percentuali mostrano la composizione del prodotto finito</div>
                      
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg border">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Cipolle Bianche</span>
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">60%</span>
                          </div>
                          <div className="text-xs text-muted-foreground">Quantità: 40 kg</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg border">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Zucchero di canna</span>
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">8%</span>
                          </div>
                          <div className="text-xs text-muted-foreground">Quantità: 750 g</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg border">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Olio extravergine</span>
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">4%</span>
                          </div>
                          <div className="text-xs text-muted-foreground">Quantità: 1.5 l</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg border">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">aceto balsamico</span>
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">2%</span>
                          </div>
                          <div className="text-xs text-muted-foreground">Quantità: 750 ml</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg border">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Sale marino</span>
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">0.8%</span>
                          </div>
                          <div className="text-xs text-muted-foreground">Quantità: 250 g</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Detailed Ingredients with Supplier Information */}
                  <div>
                    <h4 className="font-medium mb-3">Ingredienti e Provenienza</h4>
                    <div className="space-y-3">
                      {searchResults.recipe.ingredients?.map((ingredient: any, index: number) => (
                        <div key={index} className="p-4 bg-muted rounded-lg border">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{ingredient.name}</span>
                              {ingredient.productPercentage && (
                                <Badge variant="secondary" className="text-xs bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                                  {ingredient.productPercentage}%
                                </Badge>
                              )}
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {ingredient.quantity} {ingredient.unit}
                            </span>
                          </div>
                          
                          {(ingredient.supplier || ingredient.supplierLot) && (
                            <div className="space-y-1 text-sm">
                              {ingredient.supplier && (
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">Fornitore:</span>
                                  <span className="font-medium text-blue-600 dark:text-blue-400">
                                    {ingredient.supplier}
                                  </span>
                                </div>
                              )}
                              {ingredient.supplierLot && (
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">Lotto acquisto:</span>
                                  <span className="font-mono text-xs bg-blue-100 dark:bg-blue-900/30 px-2 py-1 rounded">
                                    {ingredient.supplierLot}
                                  </span>
                                </div>
                              )}
                            </div>
                          )}
                          
                          {ingredient.allergens && ingredient.allergens.length > 0 && (
                            <div className="mt-2">
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-muted-foreground">Allergeni:</span>
                                <div className="flex gap-1">
                                  {ingredient.allergens.map((allergen: string, allergenIndex: number) => (
                                    <Badge key={allergenIndex} variant="destructive" className="text-xs">
                                      {allergen}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Original simple ingredients list for reference */}
                  <div className="hidden">
                    <h4 className="font-medium mb-3">Ingredienti</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {searchResults.recipe.ingredients?.map((ingredient: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                          <span className="text-sm font-medium">{ingredient.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {ingredient.quantity} {ingredient.unit}
                            {ingredient.cost && ` - €${ingredient.cost.toFixed(2)}`}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Allergens */}
                  {searchResults.recipe.allergens && searchResults.recipe.allergens.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-3 flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-orange-500" />
                        Allergeni
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {searchResults.recipe.allergens.map((allergen: string) => (
                          <Badge key={allergen} variant="outline" className="text-xs">
                            {allergen}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Instructions */}
                  <div>
                    <h4 className="font-medium mb-3">Istruzioni di Preparazione</h4>
                    <p className="text-sm text-muted-foreground whitespace-pre-line bg-muted p-4 rounded-lg">
                      {searchResults.recipe.instructions}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* QR Label Information */}
          {searchResults.qrLabel && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <QrCode className="h-5 w-5" />
                  Etichetta QR
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Codice Etichetta:</span>
                    <span className="font-medium">{searchResults.qrLabel.code}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Data Generazione:</span>
                    <span className="font-medium">
                      {formatDate(searchResults.qrLabel.generatedAt)}
                    </span>
                  </div>

                  {searchResults.qrLabel.data && (
                    <div>
                      <h4 className="font-medium mb-3">Dati Tracciabilità</h4>
                      <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Codice Tracciabilità:</span>
                          <span className="font-mono">{searchResults.qrLabel.data.traceabilityCode}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Produttore:</span>
                          <span>{searchResults.qrLabel.data.producer}</span>
                        </div>
                        {searchResults.qrLabel.data.ingredients && (
                          <div>
                            <span className="block mb-1">Ingredienti:</span>
                            <div className="pl-4 text-muted-foreground">
                              {searchResults.qrLabel.data.ingredients.join(", ")}
                            </div>
                          </div>
                        )}
                        {searchResults.qrLabel.data.allergens && searchResults.qrLabel.data.allergens.length > 0 && (
                          <div>
                            <span className="block mb-1">Allergeni:</span>
                            <div className="pl-4 text-muted-foreground">
                              {searchResults.qrLabel.data.allergens.join(", ")}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Company Information */}
          {companyProfile && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Informazioni Produttore
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold">{companyProfile.ragioneSociale}</h3>
                      {companyProfile.settore && (
                        <Badge variant="outline" className="mt-1">
                          {companyProfile.settore}
                        </Badge>
                      )}
                    </div>

                    <div className="space-y-2">
                      {companyProfile.indirizzo && (
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <div className="text-sm">
                            <div>{companyProfile.indirizzo}</div>
                            <div>
                              {companyProfile.cap && `${companyProfile.cap} `}
                              {companyProfile.citta}
                              {companyProfile.provincia && ` (${companyProfile.provincia})`}
                            </div>
                          </div>
                        </div>
                      )}

                      {companyProfile.telefono && (
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{companyProfile.telefono}</span>
                        </div>
                      )}

                      {companyProfile.emailAziendale && (
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{companyProfile.emailAziendale}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    {companyProfile.descrizione && (
                      <div>
                        <h4 className="font-medium mb-2">Descrizione</h4>
                        <p className="text-sm text-muted-foreground">{companyProfile.descrizione}</p>
                      </div>
                    )}

                    {companyProfile.certificazioni && companyProfile.certificazioni.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Certificazioni</h4>
                        <div className="space-y-2">
                          {companyProfile.certificazioni.map((cert: any, index: number) => (
                            <div key={index} className="text-sm bg-muted p-2 rounded-lg">
                              <div className="font-medium">{cert.tipo}</div>
                              <div className="text-muted-foreground text-xs">
                                {cert.numero} - {cert.enteRilascio}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {(companyProfile.partitaIva || companyProfile.codiceFiscale) && (
                      <div className="text-xs text-muted-foreground">
                        {companyProfile.partitaIva && (
                          <div>P.IVA: {companyProfile.partitaIva}</div>
                        )}
                        {companyProfile.codiceFiscale && (
                          <div>C.F.: {companyProfile.codiceFiscale}</div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Nutritional Information */}
          {searchResults?.nutritionalValues && (
            <div className="flex justify-center">
              <NutritionalLabel 
                nutritionalValues={searchResults.nutritionalValues}
                ingredients={searchResults?.recipe?.ingredients?.map((ing: any) => ({
                  name: ing.name,
                  productPercentage: ing.productPercentage
                }))}
                className="max-w-md"
              />
            </div>
          )}
        </div>
      )}

      {/* No Results */}
      {searchResults === null && selectedBatchCode && !isLoading && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Search className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nessun risultato trovato</h3>
              <p className="text-muted-foreground">
                Il lotto "{selectedBatchCode}" non è stato trovato nel sistema.
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Verifica che il numero di lotto sia corretto e riprova.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help */}
      {!selectedBatchCode && (
        <Card>
          <CardHeader>
            <CardTitle>Come Utilizzare la Tracciabilità</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium">Ricerca per Lotto</h4>
                  <p className="text-sm text-muted-foreground">
                    Seleziona un lotto dalla lista per visualizzare 
                    tutte le informazioni complete della filiera.
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Informazioni Disponibili</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Dettagli completi del lotto</li>
                    <li>• Ricetta e ingredienti utilizzati</li>
                    <li>• Allergeni presenti</li>
                    <li>• Etichette QR generate</li>
                    <li>• Storico delle modifiche</li>
                  </ul>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <QrCode className="h-4 w-4" />
                <span>
                  Puoi anche scansionare un codice QR per accedere rapidamente 
                  alle informazioni di tracciabilità.
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default TraceabilitySearch;