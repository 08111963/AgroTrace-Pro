import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Euro, ShoppingCart, TrendingUp, Calendar, User, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const saleSchema = z.object({
  inventoryItemId: z.string().min(1, "Seleziona un prodotto"),
  batchId: z.string().min(1, "Seleziona un lotto"),
  quantitySold: z.string().min(1, "Inserisci la quantità venduta"),
  unitPrice: z.string().optional(),
  customerName: z.string().optional(),
  customerEmail: z.string().email().optional().or(z.literal("")),
  customerPhone: z.string().optional(),
  paymentMethod: z.enum(["contanti", "carta", "bonifico"]),
  notes: z.string().optional(),
  saleDate: z.string().optional(),
});

type SaleFormData = z.infer<typeof saleSchema>;

export default function SalesManagement() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: zodResolver(saleSchema),
    defaultValues: {
      inventoryItemId: "",
      batchId: "0",
      quantitySold: "1",
      unitPrice: "",
      customerName: "",
      customerEmail: "",
      customerPhone: "",
      paymentMethod: "contanti",
      notes: "",
      saleDate: new Date().toISOString().split('T')[0],
    },
  });

  // Fetch data
  const { data: sales = [] } = useQuery({
    queryKey: ["/api/sales"],
  });

  const { data: inventory = [] } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/batches"],
  });

  const { data: salesStats } = useQuery({
    queryKey: ["/api/sales/stats"],
  });

  // Create sale mutation
  const createSale = useMutation({
    mutationFn: (data: SaleFormData) => 
      fetch("/api/sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }).then(res => res.json()),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sales/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      form.reset();
      setIsDialogOpen(false);
      toast({
        title: "Vendita registrata",
        description: response.message || "La vendita è stata registrata con successo",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante la registrazione della vendita",
        variant: "destructive",
      });
    },
  });

  // Delete sale mutation
  const deleteSale = useMutation({
    mutationFn: (saleId: number) =>
      fetch(`/api/sales/${saleId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
      }).then(res => res.json()),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sales/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Vendita eliminata",
        description: response.message || "Vendita eliminata e scorte ripristinate",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante l'eliminazione della vendita",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    const quantity = Number(data.quantitySold) || 0;
    const price = Number(data.unitPrice) || 0;
    const totalAmount = (quantity * price).toFixed(2);
    
    const processedData = {
      ...data,
      inventoryItemId: Number(data.inventoryItemId),
      batchId: Number(data.batchId),
      quantitySold: data.quantitySold,
      unitPrice: data.unitPrice || "0",
      totalAmount: totalAmount,
    };
    createSale.mutate(processedData);
  };

  const selectedInventoryItem = form.watch("inventoryItemId");
  const availableItem = inventory.find((item: any) => item.id === Number(selectedInventoryItem));

  // Auto-fill unit price when product is selected
  const handleProductSelect = (value: string) => {
    form.setValue("inventoryItemId", value);
    const item = inventory.find((item: any) => item.id === Number(value));
    if (item && item.salePrice) {
      form.setValue("unitPrice", item.salePrice.toString());
    }
  };

  // Filter batches for selected product
  const availableBatches = batches.filter((batch: any) => 
    availableItem && batch.productName === availableItem.name
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-success p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <Euro className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Gestione Vendite</h1>
              <p className="text-xl text-white/90">
                Registra vendite e gestisci automaticamente inventario e lotti
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <div className="flex justify-between items-center">
        <div></div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Nuova Vendita
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Registra Nuova Vendita</DialogTitle>
              <DialogDescription>
                La vendita aggiornerà automaticamente l'inventario e i lotti
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="inventoryItemId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Prodotto *</FormLabel>
                        <Select onValueChange={handleProductSelect} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona prodotto" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {inventory
                              .filter((item: any) => 
                                item.status !== 'out_of_stock' && 
                                item.category === 'prodotti_finiti'
                              )
                              .map((item: any) => (
                              <SelectItem key={item.id} value={item.id.toString()}>
                                {item.name} - Stock: {item.currentStock} {item.unit}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="quantitySold"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quantità Venduta *</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.01" 
                            placeholder="1" 
                            {...field} 
                          />
                        </FormControl>
                        {availableItem && (
                          <p className="text-sm text-muted-foreground">
                            Disponibili: {availableItem.currentStock} {availableItem.unit}
                          </p>
                        )}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="batchId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lotto *</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona un lotto" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {availableBatches.map((batch: any) => (
                              <SelectItem key={batch.id} value={batch.id.toString()}>
                                {batch.code} - {batch.quantity} {batch.unit} rimasti
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <p className="text-sm text-orange-600">
                          Selezione lotto obbligatoria per garantire tracciabilità completa
                        </p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="unitPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Prezzo Unitario</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.01" 
                            placeholder={availableItem?.salePrice || "0.00"} 
                            {...field} 
                          />
                        </FormControl>
                        {availableItem && (
                          <p className="text-sm text-muted-foreground">
                            Prezzo di listino: €{availableItem.salePrice}
                          </p>
                        )}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="customerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome Cliente</FormLabel>
                        <FormControl>
                          <Input placeholder="Nome del cliente" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="paymentMethod"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Metodo di Pagamento</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="contanti">Contanti</SelectItem>
                            <SelectItem value="carta">Carta</SelectItem>
                            <SelectItem value="bonifico">Bonifico</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="customerEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Cliente</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="email@esempio.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="customerPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telefono Cliente</FormLabel>
                        <FormControl>
                          <Input placeholder="+39 123 456 7890" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Note</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Note aggiuntive sulla vendita" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Annulla
                  </Button>
                  <Button type="submit" disabled={createSale.isPending}>
                    {createSale.isPending ? "Registrazione..." : "Registra Vendita"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      {salesStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Euro className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Vendite Totali</p>
                  <p className="text-2xl font-bold text-green-600">€{salesStats.totalSales}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <ShoppingCart className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Transazioni</p>
                  <p className="text-2xl font-bold">{salesStats.totalTransactions}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Oggi</p>
                  <p className="text-2xl font-bold text-purple-600">€{salesStats.todayRevenue}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Vendite Oggi</p>
                  <p className="text-2xl font-bold">{salesStats.todayTransactions}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Sales List */}
      <Card>
        <CardHeader>
          <CardTitle>Registro Vendite</CardTitle>
        </CardHeader>
        <CardContent>
          {sales.length === 0 ? (
            <div className="text-center py-8">
              <ShoppingCart className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nessuna vendita registrata</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sales.map((sale: any) => (
                <div key={sale.id} className="card-elevated p-6 hover:shadow-glow-hover transition-all duration-200">
                  <div className="flex justify-between items-start">
                    <div className="space-y-3 flex-1">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-green-100 dark:bg-green-950/30 rounded-lg">
                          <ShoppingCart className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-bold text-lg text-foreground">
                            {inventory.find((item: any) => item.id === sale.inventoryItemId)?.name || 'Prodotto'}
                          </h4>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              Qtà: {sale.quantitySold} {inventory.find((item: any) => item.id === sale.inventoryItemId)?.unit || 'unità'}
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              {sale.paymentMethod}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      
                      {sale.customerName && (
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground bg-muted/30 p-2 rounded">
                          <User className="h-4 w-4" />
                          <span className="font-medium">{sale.customerName}</span>
                        </div>
                      )}
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="bg-blue-50 dark:bg-blue-950/30 p-3 rounded-lg">
                          <p className="text-blue-600 dark:text-blue-400 font-medium">Prezzo Unitario</p>
                          <p className="text-lg font-bold text-blue-700 dark:text-blue-300">€{sale.unitPrice}</p>
                        </div>
                        <div className="bg-green-50 dark:bg-green-950/30 p-3 rounded-lg">
                          <p className="text-green-600 dark:text-green-400 font-medium">Totale</p>
                          <p className="text-lg font-bold text-green-700 dark:text-green-300">
                            €{(parseFloat(sale.unitPrice) * parseFloat(sale.quantitySold)).toFixed(2)}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(sale.saleDate).toLocaleDateString('it-IT')}</span>
                        </div>
                      </div>
                      
                      {sale.notes && (
                        <div className="bg-muted/30 p-3 rounded-lg">
                          <p className="text-sm text-muted-foreground font-medium">Note:</p>
                          <p className="text-sm">{sale.notes}</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="text-right flex flex-col items-end space-y-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          if (confirm("Sei sicuro di voler eliminare questa vendita? Le scorte verranno ripristinate.")) {
                            deleteSale.mutate(sale.id);
                          }
                        }}
                        disabled={deleteSale.isPending}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <p className="text-2xl font-bold text-green-600">€{sale.totalAmount}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}