import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, X, Sparkles, ChefHat, Clock, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface GeneratedRecipe {
  name: string;
  category: string;
  description: string;
  ingredients: Array<{
    name: string;
    quantity: number;
    unit: string;
  }>;
  instructions: string[];
  preparationTime: number;
  cookingTime: number;
  difficulty: 'facile' | 'medio' | 'difficile';
  notes?: string;
}

interface NutritionalData {
  calories: number;
  proteins: number;
  carbohydrates: number;
  sugars: number;
  fats: number;
  saturatedFats: number;
  fiber: number;
  sodium: number;
  salt: number;
}

export default function AIRecipeGenerator() {
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const [newIngredient, setNewIngredient] = useState("");
  const [recipeType, setRecipeType] = useState<'dolce' | 'salato' | 'succo' | 'sottolio'>('salato');
  const [jarCount, setJarCount] = useState(10);
  const [jarCapacity, setJarCapacity] = useState(0.5);
  const [jarUnit, setJarUnit] = useState("ml");
  const [useJarSpecification, setUseJarSpecification] = useState(true);
  const [additionalInstructions, setAdditionalInstructions] = useState("");
  const [vegetablePercentage, setVegetablePercentage] = useState(85);
  const [acidType, setAcidType] = useState<'aceto' | 'limone' | 'nessuno'>('nessuno');
  const [generatedRecipe, setGeneratedRecipe] = useState<GeneratedRecipe | null>(null);
  const [nutrition, setNutrition] = useState<NutritionalData | null>(null);
  
  const { toast } = useToast();

  interface InventoryItem {
    id: number;
    name: string;
    code: string;
    category: string;
    currentStock: number;
    minimumStock: number;
    unit: string;
    unitCost: string | null;
    salePrice: string | null;
    supplier: string | null;
    location: string | null;
    status: string;
    expiryDate: Date | null;
    notes: string;
  }

  // Carica inventario per suggerimenti ingredienti
  const { data: inventory = [] } = useQuery<InventoryItem[]>({
    queryKey: ['/api/inventory'],
  });

  // Carica ingredienti disponibili dal database nutrizionale
  const { data: availableIngredients } = useQuery<{
    all: string[];
    byCategory: {
      frutta: string[];
      verdure: string[];
      dolcificanti: string[];
      spezie: string[];
      oli: string[];
      altro: string[];
    };
  }>({
    queryKey: ['/api/ingredients/available'],
  });

  const generateMutation = useMutation({
    mutationFn: async (data: {
      ingredients: string[];
      type: 'dolce' | 'salato';
      servings: number;
      targetQuantity?: number;
      targetUnit?: string;
      additionalInstructions?: string;
    }): Promise<{ recipe: GeneratedRecipe; nutrition: NutritionalData }> => {
      const response = await fetch('/api/recipes/generate', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error('Errore nella generazione della ricetta');
      }
      
      return response.json();
    },
    onSuccess: (response: { recipe: GeneratedRecipe; nutrition: NutritionalData }) => {
      setGeneratedRecipe(response.recipe);
      setNutrition(response.nutrition);
      toast({
        title: "Ricetta generata!",
        description: `Creata ricetta: ${response.recipe.name}`,
      });
    },
    onError: (error) => {
      console.error('Errore generazione ricetta:', error);
      toast({
        title: "Errore",
        description: "Impossibile generare la ricetta. Riprova più tardi.",
        variant: "destructive",
      });
    },
  });

  const saveRecipeMutation = useMutation({
    mutationFn: async (recipe: GeneratedRecipe) => {
      // Calculate yield and jarWeight from the generation parameters
      const calculatedYield = jarCount;
      const calculatedJarWeight = jarUnit === 'ml' || jarUnit === 'l' 
        ? Math.round(jarCapacity * (jarUnit === 'l' ? 1000 : 1)) // Convert to grams (1ml = 1g, 1L = 1000g)
        : jarCapacity; // Already in grams
      
      const recipeData = {
        name: recipe.name,
        category: recipe.category,
        description: recipe.description,
        ingredients: recipe.ingredients,
        instructions: recipe.instructions.join('\n'),
        preparationTime: recipe.preparationTime,
        yield: calculatedYield,
        jarWeight: calculatedJarWeight,
        status: 'active',
      };
      
      const response = await fetch('/api/recipes', {
        method: 'POST',
        body: JSON.stringify(recipeData),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error('Errore nel salvataggio della ricetta');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recipes'] });
      toast({
        title: "Ricetta salvata!",
        description: "La ricetta è stata aggiunta al tuo ricettario.",
      });
      // Reset form
      setGeneratedRecipe(null);
      setNutrition(null);
      setSelectedIngredients([]);
      setAdditionalInstructions("");
      setJarCount(10);
      setJarCapacity(200);
    },
    onError: (error) => {
      console.error('Errore salvataggio ricetta:', error);
      toast({
        title: "Errore",
        description: "Impossibile salvare la ricetta.",
        variant: "destructive",
      });
    },
  });

  const addIngredient = () => {
    if (newIngredient.trim() && !selectedIngredients.includes(newIngredient.trim())) {
      setSelectedIngredients([...selectedIngredients, newIngredient.trim()]);
      setNewIngredient("");
    }
  };

  const removeIngredient = (ingredient: string) => {
    setSelectedIngredients(selectedIngredients.filter(i => i !== ingredient));
  };

  const addInventoryIngredient = (ingredientName: string) => {
    if (!selectedIngredients.includes(ingredientName)) {
      setSelectedIngredients([...selectedIngredients, ingredientName]);
    }
  };

  const handleGenerate = () => {
    if (selectedIngredients.length === 0) {
      toast({
        title: "Ingredienti richiesti",
        description: "Seleziona almeno un ingrediente per generare la ricetta.",
        variant: "destructive",
      });
      return;
    }

    const totalVolume = jarCount * jarCapacity;
    const targetDescription = `${jarCount} vasetti da ${jarCapacity}${jarUnit}`;
    
    generateMutation.mutate({
      ingredients: selectedIngredients,
      type: recipeType as 'dolce' | 'salato' | 'succo' | 'sottolio',
      servings: 4,
      targetQuantity: totalVolume,
      targetUnit: `${jarUnit} (${targetDescription})`,
      additionalInstructions: `${additionalInstructions.trim()} ${(recipeType === 'salato' || recipeType === 'sottolio') && acidType !== 'nessuno' ? `acidificante: ${acidType === 'aceto' ? 'aceto di vino bianco' : 'succo di limone fresco'}` : ''}`.trim() || undefined,
      vegetablePercentage: vegetablePercentage,
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'facile': return 'bg-green-100 text-green-800';
      case 'medio': return 'bg-yellow-100 text-yellow-800';
      case 'difficile': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-600" />
            Generatore Ricette AI
          </CardTitle>
          <CardDescription>
            Inserisci gli ingredienti disponibili e l'AI creerà una ricetta personalizzata per te
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Selezione tipo ricetta */}
          <div className="space-y-2">
            <Label>Tipo di ricetta</Label>
            <Select value={recipeType} onValueChange={(value: 'dolce' | 'salato' | 'succo' | 'sottolio') => setRecipeType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="salato">🍽️ Salato</SelectItem>
                <SelectItem value="dolce">🍰 Dolce</SelectItem>
                <SelectItem value="succo">🧃 Succo di Frutta</SelectItem>
                <SelectItem value="sottolio">🫒 Sott'olio</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Configurazione vasetti */}
          <div className="space-y-3">
            <Label>Configurazione produzione</Label>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <Label className="text-sm">Numero vasetti</Label>
                <input
                  key="count-input"
                  type="text"
                  defaultValue="10"
                  onChange={(e) => {
                    const val = e.target.value;
                    const numVal = parseInt(val);
                    if (!isNaN(numVal) && numVal >= 1 && numVal <= 1000) {
                      setJarCount(numVal);
                    }
                  }}
                  className="flex h-10 w-full rounded-md border-2 border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                  placeholder="Numero vasetti (es. 10, 25, 50)"
                />
              </div>
              <div>
                <Label className="text-sm">Capienza</Label>
                <Select value={jarCapacity.toString()} onValueChange={(value) => setJarCapacity(parseFloat(value))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0.2">0.2</SelectItem>
                    <SelectItem value="0.25">0.25</SelectItem>
                    <SelectItem value="0.3">0.3</SelectItem>
                    <SelectItem value="0.314">0.314</SelectItem>
                    <SelectItem value="0.37">0.37</SelectItem>
                    <SelectItem value="0.5">0.5</SelectItem>
                    <SelectItem value="0.72">0.72</SelectItem>
                    <SelectItem value="1">1</SelectItem>
                    <SelectItem value="1.5">1.5</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="150">150</SelectItem>
                    <SelectItem value="200">200</SelectItem>
                    <SelectItem value="250">250</SelectItem>
                    <SelectItem value="280">280</SelectItem>
                    <SelectItem value="300">300</SelectItem>
                    <SelectItem value="314">314</SelectItem>
                    <SelectItem value="350">350</SelectItem>
                    <SelectItem value="370">370</SelectItem>
                    <SelectItem value="500">500</SelectItem>
                    <SelectItem value="580">580</SelectItem>
                    <SelectItem value="720">720</SelectItem>
                    <SelectItem value="1000">1000</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm">Unità</Label>
                <Select value={jarUnit} onValueChange={setJarUnit}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ml">ml</SelectItem>
                    <SelectItem value="g">g</SelectItem>
                    <SelectItem value="l">litri</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="text-sm text-gray-600 bg-blue-50 p-2 rounded">
              📦 Totale: {jarCount} vasetti da {jarCapacity}{jarUnit} = {jarCount * jarCapacity}{jarUnit} totali
            </div>
          </div>

          {/* Controllo percentuale verdura/frutta per conserve */}
          {(recipeType === 'sottolio' || recipeType === 'dolce' || recipeType === 'succo' || recipeType === 'salato') && (
            <div className="space-y-3">
              <Label>Composizione ricetta</Label>
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <div className="space-y-2">
                  <Label className="text-sm">
                    Percentuale {recipeType === 'sottolio' || recipeType === 'salato' ? 'verdura' : 'frutta'}: {vegetablePercentage}%
                  </Label>
                  <input
                    type="range"
                    min={recipeType === 'succo' ? "70" : "50"}
                    max={recipeType === 'succo' ? "95" : "80"}
                    value={vegetablePercentage}
                    onChange={(e) => setVegetablePercentage(parseInt(e.target.value))}
                    className="w-full h-2 bg-green-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-xs text-gray-600">
                    {recipeType === 'succo' ? (
                      <>
                        <span>70% (diluito)</span>
                        <span>85% (bilanciato)</span>
                        <span>95% (concentrato)</span>
                      </>
                    ) : (
                      <>
                        <span>50% (più liquido)</span>
                        <span>65% (bilanciato)</span>
                        <span>80% (più {recipeType === 'sottolio' ? 'verdura' : 'frutta'})</span>
                      </>
                    )}
                  </div>

                </div>
              </div>
            </div>
          )}



          {/* Ingredienti dal magazzino */}
          <div className="space-y-2">
            <Label>Ingredienti dal magazzino</Label>
            <div className="flex flex-wrap gap-2">
              {inventory.map((item) => (
                <Button
                  key={item.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addInventoryIngredient(item.name)}
                  disabled={selectedIngredients.includes(item.name)}
                  className="text-xs"
                >
                  {item.name}
                  {selectedIngredients.includes(item.name) && <span className="ml-1">✓</span>}
                </Button>
              ))}
            </div>
          </div>

          {/* Aggiungi ingrediente manualmente */}
          <div className="space-y-2">
            <Label>Aggiungi ingrediente</Label>
            <div className="flex gap-2">
              <Input
                value={newIngredient}
                onChange={(e) => setNewIngredient(e.target.value)}
                placeholder="Nome ingrediente..."
                onKeyPress={(e) => e.key === 'Enter' && addIngredient()}
              />
              <Button onClick={addIngredient} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Ingredienti selezionati */}
          {selectedIngredients.length > 0 && (
            <div className="space-y-2">
              <Label>Ingredienti selezionati</Label>
              <div className="flex flex-wrap gap-2">
                {selectedIngredients.map((ingredient) => (
                  <Badge key={ingredient} variant="secondary" className="flex items-center gap-1">
                    {ingredient}
                    <X
                      className="h-3 w-3 cursor-pointer hover:text-red-500"
                      onClick={() => removeIngredient(ingredient)}
                    />
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Scelta acidificante per conserve salate e sott'olio */}
          {(recipeType === 'salato' || recipeType === 'sottolio') && (
            <div className="space-y-3">
              <Label>Acidificante per conservazione</Label>
              <Select value={acidType} onValueChange={(value) => setAcidType(value as 'aceto' | 'limone' | 'nessuno')}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona acidificante" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nessuno">Nessun acidificante</SelectItem>
                  <SelectItem value="aceto">Aceto (tradizionale)</SelectItem>
                  <SelectItem value="limone">Succo di limone (naturale)</SelectItem>
                </SelectContent>
              </Select>
              <div className="text-xs text-gray-600 bg-yellow-50 p-2 rounded">
                {acidType === 'nessuno' ? 'Ricetta senza acidificanti aggiunti' : 
                 acidType === 'aceto' ? 'Aceto di vino bianco per sapore neutro e conservazione ottimale' : 
                 'Succo di limone fresco per acidità naturale e sapore delicato'}
              </div>
            </div>
          )}

          {/* Istruzioni aggiuntive */}
          <div className="space-y-2">
            <Label>Istruzioni aggiuntive (opzionale)</Label>
            <Textarea
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              placeholder="Es: Senza glutine, piccante, veloce da preparare..."
              rows={3}
            />
          </div>

          {/* Pulsante genera */}
          <Button
            onClick={handleGenerate}
            disabled={selectedIngredients.length === 0 || generateMutation.isPending}
            className="w-full"
            size="lg"
          >
            {generateMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generazione in corso...
              </>
            ) : (
              <>
                <ChefHat className="mr-2 h-4 w-4" />
                Genera Ricetta
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Ricetta generata */}
      {generatedRecipe && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{generatedRecipe.name}</span>
              <Badge className={getDifficultyColor(generatedRecipe.difficulty)}>
                {generatedRecipe.difficulty}
              </Badge>
            </CardTitle>
            <CardDescription>{generatedRecipe.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Info tempi */}
            <div className="flex gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                Prep: {generatedRecipe.preparationTime} min
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                Cottura: {generatedRecipe.cookingTime} min
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                {jarCount} vasetti da {jarCapacity}{jarUnit}
              </div>
            </div>

            {/* Ingredienti per la produzione */}
            <div>
              <h4 className="font-semibold mb-3 text-green-700">📋 Quantità da utilizzare in produzione</h4>
              <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200 mb-4">
                <p className="text-sm text-green-800 mb-3 font-medium">
                  Utilizza queste quantità esatte per la produzione (scarti già inclusi):
                </p>
                <div className="space-y-2">
                  {generatedRecipe.ingredients.map((ingredient, index) => (
                    <div key={index} className="flex justify-between items-center bg-white p-3 rounded border border-green-200">
                      <div className="flex flex-col">
                        <span className="font-medium text-gray-800">{ingredient.name}</span>
                        {(ingredient as any).productPercentage && (
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full mt-1 w-fit">
                            {(ingredient as any).productPercentage}% del prodotto
                          </span>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-lg text-green-700">
                          {ingredient.quantity} {ingredient.unit}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Dettaglio calcolo scarti (collassabile) */}
              <details className="bg-gray-50 p-3 rounded border">
                <summary className="cursor-pointer text-sm font-medium text-gray-600 hover:text-gray-800">
                  📊 Dettaglio calcolo scarti
                </summary>
                <div className="mt-3 space-y-2">
                  {generatedRecipe.ingredients.map((ingredient, index) => (
                    <div key={index} className="text-xs text-gray-600 bg-white p-2 rounded">
                      <div className="font-medium flex items-center justify-between">
                        <span>{ingredient.name}</span>
                        {(ingredient as any).productPercentage && (
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                            {(ingredient as any).productPercentage}% del prodotto
                          </span>
                        )}
                      </div>
                      <div>• Quantità da usare: {ingredient.quantity} {ingredient.unit}</div>
                      {(ingredient as any).wastePercentage ? (
                        <>
                          <div>• Scarto stimato: {(ingredient as any).wastePercentage}%</div>
                          <div>• <span className="font-medium text-orange-600">Quantità finale dopo scarto: {(ingredient as any).baseQuantity} {ingredient.unit}</span></div>
                        </>
                      ) : (
                        <div>• Ingrediente ausiliario (nessuno scarto)</div>
                      )}
                    </div>
                  ))}
                </div>
              </details>
            </div>

            {/* Istruzioni */}
            <div>
              <h4 className="font-semibold mb-2">Procedimento</h4>
              <ol className="space-y-2">
                {generatedRecipe.instructions.map((instruction, index) => (
                  <li key={index} className="flex">
                    <span className="font-medium text-blue-600 mr-2">{index + 1}.</span>
                    <span>{instruction}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Note */}
            {generatedRecipe.notes && (
              <div>
                <h4 className="font-semibold mb-2">Note</h4>
                <p className="text-gray-600">{generatedRecipe.notes}</p>
              </div>
            )}

            {/* Valori nutrizionali */}
            {nutrition && (
              <div>
                <h4 className="font-semibold mb-2">Valori nutrizionali (per 100g di prodotto)</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="font-medium">Calorie</div>
                    <div className="text-gray-600">{nutrition.calories.toFixed(1)} kcal</div>
                  </div>
                  <div>
                    <div className="font-medium">Proteine</div>
                    <div className="text-gray-600">{nutrition.proteins.toFixed(1)} g</div>
                  </div>
                  <div>
                    <div className="font-medium">Carboidrati</div>
                    <div className="text-gray-600">{nutrition.carbohydrates.toFixed(1)} g</div>
                  </div>
                  <div>
                    <div className="font-medium">Grassi</div>
                    <div className="text-gray-600">{nutrition.fats.toFixed(1)} g</div>
                  </div>
                  <div>
                    <div className="font-medium">Zuccheri</div>
                    <div className="text-gray-600">{nutrition.sugars.toFixed(1)} g</div>
                  </div>
                  <div>
                    <div className="font-medium">Fibre</div>
                    <div className="text-gray-600">{nutrition.fiber.toFixed(1)} g</div>
                  </div>
                  <div>
                    <div className="font-medium">Sale</div>
                    <div className="text-gray-600">{nutrition.salt.toFixed(2)} g</div>
                  </div>
                  <div>
                    <div className="font-medium">Grassi saturi</div>
                    <div className="text-gray-600">{nutrition.saturatedFats.toFixed(1)} g</div>
                  </div>
                </div>
              </div>
            )}

            {/* Pulsante salva */}
            <Button
              onClick={() => saveRecipeMutation.mutate(generatedRecipe)}
              disabled={saveRecipeMutation.isPending}
              className="w-full"
              variant="default"
            >
              {saveRecipeMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvataggio...
                </>
              ) : (
                "Salva nel Ricettario"
              )}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}