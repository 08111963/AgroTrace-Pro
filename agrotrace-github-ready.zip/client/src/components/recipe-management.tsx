import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Search, Clock, Users, Euro, DollarSign, Download } from "lucide-react";
import type { Recipe, InsertRecipe, InventoryItem } from "@shared/schema";
import ProductionCostCalculator from "./production-cost-calculator";
import { exportRecipeToPDF } from "@/lib/pdf-utils";

const recipeFormSchema = z.object({
  name: z.string().min(1, "Nome richiesto"),
  category: z.string().min(1, "Categoria richiesta"),
  description: z.string().optional(),
  ingredients: z.array(z.object({
    name: z.string().min(1, "Nome ingrediente richiesto"),
    quantity: z.number().min(0, "Quantità deve essere positiva"),
    unit: z.string().min(1, "Unità richiesta"),
    cost: z.number().min(0, "Costo deve essere positivo").optional(),
    allergens: z.array(z.string()).optional(),
    supplier: z.string().min(1, "Fornitore richiesto"),
    supplierLot: z.string().min(1, "Lotto acquisto richiesto")
  })).min(1, "Almeno un ingrediente richiesto"),
  instructions: z.string().optional(),
  preparationInstructions: z.string().optional(),
  preparationTime: z.number().min(1, "Tempo di preparazione richiesto"),
  yield: z.number().min(1, "Numero vasetti richiesto"),
  jarWeight: z.number().min(1, "Peso vasetto richiesto"),
  targetJars: z.number().min(1, "Numero vasetti target richiesto").optional(),
  salePrice: z.number().optional(),
  status: z.string().optional()
});

type RecipeFormData = z.infer<typeof recipeFormSchema>;

const CATEGORY_OPTIONS = [
  "Conserve", "Confetture", "Sottoli", "Sottaceti", "Salse", 
  "Succhi di Frutta", "Bevande", "Latte e Derivati", "Liquori", 
  "Essicati", "Affumicati", "Marmellate", "Composte", "Gelatine",
  "Sciroppi", "Infusi", "Tisane", "Altro"
];

const ALLERGEN_OPTIONS = [
  "Glutine", "Latte", "Uova", "Soia", "Noci", "Arachidi",
  "Pesce", "Crostacei", "Sedano", "Senape", "Sesamo", "Lupini", 
  "Anidride solforosa", "Molluschi"
];

const RecipeForm = ({ recipe, onClose }: { recipe?: Recipe; onClose: () => void }) => {
  const { toast } = useToast();
  const [calculatedCostPerUnit, setCalculatedCostPerUnit] = useState<number>(0);
  const [baseIngredients, setBaseIngredients] = useState<any[]>([]);

  // Funzione per calcolare le quantità degli ingredienti in base ai vasetti target
  const calculateIngredientQuantities = (targetJars: number, baseYield: number, ingredients: any[]) => {
    if (!targetJars || !baseYield || baseYield <= 0) return ingredients;
    
    const scaleFactor = targetJars / baseYield;
    return ingredients.map(ingredient => ({
      ...ingredient,
      quantity: Math.round(ingredient.quantity * scaleFactor * 100) / 100
    }));
  };

  const form = useForm<RecipeFormData>({
    resolver: zodResolver(recipeFormSchema),
    defaultValues: recipe ? {
      name: recipe.name,
      category: recipe.category,
      description: recipe.description || "",
      ingredients: recipe.ingredients || [{ name: "", quantity: 0, unit: "g", cost: 0, allergens: [] }],
      instructions: recipe.instructions || "",
      preparationTime: recipe.preparationTime,
      yield: recipe.yield || 1,
      jarWeight: recipe.jarWeight || 200,
      targetJars: recipe.yield || 1,
      salePrice: recipe.salePrice ? Number(recipe.salePrice) : undefined,
      status: recipe.status || "Attiva"
    } : {
      name: "",
      category: "",
      description: "",
      ingredients: [{ name: "", quantity: 0, unit: "g", cost: 0, allergens: [] }],
      instructions: "",
      preparationTime: 30,
      yield: 1,
      jarWeight: 200,
      targetJars: 1,
      salePrice: undefined,
      status: "Attiva"
    }
  });

  // Salva le quantità base degli ingredienti quando la ricetta viene caricata
  useEffect(() => {
    if (recipe && recipe.ingredients) {
      setBaseIngredients([...recipe.ingredients]);
    }
  }, [recipe]);

  // Watch per il campo targetJars per ricalcolare automaticamente le quantità
  const targetJars = form.watch("targetJars");
  const baseYield = form.watch("yield");
  
  useEffect(() => {
    if (targetJars && baseYield && baseIngredients.length > 0) {
      const scaledIngredients = calculateIngredientQuantities(targetJars, baseYield, baseIngredients);
      form.setValue("ingredients", scaledIngredients);
    }
  }, [targetJars, baseYield, baseIngredients]);

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "ingredients"
  });

  const { data: inventory } = useQuery({
    queryKey: ["/api/inventory"],
    enabled: false
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertRecipe) => apiRequest("POST", "/api/recipes", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({ title: "Ricetta creata con successo" });
      onClose();
    },
    onError: () => {
      toast({ title: "Errore nella creazione della ricetta", variant: "destructive" });
    }
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertRecipe) => apiRequest("PUT", `/api/recipes/${recipe?.id}`, data),
    onSuccess: () => {
      // Invalida tutte le cache correlate per aggiornamento immediato
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/traceability"] });
      queryClient.invalidateQueries({ queryKey: ["/api/qr-labels"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Ricetta aggiornata con successo" });
      onClose();
    },
    onError: () => {
      toast({ title: "Errore nell'aggiornamento della ricetta", variant: "destructive" });
    }
  });

  const onSubmit = (data: RecipeFormData) => {
    const submitData: InsertRecipe = {
      name: data.name,
      category: data.category,
      description: data.description,
      ingredients: data.ingredients,
      instructions: data.instructions,
      preparationTime: data.preparationTime,
      yield: data.yield,
      jarWeight: data.jarWeight,
      salePrice: data.salePrice ? data.salePrice.toString() : undefined,
      status: data.status
    };

    if (recipe) {
      updateMutation.mutate(submitData);
    } else {
      createMutation.mutate(submitData);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome Ricetta</FormLabel>
                <FormControl>
                  <Input placeholder="Es. Confettura di Fragole" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Categoria</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleziona categoria" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {CATEGORY_OPTIONS.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Descrizione</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Breve descrizione della ricetta..."
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="preparationTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tempo Preparazione (min)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field} 
                    onChange={e => field.onChange(Number(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="yield"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Numero Vasetti</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field} 
                    onChange={e => field.onChange(Number(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="jarWeight"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Peso Vasetto (g)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    placeholder="200"
                    {...field} 
                    onChange={e => field.onChange(Number(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="targetJars"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Vasetti Target da Produrre</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    placeholder="1"
                    {...field} 
                    onChange={e => {
                      const value = Number(e.target.value);
                      field.onChange(value);
                      // Salva le quantità base prima del calcolo se non sono ancora salvate
                      if (baseIngredients.length === 0) {
                        setBaseIngredients([...form.getValues('ingredients')]);
                      }
                    }}
                  />
                </FormControl>
                <FormMessage />
                <p className="text-xs text-muted-foreground mt-1">
                  Le quantità degli ingredienti verranno calcolate automaticamente per questo numero di vasetti
                </p>
              </FormItem>
            )}
          />
        </div>



        {/* Calcolatore Quantità Intelligente */}
        {!recipe && (
          <Card className="p-6 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
            <h3 className="text-lg font-semibold text-blue-800 dark:text-blue-200 mb-4">
              Calcolatore Quantità Automatico
            </h3>
            <p className="text-sm text-blue-700 dark:text-blue-300 mb-4">
              Inserisci il peso totale della ricetta e quanti vasetti vuoi produrre, ti suggerirò le quantità automaticamente.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium text-blue-800 dark:text-blue-200">Peso Totale Ricetta (g)</label>
                <Input 
                  type="number" 
                  placeholder="2500" 
                  value={form.watch('jarWeight') * form.watch('yield')}
                  onChange={(e) => {
                    const totalWeight = Number(e.target.value);
                    const jarWeight = form.watch('jarWeight') || 200;
                    const newYield = Math.round(totalWeight / jarWeight);
                    form.setValue('yield', newYield);
                  }}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-blue-800 dark:text-blue-200">Vasetti da Produrre</label>
                <Input 
                  type="number" 
                  value={form.watch('targetJars') || form.watch('yield')}
                  onChange={(e) => form.setValue('targetJars', Number(e.target.value))}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-blue-800 dark:text-blue-200">Peso per Vasetto</label>
                <p className="text-lg font-bold text-blue-600 mt-2">
                  {((form.watch('jarWeight') * form.watch('yield')) / (form.watch('targetJars') || form.watch('yield'))).toFixed(0)}g
                </p>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-800 p-4 rounded border">
              <h4 className="font-medium mb-2">Suggerimenti Proporzioni Standard:</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                <span>• Conserve: 70% verdura, 25% acqua, 5% olio/aceto</span>
                <span>• Confetture: 60% frutta, 35% zucchero, 5% limone/pectina</span>
                <span>• Succhi: 80% frutta, 20% acqua</span>
                <span>• Sottoli: 85% verdura, 15% olio</span>
              </div>
            </div>
          </Card>
        )}

        {/* Ingredients Section */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Ingredienti della Ricetta</h3>
              <p className="text-sm text-muted-foreground">
                Inserisci gli ingredienti. Se hai impostato vasetti target diversi, le quantità verranno scalate automaticamente.
              </p>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => append({ name: "", quantity: 0, unit: "g", cost: 0, allergens: [], supplier: "", supplierLot: "" })}
            >
              <Plus className="h-4 w-4 mr-2" />
              Aggiungi Ingrediente
            </Button>
          </div>

          <div className="space-y-4">
            {fields.map((field, index) => (
              <div key={field.id} className="p-4 border rounded-lg bg-muted/30">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-sm">Ingrediente {index + 1}</h4>
                  {fields.length > 1 && (
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={() => remove(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <FormField
                    control={form.control}
                    name={`ingredients.${index}.name`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome Ingrediente</FormLabel>
                        <FormControl>
                          <Input placeholder="Es. Fragole" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name={`ingredients.${index}.quantity`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quantità</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.01"
                            placeholder="500"
                            {...field}
                            value={field.value || ""}
                            onChange={e => field.onChange(Number(e.target.value) || "")}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name={`ingredients.${index}.unit`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Unità</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Unità" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="g">g</SelectItem>
                            <SelectItem value="kg">kg</SelectItem>
                            <SelectItem value="ml">ml</SelectItem>
                            <SelectItem value="l">l</SelectItem>
                            <SelectItem value="pz">pz</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name={`ingredients.${index}.cost`}
                    render={({ field }) => {
                      const unit = form.watch(`ingredients.${index}.unit`) || "g";
                      const isLiquid = unit === "ml" || unit === "l";
                      const costLabel = isLiquid ? "Costo al litro (€)" : "Costo al kg (€)";
                      
                      return (
                        <FormItem>
                          <FormLabel>{costLabel}</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01"
                              placeholder="2.50"
                              {...field} 
                              value={field.value || ""}
                              onChange={e => field.onChange(Number(e.target.value) || "")}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />
                </div>

                {/* Supplier and Lot Information */}
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name={`ingredients.${index}.supplier`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fornitore</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Es. Azienda Agricola Rossi"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name={`ingredients.${index}.supplierLot`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lotto Acquisto</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Es. CIP-2024-156"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Optional Allergens Section */}
                <div className="mt-3 pt-3 border-t border-muted">
                  <details className="group">
                    <summary className="cursor-pointer text-sm font-medium text-muted-foreground hover:text-foreground">
                      Allergeni (opzionale) {((form.watch(`ingredients.${index}.allergens`) || []).length > 0) && 
                        `- ${(form.watch(`ingredients.${index}.allergens`) || []).length} selezionati`}
                    </summary>
                    <div className="mt-2 grid grid-cols-2 md:grid-cols-3 gap-2">
                      {ALLERGEN_OPTIONS.map(allergen => {
                        const currentAllergens = form.watch(`ingredients.${index}.allergens`) || [];
                        const isSelected = currentAllergens.includes(allergen);
                        
                        return (
                          <Button
                            key={allergen}
                            type="button"
                            variant={isSelected ? "default" : "outline"}
                            size="sm"
                            className="text-xs"
                            onClick={() => {
                              const current = form.getValues(`ingredients.${index}.allergens`) || [];
                              const updated = isSelected
                                ? current.filter(a => a !== allergen)
                                : [...current, allergen];
                              form.setValue(`ingredients.${index}.allergens`, updated);
                            }}
                          >
                            {allergen}
                          </Button>
                        );
                      })}
                    </div>
                  </details>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Cost Calculation Section */}
        <Card className="p-4 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <h3 className="text-lg font-semibold text-blue-800 dark:text-blue-200 mb-4">Calcolo Costi Stimati</h3>
          <p className="text-sm text-blue-700 dark:text-blue-300 mb-4">
            Costi stimati della ricetta basati sui prezzi al kg/litro inseriti. I costi reali verranno calcolati sui lotti effettivamente prodotti.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium">Costo Totale Ingredienti</label>
              <p className="text-2xl font-bold text-green-600">
                €{(() => {
                  const ingredients = form.watch('ingredients') || [];
                  const totalCost = ingredients.reduce((sum, ing) => {
                    const cost = Number(ing.cost) || 0;
                    const quantity = Number(ing.quantity) || 0;
                    const unit = ing.unit || 'g';
                    
                    // Convert to base units (kg for solids, l for liquids)
                    let convertedQuantity = quantity;
                    if (unit === 'g') convertedQuantity = quantity / 1000; // g to kg
                    if (unit === 'ml') convertedQuantity = quantity / 1000; // ml to l
                    
                    return sum + (cost * convertedQuantity);
                  }, 0);
                  return totalCost.toFixed(2);
                })()}
              </p>
            </div>
            <div>
              <label className="text-sm font-medium">Peso Totale Prodotto</label>
              <p className="text-2xl font-bold text-blue-600">
                {(() => {
                  const yieldCount = form.watch('yield') || 0;
                  const jarWeight = form.watch('jarWeight') || 0;
                  const totalWeight = yieldCount * jarWeight;
                  return `${totalWeight}g`;
                })()}
              </p>
            </div>
            <div>
              <label className="text-sm font-medium">Costo per Vasetto</label>
              <p className="text-2xl font-bold text-orange-600">
                €{(() => {
                  const ingredients = form.watch('ingredients') || [];
                  const yieldCount = form.watch('yield') || 0;
                  const totalCost = ingredients.reduce((sum, ing) => {
                    const cost = Number(ing.cost) || 0;
                    const quantity = Number(ing.quantity) || 0;
                    const unit = ing.unit || 'g';
                    
                    // Convert to base units (kg for solids, l for liquids)
                    let convertedQuantity = quantity;
                    if (unit === 'g') convertedQuantity = quantity / 1000; // g to kg
                    if (unit === 'ml') convertedQuantity = quantity / 1000; // ml to l
                    
                    return sum + (cost * convertedQuantity);
                  }, 0);
                  const costPerJar = yieldCount > 0 ? totalCost / yieldCount : 0;
                  return costPerJar.toFixed(2);
                })()}
              </p>
            </div>
          </div>

          {/* Ingredient Cost Breakdown */}
          <div className="mt-6">
            <h4 className="text-md font-semibold text-blue-800 dark:text-blue-200 mb-3">Ripartizione Costi per Ingrediente</h4>
            <div className="space-y-2">
              {(() => {
                const ingredients = form.watch('ingredients') || [];
                const totalCost = ingredients.reduce((sum, ing) => {
                  const cost = Number(ing.cost) || 0;
                  const quantity = Number(ing.quantity) || 0;
                  const unit = ing.unit || 'g';
                  
                  let convertedQuantity = quantity;
                  if (unit === 'g') convertedQuantity = quantity / 1000;
                  if (unit === 'ml') convertedQuantity = quantity / 1000;
                  
                  return sum + (cost * convertedQuantity);
                }, 0);

                return ingredients.map((ingredient, index) => {
                  const cost = Number(ingredient.cost) || 0;
                  const quantity = Number(ingredient.quantity) || 0;
                  const unit = ingredient.unit || 'g';
                  
                  let convertedQuantity = quantity;
                  if (unit === 'g') convertedQuantity = quantity / 1000;
                  if (unit === 'ml') convertedQuantity = quantity / 1000;
                  
                  const ingredientCost = cost * convertedQuantity;
                  const percentage = totalCost > 0 ? (ingredientCost / totalCost) * 100 : 0;
                  
                  if (!ingredient.name || ingredientCost === 0) return null;
                  
                  return (
                    <div key={index} className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 rounded border">
                      <div className="flex items-center space-x-3">
                        <span className="font-medium text-sm">{ingredient.name}</span>
                        <span className="text-xs text-gray-500">{quantity}{unit}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-semibold min-w-[60px] text-right">
                          {percentage.toFixed(1)}%
                        </span>
                        <span className="text-sm text-gray-600 min-w-[50px] text-right">
                          €{ingredientCost.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  );
                }).filter(Boolean);
              })()}
            </div>
          </div>
        </Card>

        {/* Production Cost Calculator */}
        <ProductionCostCalculator
          ingredients={form.watch('ingredients') || []}
          preparationTime={form.watch('preparationTime') || 0}
          yield={form.watch('yield') || 0}
          onCostCalculated={(totalCost, breakdown) => {
            setCalculatedCostPerUnit(breakdown.costPerUnit || 0);
            console.log('Costo calcolato:', totalCost, breakdown);
            // Aggiorna automaticamente il campo productionCost nel form
            form.setValue('productionCost', breakdown.costPerUnit?.toFixed(2) || '0.00');
          }}
        />

        {/* Sale Price Section */}
        <Card className="p-4 bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
          <h3 className="text-lg font-semibold text-green-800 dark:text-green-200 mb-4">Suggerimenti Prezzo di Vendita</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <FormField
                control={form.control}
                name="salePrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-green-700 dark:text-green-300">Prezzo di Vendita per Vasetto (€)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01"
                        placeholder="3.50"
                        {...field} 
                        value={field.value || ""}
                        onChange={e => field.onChange(Number(e.target.value) || undefined)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="space-y-4">
              {(() => {
                const salePrice = form.watch('salePrice') || 0;
                
                // Usa il costo di produzione completo calcolato dal ProductionCostCalculator
                const costPerJar = calculatedCostPerUnit;
                const margin = salePrice > 0 && costPerJar > 0 ? ((salePrice - costPerJar) / costPerJar) * 100 : 0;
                const profitPerJar = salePrice - costPerJar;
                
                return (
                  <>
                    <div className="bg-white dark:bg-gray-800 p-3 rounded border">
                      <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Costo Produzione per Vasetto</label>
                      <p className="text-lg font-bold text-red-600">€{costPerJar.toFixed(2)}</p>
                    </div>
                    
                    {salePrice > 0 && (
                      <>
                        <div className="bg-white dark:bg-gray-800 p-3 rounded border">
                          <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Margine di Profitto</label>
                          <p className={`text-lg font-bold ${margin > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {margin.toFixed(1)}%
                          </p>
                        </div>
                        
                        <div className="bg-white dark:bg-gray-800 p-3 rounded border">
                          <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Guadagno per Vasetto</label>
                          <p className={`text-lg font-bold ${profitPerJar > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            €{profitPerJar.toFixed(2)}
                          </p>
                        </div>
                        
                        {margin < 25 && salePrice > 0 && (
                          <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 p-3 rounded">
                            <p className="text-sm text-yellow-800 dark:text-yellow-200">
                              ⚠️ Margine basso. Considera un prezzo di vendita di almeno €{(costPerJar * 1.25).toFixed(2)} per un margine del 25%.
                            </p>
                          </div>
                        )}
                      </>
                    )}
                  </>
                );
              })()}
            </div>
          </div>
        </Card>

        <FormField
          control={form.control}
          name="instructions"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Istruzioni di Preparazione (Brevi)</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Descrivi brevemente la preparazione..."
                  className="min-h-24"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="preparationInstructions"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Istruzioni Dettagliate di Preparazione</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Istruzioni complete e dettagliate per la preparazione industriale, inclusi tempi, temperature, procedure specifiche, controlli qualità, etc..."
                  className="min-h-48"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onClose}>
            Annulla
          </Button>
          <Button 
            type="submit" 
            disabled={createMutation.isPending || updateMutation.isPending}
          >
            {createMutation.isPending || updateMutation.isPending ? "Salvando..." : recipe ? "Aggiorna" : "Crea"}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default function RecipeManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | undefined>();

  const { data: recipes = [], isLoading } = useQuery({
    queryKey: ["/api/recipes"]
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/recipes/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
    }
  });

  const filteredRecipes = recipes.filter((recipe: Recipe) => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         recipe.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || recipe.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleEdit = (recipe: Recipe) => {
    setEditingRecipe(recipe);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingRecipe(undefined);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Facile": return "bg-green-100 text-green-800";
      case "Medio": return "bg-yellow-100 text-yellow-800";
      case "Difficile": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return <div className="p-6">Caricamento ricette...</div>;
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-accent p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <Users className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Gestione Ricette</h1>
              <p className="text-xl text-white/90">
                Crea e gestisci le tue ricette e formulazioni
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex gap-3">
          <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setEditingRecipe(undefined)} className="btn-primary-modern">
                <Plus className="h-4 w-4 mr-2" />
                Nuova Ricetta
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingRecipe ? "Modifica Ricetta" : "Nuova Ricetta"}
                </DialogTitle>
              </DialogHeader>
              <RecipeForm recipe={editingRecipe} onClose={handleCloseForm} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex gap-4 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Cerca ricette..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte le categorie</SelectItem>
            {CATEGORY_OPTIONS.map(category => (
              <SelectItem key={category} value={category}>{category}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRecipes.map((recipe: Recipe) => (
          <Card key={recipe.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-lg">{recipe.name}</CardTitle>
                  <Badge variant="secondary">{recipe.category}</Badge>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(recipe)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => exportRecipeToPDF(recipe)}
                    title="Esporta PDF"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => deleteMutation.mutate(recipe.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {recipe.description && (
                <p className="text-sm text-muted-foreground">{recipe.description}</p>
              )}
              
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {recipe.preparationTime} min
                </div>
                <Badge className={getDifficultyColor(recipe.difficulty)}>
                  {recipe.difficulty}
                </Badge>
              </div>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {recipe.yield} vasetti
                </div>
                <div className="flex items-center gap-1">
                  <Euro className="h-4 w-4" />
                  {recipe.jarWeight}g/vasetto
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h4 className="font-medium text-sm">Ingredienti:</h4>
                <div className="flex flex-wrap gap-1">
                  {recipe.ingredients?.slice(0, 3).map((ingredient, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {ingredient.name}
                    </Badge>
                  ))}
                  {recipe.ingredients && recipe.ingredients.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{recipe.ingredients.length - 3} altri
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredRecipes.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nessuna ricetta trovata</p>
        </div>
      )}
    </div>
  );
}