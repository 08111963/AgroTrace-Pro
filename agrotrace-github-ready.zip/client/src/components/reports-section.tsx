import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  Package, 
  ChefHat, 
  Warehouse, 
  AlertTriangle,
  Download,
  Calendar,
  Euro,
  Eye,
  FileText,
  FileDown,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Cell,
  Pie,
  LineChart,
  Line,
  Legend,
  Area,
  AreaChart
} from "recharts";
import { exportAlertsToPDF, exportQRLabelsToPDF } from "@/lib/pdf-utils";

const ReportsSection = () => {
  const [selectedPeriod, setSelectedPeriod] = useState("last_30_days");
  const [selectedReport, setSelectedReport] = useState("overview");

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: recipes = [] } = useQuery({
    queryKey: ["/api/recipes"],
  });

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/batches"],
  });

  const { data: inventory = [] } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ["/api/alerts"],
  });

  const { data: qrLabels = [] } = useQuery({
    queryKey: ["/api/qr-labels"],
  });

  // Data processing for charts
  const prepareInventoryChartData = () => {
    const categoryData = inventory.reduce((acc: any, item: any) => {
      const category = item.category || 'Altri';
      if (!acc[category]) {
        acc[category] = { name: category, value: 0, count: 0 };
      }
      acc[category].value += Number(item.currentStock || 0) * Number(item.unitCost || 0);
      acc[category].count += 1;
      return acc;
    }, {});
    
    return Object.values(categoryData);
  };

  const prepareProductionTrendData = () => {
    const monthlyData = batches.reduce((acc: any, batch: any) => {
      const date = new Date(batch.productionDate);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!acc[monthKey]) {
        acc[monthKey] = { month: monthKey, batches: 0, quantity: 0 };
      }
      acc[monthKey].batches += 1;
      acc[monthKey].quantity += Number(batch.quantity || 0);
      return acc;
    }, {});
    
    return Object.values(monthlyData).sort((a: any, b: any) => a.month.localeCompare(b.month));
  };

  const prepareRecipeCategoryData = () => {
    const categoryData = recipes.reduce((acc: any, recipe: any) => {
      const category = recipe.category || 'Altri';
      if (!acc[category]) {
        acc[category] = { name: category, value: 0 };
      }
      acc[category].value += 1;
      return acc;
    }, {});
    
    return Object.values(categoryData);
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  const inventoryChartData = prepareInventoryChartData();
  const productionTrendData = prepareProductionTrendData();
  const recipeCategoryData = prepareRecipeCategoryData();

  const generateProductionReport = () => {
    const activeBatches = batches.filter((batch: any) => batch.status === 'active');
    const soldBatches = batches.filter((batch: any) => batch.status === 'sold');
    const expiredBatches = batches.filter((batch: any) => batch.status === 'expired');

    return {
      activeBatches: activeBatches.length,
      soldBatches: soldBatches.length,
      expiredBatches: expiredBatches.length,
      totalProduction: batches.length,
      productionByProduct: batches.reduce((acc: any, batch: any) => {
        acc[batch.productName] = (acc[batch.productName] || 0) + 1;
        return acc;
      }, {})
    };
  };

  const generateInventoryReport = () => {
    const lowStock = inventory.filter((item: any) => item.status === 'low_stock');
    const outOfStock = inventory.filter((item: any) => item.status === 'out_of_stock');
    const available = inventory.filter((item: any) => item.status === 'available');

    const totalValue = inventory.reduce((sum: number, item: any) => {
      const stock = Number(item.currentStock);
      // Per i prodotti finiti usa il prezzo di vendita se impostato, altrimenti il costo unitario
      const price = item.category === 'Prodotti Finiti' && item.salePrice 
        ? Number(item.salePrice) 
        : Number(item.unitCost || 0);
      return sum + (stock * price);
    }, 0);

    const categoryBreakdown = inventory.reduce((acc: any, item: any) => {
      acc[item.category] = (acc[item.category] || 0) + 1;
      return acc;
    }, {});

    return {
      totalItems: inventory.length,
      available: available.length,
      lowStock: lowStock.length,
      outOfStock: outOfStock.length,
      totalValue,
      categoryBreakdown
    };
  };

  const generateQualityReport = () => {
    const totalAlerts = alerts.length;
    const activeAlerts = alerts.filter((alert: any) => !alert.resolved).length;
    const resolvedAlerts = alerts.filter((alert: any) => alert.resolved).length;

    const alertsByType = alerts.reduce((acc: any, alert: any) => {
      acc[alert.type] = (acc[alert.type] || 0) + 1;
      return acc;
    }, {});

    const alertsBySeverity = alerts.reduce((acc: any, alert: any) => {
      acc[alert.severity] = (acc[alert.severity] || 0) + 1;
      return acc;
    }, {});

    return {
      totalAlerts,
      activeAlerts,
      resolvedAlerts,
      alertsByType,
      alertsBySeverity
    };
  };

  const productionReport = generateProductionReport();
  const inventoryReport = generateInventoryReport();
  const qualityReport = generateQualityReport();

  const getDateFilter = () => {
    const now = new Date();
    let startDate = new Date();
    
    switch (selectedPeriod) {
      case 'last_7_days':
        startDate.setDate(now.getDate() - 7);
        break;
      case 'last_30_days':
        startDate.setDate(now.getDate() - 30);
        break;
      case 'last_90_days':
        startDate.setDate(now.getDate() - 90);
        break;
      case 'current_year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }
    
    return startDate;
  };

  const downloadReport = () => {
    const now = new Date();
    const dateStr = now.toLocaleDateString('it-IT');
    const timeStr = now.toLocaleTimeString('it-IT');
    const startDate = getDateFilter();
    
    // Filtra i dati in base al periodo selezionato
    const filteredBatches = batches.filter((batch: any) => {
      const batchDate = new Date(batch.productionDate);
      return batchDate >= startDate;
    });

    const filteredInventory = inventory.filter((item: any) => {
      const itemDate = new Date(item.createdAt || item.updatedAt);
      return itemDate >= startDate;
    });

    const filteredRecipes = recipes.filter((recipe: any) => {
      const recipeDate = new Date(recipe.createdAt || recipe.updatedAt);
      return recipeDate >= startDate;
    });
    
    // Crea il contenuto CSV con i dati filtrati
    let csvContent = '';
    
    // Header del report
    csvContent += `AgroTrace Pro - Report Completo\n`;
    csvContent += `Generato il: ${dateStr} alle ${timeStr}\n`;
    csvContent += `Periodo: ${selectedPeriod === 'last_7_days' ? 'Ultimi 7 giorni' : 
                              selectedPeriod === 'last_30_days' ? 'Ultimi 30 giorni' :
                              selectedPeriod === 'last_90_days' ? 'Ultimi 90 giorni' : 'Anno corrente'}\n`;
    csvContent += `Filtro dal: ${startDate.toLocaleDateString('it-IT')} al: ${dateStr}\n\n`;

    // Statistiche generali (sempre complete)
    csvContent += `STATISTICHE GENERALI\n`;
    csvContent += `Ricette Totali,${stats?.totalRecipes || 0}\n`;
    csvContent += `Lotti Attivi,${stats?.activeBatches || 0}\n`;
    csvContent += `Articoli Magazzino,${stats?.inventoryItems || 0}\n`;
    csvContent += `Alert Attivi,${stats?.activeAlerts || 0}\n`;
    csvContent += `Articoli Scorta Bassa,${stats?.lowStockItems || 0}\n`;
    csvContent += `Valore Totale Inventario,€${stats?.totalInventoryValue || 0}\n\n`;

    // Statistiche periodo filtrato
    csvContent += `DATI PERIODO FILTRATO\n`;
    csvContent += `Lotti Prodotti nel Periodo,${filteredBatches.length}\n`;
    csvContent += `Ricette Create/Modificate,${filteredRecipes.length}\n`;
    csvContent += `Articoli Inventario Modificati,${filteredInventory.length}\n\n`;

    // Report Inventario (sempre completo per stato attuale)
    csvContent += `INVENTARIO ATTUALE\n`;
    csvContent += `Nome,Categoria,Quantità,Unità,Costo Unitario,Prezzo Vendita,Valore,Stato,Fornitore,Data Aggiornamento\n`;
    inventory.forEach((item: any) => {
      const stock = Number(item.currentStock || 0);
      const price = item.category === 'Prodotti Finiti' && item.salePrice 
        ? Number(item.salePrice) 
        : Number(item.unitCost || 0);
      const value = stock * price;
      const updateDate = item.updatedAt ? new Date(item.updatedAt).toLocaleDateString('it-IT') : 'N/A';
      
      csvContent += `"${item.name}","${item.category}",${item.currentStock},"${item.unit}",`;
      csvContent += `${item.unitCost || 0},${item.salePrice || ''},€${value.toFixed(2)},"${item.status}","${item.supplier || ''}","${updateDate}"\n`;
    });

    csvContent += `\n`;

    // Report Ricette del periodo
    if (filteredRecipes.length > 0) {
      csvContent += `RICETTE PERIODO (${filteredRecipes.length})\n`;
      csvContent += `Nome,Categoria,Prezzo Vendita,Stato,Data Creazione,Ingredienti,Allergeni\n`;
      filteredRecipes.forEach((recipe: any) => {
        const ingredientsList = recipe.ingredients?.map((ing: any) => `${ing.name} (${ing.quantity}${ing.unit})`).join('; ') || '';
        const allergensList = recipe.allergens?.join('; ') || '';
        const createDate = recipe.createdAt ? new Date(recipe.createdAt).toLocaleDateString('it-IT') : 'N/A';
        
        csvContent += `"${recipe.name}","${recipe.category}",€${recipe.salePrice || 0},"${recipe.status}","${createDate}","${ingredientsList}","${allergensList}"\n`;
      });
      csvContent += `\n`;
    }

    // Report Lotti del periodo
    if (filteredBatches.length > 0) {
      csvContent += `LOTTI PRODUZIONE PERIODO (${filteredBatches.length})\n`;
      csvContent += `Codice,Prodotto,Quantità,Unità,Data Produzione,Data Scadenza,Stato\n`;
      filteredBatches.forEach((batch: any) => {
        const prodDate = new Date(batch.productionDate).toLocaleDateString('it-IT');
        const expDate = batch.expiryDate ? new Date(batch.expiryDate).toLocaleDateString('it-IT') : 'N/A';
        
        csvContent += `"${batch.code}","${batch.productName}",${batch.quantity},"${batch.unit}","${prodDate}","${expDate}","${batch.status}"\n`;
      });
    } else {
      csvContent += `LOTTI PRODUZIONE PERIODO\n`;
      csvContent += `Nessun lotto prodotto nel periodo selezionato\n\n`;
    }

    // Crea e scarica il file CSV
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AgroTrace-Report-${selectedPeriod}-${now.toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const renderInteractiveCharts = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Inventory Value by Category */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChartIcon className="h-5 w-5" />
              Valore Inventario per Categoria
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={inventoryChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: €${value.toFixed(0)}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {inventoryChartData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => [`€${value.toFixed(2)}`, 'Valore']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recipe Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Distribuzione Ricette per Categoria
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={recipeCategoryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#00C49F" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Production Trend */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LineChartIcon className="h-5 w-5" />
            Trend Produzione Mensile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={productionTrendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip 
                labelFormatter={(value) => `Mese: ${value}`}
                formatter={(value: any, name: string) => [
                  name === 'batches' ? `${value} lotti` : `${value} unità`,
                  name === 'batches' ? 'Lotti Prodotti' : 'Quantità Totale'
                ]}
              />
              <Legend />
              <Area
                type="monotone"
                dataKey="batches"
                stackId="1"
                stroke="#8884d8"
                fill="#8884d8"
                name="Lotti"
              />
              <Area
                type="monotone"
                dataKey="quantity"
                stackId="2"
                stroke="#82ca9d"
                fill="#82ca9d"
                name="Quantità"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Interactive Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Efficienza Produzione</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {((batches as any[]).filter(b => b.status === 'completed').length / (batches as any[]).length * 100 || 0).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">Lotti completati con successo</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Diversificazione Prodotti</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {recipeCategoryData.length}
            </div>
            <p className="text-xs text-muted-foreground">Categorie di prodotti attive</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Valore Medio Lotto</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              €{((inventory as any[]).reduce((sum, item) => sum + (Number(item.currentStock || 0) * Number(item.unitCost || 0)), 0) / Math.max((batches as any[]).length, 1) || 0).toFixed(0)}
            </div>
            <p className="text-xs text-muted-foreground">Valore medio per lotto prodotto</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderOverviewReport = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Ricette Totali</CardTitle>
          <ChefHat className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{recipes.length}</div>
          <p className="text-xs text-muted-foreground">
            {recipes.filter((r: any) => r.status === 'active').length} attive
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Lotti Prodotti</CardTitle>
          <Package className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{batches.length}</div>
          <p className="text-xs text-muted-foreground">
            <TrendingUp className="inline h-3 w-3 mr-1" />
            {productionReport.activeBatches} attivi
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Prodotti Magazzino</CardTitle>
          <Warehouse className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{inventory.length}</div>
          <p className="text-xs text-muted-foreground">
            {inventoryReport.lowStock > 0 ? (
              <>
                <TrendingDown className="inline h-3 w-3 mr-1 text-orange-500" />
                {inventoryReport.lowStock} sotto soglia
              </>
            ) : (
              <>
                <TrendingUp className="inline h-3 w-3 mr-1 text-green-500" />
                Scorte ottimali
              </>
            )}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Valore Inventario</CardTitle>
          <Euro className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            €{stats?.totalInventoryValue?.toLocaleString('it-IT', {
              minimumFractionDigits: 0,
              maximumFractionDigits: 0
            }) || 0}
          </div>
          <p className="text-xs text-muted-foreground">
            {inventory.length} articoli
          </p>
        </CardContent>
      </Card>
    </div>
  );

  const renderProductionReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Stati Lotti</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">Attivi</span>
                <Badge variant="default">{productionReport.activeBatches}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Venduti</span>
                <Badge variant="secondary">{productionReport.soldBatches}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Scaduti</span>
                <Badge variant="destructive">{productionReport.expiredBatches}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Produzione per Prodotto</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(productionReport.productionByProduct).map(([product, count]) => (
                <div key={product} className="flex items-center justify-between text-sm">
                  <span className="truncate">{product}</span>
                  <span className="font-medium">{count as number}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Efficienza Produttiva</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">
                  {((productionReport.soldBatches / productionReport.totalProduction) * 100).toFixed(1)}%
                </div>
                <p className="text-sm text-muted-foreground">Tasso di vendita</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {productionReport.totalProduction}
                </div>
                <p className="text-sm text-muted-foreground">Lotti totali</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderInventoryReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Disponibili</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{inventoryReport.available}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Scorte Basse</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">{inventoryReport.lowStock}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Esauriti</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">{inventoryReport.outOfStock}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Valore Totale</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              €{inventoryReport.totalValue.toFixed(2)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Distribuzione per Categoria</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Object.entries(inventoryReport.categoryBreakdown).map(([category, count]) => (
              <div key={category} className="text-center p-4 bg-muted rounded-lg">
                <div className="text-lg font-bold">{count as number}</div>
                <div className="text-sm text-muted-foreground capitalize">
                  {category.replace('_', ' ')}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderQualityReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Alert Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold">{qualityReport.totalAlerts}</div>
              <p className="text-sm text-muted-foreground mt-2">
                {qualityReport.activeAlerts} attivi, {qualityReport.resolvedAlerts} risolti
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Alert per Tipo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(qualityReport.alertsByType).map(([type, count]) => (
                <div key={type} className="flex items-center justify-between text-sm">
                  <span className="capitalize">{type.replace('_', ' ')}</span>
                  <Badge variant="outline">{count as number}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Alert per Gravità</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(qualityReport.alertsBySeverity).map(([severity, count]) => {
                const variant = severity === 'high' ? 'destructive' : 
                              severity === 'medium' ? 'secondary' : 'outline';
                return (
                  <div key={severity} className="flex items-center justify-between text-sm">
                    <span className="capitalize">{severity}</span>
                    <Badge variant={variant}>{count as number}</Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-primary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
                <BarChart3 className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">Reports e Analisi</h1>
                <p className="text-xl text-white/90">
                  Analisi complete del sistema agroalimentare
                </p>
              </div>
            </div>
            <Button onClick={downloadReport} variant="outline" className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30">
              <Download className="h-4 w-4 mr-2" />
              Esporta Report
            </Button>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      {/* Controls */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <Select value={selectedReport} onValueChange={setSelectedReport}>
              <SelectTrigger className="w-full sm:w-48">
                <FileText className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overview">Panoramica Generale</SelectItem>
                <SelectItem value="charts">Grafici Interattivi</SelectItem>
                <SelectItem value="production">Report Produzione</SelectItem>
                <SelectItem value="inventory">Report Magazzino</SelectItem>
                <SelectItem value="quality">Report Qualità</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-full sm:w-48">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="last_7_days">Ultimi 7 giorni</SelectItem>
                <SelectItem value="last_30_days">Ultimi 30 giorni</SelectItem>
                <SelectItem value="last_90_days">Ultimi 90 giorni</SelectItem>
                <SelectItem value="current_year">Anno corrente</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Report Content */}
      <div className="space-y-6">
        {selectedReport === "overview" && renderOverviewReport()}
        {selectedReport === "charts" && renderInteractiveCharts()}
        {selectedReport === "production" && renderProductionReport()}
        {selectedReport === "inventory" && renderInventoryReport()}
        {selectedReport === "quality" && renderQualityReport()}
      </div>

      {/* Additional Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Statistiche Aggiuntive</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="font-bold text-lg">{recipes.length}</div>
              <div className="text-muted-foreground">Ricette nel database</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="font-bold text-lg">
                {recipes.reduce((sum: number, recipe: any) => {
                  return sum + (recipe.ingredients?.length || 0);
                }, 0)}
              </div>
              <div className="text-muted-foreground">Ingredienti totali</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="font-bold text-lg">
                {new Set(recipes.flatMap((recipe: any) => recipe.allergens || [])).size}
              </div>
              <div className="text-muted-foreground">Allergeni tracciati</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="font-bold text-lg">
                {Math.round(
                  batches.reduce((sum: number, batch: any) => {
                    return sum + Number(batch.quantity || 0);
                  }, 0)
                )}
              </div>
              <div className="text-muted-foreground">Unità prodotte</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Export Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Informazioni Export
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground space-y-2">
            <p>
              I report possono essere esportati in formato JSON per ulteriori analisi.
              Include tutti i dati aggregati del periodo selezionato.
            </p>
            <p>
              I dati esportati comprendono: statistiche di produzione, analisi inventario, 
              report qualità e metriche di performance del sistema.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReportsSection;