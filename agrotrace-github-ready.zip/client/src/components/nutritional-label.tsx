import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Info } from "lucide-react";

interface NutritionalData {
  calories: number;
  proteins: number;
  carbohydrates: number;
  sugars: number;
  fats: number;
  saturatedFats: number;
  fiber: number;
  sodium: number;
  salt: number;
}

interface Ingredient {
  name: string;
  productPercentage?: number;
}

interface NutritionalLabelProps {
  nutritionalValues: NutritionalData;
  ingredients?: Ingredient[];
  className?: string;
}

const NutritionalLabel = ({ nutritionalValues, ingredients = [], className = "" }: NutritionalLabelProps) => {
  const formatValue = (value: number, unit: string, decimals: number = 1) => {
    return `${value.toFixed(decimals)}${unit}`;
  };

  return (
    <Card className={`w-full max-w-sm ${className}`}>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-center">
          Informazioni Nutrizionali
        </CardTitle>
        <div className="text-center text-sm text-muted-foreground">
          Per 100g di prodotto
        </div>
        <Separator />
      </CardHeader>
      <CardContent className="space-y-2">
        {/* Energia */}
        <div className="flex justify-between items-center">
          <span className="font-medium">Energia</span>
          <span className="font-bold">{formatValue(nutritionalValues.calories, ' kcal', 0)}</span>
        </div>
        
        <Separator className="my-2" />
        
        {/* Grassi */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="font-medium">Grassi</span>
            <span>{formatValue(nutritionalValues.fats, 'g')}</span>
          </div>
          <div className="flex justify-between pl-4 text-sm text-muted-foreground">
            <span>di cui acidi grassi saturi</span>
            <span>{formatValue(nutritionalValues.saturatedFats, 'g')}</span>
          </div>
        </div>
        
        {/* Carboidrati */}
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="font-medium">Carboidrati</span>
            <span>{formatValue(nutritionalValues.carbohydrates, 'g')}</span>
          </div>
          <div className="flex justify-between pl-4 text-sm text-muted-foreground">
            <span>di cui zuccheri</span>
            <span>{formatValue(nutritionalValues.sugars, 'g')}</span>
          </div>
        </div>
        
        {/* Fibre */}
        <div className="flex justify-between">
          <span className="font-medium">Fibre</span>
          <span>{formatValue(nutritionalValues.fiber, 'g')}</span>
        </div>
        
        {/* Proteine */}
        <div className="flex justify-between">
          <span className="font-medium">Proteine</span>
          <span>{formatValue(nutritionalValues.proteins, 'g')}</span>
        </div>
        
        {/* Sale */}
        <div className="flex justify-between">
          <span className="font-medium">Sale</span>
          <span>{formatValue(nutritionalValues.salt, 'g')}</span>
        </div>
        
        {/* Composizione ingredienti */}
        {ingredients && ingredients.length > 0 && (
          <>
            <Separator className="my-3" />
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Composizione</h4>
              <div className="space-y-1">
                {(() => {
                  console.log('Nutritional Label - Ingredients received:', ingredients);
                  const filteredIngredients = ingredients
                    .filter(ing => ing.productPercentage != null && ing.productPercentage > 0)
                    .sort((a, b) => (b.productPercentage || 0) - (a.productPercentage || 0));
                  
                  console.log('Filtered ingredients with percentages:', filteredIngredients);
                  
                  if (filteredIngredients.length === 0) {
                    return (
                      <div className="text-xs text-muted-foreground">
                        Dati composizione non disponibili
                      </div>
                    );
                  }
                  
                  return filteredIngredients.map((ingredient, index) => (
                    <div key={index} className="flex justify-between text-xs">
                      <span className="capitalize">{ingredient.name.toLowerCase()}</span>
                      <span className="font-medium">{ingredient.productPercentage}%</span>
                    </div>
                  ));
                })()}
              </div>
            </div>
          </>
        )}
        
        <Separator className="my-3" />
        
        {/* Info aggiuntive */}
        <div className="flex items-start gap-2 text-xs text-muted-foreground">
          <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
          <div>
            <p className="mb-1">Valori nutrizionali calcolati automaticamente in base agli ingredienti e alle quantità utilizzate nella ricetta.</p>
            <p>I valori possono variare leggermente a seconda delle materie prime utilizzate.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default NutritionalLabel;