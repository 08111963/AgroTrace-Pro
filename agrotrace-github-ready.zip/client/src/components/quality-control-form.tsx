import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Thermometer, 
  Beaker, 
  Droplet, 
  Eye, 
  Scale, 
  Plus, 
  Trash2,
  CheckCircle,
  AlertTriangle,
  XCircle
} from "lucide-react";

interface QualityParameter {
  name: string;
  value: string | number;
  target?: string;
  min?: number;
  max?: number;
  unit?: string;
  status?: 'OK' | 'WARNING' | 'FAIL';
  operator?: string;
  notes?: string;
}

interface QualityControlFormProps {
  mode: 'recipe' | 'batch';
  initialData?: any;
  onSave: (data: any) => void;
  recipeTargets?: any; // Per i lotti, i target dalla ricetta
}

export default function QualityControlForm({ 
  mode, 
  initialData, 
  onSave, 
  recipeTargets 
}: QualityControlFormProps) {
  const [qualityData, setQualityData] = useState({
    ph: mode === 'recipe' ? { min: 4.0, max: 4.5, unit: 'pH' } : { value: '', status: 'OK' as const },
    brix: mode === 'recipe' ? { min: 5.5, max: 6.0, unit: '°Brix' } : { value: '', status: 'OK' as const },
    temperature: mode === 'recipe' ? { min: 80, max: 90, unit: '°C' } : { value: '', status: 'OK' as const },
    viscosity: mode === 'recipe' ? { target: 'Standard', description: 'Consistenza normale' } : { value: '', status: 'OK' as const },
    color: mode === 'recipe' ? { target: 'Rosso intenso', description: 'Colore tipico pomodoro maturo' } : { value: '', status: 'OK' as const },
    ...initialData
  });

  const [customParameters, setCustomParameters] = useState<QualityParameter[]>([]);
  const [currentOperator, setCurrentOperator] = useState('');

  const handleStandardParameterChange = (param: string, field: string, value: any) => {
    setQualityData(prev => ({
      ...prev,
      [param]: {
        ...prev[param],
        [field]: value,
        ...(mode === 'batch' && field === 'value' && { measuredAt: new Date().toISOString() })
      }
    }));
  };

  const addCustomParameter = () => {
    setCustomParameters(prev => [...prev, {
      name: '',
      value: '',
      unit: '',
      status: 'OK',
      operator: currentOperator
    }]);
  };

  const removeCustomParameter = (index: number) => {
    setCustomParameters(prev => prev.filter((_, i) => i !== index));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'OK': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'WARNING': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'FAIL': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OK': return 'bg-green-100 text-green-800';
      case 'WARNING': return 'bg-yellow-100 text-yellow-800';
      case 'FAIL': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const evaluateStatus = (value: number, min?: number, max?: number): 'OK' | 'WARNING' | 'FAIL' => {
    if (!min || !max) return 'OK';
    if (value >= min && value <= max) return 'OK';
    if (value < min * 0.9 || value > max * 1.1) return 'FAIL';
    return 'WARNING';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">
          {mode === 'recipe' ? 'Parametri Qualità Target' : 'Controlli Qualità Produzione'}
        </h3>
        {mode === 'batch' && (
          <div className="flex items-center gap-2">
            <Label htmlFor="operator">Operatore:</Label>
            <Input
              id="operator"
              placeholder="Nome operatore"
              value={currentOperator}
              onChange={(e) => setCurrentOperator(e.target.value)}
              className="w-48"
            />
          </div>
        )}
      </div>

      {/* Parametri Standard */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* pH */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Droplet className="w-4 h-4" />
              pH
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {mode === 'recipe' ? (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="ph-min">Min</Label>
                    <Input
                      id="ph-min"
                      type="number"
                      step="0.1"
                      value={qualityData.ph?.min || ''}
                      onChange={(e) => handleStandardParameterChange('ph', 'min', parseFloat(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="ph-max">Max</Label>
                    <Input
                      id="ph-max"
                      type="number"
                      step="0.1"
                      value={qualityData.ph?.max || ''}
                      onChange={(e) => handleStandardParameterChange('ph', 'max', parseFloat(e.target.value))}
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-600">
                  Target: {qualityData.ph?.min} - {qualityData.ph?.max} pH
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Valore misurato"
                    value={qualityData.ph?.value || ''}
                    onChange={(e) => {
                      const value = parseFloat(e.target.value);
                      const status = recipeTargets?.ph ? 
                        evaluateStatus(value, recipeTargets.ph.min, recipeTargets.ph.max) : 'OK';
                      handleStandardParameterChange('ph', 'value', value);
                      handleStandardParameterChange('ph', 'status', status);
                    }}
                  />
                  <Badge className={getStatusColor(qualityData.ph?.status || 'OK')}>
                    {getStatusIcon(qualityData.ph?.status || 'OK')}
                    {qualityData.ph?.status || 'OK'}
                  </Badge>
                </div>
                {recipeTargets?.ph && (
                  <div className="text-sm text-gray-600">
                    Target: {recipeTargets.ph.min} - {recipeTargets.ph.max} pH
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Grado Brix */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Beaker className="w-4 h-4" />
              Grado Brix
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {mode === 'recipe' ? (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="brix-min">Min</Label>
                    <Input
                      id="brix-min"
                      type="number"
                      step="0.1"
                      value={qualityData.brix?.min || ''}
                      onChange={(e) => handleStandardParameterChange('brix', 'min', parseFloat(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="brix-max">Max</Label>
                    <Input
                      id="brix-max"
                      type="number"
                      step="0.1"
                      value={qualityData.brix?.max || ''}
                      onChange={(e) => handleStandardParameterChange('brix', 'max', parseFloat(e.target.value))}
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-600">
                  Target: {qualityData.brix?.min} - {qualityData.brix?.max}°Brix
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Valore misurato"
                    value={qualityData.brix?.value || ''}
                    onChange={(e) => {
                      const value = parseFloat(e.target.value);
                      const status = recipeTargets?.brix ? 
                        evaluateStatus(value, recipeTargets.brix.min, recipeTargets.brix.max) : 'OK';
                      handleStandardParameterChange('brix', 'value', value);
                      handleStandardParameterChange('brix', 'status', status);
                    }}
                  />
                  <Badge className={getStatusColor(qualityData.brix?.status || 'OK')}>
                    {getStatusIcon(qualityData.brix?.status || 'OK')}
                    {qualityData.brix?.status || 'OK'}
                  </Badge>
                </div>
                {recipeTargets?.brix && (
                  <div className="text-sm text-gray-600">
                    Target: {recipeTargets.brix.min} - {recipeTargets.brix.max}°Brix
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Temperatura */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Thermometer className="w-4 h-4" />
              Temperatura
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {mode === 'recipe' ? (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="temp-min">Min °C</Label>
                    <Input
                      id="temp-min"
                      type="number"
                      value={qualityData.temperature?.min || ''}
                      onChange={(e) => handleStandardParameterChange('temperature', 'min', parseFloat(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="temp-max">Max °C</Label>
                    <Input
                      id="temp-max"
                      type="number"
                      value={qualityData.temperature?.max || ''}
                      onChange={(e) => handleStandardParameterChange('temperature', 'max', parseFloat(e.target.value))}
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-600">
                  Target: {qualityData.temperature?.min} - {qualityData.temperature?.max}°C
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    placeholder="Temperatura °C"
                    value={qualityData.temperature?.value || ''}
                    onChange={(e) => {
                      const value = parseFloat(e.target.value);
                      const status = recipeTargets?.temperature ? 
                        evaluateStatus(value, recipeTargets.temperature.min, recipeTargets.temperature.max) : 'OK';
                      handleStandardParameterChange('temperature', 'value', value);
                      handleStandardParameterChange('temperature', 'status', status);
                    }}
                  />
                  <Badge className={getStatusColor(qualityData.temperature?.status || 'OK')}>
                    {getStatusIcon(qualityData.temperature?.status || 'OK')}
                    {qualityData.temperature?.status || 'OK'}
                  </Badge>
                </div>
                {recipeTargets?.temperature && (
                  <div className="text-sm text-gray-600">
                    Target: {recipeTargets.temperature.min} - {recipeTargets.temperature.max}°C
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Viscosità */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Scale className="w-4 h-4" />
              Viscosità
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {mode === 'recipe' ? (
              <>
                <div>
                  <Label htmlFor="viscosity-target">Target</Label>
                  <Select
                    value={qualityData.viscosity?.target || ''}
                    onValueChange={(value) => handleStandardParameterChange('viscosity', 'target', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleziona viscosità" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Liquida">Liquida</SelectItem>
                      <SelectItem value="Standard">Standard</SelectItem>
                      <SelectItem value="Densa">Densa</SelectItem>
                      <SelectItem value="Molto Densa">Molto Densa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="viscosity-desc">Descrizione</Label>
                  <Input
                    id="viscosity-desc"
                    placeholder="Descrizione viscosità"
                    value={qualityData.viscosity?.description || ''}
                    onChange={(e) => handleStandardParameterChange('viscosity', 'description', e.target.value)}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <Select
                    value={qualityData.viscosity?.value || ''}
                    onValueChange={(value) => {
                      handleStandardParameterChange('viscosity', 'value', value);
                      const status = recipeTargets?.viscosity?.target === value ? 'OK' : 'WARNING';
                      handleStandardParameterChange('viscosity', 'status', status);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Viscosità misurata" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Liquida">Liquida</SelectItem>
                      <SelectItem value="Standard">Standard</SelectItem>
                      <SelectItem value="Densa">Densa</SelectItem>
                      <SelectItem value="Molto Densa">Molto Densa</SelectItem>
                    </SelectContent>
                  </Select>
                  <Badge className={getStatusColor(qualityData.viscosity?.status || 'OK')}>
                    {getStatusIcon(qualityData.viscosity?.status || 'OK')}
                    {qualityData.viscosity?.status || 'OK'}
                  </Badge>
                </div>
                {recipeTargets?.viscosity && (
                  <div className="text-sm text-gray-600">
                    Target: {recipeTargets.viscosity.target}
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Colore */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Eye className="w-4 h-4" />
              Colore
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {mode === 'recipe' ? (
              <>
                <div>
                  <Label htmlFor="color-target">Target</Label>
                  <Input
                    id="color-target"
                    placeholder="Es. Rosso intenso"
                    value={qualityData.color?.target || ''}
                    onChange={(e) => handleStandardParameterChange('color', 'target', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="color-desc">Descrizione</Label>
                  <Input
                    id="color-desc"
                    placeholder="Descrizione colore"
                    value={qualityData.color?.description || ''}
                    onChange={(e) => handleStandardParameterChange('color', 'description', e.target.value)}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <Select
                    value={qualityData.color?.value || ''}
                    onValueChange={(value) => {
                      handleStandardParameterChange('color', 'value', value);
                      const status = value === 'Conforme' ? 'OK' : value === 'Parzialmente conforme' ? 'WARNING' : 'FAIL';
                      handleStandardParameterChange('color', 'status', status);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Valutazione colore" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Conforme">Conforme</SelectItem>
                      <SelectItem value="Parzialmente conforme">Parzialmente conforme</SelectItem>
                      <SelectItem value="Non conforme">Non conforme</SelectItem>
                    </SelectContent>
                  </Select>
                  <Badge className={getStatusColor(qualityData.color?.status || 'OK')}>
                    {getStatusIcon(qualityData.color?.status || 'OK')}
                    {qualityData.color?.status || 'OK'}
                  </Badge>
                </div>
                {recipeTargets?.color && (
                  <div className="text-sm text-gray-600">
                    Target: {recipeTargets.color.target}
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Parametri Personalizzati */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Parametri Personalizzati</CardTitle>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addCustomParameter}
            >
              <Plus className="w-4 h-4 mr-2" />
              Aggiungi Parametro
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {customParameters.length === 0 ? (
            <p className="text-gray-500 text-center py-4">
              Nessun parametro personalizzato aggiunto
            </p>
          ) : (
            <div className="space-y-4">
              {customParameters.map((param, index) => (
                <div key={index} className="flex items-center gap-2 p-3 border rounded-lg">
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-2">
                    <Input
                      placeholder="Nome parametro"
                      value={param.name}
                      onChange={(e) => {
                        const updated = [...customParameters];
                        updated[index].name = e.target.value;
                        setCustomParameters(updated);
                      }}
                    />
                    <Input
                      placeholder="Valore"
                      value={param.value}
                      onChange={(e) => {
                        const updated = [...customParameters];
                        updated[index].value = e.target.value;
                        setCustomParameters(updated);
                      }}
                    />
                    <Input
                      placeholder="Unità"
                      value={param.unit || ''}
                      onChange={(e) => {
                        const updated = [...customParameters];
                        updated[index].unit = e.target.value;
                        setCustomParameters(updated);
                      }}
                    />
                    {mode === 'batch' && (
                      <Select
                        value={param.status}
                        onValueChange={(value) => {
                          const updated = [...customParameters];
                          updated[index].status = value as 'OK' | 'WARNING' | 'FAIL';
                          setCustomParameters(updated);
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="OK">OK</SelectItem>
                          <SelectItem value="WARNING">WARNING</SelectItem>
                          <SelectItem value="FAIL">FAIL</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeCustomParameter(index)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Informazioni Aggiuntive per Lotti */}
      {mode === 'batch' && (
        <Card>
          <CardHeader>
            <CardTitle>Dettagli Produzione</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="facility">Stabilimento</Label>
                <Input
                  id="facility"
                  placeholder="Nome stabilimento"
                />
              </div>
              <div>
                <Label htmlFor="production-line">Linea Produttiva</Label>
                <Input
                  id="production-line"
                  placeholder="Linea di produzione"
                />
              </div>
              <div>
                <Label htmlFor="equipment">Attrezzature Utilizzate</Label>
                <Input
                  id="equipment"
                  placeholder="Es. Pastorizzatore A1, Riempitrice B2"
                />
              </div>
              <div>
                <Label htmlFor="yield">Resa (%)</Label>
                <Input
                  id="yield"
                  type="number"
                  placeholder="Percentuale resa"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="production-notes">Note Produzione</Label>
              <Textarea
                id="production-notes"
                placeholder="Note aggiuntive sulla produzione..."
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex justify-end gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={() => window.history.back()}
        >
          Annulla
        </Button>
        <Button
          type="button"
          onClick={() => onSave({
            qualityParameters: mode === 'recipe' ? qualityData : undefined,
            qualityControls: mode === 'batch' ? qualityData : undefined,
            customParameters
          })}
        >
          {mode === 'recipe' ? 'Salva Parametri' : 'Salva Controlli'}
        </Button>
      </div>
    </div>
  );
}