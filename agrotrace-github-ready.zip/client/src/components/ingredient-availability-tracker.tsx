import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { AlertTriangle, Package, TrendingDown, Clock, Search, RefreshCw } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import type { InventoryItem, IngredientTracking } from "@shared/schema";

interface IngredientAvailability {
  currentStock: number;
  minimumStock: number;
  status: 'ok' | 'low' | 'critical';
  daysRemaining?: number;
  averageDailyUsage?: number;
}

export default function IngredientAvailabilityTracker() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIngredient, setSelectedIngredient] = useState<string>("");
  const queryClient = useQueryClient();

  // Query per ottenere tutti gli articoli dell'inventario
  const { data: inventory = [], isLoading: inventoryLoading } = useQuery({
    queryKey: ["/api/inventory"],
  });

  // Query per ottenere articoli con scorte basse
  const { data: lowStockItems = [], isLoading: lowStockLoading } = useQuery({
    queryKey: ["/api/ingredient-tracking/low-stock"],
  });

  // Query per ottenere la disponibilità di un ingrediente specifico
  const { data: ingredientAvailability, isLoading: availabilityLoading } = useQuery({
    queryKey: ["/api/ingredient-availability", selectedIngredient],
    queryFn: async () => {
      if (!selectedIngredient) return null;
      const response = await fetch(`/api/ingredient-availability/${encodeURIComponent(selectedIngredient)}`);
      if (!response.ok) throw new Error('Failed to fetch ingredient availability');
      return response.json();
    },
    enabled: !!selectedIngredient,
  });

  // Query per ottenere il tracking degli ingredienti
  const { data: ingredientTracking = [], isLoading: trackingLoading } = useQuery({
    queryKey: ["/api/ingredient-tracking"],
  });

  // Filtra l'inventario in base al termine di ricerca
  const filteredInventory = inventory.filter((item: InventoryItem) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calcola le statistiche generali
  const totalItems = inventory.length;
  const criticalItems = inventory.filter((item: InventoryItem) => 
    Number(item.currentStock) <= 0
  ).length;
  const lowStockCount = lowStockItems.length;

  // Funzione per ottenere il colore del badge in base allo stato
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ok': return 'bg-green-500 hover:bg-green-600';
      case 'low': return 'bg-yellow-500 hover:bg-yellow-600';
      case 'critical': return 'bg-red-500 hover:bg-red-600';
      default: return 'bg-gray-500 hover:bg-gray-600';
    }
  };

  // Funzione per ottenere lo stato di un articolo
  const getItemStatus = (item: InventoryItem): 'ok' | 'low' | 'critical' => {
    const current = Number(item.currentStock);
    const minimum = Number(item.minimumStock);
    
    if (current <= 0) return 'critical';
    if (current <= minimum) return 'low';
    return 'ok';
  };

  // Calcola la percentuale di stock rimanente
  const getStockPercentage = (item: InventoryItem): number => {
    const current = Number(item.currentStock);
    const minimum = Number(item.minimumStock);
    const maximum = minimum * 3; // Assumiamo che il massimo sia 3 volte il minimo
    
    return Math.min(100, Math.max(0, (current / maximum) * 100));
  };

  // Mutation per aggiornare la cache quando necessario
  const refreshMutation = useMutation({
    mutationFn: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/ingredient-tracking/low-stock"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/ingredient-tracking"] });
    },
  });

  // Auto-refresh ogni 30 secondi
  useEffect(() => {
    const interval = setInterval(() => {
      refreshMutation.mutate();
    }, 30000);

    return () => clearInterval(interval);
  }, [refreshMutation]);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-primary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <TrendingDown className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Disponibilità Ingredienti</h1>
              <p className="text-xl text-white/90">
                Monitora scorte e disponibilità ingredienti in tempo reale
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      {/* Header con statistiche generali */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Package className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm font-medium text-gray-600">Totale Articoli</p>
                <p className="text-2xl font-bold">{totalItems}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingDown className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-sm font-medium text-gray-600">Scorte Basse</p>
                <p className="text-2xl font-bold text-yellow-600">{lowStockCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              <div>
                <p className="text-sm font-medium text-gray-600">Scorte Critiche</p>
                <p className="text-2xl font-bold text-red-600">{criticalItems}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ultimo Aggiornamento</p>
                <p className="text-sm text-gray-500">In tempo reale</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => refreshMutation.mutate()}
                disabled={refreshMutation.isPending}
              >
                <RefreshCw className={`h-4 w-4 ${refreshMutation.isPending ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alert per scorte critiche */}
      {criticalItems > 0 && (
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-500" />
          <AlertDescription className="text-red-800">
            <strong>Attenzione!</strong> Ci sono {criticalItems} articoli con scorte esaurite che necessitano di rifornimento immediato.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Lista Inventario con Monitoraggio */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-5 w-5" />
              <span>Monitoraggio Inventario</span>
            </CardTitle>
            <div className="flex space-x-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cerca ingrediente..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {inventoryLoading ? (
                <div className="text-center py-4">Caricamento inventario...</div>
              ) : filteredInventory.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  {searchTerm ? "Nessun articolo trovato" : "Nessun articolo nell'inventario"}
                </div>
              ) : (
                filteredInventory.map((item: InventoryItem) => {
                  const status = getItemStatus(item);
                  const percentage = getStockPercentage(item);
                  
                  return (
                    <div
                      key={item.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => setSelectedIngredient(item.name)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h4 className="font-medium">{item.name}</h4>
                          <p className="text-sm text-gray-500">{item.category}</p>
                        </div>
                        <Badge className={getStatusColor(status)}>
                          {status === 'ok' && 'Disponibile'}
                          {status === 'low' && 'Scorte Basse'}
                          {status === 'critical' && 'Critico'}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Stock Attuale: {item.currentStock} {item.unit}</span>
                          <span>Minimo: {item.minimumStock} {item.unit}</span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>

        {/* Dettagli Ingrediente Selezionato */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5" />
              <span>Dettagli Disponibilità</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!selectedIngredient ? (
              <div className="text-center py-8 text-gray-500">
                Seleziona un ingrediente per visualizzare i dettagli di disponibilità
              </div>
            ) : availabilityLoading ? (
              <div className="text-center py-8">Caricamento dettagli...</div>
            ) : ingredientAvailability ? (
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg mb-2">{selectedIngredient}</h3>
                  <Badge className={getStatusColor(ingredientAvailability.status)}>
                    {ingredientAvailability.status === 'ok' && 'Disponibile'}
                    {ingredientAvailability.status === 'low' && 'Scorte Basse'}
                    {ingredientAvailability.status === 'critical' && 'Critico'}
                  </Badge>
                </div>

                <Separator />

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-600">Stock Attuale</Label>
                    <p className="text-2xl font-bold">{ingredientAvailability.currentStock}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">Stock Minimo</Label>
                    <p className="text-2xl font-bold">{ingredientAvailability.minimumStock}</p>
                  </div>
                </div>

                {ingredientAvailability.averageDailyUsage !== undefined && (
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <TrendingDown className="h-5 w-5 text-green-500" />
                      <div className="w-full">
                        <p className="font-medium text-green-800">Consumo Medio Giornaliero</p>
                        <p className="text-2xl font-bold text-green-600">
                          {ingredientAvailability.averageDailyUsage}
                        </p>
                        <div className="text-sm text-green-600 mt-2">
                          <p className="font-medium">Metodo di calcolo:</p>
                          <p>• Somma tutto l'ingrediente utilizzato negli ultimi 30 utilizzi</p>
                          <p>• Calcola i giorni tra primo e ultimo utilizzo registrato</p>
                          <p>• Formula: Totale utilizzato ÷ giorni effettivi</p>
                          <p className="mt-1 text-xs italic">
                            Esempio: 2500 vasetti utilizzati in 6 giorni = 401.25 vasetti/giorno
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {ingredientAvailability.daysRemaining !== undefined && (
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-5 w-5 text-blue-500" />
                      <div>
                        <p className="font-medium text-blue-800">Giorni Rimanenti</p>
                        <p className="text-2xl font-bold text-blue-600">
                          {ingredientAvailability.daysRemaining}
                        </p>
                        <p className="text-sm text-blue-600">
                          Basato sul consumo medio effettivo
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                <Button
                  variant="outline"
                  onClick={() => setSelectedIngredient("")}
                  className="w-full"
                >
                  Chiudi Dettagli
                </Button>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                Nessun dato disponibile per questo ingrediente
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Sezione Scorte Basse */}
      {lowStockCount > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-yellow-600">
              <AlertTriangle className="h-5 w-5" />
              <span>Articoli con Scorte Basse</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {lowStockLoading ? (
                <div className="col-span-full text-center py-4">Caricamento...</div>
              ) : (
                lowStockItems.map((item: InventoryItem) => (
                  <div key={item.id} className="p-4 border border-yellow-200 rounded-lg bg-yellow-50">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{item.name}</h4>
                      <Badge className="bg-yellow-500 hover:bg-yellow-600">
                        Scorte Basse
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{item.category}</p>
                    <div className="text-sm">
                      <p>Attuale: <span className="font-medium">{item.currentStock} {item.unit}</span></p>
                      <p>Minimo: <span className="font-medium">{item.minimumStock} {item.unit}</span></p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}