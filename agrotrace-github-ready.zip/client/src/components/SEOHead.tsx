import { useEffect } from 'react';
import { useLocation } from 'wouter';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonical?: string;
  noindex?: boolean;
}

const SEOHead = ({ 
  title = "AgroTrace Pro - Gestione Tracciabilità Agroalimentare",
  description = "Sistema completo per la gestione della tracciabilità agroalimentare con ricette, lotti, inventario e QR code automatici.",
  keywords = "tracciabilità agroalimentare, gestione ricette, lotti produzione, inventario ingredienti",
  canonical,
  noindex = false 
}: SEOHeadProps) => {
  const [location] = useLocation();

  useEffect(() => {
    // Update document title
    document.title = title;

    // Helper function to update or create meta tags
    const updateMetaTag = (attribute: string, value: string, content: string) => {
      let meta = document.querySelector(`meta[${attribute}="${value}"]`) as HTMLMetaElement;
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, value);
        document.head.appendChild(meta);
      }
      meta.content = content;
    };

    // Update meta description
    updateMetaTag('name', 'description', description);
    
    // Update meta keywords
    updateMetaTag('name', 'keywords', keywords);
    
    // Update Open Graph tags
    updateMetaTag('property', 'og:title', title);
    updateMetaTag('property', 'og:description', description);
    
    // Update Twitter Card tags
    updateMetaTag('name', 'twitter:title', title);
    updateMetaTag('name', 'twitter:description', description);
    
    // Update robots meta
    const robotsContent = noindex ? 'noindex, nofollow' : 'index, follow';
    updateMetaTag('name', 'robots', robotsContent);

    // Update canonical URL
    const canonicalUrl = canonical || `https://agrotracepro.replit.app${location}`;
    let canonicalLink = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.rel = 'canonical';
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.href = canonicalUrl;

    // Update Open Graph URL
    updateMetaTag('property', 'og:url', canonicalUrl);

  }, [title, description, keywords, canonical, noindex, location]);

  return null; // This component doesn't render anything visible
};

export default SEOHead;