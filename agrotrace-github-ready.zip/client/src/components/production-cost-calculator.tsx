import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Calculator, Euro, Package, Zap, Users, Wrench } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";

interface PackagingCost {
  containerType: string;
  containerCost: number;
  labelCost?: number;
  closureCost?: number;
  quantity: number;
}

interface OverheadCosts {
  electricityCostPerHour: number;
  machineryDepreciationPerHour: number;
  laborCostPerHour: number;
  facilityRentPerHour?: number;
  otherOverheadPerHour?: number;
}

interface CostCalculatorProps {
  recipeId?: number;
  ingredients: Array<{
    name: string;
    quantity: number;
    unit: string;
    cost?: number;
  }>;
  preparationTime: number; // in minutes
  yield: number; // number of units produced
  onCostCalculated: (totalCost: number, breakdown: any) => void;
}

const ProductionCostCalculator: React.FC<CostCalculatorProps> = ({
  recipeId,
  ingredients,
  preparationTime,
  yield: recipeYield,
  onCostCalculated,
}) => {
  const [packagingCosts, setPackagingCosts] = useState<PackagingCost[]>([
    { containerType: "Vasetto vetro 212ml", containerCost: 0.35, labelCost: 0.05, closureCost: 0.08, quantity: 1 }
  ]);

  // Recupera prezzi dall'inventario per ingredienti senza costo
  const { data: inventory = [] } = useQuery({
    queryKey: ["/api/inventory"]
  });
  
  const [overheadCosts, setOverheadCosts] = useState<OverheadCosts>({
    electricityCostPerHour: 0.25,
    machineryDepreciationPerHour: 2.50,
    laborCostPerHour: 15.00,
    facilityRentPerHour: 1.20,
    otherOverheadPerHour: 0.80
  });

  const [costBreakdown, setCostBreakdown] = useState<any>(null);

  const containerTypes = [
    "Vasetto vetro 212ml",
    "Vasetto vetro 314ml", 
    "Vasetto vetro 580ml",
    "Barattolo latta 400ml",
    "Bottiglia vetro 250ml",
    "Bottiglia vetro 500ml",
    "Busta sottovuoto",
    "Contenitore plastica"
  ];

  const addPackagingCost = () => {
    setPackagingCosts([...packagingCosts, {
      containerType: "Vasetto vetro 212ml",
      containerCost: 0.35,
      labelCost: 0.05,
      closureCost: 0.08,
      quantity: 1
    }]);
  };

  const removePackagingCost = (index: number) => {
    setPackagingCosts(packagingCosts.filter((_, i) => i !== index));
  };

  const updatePackagingCost = (index: number, field: keyof PackagingCost, value: string | number) => {
    const updated = [...packagingCosts];
    updated[index] = { ...updated[index], [field]: value };
    setPackagingCosts(updated);
  };

  const optimizeIngredientCosts = () => {
    // Prezzi di riferimento realistici per ingredienti comuni
    const referencePrices: Record<string, number> = {
      'cipolle': 1.5, // €/kg
      'cipolla': 1.5,
      'olio evo': 10, // €/litro
      'olio extravergine': 10,
      'olio di oliva': 10,
      'zucchero': 1.8, // €/kg
      'zucchero di canna': 2.2,
      'aceto balsamico': 20, // €/litro
      'aceto': 3,
      'pomodori': 2.5, // €/kg
      'aglio': 8, // €/kg
      'basilico': 15, // €/kg
      'sale': 1, // €/kg
      'pepe': 25, // €/kg
      'parmigiano': 35, // €/kg
      'pecorino': 30, // €/kg
    };

    // Suggerisci prezzi ottimizzati
    const suggestions = ingredients.map(ingredient => {
      const name = ingredient.name.toLowerCase();
      let suggestedPrice = ingredient.cost || 0;
      
      // Cerca una corrispondenza nei prezzi di riferimento
      for (const [key, price] of Object.entries(referencePrices)) {
        if (name.includes(key)) {
          suggestedPrice = price;
          break;
        }
      }
      
      return {
        ...ingredient,
        suggestedCost: suggestedPrice,
        currentCost: ingredient.cost || 0
      };
    });

    return suggestions;
  };

  const calculateCosts = () => {
    // 1. Costo ingredienti (convertendo unità correttamente)
    const ingredientsCost = ingredients.reduce((total, ingredient) => {
      let cost = ingredient.cost || 0;
      const quantity = ingredient.quantity || 0;
      const unit = ingredient.unit || 'g';
      
      // Se il costo non è definito nella ricetta, cerca nell'inventario
      if (cost === 0 && Array.isArray(inventory)) {
        const inventoryItem = inventory.find((item: any) => 
          item.name && ingredient.name && (
            item.name.toLowerCase().includes(ingredient.name.toLowerCase()) ||
            ingredient.name.toLowerCase().includes(item.name.toLowerCase())
          )
        );
        if (inventoryItem && inventoryItem.unitCost) {
          cost = inventoryItem.unitCost;
        }
      }
      
      if (cost === 0) return total;
      
      // Calcola il costo assumendo che i prezzi inseriti siano per kg/litro
      let ingredientCost = 0;
      
      if (unit === 'g') {
        // Prezzo per kg, quantità in grammi
        const costPerGram = cost / 1000;
        ingredientCost = costPerGram * quantity;
      } else if (unit === 'kg') {
        // Prezzo per kg, quantità in kg
        ingredientCost = cost * quantity;
      } else if (unit === 'ml') {
        // Prezzo per litro, quantità in ml
        const costPerMl = cost / 1000;
        ingredientCost = costPerMl * quantity;
      } else if (unit === 'L' || unit === 'l') {
        // Prezzo per litro, quantità in litri
        ingredientCost = cost * quantity;
      } else {
        // Unità non riconosciuta, usa il costo direttamente
        ingredientCost = cost * quantity;
      }
      
      const priceSource = ingredient.cost ? 'ricetta' : 'inventario';
      console.log(`${ingredient.name}: ${quantity}${unit} × €${cost}/${unit === 'g' || unit === 'kg' ? 'kg' : 'l'} = €${ingredientCost.toFixed(4)} (da ${priceSource})`);
      return total + ingredientCost;
    }, 0);

    // 2. Costi confezionamento per singola unità
    const packagingCostPerUnit = packagingCosts.reduce((total, pkg) => {
      const containerCost = pkg.containerCost || 0;
      const labelCost = pkg.labelCost || 0;
      const closureCost = pkg.closureCost || 0;
      return total + (containerCost + labelCost + closureCost) * (pkg.quantity || 1);
    }, 0);

    // 3. Tempo di produzione in ore
    const productionTimeHours = preparationTime / 60;

    // 4. Costi generali totali per la produzione
    const totalElectricityCost = overheadCosts.electricityCostPerHour * productionTimeHours;
    const totalMachineryCost = overheadCosts.machineryDepreciationPerHour * productionTimeHours;
    const totalLaborCost = overheadCosts.laborCostPerHour * productionTimeHours;
    const totalFacilityCost = (overheadCosts.facilityRentPerHour || 0) * productionTimeHours;
    const totalOtherOverhead = (overheadCosts.otherOverheadPerHour || 0) * productionTimeHours;

    const totalOverheadCosts = totalElectricityCost + totalMachineryCost + totalLaborCost + totalFacilityCost + totalOtherOverhead;

    // 5. Costi totali per l'intero lotto
    const totalBatchCost = ingredientsCost + totalOverheadCosts + (packagingCostPerUnit * recipeYield);

    // 6. Costo per unità
    const costPerUnit = totalBatchCost / recipeYield;

    const breakdown = {
      ingredientsCost,
      packagingCostPerUnit,
      totalPackagingCost: packagingCostPerUnit * recipeYield,
      overheadCosts: {
        electricity: totalElectricityCost,
        machinery: totalMachineryCost,
        labor: totalLaborCost,
        facility: totalFacilityCost,
        other: totalOtherOverhead,
        total: totalOverheadCosts
      },
      totalBatchCost,
      costPerUnit,
      yield: recipeYield,
      productionTimeHours
    };

    setCostBreakdown(breakdown);
    onCostCalculated(totalBatchCost, breakdown);
  };

  useEffect(() => {
    calculateCosts();
  }, [packagingCosts, overheadCosts, ingredients, preparationTime, recipeYield]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Calcolo Costi di Produzione Completo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Costi Confezionamento */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Package className="h-4 w-4" />
                Costi Confezionamento
              </h3>
              <Button onClick={addPackagingCost} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Aggiungi Contenitore
              </Button>
            </div>
            
            <div className="space-y-4">
              {packagingCosts.map((pkg, index) => (
                <Card key={index} className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div>
                      <Label>Tipo Contenitore</Label>
                      <Select value={pkg.containerType} onValueChange={(value) => updatePackagingCost(index, 'containerType', value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {containerTypes.map((type) => (
                            <SelectItem key={type} value={type}>{type}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label>Costo Contenitore (€)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={pkg.containerCost}
                        onChange={(e) => updatePackagingCost(index, 'containerCost', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    
                    <div>
                      <Label>Costo Etichetta (€)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={pkg.labelCost || 0}
                        onChange={(e) => updatePackagingCost(index, 'labelCost', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    
                    <div>
                      <Label>Costo Chiusura (€)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={pkg.closureCost || 0}
                        onChange={(e) => updatePackagingCost(index, 'closureCost', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    
                    <div className="flex items-end gap-2">
                      <div className="flex-1">
                        <Label>Quantità</Label>
                        <Input
                          type="number"
                          value={pkg.quantity}
                          onChange={(e) => updatePackagingCost(index, 'quantity', parseInt(e.target.value) || 1)}
                        />
                      </div>
                      {packagingCosts.length > 1 && (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => removePackagingCost(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <Separator />

          {/* Costi Generali */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Wrench className="h-4 w-4" />
              Costi Generali (per ora)
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label className="flex items-center gap-2">
                  <Zap className="h-3 w-3" />
                  Elettricità (€/ora)
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  value={overheadCosts.electricityCostPerHour}
                  onChange={(e) => setOverheadCosts({
                    ...overheadCosts,
                    electricityCostPerHour: parseFloat(e.target.value) || 0
                  })}
                />
              </div>
              
              <div>
                <Label className="flex items-center gap-2">
                  <Wrench className="h-3 w-3" />
                  Usura Macchinari (€/ora)
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  value={overheadCosts.machineryDepreciationPerHour}
                  onChange={(e) => setOverheadCosts({
                    ...overheadCosts,
                    machineryDepreciationPerHour: parseFloat(e.target.value) || 0
                  })}
                />
              </div>
              
              <div>
                <Label className="flex items-center gap-2">
                  <Users className="h-3 w-3" />
                  Manodopera (€/ora)
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  value={overheadCosts.laborCostPerHour}
                  onChange={(e) => setOverheadCosts({
                    ...overheadCosts,
                    laborCostPerHour: parseFloat(e.target.value) || 0
                  })}
                />
              </div>
              
              <div>
                <Label>Affitto Locale (€/ora)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={overheadCosts.facilityRentPerHour || 0}
                  onChange={(e) => setOverheadCosts({
                    ...overheadCosts,
                    facilityRentPerHour: parseFloat(e.target.value) || 0
                  })}
                />
              </div>
              
              <div>
                <Label>Altri Costi Generali (€/ora)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={overheadCosts.otherOverheadPerHour || 0}
                  onChange={(e) => setOverheadCosts({
                    ...overheadCosts,
                    otherOverheadPerHour: parseFloat(e.target.value) || 0
                  })}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Riepilogo Costi */}
      {costBreakdown && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Euro className="h-5 w-5" />
              Riepilogo Costi di Produzione
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Dettaglio Costi */}
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Costo Ingredienti:</span>
                  <Badge variant="outline">€ {costBreakdown.ingredientsCost.toFixed(2)}</Badge>
                </div>
                
                <div className="flex justify-between">
                  <span>Confezionamento Totale:</span>
                  <Badge variant="outline">€ {costBreakdown.totalPackagingCost.toFixed(2)}</Badge>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <h4 className="font-medium">Costi Generali ({costBreakdown.productionTimeHours.toFixed(1)}h):</h4>
                  <div className="pl-4 space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>• Elettricità:</span>
                      <span>€ {costBreakdown.overheadCosts.electricity.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Usura Macchinari:</span>
                      <span>€ {costBreakdown.overheadCosts.machinery.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Manodopera:</span>
                      <span>€ {costBreakdown.overheadCosts.labor.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Affitto:</span>
                      <span>€ {costBreakdown.overheadCosts.facility.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Altri:</span>
                      <span>€ {costBreakdown.overheadCosts.other.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="flex justify-between font-medium">
                    <span>Totale Costi Generali:</span>
                    <Badge>€ {costBreakdown.overheadCosts.total.toFixed(2)}</Badge>
                  </div>
                </div>
              </div>

              {/* Totali */}
              <div className="space-y-4">
                <div className="bg-muted p-4 rounded-lg space-y-3">
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Costo Totale Lotto:</span>
                    <Badge className="text-lg">€ {costBreakdown.totalBatchCost.toFixed(2)}</Badge>
                  </div>
                  
                  <div className="flex justify-between">
                    <span>Quantità Prodotta:</span>
                    <span>{costBreakdown.yield} unità</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between text-xl font-bold">
                    <span>Costo per Unità:</span>
                    <Badge variant="default" className="text-xl">
                      € {costBreakdown.costPerUnit.toFixed(2)}
                    </Badge>
                  </div>
                </div>

                {/* Suggerimenti Prezzo */}
                <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Suggerimenti Prezzo di Vendita:</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Margine 30%:</span>
                      <span className="font-medium">€ {(costBreakdown.costPerUnit * 1.3).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Margine 50%:</span>
                      <span className="font-medium">€ {(costBreakdown.costPerUnit * 1.5).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Margine 100%:</span>
                      <span className="font-medium">€ {(costBreakdown.costPerUnit * 2).toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {/* Avviso Costi Elevati e Ottimizzazione */}
                {costBreakdown.costPerUnit > 20 && (
                  <div className="bg-orange-50 dark:bg-orange-950 p-4 rounded-lg border border-orange-200">
                    <h4 className="font-medium text-orange-800 dark:text-orange-200 mb-2">⚠️ Attenzione: Costi Elevati</h4>
                    <p className="text-sm text-orange-700 dark:text-orange-300">
                      Il costo per unità (€{costBreakdown.costPerUnit.toFixed(2)}) sembra elevato. 
                      Verifica i prezzi degli ingredienti inseriti nella ricetta.
                    </p>
                    
                    {/* Suggerimenti di ottimizzazione */}
                    <div className="mt-3">
                      <h5 className="text-sm font-medium text-orange-800 dark:text-orange-200 mb-2">
                        Suggerimenti di ottimizzazione prezzi:
                      </h5>
                      <div className="space-y-2">
                        {optimizeIngredientCosts().map((suggestion, index) => {
                          const currentCost = suggestion.currentCost || 0;
                          const suggestedCost = suggestion.suggestedCost || 0;
                          const savings = currentCost - suggestedCost;
                          
                          if (savings <= 0) return null;
                          
                          return (
                            <div key={index} className="bg-white dark:bg-gray-800 p-2 rounded text-xs">
                              <div className="flex justify-between items-center">
                                <span className="font-medium">{suggestion.name}</span>
                                <div className="text-right">
                                  <div className="text-red-600 line-through">€{currentCost.toFixed(2)}</div>
                                  <div className="text-green-600 font-bold">€{suggestedCost.toFixed(2)}</div>
                                </div>
                              </div>
                              <div className="text-green-600 text-right mt-1">
                                Risparmio: €{(savings * suggestion.quantity).toFixed(2)}
                              </div>
                            </div>
                          );
                        }).filter(Boolean)}
                      </div>
                    </div>
                    
                    <div className="mt-3 text-xs text-orange-600 dark:text-orange-400">
                      <p>Prezzi di riferimento market standard:</p>
                      <div className="grid grid-cols-2 gap-1 mt-1">
                        <div>• Cipolle: €1.5/kg</div>
                        <div>• Olio EVO: €10/litro</div>
                        <div>• Zucchero: €1.8/kg</div>
                        <div>• Aceto bals.: €20/litro</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Analisi Efficienza */}
                <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Analisi Efficienza:</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Incidenza ingredienti:</span>
                      <span className="font-medium">
                        {((costBreakdown.ingredientsCost / costBreakdown.totalBatchCost) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Incidenza confezionamento:</span>
                      <span className="font-medium">
                        {((costBreakdown.totalPackagingCost / costBreakdown.totalBatchCost) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Incidenza costi generali:</span>
                      <span className="font-medium">
                        {((costBreakdown.overheadCosts.total / costBreakdown.totalBatchCost) * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ProductionCostCalculator;