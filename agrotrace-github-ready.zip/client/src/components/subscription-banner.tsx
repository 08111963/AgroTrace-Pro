import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Clock, 
  Crown, 
  AlertTriangle, 
  Zap, 
  X,
  CheckCircle,
  ArrowRight
} from "lucide-react";

interface LicenseStatus {
  isValid: boolean;
  status: 'trial' | 'active' | 'expired' | 'cancelled';
  plan: string;
  daysRemaining?: number;
  trialDaysRemaining?: number;
  features: {
    maxRecipes: number;
    maxBatches: number;
    maxInventoryItems: number;
    hasAdvancedReports: boolean;
    hasQRLabels: boolean;
    hasTraceability: boolean;
    hasBackup: boolean;
    hasAPIAccess: boolean;
  };
  message?: string;
  upgradeRequired?: boolean;
}

interface SubscriptionBannerProps {
  onUpgradeClick?: () => void;
}

export default function SubscriptionBanner({ onUpgradeClick }: SubscriptionBannerProps) {
  const [dismissed, setDismissed] = useState(false);

  const { data: licenseStatus } = useQuery<LicenseStatus>({
    queryKey: ["/api/license/status"],
    refetchInterval: 5 * 60 * 1000, // Aggiorna ogni 5 minuti
    staleTime: 2 * 60 * 1000, // 2 minuti
  });

  // Non mostrare se dismesso
  if (dismissed) {
    return null;
  }

  // Se non ci sono dati sulla licenza, mostra un banner generico per la prova
  if (!licenseStatus) {
    return (
      <Alert className="mb-6 border-l-4 border-l-blue-500 bg-blue-50 dark:bg-blue-950/20">
        <Clock className="h-5 w-5" />
        <AlertDescription className="flex-1">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Badge variant="default" className="capitalize">
                  Prova Gratuita
                </Badge>
                <span className="text-sm font-medium">
                  Piano Gratuito - 7 giorni
                </span>
              </div>
              
              <p className="text-sm mb-3">
                Accedi per vedere il tuo stato della prova gratuita
              </p>
            </div>
            
            <div className="flex gap-2 ml-4">
              <Button 
                onClick={onUpgradeClick}
                variant="default" 
                size="sm"
                className="whitespace-nowrap"
              >
                <Crown className="h-4 w-4 mr-2" />
                Piani Premium
              </Button>
            </div>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  // Non mostrare per utenti con abbonamento attivo senza avvisi
  if (licenseStatus.status === 'active' && !licenseStatus.message) {
    return null;
  }

  const getStatusVariant = () => {
    if (licenseStatus.upgradeRequired) return "destructive";
    if (licenseStatus.status === 'trial') return "default";
    if (licenseStatus.status === 'active') return "secondary";
    return "outline";
  };

  const getStatusIcon = () => {
    if (licenseStatus.upgradeRequired) return AlertTriangle;
    if (licenseStatus.status === 'trial') return Clock;
    if (licenseStatus.status === 'active') return CheckCircle;
    return Crown;
  };

  const StatusIcon = getStatusIcon();

  const getProgressValue = () => {
    if (licenseStatus.status === 'trial' && licenseStatus.trialDaysRemaining) {
      return (licenseStatus.trialDaysRemaining / 7) * 100;
    }
    if (licenseStatus.status === 'active' && licenseStatus.daysRemaining) {
      return Math.min((licenseStatus.daysRemaining / 30) * 100, 100);
    }
    return 0;
  };

  const getProgressColor = () => {
    const progress = getProgressValue();
    if (progress < 20) return "bg-red-500";
    if (progress < 50) return "bg-orange-500";
    return "bg-green-500";
  };

  return (
    <Alert className={`mb-6 border-l-4 ${
      licenseStatus.upgradeRequired 
        ? 'border-l-red-500 bg-red-50 dark:bg-red-950/20' 
        : licenseStatus.status === 'trial'
        ? 'border-l-blue-500 bg-blue-50 dark:bg-blue-950/20'
        : 'border-l-green-500 bg-green-50 dark:bg-green-950/20'
    }`}>
      <StatusIcon className="h-5 w-5" />
      <AlertDescription className="flex-1">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Badge variant={getStatusVariant()} className="capitalize">
                {licenseStatus.status === 'trial' ? 'Prova Gratuita' : 
                 licenseStatus.status === 'active' ? 'Abbonamento Attivo' :
                 licenseStatus.status === 'expired' ? 'Scaduto' : 'Non Attivo'}
              </Badge>
              <span className="text-sm font-medium">
                Piano {licenseStatus.plan === 'free' ? 'Gratuito' : licenseStatus.plan}
              </span>
            </div>
            
            <p className="text-sm mb-3">
              {licenseStatus.message || (
                licenseStatus.status === 'trial' 
                  ? `Prova gratuita - ${licenseStatus.trialDaysRemaining} giorni rimanenti`
                  : `Abbonamento attivo - ${licenseStatus.daysRemaining} giorni rimanenti`
              )}
            </p>

            {/* Barra di progresso per trial e abbonamenti in scadenza */}
            {(licenseStatus.status === 'trial' || 
              (licenseStatus.status === 'active' && licenseStatus.daysRemaining && licenseStatus.daysRemaining <= 30)) && (
              <div className="mb-3">
                <Progress 
                  value={getProgressValue()} 
                  className="h-2"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>
                    {licenseStatus.status === 'trial' ? 'Inizio prova' : 'Ultimo rinnovo'}
                  </span>
                  <span>
                    {licenseStatus.status === 'trial' ? 'Fine prova' : 'Prossimo rinnovo'}
                  </span>
                </div>
              </div>
            )}

            {/* Limiti attuali */}
            <div className="flex gap-4 text-xs text-muted-foreground">
              <span>Ricette: {licenseStatus.features.maxRecipes === -1 ? '∞' : licenseStatus.features.maxRecipes}</span>
              <span>Lotti: {licenseStatus.features.maxBatches === -1 ? '∞' : licenseStatus.features.maxBatches}</span>
              <span>Magazzino: {licenseStatus.features.maxInventoryItems === -1 ? '∞' : licenseStatus.features.maxInventoryItems}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 ml-4">
            {licenseStatus.upgradeRequired || licenseStatus.status === 'trial' ? (
              <Button 
                size="sm" 
                onClick={onUpgradeClick}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Crown className="h-4 w-4 mr-2" />
                {licenseStatus.upgradeRequired ? 'Attiva Piano' : 'Aggiorna'}
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            ) : null}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDismissed(true)}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </AlertDescription>
    </Alert>
  );
}