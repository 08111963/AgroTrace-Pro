import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Crown,
  Check,
  Zap,
  Shield,
  BarChart3,
  QrCode,
  Search,
  Database,
  Clock,
  Gift
} from "lucide-react";

interface SubscriptionPlan {
  id: number;
  name: string;
  displayName: string;
  description: string;
  price: string;
  currency: string;
  billingPeriod: string;
  trialDays: number;
  maxRecipes: number;
  maxBatches: number;
  maxInventoryItems: number;
  maxUsers: number;
  maxStorageGB: number;
  hasAdvancedReports: boolean;
  hasQRLabels: boolean;
  hasTraceability: boolean;
  hasBackup: boolean;
  hasAPIAccess: boolean;
  hasPrioritySupport: boolean;
  isActive: boolean;
}

interface PricingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentPlan?: string;
}

export default function PricingModal({ open, onOpenChange, currentPlan }: PricingModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: plans = [], isLoading } = useQuery<SubscriptionPlan[]>({
    queryKey: ["/api/license/plans"],
    enabled: open,
  });

  const upgradeMutation = useMutation({
    mutationFn: async (planName: string) => {
      return await apiRequest(`/api/license/upgrade`, "POST", { 
        planName,
        paymentMethod: "pending" // Da implementare con sistema di pagamento reale
      });
    },
    onSuccess: () => {
      toast({
        title: "Piano aggiornato",
        description: "Il tuo piano è stato aggiornato con successo!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/license/status"] });
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante l'aggiornamento del piano",
        variant: "destructive",
      });
    },
  });

  const handleUpgrade = (planName: string) => {
    setSelectedPlan(planName);
    upgradeMutation.mutate(planName);
  };

  const getPlanIcon = (planName: string) => {
    switch (planName) {
      case 'free': return Gift;
      case 'basic': return Zap;
      case 'premium': return Crown;
      case 'enterprise': return Shield;
      default: return Crown;
    }
  };

  const getPlanColor = (planName: string) => {
    switch (planName) {
      case 'free': return 'border-gray-200 bg-gray-50';
      case 'basic': return 'border-blue-200 bg-blue-50';
      case 'premium': return 'border-purple-200 bg-purple-50 ring-2 ring-purple-500';
      case 'enterprise': return 'border-orange-200 bg-orange-50';
      default: return 'border-gray-200 bg-gray-50';
    }
  };

  const formatLimit = (value: number) => {
    return value === -1 ? 'Illimitato' : value.toString();
  };

  const isCurrentPlan = (planName: string) => {
    return currentPlan === planName;
  };

  const sortedPlans = plans.sort((a, b) => {
    const order = { free: 0, basic: 1, premium: 2, enterprise: 3 };
    return (order[a.name as keyof typeof order] || 0) - (order[b.name as keyof typeof order] || 0);
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            Scegli il Piano Perfetto per Te
          </DialogTitle>
          <DialogDescription className="text-center text-lg">
            Tutti i piani includono una prova gratuita. Aggiorna o annulla in qualsiasi momento.
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
            {sortedPlans.map((plan) => {
              const PlanIcon = getPlanIcon(plan.name);
              const isPopular = plan.name === 'premium';
              const isCurrentSelected = isCurrentPlan(plan.name);
              
              return (
                <Card 
                  key={plan.id} 
                  className={`relative ${getPlanColor(plan.name)} transition-all hover:shadow-lg ${
                    isPopular ? 'scale-105' : ''
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-purple-600 text-white">
                        Più Popolare
                      </Badge>
                    </div>
                  )}
                  
                  {isCurrentSelected && (
                    <div className="absolute -top-3 right-4">
                      <Badge variant="secondary">
                        Piano Attuale
                      </Badge>
                    </div>
                  )}

                  <CardHeader className="text-center">
                    <div className="flex justify-center mb-2">
                      <PlanIcon className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{plan.displayName}</CardTitle>
                    <div className="text-3xl font-bold">
                      €{plan.price}
                      {plan.name !== 'free' && (
                        <span className="text-sm font-normal text-muted-foreground">
                          /{plan.billingPeriod === 'monthly' ? 'mese' : 'anno'}
                        </span>
                      )}
                    </div>
                    
                    {/* Durata prova gratuita */}
                    <div className="flex items-center justify-center gap-2 mt-2 p-2 bg-green-100 rounded-lg">
                      <Clock className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium text-green-700">
                        {plan.trialDays} giorni di prova gratuita
                      </span>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mt-2">
                      {plan.description}
                    </p>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {/* Limiti del piano */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Ricette</span>
                        <span className="font-medium">{formatLimit(plan.maxRecipes)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Lotti</span>
                        <span className="font-medium">{formatLimit(plan.maxBatches)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Articoli magazzino</span>
                        <span className="font-medium">{formatLimit(plan.maxInventoryItems)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Utenti</span>
                        <span className="font-medium">{formatLimit(plan.maxUsers)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Storage</span>
                        <span className="font-medium">{plan.maxStorageGB} GB</span>
                      </div>
                    </div>

                    <Separator />

                    {/* Funzionalità incluse */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-500" />
                        <span>Dashboard base</span>
                      </div>
                      
                      {plan.hasQRLabels && (
                        <div className="flex items-center gap-2 text-sm">
                          <QrCode className="h-4 w-4 text-green-500" />
                          <span>Etichette QR</span>
                        </div>
                      )}
                      
                      {plan.hasTraceability && (
                        <div className="flex items-center gap-2 text-sm">
                          <Search className="h-4 w-4 text-green-500" />
                          <span>Tracciabilità completa</span>
                        </div>
                      )}
                      
                      {plan.hasAdvancedReports && (
                        <div className="flex items-center gap-2 text-sm">
                          <BarChart3 className="h-4 w-4 text-green-500" />
                          <span>Report avanzati</span>
                        </div>
                      )}
                      
                      {plan.hasBackup && (
                        <div className="flex items-center gap-2 text-sm">
                          <Database className="h-4 w-4 text-green-500" />
                          <span>Backup automatico</span>
                        </div>
                      )}
                      
                      {plan.hasAPIAccess && (
                        <div className="flex items-center gap-2 text-sm">
                          <Zap className="h-4 w-4 text-green-500" />
                          <span>Accesso API</span>
                        </div>
                      )}
                      
                      {plan.hasPrioritySupport && (
                        <div className="flex items-center gap-2 text-sm">
                          <Shield className="h-4 w-4 text-green-500" />
                          <span>Supporto prioritario</span>
                        </div>
                      )}
                    </div>

                    <Button 
                      className="w-full mt-4" 
                      variant={isPopular ? "default" : "outline"}
                      disabled={isCurrentSelected || upgradeMutation.isPending}
                      onClick={() => handleUpgrade(plan.name)}
                    >
                      {upgradeMutation.isPending && selectedPlan === plan.name ? (
                        <div className="flex items-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          Attivazione...
                        </div>
                      ) : isCurrentSelected ? (
                        "Piano Attuale"
                      ) : plan.name === 'free' ? (
                        "Inizia Prova Gratuita"
                      ) : (
                        `Prova ${plan.trialDays} giorni gratis`
                      )}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <div className="text-center">
            <p className="text-sm text-blue-700 font-medium">
              🎯 Tutte le prove gratuite includono accesso completo alle funzionalità del piano
            </p>
            <p className="text-xs text-blue-600 mt-1">
              La fatturazione inizia solo al termine del periodo di prova. Puoi annullare in qualsiasi momento.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}