import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { insertInventorySchema, type InventoryItem, type InsertInventoryItem } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { PieChart as RechartsPieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  Warehouse, 
  AlertTriangle, 
  Package, 
  Euro,
  Filter,
  Save,
  TrendingDown,
  TrendingUp,
  Eye,
  PieChart,
  Download,
  FileText
} from "lucide-react";

type InventoryFormData = z.infer<typeof inventoryFormSchema>;

const inventoryFormSchema = insertInventorySchema.extend({
  currentStock: z.string().min(1, "Scorta corrente richiesta"),
  minimumStock: z.string().min(1, "Scorta minima richiesta"),
  unitCost: z.string().optional(),
  salePrice: z.string().optional(),
  expiryDate: z.string().optional()
});

const ManualProductImport = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedProduct, setSelectedProduct] = useState("");
  const [quantity, setQuantity] = useState("");
  const [open, setOpen] = useState(true);

  const { data: recipes = [] } = useQuery({
    queryKey: ["/api/recipes"],
  });

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/batches"],
  });

  const importMutation = useMutation({
    mutationFn: (data: { productName: string; quantity: string }) => 
      apiRequest("POST", "/api/inventory/import-specific-product", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: `Prodotto ${selectedProduct} importato con successo` });
      setOpen(false);
    },
    onError: () => {
      toast({ title: "Errore nell'importazione del prodotto", variant: "destructive" });
    }
  });

  const availableProducts = [
    ...recipes.map(r => ({ name: r.name, type: 'recipe', salePrice: r.salePrice })),
    ...batches.map(b => ({ name: b.productName, type: 'batch', code: b.code }))
  ];

  const handleImport = () => {
    if (!selectedProduct || !quantity) return;
    importMutation.mutate({ productName: selectedProduct, quantity });
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Importa Prodotto Specifico</DialogTitle>
      </DialogHeader>
      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium">Seleziona Prodotto</label>
          <Select value={selectedProduct} onValueChange={setSelectedProduct}>
            <SelectTrigger>
              <SelectValue placeholder="Scegli prodotto da importare" />
            </SelectTrigger>
            <SelectContent>
              {availableProducts.map((product, index) => (
                <SelectItem key={index} value={product.name}>
                  {product.name} ({product.type === 'recipe' ? 'Ricetta' : 'Lotto'})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-sm font-medium">Quantità</label>
          <Input
            type="number"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            placeholder="Inserisci quantità"
          />
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Annulla
          </Button>
          <Button 
            onClick={handleImport}
            disabled={!selectedProduct || !quantity || importMutation.isPending}
          >
            <Package className="h-4 w-4 mr-2" />
            Importa Prodotto
          </Button>
        </div>
      </div>
    </DialogContent>
  );
};

const InventoryForm = ({ item, onClose }: { item?: InventoryItem; onClose: () => void }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InventoryFormData>({
    resolver: zodResolver(inventoryFormSchema),
    defaultValues: {
      code: item?.code || "",
      name: item?.name || "",
      category: item?.category || "materie_prime",
      currentStock: item?.currentStock || "",
      unit: item?.unit || "kg",
      minimumStock: item?.minimumStock || "",
      unitCost: item?.unitCost || "",
      salePrice: item?.salePrice || "",
      supplier: item?.supplier || "",
      location: item?.location || "",
      expiryDate: item?.expiryDate ? new Date(item.expiryDate).toISOString().split('T')[0] : "",
      status: item?.status || "available"
    }
  });

  // Aggiorna i valori del form quando cambia l'item
  useEffect(() => {
    if (item) {
      form.reset({
        code: item.code || "",
        name: item.name || "",
        category: item.category || "materie_prime",
        currentStock: item.currentStock || "",
        unit: item.unit || "kg",
        minimumStock: item.minimumStock || "",
        unitCost: item.unitCost || "",
        salePrice: item.salePrice || "",
        supplier: item.supplier || "",
        location: item.location || "",
        expiryDate: item.expiryDate ? new Date(item.expiryDate).toISOString().split('T')[0] : "",
        status: item.status || "available"
      });
    }
  }, [item, form]);

  const createMutation = useMutation({
    mutationFn: (data: InsertInventoryItem) => apiRequest("POST", "/api/inventory", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts/active"] });
      toast({ title: "Prodotto aggiunto al magazzino" });
      onClose();
    },
    onError: () => {
      toast({ title: "Errore nell'aggiunta del prodotto", variant: "destructive" });
    }
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertInventoryItem) => apiRequest("PUT", `/api/inventory/${item?.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts/active"] });
      toast({ title: "Prodotto aggiornato" });
      onClose();
    },
    onError: () => {
      toast({ title: "Errore nell'aggiornamento del prodotto", variant: "destructive" });
    }
  });

  const onSubmit = (data: InventoryFormData) => {
    const submitData: InsertInventoryItem = {
      ...data,
      expiryDate: data.expiryDate ? new Date(data.expiryDate) : undefined,
      unitCost: data.unitCost || undefined,
      salePrice: data.salePrice || undefined,
      supplier: data.supplier || undefined,
      location: data.location || undefined
    };

    if (item) {
      updateMutation.mutate(submitData);
    } else {
      createMutation.mutate(submitData);
    }
  };

  return (
    <DialogContent className="max-w-2xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Warehouse className="h-5 w-5" />
          {item ? "Modifica Prodotto" : "Nuovo Prodotto"}
        </DialogTitle>
      </DialogHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Codice Prodotto</FormLabel>
                  <FormControl>
                    <Input placeholder="Codice univoco" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome Prodotto</FormLabel>
                  <FormControl>
                    <Input placeholder="Nome del prodotto" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Categoria</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="materie_prime">Materie Prime</SelectItem>
                    <SelectItem value="prodotti_finiti">Prodotti Finiti</SelectItem>
                    <SelectItem value="imballaggi">Imballaggi</SelectItem>
                    <SelectItem value="ingredienti">Ingredienti</SelectItem>
                    <SelectItem value="conservanti">Conservanti</SelectItem>
                    <SelectItem value="additivi">Additivi</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <FormField
              control={form.control}
              name="currentStock"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Scorta Corrente</FormLabel>
                  <FormControl>
                    <Input placeholder="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="minimumStock"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Scorta Minima</FormLabel>
                  <FormControl>
                    <Input placeholder="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="unit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unità</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="kg">kg</SelectItem>
                      <SelectItem value="g">g</SelectItem>
                      <SelectItem value="L">L</SelectItem>
                      <SelectItem value="ml">ml</SelectItem>
                      <SelectItem value="pz">pz</SelectItem>
                      <SelectItem value="vasetti">vasetti</SelectItem>
                      <SelectItem value="confezioni">confezioni</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="unitCost"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Costo Unitario (€)</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" placeholder="0.00" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="salePrice"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Prezzo Vendita (€)</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" placeholder="0.00" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="supplier"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Fornitore</FormLabel>
                  <FormControl>
                    <Input placeholder="Nome fornitore" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ubicazione</FormLabel>
                  <FormControl>
                    <Input placeholder="Magazzino, scaffale, ecc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="expiryDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Data di Scadenza (opzionale)</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Stato</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="available">Disponibile</SelectItem>
                      <SelectItem value="low_stock">Scorte Basse</SelectItem>
                      <SelectItem value="out_of_stock">Esaurito</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Annulla
            </Button>
            <Button 
              type="submit" 
              disabled={createMutation.isPending || updateMutation.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              {item ? "Aggiorna" : "Aggiungi"} Prodotto
            </Button>
          </div>
        </form>
      </Form>
    </DialogContent>
  );
};

const InventoryManagement = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [selectedItem, setSelectedItem] = useState<InventoryItem | undefined>();
  const [showForm, setShowForm] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showProfitBreakdown, setShowProfitBreakdown] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: inventory = [], isLoading } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const { data: recipes = [] } = useQuery({
    queryKey: ["/api/recipes"],
  });

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/batches"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  // Company profile for PDF header
  const { data: companyProfile } = useQuery({
    queryKey: ["/api/company-profile"]
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/inventory/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Prodotto eliminato dal magazzino" });
    },
    onError: () => {
      toast({ title: "Errore nell'eliminazione del prodotto", variant: "destructive" });
    }
  });

  const importMutation = useMutation({
    mutationFn: (ingredients: any[]) => 
      apiRequest("POST", "/api/inventory/import-ingredients", { ingredients }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ 
        title: `${data.imported} ingredienti importati con successo`,
        description: data.skipped > 0 ? `${data.skipped} già presenti nel magazzino` : undefined
      });
      setShowImportDialog(false);
    },
    onError: () => {
      toast({ title: "Errore nell'importazione degli ingredienti", variant: "destructive" });
    }
  });

  const filteredInventory = inventory.filter((item: InventoryItem) => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.supplier?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !categoryFilter || categoryFilter === "all" || item.category === categoryFilter;
    const matchesStatus = !statusFilter || statusFilter === "all" || item.status === statusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleEdit = (item: InventoryItem) => {
    setSelectedItem(item);
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    deleteMutation.mutate(id);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "available": return "default";
      case "low_stock": return "secondary";
      case "out_of_stock": return "destructive";
      default: return "outline";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "available": return "Disponibile";
      case "low_stock": return "Scorte Basse";
      case "out_of_stock": return "Esaurito";
      default: return status;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "materie_prime": return "Materie Prime";
      case "prodotti_finiti": return "Prodotti Finiti";
      case "imballaggi": return "Imballaggi";
      case "ingredienti": return "Ingredienti";
      case "conservanti": return "Conservanti";
      case "additivi": return "Additivi";
      default: return category;
    }
  };

  const getStockTrend = (current: string, minimum: string) => {
    const currentNum = Number(current);
    const minimumNum = Number(minimum);
    
    if (currentNum <= 0) return "out";
    if (currentNum <= minimumNum) return "low";
    if (currentNum <= minimumNum * 1.5) return "warning";
    return "good";
  };

  // PDF Export Function
  const exportInventoryToPDF = () => {
    const doc = new jsPDF();
    const currentDate = new Date().toLocaleDateString('it-IT');

    // Header Background
    doc.setFillColor(76, 175, 80);
    doc.rect(0, 0, 210, 35, 'F');

    // Company Header
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('REPORT INVENTARIO MAGAZZINO', 20, 18);
    
    doc.setFontSize(11);
    doc.text(`Generato il: ${currentDate}`, 20, 26);
    
    // Reset text color
    doc.setTextColor(0, 0, 0);
    
    if (companyProfile) {
      // Company info box
      doc.setFillColor(248, 249, 250);
      doc.rect(15, 45, 180, 35, 'F');
      doc.setDrawColor(220, 220, 220);
      doc.rect(15, 45, 180, 35, 'S');
      
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(52, 58, 64);
      doc.text((companyProfile as any).ragioneSociale || 'Azienda', 20, 55);
      
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(108, 117, 125);
      let yPos = 62;
      
      if ((companyProfile as any).indirizzo) {
        doc.text(`${(companyProfile as any).indirizzo}`, 20, yPos);
        yPos += 4;
      }
      if ((companyProfile as any).citta && (companyProfile as any).cap) {
        doc.text(`${(companyProfile as any).cap} ${(companyProfile as any).citta}`, 20, yPos);
        yPos += 4;
      }
      
      // Second column for contact info
      let contactY = 62;
      if ((companyProfile as any).partitaIva) {
        doc.text(`P.IVA: ${(companyProfile as any).partitaIva}`, 120, contactY);
        contactY += 4;
      }
      if ((companyProfile as any).telefono) {
        doc.text(`Tel: ${(companyProfile as any).telefono}`, 120, contactY);
        contactY += 4;
      }
      if ((companyProfile as any).emailAziendale) {
        doc.text(`Email: ${(companyProfile as any).emailAziendale}`, 120, contactY);
      }
    }

    // Reset text color for content
    doc.setTextColor(0, 0, 0);

    // Summary Statistics (using backend data for consistency)
    const totalProducts = (stats as any)?.inventoryItems || (inventory as any[]).length;
    const totalValue = (stats as any)?.totalInventoryValue || (inventory as any[]).reduce((sum: number, item: InventoryItem) => 
      sum + (Number(item.currentStock) * Number(item.unitCost || 0)), 0
    );
    const lowStockItems = (stats as any)?.lowStockItems || (inventory as any[]).filter((item: InventoryItem) => 
      Number(item.currentStock) <= Number(item.minimumStock)
    ).length;
    const outOfStockItems = (inventory as any[]).filter((item: InventoryItem) => 
      Number(item.currentStock) === 0
    ).length;

    // Summary Statistics Box
    doc.setFillColor(240, 248, 255);
    doc.rect(15, companyProfile ? 90 : 50, 180, 30, 'F');
    doc.setDrawColor(76, 175, 80);
    doc.setLineWidth(0.5);
    doc.rect(15, companyProfile ? 90 : 50, 180, 30, 'S');

    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(76, 175, 80);
    doc.text('RIEPILOGO INVENTARIO', 20, companyProfile ? 100 : 60);
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(52, 58, 64);
    let summaryY = companyProfile ? 107 : 67;
    
    // Create two columns for stats
    doc.text(`Totale Prodotti: ${totalProducts}`, 20, summaryY);
    doc.text(`Scorte Basse: ${lowStockItems}`, 110, summaryY);
    doc.text(`Prodotti Esauriti: ${outOfStockItems}`, 20, summaryY + 6);
    
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(76, 175, 80);
    doc.text(`Valore Totale: €${totalValue.toLocaleString('it-IT', { 
      minimumFractionDigits: 2, maximumFractionDigits: 2 
    })}`, 110, summaryY + 6);

    // Products Table
    const tableData = (inventory as any[]).map((item: InventoryItem) => [
      item.code,
      item.name,
      getCategoryLabel(item.category),
      `${item.currentStock} ${item.unit}`,
      `${item.minimumStock} ${item.unit}`,
      getStatusLabel(item.status),
      item.salePrice ? `€${Number(item.salePrice).toFixed(2)}` : (item.unitCost ? `€${Number(item.unitCost).toFixed(2)}` : '-'),
      item.salePrice ? `€${(Number(item.currentStock) * Number(item.salePrice)).toFixed(2)}` : (item.unitCost ? `€${(Number(item.currentStock) * Number(item.unitCost)).toFixed(2)}` : '-')
    ]);

    const tableColumns = [
      'Codice',
      'Nome Prodotto',
      'Categoria',
      'Scorta Corrente',
      'Scorta Minima',
      'Stato',
      'Prezzo Vendita',
      'Valore Tot.'
    ];

    // Reset text color for table
    doc.setTextColor(0, 0, 0);

    autoTable(doc, {
      head: [tableColumns],
      body: tableData,
      startY: companyProfile ? 130 : 90,
      styles: {
        fontSize: 8,
        cellPadding: 3,
        halign: 'left',
        lineColor: [220, 220, 220],
        lineWidth: 0.1,
      },
      headStyles: {
        fillColor: [76, 175, 80],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        halign: 'center',
        fontSize: 9,
      },
      alternateRowStyles: {
        fillColor: [248, 249, 250],
      },
      columnStyles: {
        0: { cellWidth: 18, halign: 'center', fontSize: 7 }, // Codice
        1: { cellWidth: 40, halign: 'left', fontSize: 8 }, // Nome
        2: { cellWidth: 22, halign: 'center', fontSize: 7 }, // Categoria
        3: { cellWidth: 20, halign: 'center', fontSize: 7 }, // Scorta Corrente
        4: { cellWidth: 16, halign: 'center', fontSize: 7 }, // Scorta Minima
        5: { cellWidth: 18, halign: 'center', fontSize: 7 }, // Stato
        6: { cellWidth: 20, halign: 'right', fontSize: 8 }, // Prezzo Vendita
        7: { cellWidth: 21, halign: 'right', fontSize: 8, fontStyle: 'bold' }, // Valore Tot.
      },
      margin: { left: 15, right: 15 },
      tableWidth: 'wrap'
    });

    // Add calculation verification section with improved styling
    const finalY = (doc as any).lastAutoTable.finalY + 20;
    
    // Verification section header
    doc.setFillColor(76, 175, 80);
    doc.rect(15, finalY - 5, 180, 12, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('VERIFICA CALCOLI INVENTARIO', 20, finalY + 2);
    
    doc.setTextColor(52, 58, 64);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    let verifyY = finalY + 15;
    
    // Show individual product calculations in a cleaner format
    (inventory as any[]).forEach((item: InventoryItem, index: number) => {
      const price = item.salePrice || item.unitCost;
      if (price && Number(price) > 0) {
        const itemValue = Number(item.currentStock) * Number(price);
        const priceLabel = item.salePrice ? 'Prezzo vendita' : 'Costo unit.';
        
        // Add subtle background for each calculation
        if (index % 2 === 0) {
          doc.setFillColor(248, 249, 250);
          doc.rect(15, verifyY - 3, 180, 8, 'F');
        }
        
        doc.text(`${item.name}: ${item.currentStock} × €${Number(price).toFixed(2)} (${priceLabel}) = €${itemValue.toFixed(2)}`, 20, verifyY);
        verifyY += 8;
        
        // Add new page if needed
        if (verifyY > doc.internal.pageSize.height - 50) {
          doc.addPage();
          verifyY = 30;
        }
      }
    });
    
    // Total verification with highlight box
    doc.setFillColor(240, 248, 255);
    doc.rect(15, verifyY + 5, 180, 15, 'F');
    doc.setDrawColor(76, 175, 80);
    doc.setLineWidth(1);
    doc.rect(15, verifyY + 5, 180, 15, 'S');
    
    doc.setTextColor(76, 175, 80);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text(`TOTALE VERIFICATO: €${totalValue.toLocaleString('it-IT', { 
      minimumFractionDigits: 2, maximumFractionDigits: 2 
    })}`, 20, verifyY + 15);

    // Add professional footer to all pages
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      
      // Footer line
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.5);
      doc.line(15, doc.internal.pageSize.height - 20, 195, doc.internal.pageSize.height - 20);
      
      doc.setTextColor(108, 117, 125);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`Pagina ${i} di ${pageCount}`, doc.internal.pageSize.width - 30, doc.internal.pageSize.height - 12);
      doc.text('AgroTrace Pro - Sistema di Gestione Inventario', 20, doc.internal.pageSize.height - 12);
      doc.text(`Generato il ${currentDate}`, 20, doc.internal.pageSize.height - 6);
    }

    // Save the PDF
    doc.save(`inventario-magazzino-${currentDate.replace(/\//g, '-')}.pdf`);
    
    toast({
      title: "PDF generato con successo",
      description: "Il report dell'inventario è stato scaricato"
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-warning p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <Warehouse className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Gestione Magazzino</h1>
              <p className="text-xl text-white/90">
                Monitora inventario e scorte con alert automatici
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="outline"
              onClick={exportInventoryToPDF}
              className="bg-white/20 backdrop-blur-sm text-white border-white/30 hover:bg-white/30"
            >
              <Download className="h-4 w-4 mr-2" />
              Esporta PDF
            </Button>
            <Button 
              variant="outline"
              onClick={() => setShowImportDialog(true)}
              className="bg-white/20 backdrop-blur-sm text-white border-white/30 hover:bg-white/30"
            >
              <Package className="h-4 w-4 mr-2" />
              Importa da Ricette/Lotti
            </Button>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <div className="flex items-center justify-between">
        <div></div>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            onClick={exportInventoryToPDF}
          >
            <Download className="h-4 w-4 mr-2" />
            Esporta PDF
          </Button>
          <Button 
            variant="outline"
            onClick={() => setShowImportDialog(true)}
          >
            <Package className="h-4 w-4 mr-2" />
            Importa da Ricette/Lotti
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Package className="h-4 w-4 mr-2" />
                Importa Prodotto Specifico
              </Button>
            </DialogTrigger>
            <ManualProductImport />
          </Dialog>
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogTrigger asChild>
              <Button onClick={() => setSelectedItem(undefined)}>
                <Plus className="h-4 w-4 mr-2" />
                Nuovo Prodotto
              </Button>
            </DialogTrigger>
            <InventoryForm 
              item={selectedItem} 
              onClose={() => setShowForm(false)} 
            />
          </Dialog>
        </div>
      </div>

      {/* Statistiche Inventario */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Prodotti Totali</CardTitle>
              <Warehouse className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.inventoryItems}</div>
              <p className="text-xs text-muted-foreground">articoli in magazzino</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Valore Totale Inventario</CardTitle>
              <Euro className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                €{stats.totalInventoryValue?.toLocaleString('it-IT', { 
                  minimumFractionDigits: 0,
                  maximumFractionDigits: 0 
                }) || 0}
              </div>
              <p className="text-xs text-muted-foreground">valore calcolato dal database</p>
            </CardContent>
          </Card>

          <Card 
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => setShowProfitBreakdown(true)}
          >
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Profitto Totale Lotti</CardTitle>
              <div className="flex items-center gap-1">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <Eye className="h-3 w-3 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                €{inventory?.filter((item: InventoryItem) => 
                    item.category === 'prodotti_finiti' && item.profit
                  ).reduce((total: number, item: InventoryItem) => 
                    total + (Number(item.currentStock) * Number(item.profit || 0)), 0
                  ).toLocaleString('it-IT', { 
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0 
                  }) || 0}
              </div>
              <p className="text-xs text-muted-foreground">clicca per vedere dettagli</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Scorte Basse</CardTitle>
              <AlertTriangle className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-500">{stats.lowStockItems}</div>
              <p className="text-xs text-muted-foreground">articoli sotto soglia</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Alert Attivi</CardTitle>
              <AlertTriangle className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500">{stats.activeAlerts}</div>
              <p className="text-xs text-muted-foreground">notifiche da gestire</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Cerca per nome, codice o fornitore..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtra per categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutte le categorie</SelectItem>
                <SelectItem value="materie_prime">Materie Prime</SelectItem>
                <SelectItem value="prodotti_finiti">Prodotti Finiti</SelectItem>
                <SelectItem value="imballaggi">Imballaggi</SelectItem>
                <SelectItem value="ingredienti">Ingredienti</SelectItem>
                <SelectItem value="conservanti">Conservanti</SelectItem>
                <SelectItem value="additivi">Additivi</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtra per stato" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti gli stati</SelectItem>
                <SelectItem value="available">Disponibile</SelectItem>
                <SelectItem value="low_stock">Scorte Basse</SelectItem>
                <SelectItem value="out_of_stock">Esaurito</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Inventory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredInventory.map((item: InventoryItem) => {
          const stockTrend = getStockTrend(item.currentStock, item.minimumStock);
          const stock = Number(item.currentStock);
          // Per i prodotti finiti usa il prezzo di vendita se impostato, altrimenti il costo unitario
          const price = item.category === 'prodotti_finiti' && item.salePrice 
            ? Number(item.salePrice) 
            : Number(item.unitCost || 0);
          const totalValue = stock * price;
          
          return (
            <Card key={item.id} className="card-hover">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{item.name}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">{item.code}</p>
                    <Badge variant="outline" className="mt-2">
                      {getCategoryLabel(item.category)}
                    </Badge>
                  </div>
                  <Badge variant={getStatusBadgeVariant(item.status)}>
                    {getStatusLabel(item.status)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {/* Stock Info */}
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Scorta:</span>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">
                        {item.currentStock} {item.unit}
                      </span>
                      {stockTrend === "low" && <TrendingDown className="h-4 w-4 text-orange-500" />}
                      {stockTrend === "out" && <AlertTriangle className="h-4 w-4 text-red-500" />}
                      {stockTrend === "good" && <TrendingUp className="h-4 w-4 text-green-500" />}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Minimo:</span>
                    <span>{item.minimumStock} {item.unit}</span>
                  </div>

                  {item.unitCost && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Costo/unità:</span>
                      <span>€{Number(item.unitCost).toFixed(2)}</span>
                    </div>
                  )}

                  {item.salePrice && item.category === 'prodotti_finiti' && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Prezzo vendita:</span>
                      <span className="text-green-600 font-medium">€{Number(item.salePrice).toFixed(2)}</span>
                    </div>
                  )}

                  {item.profit && item.category === 'prodotti_finiti' && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Profitto/unità:</span>
                      <span className="text-blue-600 font-medium">€{Number(item.profit).toFixed(2)}</span>
                    </div>
                  )}

                  {item.unitCost && (
                    <div className="flex items-center justify-between text-sm font-medium">
                      <span className="text-muted-foreground">Valore totale:</span>
                      <span className="text-primary">€{totalValue.toFixed(2)}</span>
                    </div>
                  )}

                  {item.supplier && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Fornitore:</span>
                      <span className="text-right truncate">{item.supplier}</span>
                    </div>
                  )}

                  {item.location && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Ubicazione:</span>
                      <span className="text-right truncate">{item.location}</span>
                    </div>
                  )}

                  {item.expiryDate && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Scadenza:</span>
                      <span>{new Date(item.expiryDate).toLocaleDateString('it-IT')}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-4">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleEdit(item)}
                    className="flex-1"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Modifica
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Eliminare il prodotto?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Questa azione non può essere annullata. Il prodotto "{item.name}" 
                          verrà rimosso dal magazzino.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Annulla</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={() => handleDelete(item.id)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Elimina
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredInventory.length === 0 && !isLoading && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Warehouse className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nessun prodotto trovato</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm || categoryFilter || statusFilter
                  ? "Prova a modificare i filtri di ricerca"
                  : "Inizia aggiungendo prodotti al magazzino"
                }
              </p>
              {!searchTerm && !categoryFilter && !statusFilter && (
                <Button onClick={() => setShowForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Aggiungi Primo Prodotto
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Importa Ingredienti da Ricette e Lotti</DialogTitle>
          </DialogHeader>
          <ImportIngredientsForm 
            recipes={recipes}
            batches={batches}
            onImport={(ingredients) => importMutation.mutate(ingredients)}
            isLoading={importMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Profit Breakdown Dialog */}
      <Dialog open={showProfitBreakdown} onOpenChange={setShowProfitBreakdown}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Distribuzione Profitti per Prodotto
            </DialogTitle>
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Grafico Distribuzione</h3>
              <ProfitChart inventory={inventory} />
            </div>

            {/* Details Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Dettagli per Prodotto</h3>
              {inventory?.filter((item: InventoryItem) => 
                item.category === 'prodotti_finiti' && item.profit
              ).map((item: InventoryItem) => {
                const totalProfit = Number(item.currentStock) * Number(item.profit || 0);
                const profitPerUnit = Number(item.profit || 0);
                const stock = Number(item.currentStock);
                
                return (
                  <Card key={item.id}>
                    <CardContent className="pt-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-lg">{item.name}</h4>
                          <div className="grid grid-cols-2 gap-4 mt-2 text-sm text-muted-foreground">
                            <div>
                              <span className="font-medium">Scorte:</span> {stock} {item.unit}
                            </div>
                            <div>
                              <span className="font-medium">Profitto/unità:</span> €{profitPerUnit.toFixed(2)}
                            </div>
                            <div>
                              <span className="font-medium">Prezzo vendita:</span> €{Number(item.salePrice || 0).toFixed(2)}
                            </div>
                            <div>
                              <span className="font-medium">Costo produzione:</span> €{Number(item.unitCost || 0).toFixed(2)}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-green-600">
                            €{totalProfit.toLocaleString('it-IT', { 
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2 
                            })}
                          </div>
                          <div className="text-xs text-muted-foreground">profitto totale</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
              
              <div className="border-t pt-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">Profitto Totale Complessivo:</span>
                  <span className="text-2xl font-bold text-green-600">
                    €{inventory?.filter((item: InventoryItem) => 
                        item.category === 'prodotti_finiti' && item.profit
                      ).reduce((total: number, item: InventoryItem) => 
                        total + (Number(item.currentStock) * Number(item.profit || 0)), 0
                      ).toLocaleString('it-IT', { 
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2 
                      }) || '0.00'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Profit Chart Component
const ProfitChart = ({ inventory }: { inventory: any[] }) => {
  const chartData = inventory?.filter((item: InventoryItem) => 
    item.category === 'prodotti_finiti' && item.profit
  ).map((item: InventoryItem) => {
    const totalProfit = Number(item.currentStock) * Number(item.profit || 0);
    return {
      name: item.name,
      value: totalProfit,
      percentage: 0
    };
  }) || [];

  const totalSum = chartData.reduce((sum: number, item: any) => sum + item.value, 0);
  chartData.forEach((item: any) => {
    item.percentage = totalSum > 0 ? (item.value / totalSum * 100) : 0;
  });

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

  if (chartData.length === 0) {
    return (
      <div className="h-80 flex items-center justify-center text-muted-foreground">
        Nessun dato di profitto disponibile
      </div>
    );
  }

  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <RechartsPieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            outerRadius={100}
            dataKey="value"
            label={({ name, percentage }: any) => `${name}: ${percentage.toFixed(1)}%`}
          >
            {chartData.map((entry: any, index: number) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            formatter={(value: number) => [
              `€${value.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
              'Profitto'
            ]}
          />
          <Legend />
        </RechartsPieChart>
      </ResponsiveContainer>
    </div>
  );
};

// Import Ingredients Form Component
const ImportIngredientsForm = ({ 
  recipes, 
  batches, 
  onImport, 
  isLoading 
}: { 
  recipes: any[];
  batches: any[];
  onImport: (ingredients: any[]) => void;
  isLoading: boolean;
}) => {
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [importType, setImportType] = useState<"recipes" | "batches">("recipes");

  // Estrai tutti gli ingredienti unici dalle ricette selezionate
  const getIngredientsFromRecipes = () => {
    const allIngredients = new Map();
    
    recipes.forEach((recipe: any) => {
      if (selectedItems.has(`recipe-${recipe.id}`) && recipe.ingredients) {
        recipe.ingredients.forEach((ingredient: any) => {
          const key = ingredient.name.toLowerCase();
          if (!allIngredients.has(key)) {
            allIngredients.set(key, {
              name: ingredient.name,
              unit: ingredient.unit,
              category: "ingredienti",
              supplier: ingredient.supplier || null,
              supplierLot: ingredient.supplierLot || null,
              unitCost: ingredient.cost || null,
              currentStock: "0",
              minimumStock: "10",
              status: "out_of_stock",
              location: "Magazzino principale"
            });
          }
        });
      }
    });
    
    return Array.from(allIngredients.values());
  };

  // Estrai prodotti dai lotti - crea articoli di magazzino per prodotti finiti se non esistono
  const getProductsFromBatches = () => {
    const products: any[] = [];
    
    batches.forEach((batch: any) => {
      if (selectedItems.has(`batch-${batch.id}`)) {
        // Trova la ricetta associata per ottenere il prezzo di vendita
        const recipe = recipes.find((r: any) => r.id === batch.recipeId);
        const salePrice = recipe?.salePrice || "5.00"; // Default €5 se non specificato
        
        products.push({
          name: batch.productName,
          unit: batch.unit,
          category: "prodotti_finiti",
          currentStock: batch.quantity || "0",
          minimumStock: "5",
          status: batch.quantity && Number(batch.quantity) > 0 ? "available" : "out_of_stock",
          location: "Magazzino prodotti finiti",
          expiryDate: batch.expiryDate || null,
          batchCode: batch.code,
          notes: `Prodotto del lotto ${batch.code}`,
          unitCost: recipe?.productionCost || "1.52", // Costo di produzione dalla ricetta
          salePrice: salePrice, // Prezzo di vendita dalla ricetta
          code: batch.code // Usa il codice lotto come codice prodotto
        });
      }
    });
    
    return products;
  };

  const handleSelectAll = () => {
    const items = importType === "recipes" ? recipes : batches;
    const prefix = importType === "recipes" ? "recipe" : "batch";
    
    if (selectedItems.size === items.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(items.map(item => `${prefix}-${item.id}`)));
    }
  };

  const handleItemToggle = (id: string) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedItems(newSelected);
  };

  const handleImport = () => {
    const ingredients = importType === "recipes" 
      ? getIngredientsFromRecipes() 
      : getProductsFromBatches();
    
    if (ingredients.length > 0) {
      onImport(ingredients);
    }
  };

  const currentItems = importType === "recipes" ? recipes : batches;
  const selectedCount = Array.from(selectedItems).filter(id => 
    id.startsWith(importType === "recipes" ? "recipe" : "batch")
  ).length;

  return (
    <div className="space-y-6">
      {/* Import Type Selection */}
      <div className="flex gap-4">
        <Button
          variant={importType === "recipes" ? "default" : "outline"}
          onClick={() => {
            setImportType("recipes");
            setSelectedItems(new Set());
          }}
        >
          <Package className="h-4 w-4 mr-2" />
          Da Ricette ({recipes.length})
        </Button>
        <Button
          variant={importType === "batches" ? "default" : "outline"}
          onClick={() => {
            setImportType("batches");
            setSelectedItems(new Set());
          }}
        >
          <Warehouse className="h-4 w-4 mr-2" />
          Prodotti Finiti ({batches.length})
        </Button>
      </div>

      {/* Selection Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSelectAll}
          >
            {selectedCount === currentItems.length ? "Deseleziona Tutti" : "Seleziona Tutti"}
          </Button>
          <span className="text-sm text-muted-foreground">
            {selectedCount} di {currentItems.length} selezionati
          </span>
        </div>
      </div>

      {/* Items List */}
      <div className="max-h-96 overflow-y-auto border rounded-lg">
        {currentItems.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">
            <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Nessun {importType === "recipes" ? "ricetta" : "lotto"} disponibile</p>
          </div>
        ) : (
          <div className="divide-y">
            {currentItems.map((item: any) => {
              const itemId = `${importType === "recipes" ? "recipe" : "batch"}-${item.id}`;
              const isSelected = selectedItems.has(itemId);
              
              return (
                <div
                  key={itemId}
                  className={`p-4 cursor-pointer hover:bg-muted/50 transition-colors ${
                    isSelected ? "bg-muted" : ""
                  }`}
                  onClick={() => handleItemToggle(itemId)}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => handleItemToggle(itemId)}
                      className="rounded"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium">
                          {importType === "recipes" ? item.name : item.productName}
                        </h4>
                        {importType === "batches" && (
                          <Badge variant="outline" className="text-xs">
                            {item.code}
                          </Badge>
                        )}
                      </div>
                      
                      {importType === "recipes" ? (
                        <div className="text-sm text-muted-foreground">
                          <p>{item.category} • {item.ingredients?.length || 0} ingredienti</p>
                          {item.ingredients?.slice(0, 3).map((ing: any, idx: number) => (
                            <span key={idx} className="inline-block mr-2">
                              {ing.name}
                              {idx < Math.min(2, (item.ingredients?.length || 0) - 1) ? "," : ""}
                            </span>
                          ))}
                          {(item.ingredients?.length || 0) > 3 && (
                            <span className="text-muted-foreground">
                              +{(item.ingredients?.length || 0) - 3} altri
                            </span>
                          )}
                        </div>
                      ) : (
                        <div className="text-sm text-muted-foreground">
                          <p>Quantità: {item.quantity} {item.unit}</p>
                          <p>Produzione: {new Date(item.productionDate).toLocaleDateString()}</p>
                          {item.expiryDate && (
                            <p>Scadenza: {new Date(item.expiryDate).toLocaleDateString()}</p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button
          variant="outline"
          onClick={() => setSelectedItems(new Set())}
        >
          Annulla
        </Button>
        <Button
          onClick={handleImport}
          disabled={selectedItems.size === 0 || isLoading}
        >
          {isLoading ? (
            <>Importazione...</>
          ) : (
            <>
              <Package className="h-4 w-4 mr-2" />
              Importa {selectedCount} {importType === "recipes" ? "Ricette" : "Lotti"}
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default InventoryManagement;