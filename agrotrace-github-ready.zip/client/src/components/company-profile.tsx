import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Building2, MapPin, Phone, Mail, FileText, Plus, Trash2 } from "lucide-react";
import type { CompanyProfile } from "@shared/schema";

// Schema per la validazione del form
const companyProfileSchema = z.object({
  ragioneSociale: z.string().min(1, "Ragione sociale richiesta"),
  partitaIva: z.string().optional(),
  codiceFiscale: z.string().optional(),
  indirizzo: z.string().min(1, "Indirizzo richiesto"),
  cap: z.string().optional(),
  citta: z.string().min(1, "Città richiesta"),
  provincia: z.string().optional(),
  paese: z.string().optional(),
  telefono: z.string().optional(),
  cellulare: z.string().optional(),
  emailAziendale: z.string().email("Email non valida").optional().or(z.literal("")),
  sitoweb: z.string().url("URL non valido").optional().or(z.literal("")),
  tipologiaProduzione: z.string().optional(),
  superficieAziendale: z.string().optional(),
  unitaMisuraSuperficie: z.string().optional(),
  formaGiuridica: z.string().optional(),
  dataCostituzione: z.string().optional(),
  codiceAteco: z.string().optional(),
  iban: z.string().optional(),
  banca: z.string().optional(),
  descrizioneAttivita: z.string().optional(),
  note: z.string().optional(),
});

const certificationSchema = z.object({
  tipo: z.string().min(1, "Tipo certificazione richiesto"),
  numero: z.string().min(1, "Numero certificazione richiesto"),
  dataRilascio: z.string().min(1, "Data rilascio richiesta"),
  dataScadenza: z.string().min(1, "Data scadenza richiesta"),
  enteRilascio: z.string().min(1, "Ente rilascio richiesto"),
});

type CompanyProfileFormData = z.infer<typeof companyProfileSchema>;
type CertificationData = z.infer<typeof certificationSchema>;

export default function CompanyProfile() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [certifications, setCertifications] = useState<CertificationData[]>([]);
  const [newCertification, setNewCertification] = useState<CertificationData>({
    tipo: "",
    numero: "",
    dataRilascio: "",
    dataScadenza: "",
    enteRilascio: "",
  });

  // Query per ottenere il profilo aziendale esistente
  const { data: profile, isLoading } = useQuery<CompanyProfile>({
    queryKey: ["/api/company-profile"],
    retry: false,
  });

  const form = useForm<CompanyProfileFormData>({
    resolver: zodResolver(companyProfileSchema),
    defaultValues: {
      ragioneSociale: "",
      partitaIva: "",
      codiceFiscale: "",
      indirizzo: "",
      cap: "",
      citta: "",
      provincia: "",
      paese: "Italia",
      telefono: "",
      cellulare: "",
      emailAziendale: "",
      sitoweb: "",
      tipologiaProduzione: "",
      superficieAziendale: "",
      unitaMisuraSuperficie: "ettari",
      formaGiuridica: "",
      dataCostituzione: "",
      codiceAteco: "",
      iban: "",
      banca: "",
      descrizioneAttivita: "",
      note: "",
    },
  });

  // Popola il form quando i dati del profilo sono caricati
  useEffect(() => {
    if (profile) {
      form.reset({
        ragioneSociale: profile.ragioneSociale || "",
        partitaIva: profile.partitaIva || "",
        codiceFiscale: profile.codiceFiscale || "",
        indirizzo: profile.indirizzo || "",
        cap: profile.cap || "",
        citta: profile.citta || "",
        provincia: profile.provincia || "",
        paese: profile.paese || "Italia",
        telefono: profile.telefono || "",
        cellulare: profile.cellulare || "",
        emailAziendale: profile.emailAziendale || "",
        sitoweb: profile.sitoweb || "",
        tipologiaProduzione: profile.tipologiaProduzione || "",
        superficieAziendale: profile.superficieAziendale?.toString() || "",
        unitaMisuraSuperficie: profile.unitaMisuraSuperficie || "ettari",
        formaGiuridica: profile.formaGiuridica || "",
        dataCostituzione: profile.dataCostituzione ? new Date(profile.dataCostituzione).toISOString().split('T')[0] : "",
        codiceAteco: profile.codiceAteco || "",
        iban: profile.iban || "",
        banca: profile.banca || "",
        descrizioneAttivita: profile.descrizioneAttivita || "",
        note: profile.note || "",
      });

      if (profile.certificazioni && Array.isArray(profile.certificazioni)) {
        setCertifications(profile.certificazioni);
      }
    }
  }, [profile, form]);

  // Mutation per creare/aggiornare il profilo
  const profileMutation = useMutation({
    mutationFn: async (data: CompanyProfileFormData & { certificazioni?: CertificationData[] }) => {
      const method = profile ? "PUT" : "POST";
      
      // Prepara i dati convertendo le date in formato corretto
      const processedData = {
        ...data,
        // Converte la data di costituzione in Date object se presente e non vuota
        dataCostituzione: data.dataCostituzione && data.dataCostituzione.trim() !== '' 
          ? new Date(data.dataCostituzione) 
          : null,
        // Converte i valori di superficie aziendale se presenti
        superficieAziendale: data.superficieAziendale && data.superficieAziendale.trim() !== '' 
          ? parseFloat(data.superficieAziendale) 
          : null,
        // Gestisce le certificazioni
        certificazioni: certifications.length > 0 ? certifications : null
      };
      
      const response = await apiRequest(method, "/api/company-profile", processedData);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Successo",
        description: profile 
          ? "Profilo aziendale aggiornato con successo"
          : "Profilo aziendale creato con successo",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/company-profile"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CompanyProfileFormData) => {
    const formData = {
      ...data,
      certificazioni: certifications.length > 0 ? certifications : undefined,
    };
    profileMutation.mutate(formData);
  };

  const addCertification = () => {
    if (newCertification.tipo && newCertification.numero && 
        newCertification.dataRilascio && newCertification.dataScadenza && 
        newCertification.enteRilascio) {
      setCertifications([...certifications, newCertification]);
      setNewCertification({
        tipo: "",
        numero: "",
        dataRilascio: "",
        dataScadenza: "",
        enteRilascio: "",
      });
    }
  };

  const removeCertification = (index: number) => {
    setCertifications(certifications.filter((_, i) => i !== index));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary mx-auto mb-4"></div>
          <p>Caricamento profilo aziendale...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl gradient-primary p-8 shadow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl shadow-glow">
              <Building2 className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Profilo Aziendale</h1>
              <p className="text-xl text-white/90">
                Gestisci le informazioni aziendali e i dati fiscali
              </p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Informazioni Generali */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Informazioni Generali
              </CardTitle>
              <CardDescription>
                Dati identificativi dell'azienda
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="ragioneSociale"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Ragione Sociale *</FormLabel>
                    <FormControl>
                      <Input placeholder="Es. Azienda Agraria Annessa al Convitto S.r.l." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="partitaIva"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Partita IVA</FormLabel>
                    <FormControl>
                      <Input placeholder="IT01234567890" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="codiceFiscale"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Codice Fiscale</FormLabel>
                    <FormControl>
                      <Input placeholder="01234567890" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="codiceAteco"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Codice ATECO</FormLabel>
                    <FormControl>
                      <Input placeholder="01.11.10" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Campo rimosso perché non presente nel database schema */}
            </CardContent>
          </Card>

          {/* Sede e Contatti */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Sede e Contatti
              </CardTitle>
              <CardDescription>
                Indirizzo e informazioni di contatto
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="indirizzo"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Indirizzo *</FormLabel>
                    <FormControl>
                      <Input placeholder="Via/Piazza, numero civico" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cap"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CAP</FormLabel>
                    <FormControl>
                      <Input placeholder="12345" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="citta"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Città *</FormLabel>
                    <FormControl>
                      <Input placeholder="Nome della città" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="provincia"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Provincia</FormLabel>
                    <FormControl>
                      <Input placeholder="Sigla provincia (es. MI)" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="telefono"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Telefono</FormLabel>
                    <FormControl>
                      <Input placeholder="+39 123 456 7890" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="emailAziendale"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Aziendale</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="info@azienda.it" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cellulare"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cellulare</FormLabel>
                    <FormControl>
                      <Input placeholder="+39 123 456 7890" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sitoweb"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sito Web</FormLabel>
                    <FormControl>
                      <Input placeholder="https://www.azienda.it" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Informazioni Commerciali */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Informazioni Commerciali
              </CardTitle>
              <CardDescription>
                Dati economici e di business
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="tipologiaProduzione"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipologia Produzione</FormLabel>
                    <FormControl>
                      <Input placeholder="biologica, convenzionale, biodinamica" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dataCostituzione"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data Costituzione</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="superficieAziendale"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Superficie Aziendale</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="unitaMisuraSuperficie"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unità di Misura</FormLabel>
                    <FormControl>
                      <Input placeholder="ettari" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="iban"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>IBAN</FormLabel>
                    <FormControl>
                      <Input placeholder="IT60 X054 2811 1010 0000 0123 456" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="banca"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Banca</FormLabel>
                    <FormControl>
                      <Input placeholder="Nome della banca" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="descrizioneAttivita"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Descrizione Attività</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Breve descrizione dell'attività aziendale..."
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Certificazioni */}
          <Card>
            <CardHeader>
              <CardTitle>Certificazioni</CardTitle>
              <CardDescription>
                Certificazioni aziendali (ISO, biologico, qualità, ecc.)
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Lista certificazioni esistenti */}
              {certifications.length > 0 && (
                <div className="space-y-2 mb-4">
                  {certifications.map((cert, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{cert.tipo} - {cert.numero}</p>
                        <p className="text-sm text-muted-foreground">
                          Rilasciato da {cert.enteRilascio} il {cert.dataRilascio}, scade il {cert.dataScadenza}
                        </p>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeCertification(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Separator className="my-4" />
                </div>
              )}

              {/* Form per aggiungere nuova certificazione */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Tipo Certificazione</label>
                  <Input
                    placeholder="Es. ISO 9001, Biologico"
                    value={newCertification.tipo}
                    onChange={(e) => setNewCertification({ ...newCertification, tipo: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Numero</label>
                  <Input
                    placeholder="Numero certificazione"
                    value={newCertification.numero}
                    onChange={(e) => setNewCertification({ ...newCertification, numero: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Data Rilascio</label>
                  <Input
                    type="date"
                    value={newCertification.dataRilascio}
                    onChange={(e) => setNewCertification({ ...newCertification, dataRilascio: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Data Scadenza</label>
                  <Input
                    type="date"
                    value={newCertification.dataScadenza}
                    onChange={(e) => setNewCertification({ ...newCertification, dataScadenza: e.target.value })}
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="text-sm font-medium">Ente Rilascio</label>
                  <Input
                    placeholder="Ente che ha rilasciato la certificazione"
                    value={newCertification.enteRilascio}
                    onChange={(e) => setNewCertification({ ...newCertification, enteRilascio: e.target.value })}
                  />
                </div>
                <div className="md:col-span-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={addCertification}
                    disabled={!newCertification.tipo || !newCertification.numero || 
                             !newCertification.dataRilascio || !newCertification.dataScadenza || 
                             !newCertification.enteRilascio}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Aggiungi Certificazione
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Note */}
          <Card>
            <CardHeader>
              <CardTitle>Note</CardTitle>
              <CardDescription>
                Informazioni aggiuntive
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="note"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="Note aggiuntive..."
                        rows={4}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Bottoni azione */}
          <div className="flex justify-end space-x-4">
            <Button
              type="submit"
              disabled={profileMutation.isPending}
              className="min-w-[120px]"
            >
              {profileMutation.isPending ? (
                <div className="flex items-center">
                  <div className="h-4 w-4 animate-spin rounded-full border-b-2 border-white mr-2"></div>
                  Salvando...
                </div>
              ) : (
                profile ? "Aggiorna Profilo" : "Crea Profilo"
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}