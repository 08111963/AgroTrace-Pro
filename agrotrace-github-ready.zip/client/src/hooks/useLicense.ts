import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface LicenseStatus {
  isValid: boolean;
  status: 'trial' | 'active' | 'expired' | 'cancelled';
  plan: string;
  daysRemaining?: number;
  trialDaysRemaining?: number;
  features: {
    maxRecipes: number;
    maxBatches: number;
    maxInventoryItems: number;
    hasAdvancedReports: boolean;
    hasQRLabels: boolean;
    hasTraceability: boolean;
    hasBackup: boolean;
    hasAPIAccess: boolean;
  };
  message?: string;
  upgradeRequired?: boolean;
}

export function useLicense() {
  const { data: licenseStatus, isLoading } = useQuery<LicenseStatus>({
    queryKey: ["/api/license/status"],
    refetchInterval: 5 * 60 * 1000, // Aggiorna ogni 5 minuti
    staleTime: 2 * 60 * 1000, // 2 minuti
  });

  const hasFeature = (feature: string): boolean => {
    if (!licenseStatus?.isValid) return false;
    
    switch (feature) {
      case 'advanced_reports':
        return licenseStatus.features.hasAdvancedReports;
      case 'qr_labels':
        return licenseStatus.features.hasQRLabels;
      case 'traceability':
        return licenseStatus.features.hasTraceability;
      case 'backup':
        return licenseStatus.features.hasBackup;
      case 'api_access':
        return licenseStatus.features.hasAPIAccess;
      default:
        return true;
    }
  };

  const canCreateResource = (resource: 'recipes' | 'batches' | 'inventory', currentCount: number): boolean => {
    if (!licenseStatus?.isValid) return false;
    
    switch (resource) {
      case 'recipes':
        return licenseStatus.features.maxRecipes === -1 || currentCount < licenseStatus.features.maxRecipes;
      case 'batches':
        return licenseStatus.features.maxBatches === -1 || currentCount < licenseStatus.features.maxBatches;
      case 'inventory':
        return licenseStatus.features.maxInventoryItems === -1 || currentCount < licenseStatus.features.maxInventoryItems;
      default:
        return true;
    }
  };

  const getResourceLimit = (resource: 'recipes' | 'batches' | 'inventory'): number => {
    if (!licenseStatus) return 0;
    
    switch (resource) {
      case 'recipes':
        return licenseStatus.features.maxRecipes;
      case 'batches':
        return licenseStatus.features.maxBatches;
      case 'inventory':
        return licenseStatus.features.maxInventoryItems;
      default:
        return 0;
    }
  };

  const isTrialExpiring = (): boolean => {
    return licenseStatus?.status === 'trial' && (licenseStatus.trialDaysRemaining || 0) <= 3;
  };

  const isSubscriptionExpiring = (): boolean => {
    return licenseStatus?.status === 'active' && (licenseStatus.daysRemaining || 0) <= 7;
  };

  return {
    licenseStatus,
    isLoading,
    hasFeature,
    canCreateResource,
    getResourceLimit,
    isTrialExpiring,
    isSubscriptionExpiring,
    isExpired: licenseStatus?.upgradeRequired || false,
    daysRemaining: licenseStatus?.trialDaysRemaining || licenseStatus?.daysRemaining || 0,
    planName: licenseStatus?.plan || 'free'
  };
}