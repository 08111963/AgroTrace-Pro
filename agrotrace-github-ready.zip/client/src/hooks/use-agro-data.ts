import { useQuery } from "@tanstack/react-query";
import type { Recipe, Batch, InventoryItem, Alert, QRLabel } from "@shared/schema";

// Custom hook for agricultural dashboard data
export const useAgroData = () => {
  const {
    data: recipes,
    isLoading: recipesLoading,
    error: recipesError,
  } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const {
    data: batches,
    isLoading: batchesLoading,
    error: batchesError,
  } = useQuery<Batch[]>({
    queryKey: ["/api/batches"],
    staleTime: 5 * 60 * 1000,
  });

  const {
    data: inventory,
    isLoading: inventoryLoading,
    error: inventoryError,
  } = useQuery<InventoryItem[]>({
    queryKey: ["/api/inventory"],
    staleTime: 5 * 60 * 1000,
  });

  const {
    data: activeAlerts,
    isLoading: alertsLoading,
    error: alertsError,
  } = useQuery<Alert[]>({
    queryKey: ["/api/alerts/active"],
    staleTime: 1 * 60 * 1000, // 1 minute for alerts
  });

  const {
    data: qrLabels,
    isLoading: qrLoading,
    error: qrError,
  } = useQuery<QRLabel[]>({
    queryKey: ["/api/qr-labels"],
    staleTime: 5 * 60 * 1000,
  });

  const {
    data: dashboardStats,
    isLoading: statsLoading,
    error: statsError,
  } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    staleTime: 2 * 60 * 1000, // 2 minutes
  });

  // Computed values
  const activeBatches = batches?.filter(batch => 
    batch.status === 'in_progress' || batch.status === 'planned'
  ) || [];

  const lowStockItems = inventory?.filter(item => 
    item.status === 'low_stock' || item.status === 'out_of_stock'
  ) || [];

  const activeRecipes = recipes?.filter(recipe => 
    recipe.status === 'active'
  ) || [];

  const completedBatches = batches?.filter(batch => 
    batch.status === 'completed'
  ) || [];

  const recentActivities = batches?.slice(0, 5).map(batch => ({
    id: batch.id,
    type: 'batch',
    title: `Lotto ${batch.code}`,
    description: `${batch.productName} - ${batch.status}`,
    timestamp: batch.createdAt,
    status: batch.status,
  })) || [];

  // Production metrics
  const productionMetrics = {
    totalBatches: batches?.length || 0,
    activeBatchesCount: activeBatches.length,
    completedBatchesCount: completedBatches.length,
    productionRate: completedBatches.length > 0 
      ? Math.round((completedBatches.length / (batches?.length || 1)) * 100)
      : 0,
  };

  // Inventory metrics
  const inventoryMetrics = {
    totalItems: inventory?.length || 0,
    lowStockCount: lowStockItems.length,
    totalValue: inventory?.reduce((sum, item) => {
      const value = Number(item.currentStock) * Number(item.unitCost || 0);
      return sum + value;
    }, 0) || 0,
    stockHealth: inventory && inventory.length > 0
      ? Math.round(((inventory.length - lowStockItems.length) / inventory.length) * 100)
      : 100,
  };

  // Quality metrics
  const qualityMetrics = {
    activeAlertsCount: activeAlerts?.length || 0,
    recipeCompliance: activeRecipes.length,
    traceabilityScore: qrLabels?.length || 0,
  };

  return {
    // Raw data
    recipes,
    batches,
    inventory,
    activeAlerts,
    qrLabels,
    dashboardStats,
    
    // Loading states
    isLoading: recipesLoading || batchesLoading || inventoryLoading || alertsLoading || qrLoading || statsLoading,
    
    // Error states
    hasError: recipesError || batchesError || inventoryError || alertsError || qrError || statsError,
    
    // Computed data
    activeBatches,
    lowStockItems,
    activeRecipes,
    completedBatches,
    recentActivities,
    
    // Metrics
    productionMetrics,
    inventoryMetrics,
    qualityMetrics,
  };
};

// Hook for specific recipe operations
export const useRecipeOperations = () => {
  const { data: recipes } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const getRecipeById = (id: number) => {
    return recipes?.find(recipe => recipe.id === id);
  };

  const getRecipesByCategory = (category: string) => {
    return recipes?.filter(recipe => recipe.category === category) || [];
  };

  const getActiveRecipes = () => {
    return recipes?.filter(recipe => recipe.status === 'active') || [];
  };

  const calculateRecipeCost = (recipe: Recipe) => {
    return recipe.ingredients.reduce((total, ingredient) => {
      return total + (ingredient.cost || 0);
    }, 0);
  };

  return {
    recipes,
    getRecipeById,
    getRecipesByCategory,
    getActiveRecipes,
    calculateRecipeCost,
  };
};

// Hook for batch tracking operations
export const useBatchOperations = () => {
  const { data: batches } = useQuery<Batch[]>({
    queryKey: ["/api/batches"],
  });

  const getBatchById = (id: number) => {
    return batches?.find(batch => batch.id === id);
  };

  const getBatchesByStatus = (status: string) => {
    return batches?.filter(batch => batch.status === status) || [];
  };

  const getBatchesByRecipe = (recipeId: number) => {
    return batches?.filter(batch => batch.recipeId === recipeId) || [];
  };

  const isOverdue = (batch: Batch) => {
    if (!batch.expectedEndDate) return false;
    return new Date() > new Date(batch.expectedEndDate) && batch.status !== 'completed';
  };

  const getOverdueBatches = () => {
    return batches?.filter(isOverdue) || [];
  };

  return {
    batches,
    getBatchById,
    getBatchesByStatus,
    getBatchesByRecipe,
    isOverdue,
    getOverdueBatches,
  };
};

// Hook for inventory operations
export const useInventoryOperations = () => {
  const { data: inventory } = useQuery<InventoryItem[]>({
    queryKey: ["/api/inventory"],
  });

  const getItemById = (id: number) => {
    return inventory?.find(item => item.id === id);
  };

  const getItemsByCategory = (category: string) => {
    return inventory?.filter(item => item.category === category) || [];
  };

  const getLowStockItems = () => {
    return inventory?.filter(item => 
      Number(item.currentStock) <= Number(item.minimumStock)
    ) || [];
  };

  const getItemsBySupplier = (supplier: string) => {
    return inventory?.filter(item => item.supplier === supplier) || [];
  };

  const calculateTotalValue = () => {
    return inventory?.reduce((total, item) => {
      const value = Number(item.currentStock) * Number(item.unitCost || 0);
      return total + value;
    }, 0) || 0;
  };

  const getExpiringItems = (daysFromNow: number = 30) => {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + daysFromNow);
    
    return inventory?.filter(item => {
      if (!item.expiryDate) return false;
      return new Date(item.expiryDate) <= futureDate;
    }) || [];
  };

  return {
    inventory,
    getItemById,
    getItemsByCategory,
    getLowStockItems,
    getItemsBySupplier,
    calculateTotalValue,
    getExpiringItems,
  };
};
