import { useEffect } from 'react';
import { useLocation } from 'wouter';

interface SEOConfig {
  title: string;
  description: string;
  canonical?: string;
  keywords?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogType?: string;
  noindex?: boolean;
}

export const useSEO = (config: SEOConfig) => {
  const [location] = useLocation();

  useEffect(() => {
    // Update document title
    document.title = config.title;

    // Get or create meta tags
    const updateMetaTag = (name: string, content: string, property?: boolean) => {
      const attribute = property ? 'property' : 'name';
      let meta = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
      
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, name);
        document.head.appendChild(meta);
      }
      
      meta.content = content;
    };

    // Update canonical link
    const updateCanonical = (url: string) => {
      let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
      
      if (!canonical) {
        canonical = document.createElement('link');
        canonical.rel = 'canonical';
        document.head.appendChild(canonical);
      }
      
      canonical.href = url;
    };

    // Update robots meta
    const updateRobots = (content: string) => {
      updateMetaTag('robots', content);
    };

    // Current URL construction
    const baseUrl = window.location.origin;
    const currentPath = location === '/' ? '' : location;
    const canonicalUrl = config.canonical || `${baseUrl}${currentPath}`;

    // Update all meta tags
    updateMetaTag('description', config.description);
    updateMetaTag('keywords', config.keywords || '');
    updateMetaTag('og:title', config.ogTitle || config.title, true);
    updateMetaTag('og:description', config.ogDescription || config.description, true);
    updateMetaTag('og:type', config.ogType || 'website', true);
    updateMetaTag('og:url', canonicalUrl, true);
    updateCanonical(canonicalUrl);
    
    // Handle indexing
    if (config.noindex) {
      updateRobots('noindex, nofollow');
    } else {
      updateRobots('index, follow');
    }

  }, [config, location]);
};

// SEO configurations for different pages
export const seoConfigs = {
  dashboard: {
    title: 'Dashboard - AgroTrace Pro | Panoramica Gestione Agroalimentare',
    description: 'Dashboard principale di AgroTrace Pro per monitorare ricette, lotti di produzione, inventario e statistiche aziendali in tempo reale.',
    keywords: 'dashboard agroalimentare, monitoraggio produzione, statistiche azienda agricola, gestione lotti'
  },
  
  recipes: {
    title: 'Ricette - AgroTrace Pro | Gestione Ricette Agroalimentari',
    description: 'Crea e gestisci ricette agroalimentari con ingredienti, allergeni, valori nutrizionali e costi di produzione automatici.',
    keywords: 'ricette agroalimentari, ingredienti, allergeni, valori nutrizionali, costi produzione'
  },
  
  batches: {
    title: 'Lotti - AgroTrace Pro | Tracciabilità Lotti di Produzione',
    description: 'Gestione completa dei lotti di produzione con tracciabilità, QR code, scadenze e conformità normative agroalimentari.',
    keywords: 'lotti produzione, tracciabilità, QR code, scadenze, normative agroalimentari'
  },
  
  inventory: {
    title: 'Inventario - AgroTrace Pro | Gestione Magazzino Ingredienti',
    description: 'Sistema automatizzato per la gestione dell\'inventario ingredienti con controllo scorte, fornitori e costi unitari.',
    keywords: 'inventario ingredienti, gestione magazzino, controllo scorte, fornitori'
  },
  
  reports: {
    title: 'Report - AgroTrace Pro | Report e Analisi Tracciabilità',
    description: 'Genera report dettagliati di tracciabilità, analisi nutrizionali e documenti PDF per conformità normative.',
    keywords: 'report tracciabilità, analisi nutrizionali, documenti PDF, conformità normative'
  },
  
  aiRecipes: {
    title: 'Generatore AI - AgroTrace Pro | Ricette con Intelligenza Artificiale',
    description: 'Genera ricette agroalimentari personalizzate con AI, ottimizzando ingredienti, percentuali e valori nutrizionali.',
    keywords: 'generatore ricette AI, intelligenza artificiale, ottimizzazione ingredienti'
  }
};