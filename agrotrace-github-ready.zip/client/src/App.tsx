import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import SEOHead from "@/components/SEOHead";
import Dashboard from "@/pages/dashboard";
import LoginPage from "@/pages/login";
import LandingPage from "@/pages/landing";
import TraceabilityPage from "@/pages/traceability";
import ForgotPassword from "@/pages/forgot-password";
import ResetPassword from "@/pages/reset-password";
import AboutPage from "@/pages/about";
import PrivacyPage from "@/pages/privacy";
import TermsPage from "@/pages/terms";
import ContactPage from "@/pages/contact";
import DocumentationPage from "@/pages/documentation";
import QRExamplePage from "@/pages/qr-example";
import RecipeExamplePage from "@/pages/recipe-example";
import BatchExamplePage from "@/pages/batch-example";
import InventoryExamplePage from "@/pages/inventory-example";
import QuickGuidePage from "@/pages/quick-guide";
import VideoTutorialsPage from "@/pages/video-tutorials";
import FAQPage from "@/pages/faq";
import BackupInfoPage from "@/pages/backup-info";
import APIDocsPage from "@/pages/api-docs";
import BackupPage from "@/pages/backup";
import QualityControlExamplePage from "@/pages/quality-control-example";
import RecipeCalculatorPage from "@/pages/recipe-calculator";
import LicenseActivationPage from "@/pages/license-activation";
import AdminLicenseManagementPage from "@/pages/admin-license-management";
import Sidebar from "@/components/sidebar";
import TopBar from "@/components/topbar";
import { useQuery } from "@tanstack/react-query";
import { initGA } from "./lib/analytics";
import { useAnalytics } from "./hooks/use-analytics";

function Router() {
  // Track page views when routes change
  useAnalytics();
  
  const [location] = useLocation();
  const [activeSection, setActiveSection] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { isAuthenticated, isLoading } = useAuth();

  // SEO configuration based on current route
  const getSEOProps = () => {
    switch (location) {
      case '/dashboard':
        return {
          title: 'Dashboard - AgroTrace Pro | Panoramica Gestione Agroalimentare',
          description: 'Dashboard principale di AgroTrace Pro per monitorare ricette, lotti di produzione, inventario e statistiche aziendali in tempo reale.',
          keywords: 'dashboard agroalimentare, monitoraggio produzione, statistiche azienda agricola, gestione lotti',
          canonical: 'https://agrotracepro.replit.app/dashboard'
        };
      case '/recipes':
        return {
          title: 'Gestione Ricette - AgroTrace Pro | Ricette Agroalimentari',
          description: 'Crea e gestisci ricette agroalimentari con calcolo automatico di ingredienti, valori nutrizionali e costi di produzione.',
          keywords: 'ricette agroalimentari, gestione ricette, ingredienti, valori nutrizionali, calcolo costi',
          canonical: 'https://agrotracepro.replit.app/recipes'
        };
      case '/batches':
        return {
          title: 'Gestione Lotti - AgroTrace Pro | Produzione e Tracciabilità',
          description: 'Gestisci lotti di produzione agroalimentare con tracciabilità completa, QR code e monitoraggio stato produzione.',
          keywords: 'lotti produzione, tracciabilità lotti, QR code lotti, gestione produzione agroalimentare',
          canonical: 'https://agrotracepro.replit.app/batches'
        };
      case '/inventory':
        return {
          title: 'Gestione Inventario - AgroTrace Pro | Magazzino Ingredienti',
          description: 'Sistema completo per la gestione del magazzino e inventario ingredienti con alert automatici e tracking scorte.',
          keywords: 'inventario ingredienti, gestione magazzino, scorte agroalimentari, alert magazzino',
          canonical: 'https://agrotracepro.replit.app/inventory'
        };
      case '/alerts':
        return {
          title: 'Alert Scorte - AgroTrace Pro | Monitoraggio Magazzino',
          description: 'Sistema di allerta automatico per scorte basse, scadenze ingredienti e monitoraggio critico del magazzino.',
          keywords: 'alert scorte, monitoraggio magazzino, scadenze ingredienti, allerte automatiche',
          canonical: 'https://agrotracepro.replit.app/alerts'
        };
      case '/traceability':
        return {
          title: 'Tracciabilità - AgroTrace Pro | Ricerca Lotti e QR Code',
          description: 'Sistema di tracciabilità completa per lotti agroalimentari con QR code, ingredienti e valori nutrizionali.',
          keywords: 'tracciabilità lotti, QR code, ingredienti, valori nutrizionali',
          canonical: 'https://agrotracepro.replit.app/traceability'
        };
      case '/reports':
        return {
          title: 'Reports - AgroTrace Pro | Analisi e Statistiche Produzione',
          description: 'Reports dettagliati su produzione, profitti, utilizzo ingredienti e analisi complete per aziende agroalimentari.',
          keywords: 'reports agroalimentari, analisi produzione, statistiche profitti, reports ingredienti',
          canonical: 'https://agrotracepro.replit.app/reports'
        };
      case '/ai-recipes':
        return {
          title: 'AI Ricette - AgroTrace Pro | Generatore Ricette Intelligente',
          description: 'Generatore AI di ricette agroalimentari con calcolo automatico percentuali ingredienti e ottimizzazione ricette.',
          keywords: 'AI ricette, generatore ricette, intelligenza artificiale cucina, ottimizzazione ricette',
          canonical: 'https://agrotracepro.replit.app/ai-recipes'
        };
      case '/sales':
        return {
          title: 'Gestione Vendite - AgroTrace Pro | Vendite e Inventario',
          description: 'Sistema completo per gestire vendite con aggiornamento automatico di inventario e lotti. Tracciamento clienti e statistiche.',
          keywords: 'gestione vendite, vendite agroalimentari, aggiornamento inventario, tracciamento clienti',
          canonical: 'https://agrotracepro.replit.app/sales'
        };
      case '/profile':
        return {
          title: 'Profilo Aziendale - AgroTrace Pro | Dati Azienda',
          description: 'Gestione profilo aziendale, certificazioni, dati produttivi e informazioni legali per aziende agroalimentari.',
          keywords: 'profilo aziendale, certificazioni agroalimentari, dati azienda, informazioni legali',
          canonical: 'https://agrotracepro.replit.app/profile'
        };
      case '/login':
        return {
          title: 'Accesso - AgroTrace Pro | Login Sistema Tracciabilità',
          description: 'Accedi al sistema AgroTrace Pro per gestire la tracciabilità agroalimentare della tua azienda.',
          keywords: 'login agroalimentare, accesso sistema tracciabilità',
          canonical: 'https://agrotracepro.replit.app/login',
          noindex: true
        };
      case '/about':
        return {
          title: 'Chi Siamo - AgroTrace Pro | Azienda e Missione',
          description: 'Scopri la storia di AgroTrace Pro, la nostra missione per la tracciabilità agroalimentare e i valori che ci guidano.',
          keywords: 'chi siamo, azienda agroalimentare, missione tracciabilità',
          canonical: 'https://agrotracepro.replit.app/about'
        };
      case '/privacy':
        return {
          title: 'Privacy Policy - AgroTrace Pro | Protezione Dati',
          description: 'Informativa sulla privacy di AgroTrace Pro: come proteggiamo i tuoi dati aziendali e rispettiamo il GDPR.',
          keywords: 'privacy policy, protezione dati, GDPR, sicurezza',
          canonical: 'https://agrotracepro.replit.app/privacy'
        };
      case '/terms':
        return {
          title: 'Termini di Servizio - AgroTrace Pro | Condizioni Uso',
          description: 'Termini e condizioni di utilizzo del servizio AgroTrace Pro per la tracciabilità agroalimentare.',
          keywords: 'termini servizio, condizioni uso, contratto software',
          canonical: 'https://agrotracepro.replit.app/terms'
        };
      case '/contact':
        return {
          title: 'Contatti - AgroTrace Pro | Supporto e Assistenza',
          description: 'Contatta il team di AgroTrace Pro per supporto tecnico, informazioni commerciali e assistenza clienti.',
          keywords: 'contatti, supporto tecnico, assistenza clienti',
          canonical: 'https://agrotracepro.replit.app/contact'
        };
      case '/documentation':
        return {
          title: 'Documentazione - AgroTrace Pro | Guide e Tutorial',
          description: 'Guide complete, tutorial e documentazione per utilizzare al meglio AgroTrace Pro nella tua azienda.',
          keywords: 'documentazione, guide, tutorial, manuale utente',
          canonical: 'https://agrotracepro.replit.app/documentation'
        };
      default:
        return {
          title: 'AgroTrace Pro - Gestione Tracciabilità Agroalimentare | Sistema Completo',
          description: 'AgroTrace Pro: piattaforma completa per la gestione della tracciabilità agroalimentare. Ricette, lotti, inventario, QR code e valori nutrizionali automatici.',
          keywords: 'tracciabilità agroalimentare, gestione ricette, lotti produzione, inventario ingredienti, QR code, valori nutrizionali',
          canonical: 'https://agrotracepro.replit.app/'
        };
    }
  };

  // Get active alerts count for topbar (only if authenticated)
  const { data: alerts = [] } = useQuery({
    queryKey: ["/api/alerts/active"],
    enabled: isAuthenticated,
  });

  // Auto-close sidebar on mobile
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Public routes (no authentication required)
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Caricamento...</p>
        </div>
      </div>
    );
  }

  // Routes for non-authenticated users
  if (!isAuthenticated) {
    return (
      <>
        <SEOHead {...getSEOProps()} />
        <Switch>
          <Route path="/login" component={LoginPage} />
          <Route path="/forgot-password" component={ForgotPassword} />
          <Route path="/reset-password" component={ResetPassword} />
          <Route path="/tracciabilita/:batchCode" component={TraceabilityPage} />
          <Route path="/about" component={AboutPage} />
          <Route path="/privacy" component={PrivacyPage} />
          <Route path="/terms" component={TermsPage} />
          <Route path="/contact" component={ContactPage} />
          <Route path="/documentation" component={DocumentationPage} />
          <Route path="/qr-example" component={QRExamplePage} />
          <Route path="/recipe-example" component={RecipeExamplePage} />
          <Route path="/batch-example" component={BatchExamplePage} />
          <Route path="/inventory-example" component={InventoryExamplePage} />
          <Route path="/quick-guide" component={QuickGuidePage} />
          <Route path="/video-tutorials" component={VideoTutorialsPage} />
          <Route path="/faq" component={FAQPage} />
          <Route path="/backup-info" component={BackupInfoPage} />
          <Route path="/api-docs" component={APIDocsPage} />
          <Route path="/quality-control-example" component={QualityControlExamplePage} />
          <Route path="/" component={LandingPage} />
          <Route component={LandingPage} />
        </Switch>
      </>
    );
  }

  // Protected routes (authentication required)
  return (
    <div className="min-h-screen bg-background">
      <SEOHead {...getSEOProps()} />
      <TopBar 
        activeAlerts={Array.isArray(alerts) ? alerts.length : 0} 
        setSidebarOpen={setSidebarOpen}
        setActiveSection={setActiveSection}
      />
      
      <div className="flex pt-16">
        <Sidebar 
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
        
        <main className={`flex-1 transition-all duration-300 ${
          sidebarOpen ? 'ml-64' : 'ml-0'
        } md:ml-64`}>
          <div className="p-6">
            <Switch>
              <Route path="/tracciabilita/:batchCode" component={TraceabilityPage} />
              <Route path="/dashboard" component={() => <Dashboard activeSection="dashboard" setActiveSection={setActiveSection} />} />
              <Route path="/recipes" component={() => <Dashboard activeSection="ricette" setActiveSection={setActiveSection} />} />
              <Route path="/batches" component={() => <Dashboard activeSection="lotti" setActiveSection={setActiveSection} />} />
              <Route path="/inventory" component={() => <Dashboard activeSection="magazzino" setActiveSection={setActiveSection} />} />
              <Route path="/sales" component={() => <Dashboard activeSection="vendite" setActiveSection={setActiveSection} />} />
              <Route path="/alerts" component={() => <Dashboard activeSection="alert" setActiveSection={setActiveSection} />} />
              <Route path="/traceability" component={() => <Dashboard activeSection="tracciabilita" setActiveSection={setActiveSection} />} />
              <Route path="/reports" component={() => <Dashboard activeSection="reports" setActiveSection={setActiveSection} />} />
              <Route path="/ai-recipes" component={() => <Dashboard activeSection="ai-ricette" setActiveSection={setActiveSection} />} />
              <Route path="/recipe-calculator" component={RecipeCalculatorPage} />
              <Route path="/backup" component={BackupPage} />
              <Route path="/license" component={LicenseActivationPage} />
              <Route path="/admin/licenses" component={AdminLicenseManagementPage} />
              <Route path="/profile" component={() => <Dashboard activeSection="profilo-aziendale" setActiveSection={setActiveSection} />} />
              <Route path="/" component={() => <Dashboard activeSection={activeSection} setActiveSection={setActiveSection} />} />
              <Route component={() => <Dashboard activeSection={activeSection} setActiveSection={setActiveSection} />} />
            </Switch>
          </div>
        </main>
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}

function App() {
  // Initialize Google Analytics when app loads
  useEffect(() => {
    // Verify required environment variable is present
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    } else {
      initGA();
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;